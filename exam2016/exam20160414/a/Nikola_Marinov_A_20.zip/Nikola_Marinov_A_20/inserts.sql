use exam;
INSERT INTO Article_19
	(created_on,password,price)
VALUES
	('2016-02-07 13:06:11','Erebus',2.0),
	('2016-02-07 13:06:11','Erebus',2.0),
	('2016-02-07 13:06:11','Erebus',2.0),
	('2016-02-07 13:06:11','Erebus',2.0),
	('2016-02-07 13:06:11','Erebus',2.0);

INSERT INTO Tag
	(hash,name)
VALUES
	('Erebus','Erebus'),
	('Erebus','Erebus'),
	('Erebus','Erebus'),
	('Erebus','Erebus'),
	('Erebus','Erebus');

INSERT INTO Category
	(name,created_by,article_19_id,user_id)
VALUES
	('Erebus','Erebus',1,1),
	('Erebus','Erebus',2,2),
	('Erebus','Erebus',3,3),
	('Erebus','Erebus',4,4),
	('Erebus','Erebus',5,5);

INSERT INTO User
	(gender,twitter,password,tag_id)
VALUES
	('Erebus','Erebus','Erebus',1),
	('Erebus','Erebus','Erebus',2),
	('Erebus','Erebus','Erebus',3),
	('Erebus','Erebus','Erebus',4),
	('Erebus','Erebus','Erebus',5);

