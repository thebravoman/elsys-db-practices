use exam;

select User.id from User inner join Category_user on User.id=Category_user.user_id inner join Category on Category_user.category_id=Category.id
inner join Tag on Category.id=Tag.id;