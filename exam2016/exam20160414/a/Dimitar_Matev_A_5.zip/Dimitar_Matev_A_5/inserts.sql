use exam;
INSERT INTO Category
	(description,created_by)
VALUES
	('Erebus','Erebus'),
	('Erebus','Erebus'),
	('Erebus','Erebus'),
	('Erebus','Erebus'),
	('Erebus','Erebus');

INSERT INTO User
	(age,picture_url,created_on)
VALUES
	(0,'Erebus','10/15/2016 10:06:2 PM'),
	(0,'Erebus','10/15/2016 10:06:2 PM'),
	(0,'Erebus','10/15/2016 10:06:2 PM'),
	(0,'Erebus','10/15/2016 10:06:2 PM'),
	(0,'Erebus','10/15/2016 10:06:2 PM');

INSERT INTO Article_6
	(content,visible,name,category_id,user_id)
VALUES
	('Erebus',TRUE,'Erebus',1,1),
	('Erebus',TRUE,'Erebus',2,2),
	('Erebus',TRUE,'Erebus',3,3),
	('Erebus',TRUE,'Erebus',4,4),
	('Erebus',TRUE,'Erebus',5,5);

INSERT INTO Tag
	(priority,second_priority,category_id)
VALUES
	(0,1.0,1),
	(0,1.0,2),
	(0,1.0,3),
	(0,1.0,4),
	(0,1.0,5);

