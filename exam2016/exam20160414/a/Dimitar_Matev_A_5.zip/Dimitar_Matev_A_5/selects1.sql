use exam;

select Article_6.id from Article_6 inner join User on User.id=Article_6.user_id inner join Tag on Tag.id=User.id where Tag.id = 1;