drop database if exists exam;
create database if not exists exam;
use exam;

create table Article_0 (id int primary key, published_on DATE, price currency, visible BOOLEAN);
create table Category(id int primary key, name VARCHAR (32), created_by text);
create table User(id int primary key, description text, name VARCHAR (6), created_on DATE);
create table Tag (id int primary key, second_priority float, description varchar (16));

alter table User add column Tag_id int, add foreign key (Tag_id) references Tag(id);
alter table Tag add foreign key (id) references Category(id);
alter table Category add foreign key (id) references Article_0(id);