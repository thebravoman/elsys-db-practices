insert into Article_0 (id,published_on,price, visible) values (1,"2016-06-02",2.5,true);
insert into Category (id, name, created_by) values (1,"gosho","2017-02-01");
insert into User (id, description, name, created_on) values (1,"asdf","male","2016-06-12");
insert into Tag (id, second_priority, description) values (1,2.6, "pesho");
insert into Article_0 (id,published_on,price, visible) values (2,"2016-06-22",2.7,false);
insert into Category (id, name, created_by) values (2,"gosho","2017-02-11");
insert into User (id, description, name, created_on) values (2,"asdf","male","2016-06-12");
insert into Tag (id, second_priority, description) values (2,2.1, "pesho");