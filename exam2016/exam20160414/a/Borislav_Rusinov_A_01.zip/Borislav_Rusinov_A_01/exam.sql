-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: 
-- Версия на сървъра: 10.1.9-MariaDB
-- PHP Version: 5.5.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `exam`
--

-- --------------------------------------------------------

--
-- Структура на таблица `article_0`
--

CREATE TABLE `article_0` (
  `id` int(11) NOT NULL,
  `published_on` date DEFAULT NULL,
  `price` decimal(10,0) DEFAULT NULL,
  `visible` tinyint(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Схема на данните от таблица `article_0`
--

INSERT INTO `article_0` (`id`, `published_on`, `price`, `visible`) VALUES
(1, '2016-06-02', '3', 1),
(2, '2016-06-22', '3', 0);

-- --------------------------------------------------------

--
-- Структура на таблица `category`
--

CREATE TABLE `category` (
  `id` int(11) NOT NULL,
  `name` varchar(32) DEFAULT NULL,
  `created_by` text
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Схема на данните от таблица `category`
--

INSERT INTO `category` (`id`, `name`, `created_by`) VALUES
(1, 'gosho', '2017-02-01'),
(2, 'gosho', '2017-02-11');

-- --------------------------------------------------------

--
-- Структура на таблица `tag_part1`
--

CREATE TABLE `tag_part1` (
  `id` int(11) NOT NULL,
  `second_priority` float DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Схема на данните от таблица `tag_part1`
--

INSERT INTO `tag_part1` (`id`, `second_priority`) VALUES
(1, 2.6),
(2, 2.1);

-- --------------------------------------------------------

--
-- Структура на таблица `tag_part2`
--

CREATE TABLE `tag_part2` (
  `id` int(11) NOT NULL,
  `description` varchar(16) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Схема на данните от таблица `tag_part2`
--

INSERT INTO `tag_part2` (`id`, `description`) VALUES
(1, 'pesho'),
(2, 'pesho');

-- --------------------------------------------------------

--
-- Структура на таблица `user`
--

CREATE TABLE `user` (
  `id` int(11) NOT NULL,
  `description` text,
  `name` varchar(6) DEFAULT NULL,
  `created_on` date DEFAULT NULL,
  `Tag_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Схема на данните от таблица `user`
--

INSERT INTO `user` (`id`, `description`, `name`, `created_on`, `Tag_id`) VALUES
(1, 'asdf', 'male', '2016-06-12', NULL),
(2, 'asdf', 'male', '2016-06-12', NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `article_0`
--
ALTER TABLE `article_0`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `category`
--
ALTER TABLE `category`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tag_part1`
--
ALTER TABLE `tag_part1`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tag_part2`
--
ALTER TABLE `tag_part2`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`),
  ADD KEY `Tag_id` (`Tag_id`);

--
-- Ограничения за дъмпнати таблици
--

--
-- Ограничения за таблица `category`
--
ALTER TABLE `category`
  ADD CONSTRAINT `category_ibfk_1` FOREIGN KEY (`id`) REFERENCES `article_0` (`id`);

--
-- Ограничения за таблица `tag_part2`
--
ALTER TABLE `tag_part2`
  ADD CONSTRAINT `tag_part2_ibfk_1` FOREIGN KEY (`id`) REFERENCES `category` (`id`);

--
-- Ограничения за таблица `user`
--
ALTER TABLE `user`
  ADD CONSTRAINT `user_ibfk_1` FOREIGN KEY (`Tag_id`) REFERENCES `tag_part2` (`id`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
