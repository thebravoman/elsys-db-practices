select Article_0.price from Article_0 inner join Category on Article_0.id=Category.id inner join Tag_part2 on Category.id=Tag_part2.id where Tag_part2.id=2;
