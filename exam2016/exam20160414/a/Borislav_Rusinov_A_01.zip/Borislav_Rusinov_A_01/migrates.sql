Create table Tag_part1 (id INT NOT NULL PRIMARY KEY, second_priority float);
INSERT INTO Tag_part1 (id , second_priority)  
SELECT Tag.id, Tag.second_priority
FROM Tag;

RENAME TABLE Tag to Tag_part2;
ALTER TABLE Tag_part2 drop column second_priority;
