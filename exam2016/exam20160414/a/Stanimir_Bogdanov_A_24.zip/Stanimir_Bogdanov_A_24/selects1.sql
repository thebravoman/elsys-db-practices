SELECT Article_23.id FROM Article_23 JOIN Tag
ON Article_23.id = Tag.article_id JOIN User
ON Tag.id = User.tag_id
WHERE User.id = 1;