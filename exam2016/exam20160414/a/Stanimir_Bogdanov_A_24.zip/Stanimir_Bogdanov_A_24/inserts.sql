INSERT INTO Article_23 (created_on, password, visible) VALUES
("2016-04-14 05:08:07", "password1", TRUE),
("2016-04-14 05:08:07", "password2", FALSE);

INSERT INTO Category (created_by, date_created_on, article_id) VALUES
("first creator", "2016-04-14 05:08:07", 1),
("second creator", "2016-04-14 05:08:07", 2);

INSERT INTO User (name, twitter, picture_url, tag_id) VALUES
('name1', "twitter1", "picurl1", 1),
('name2', "twitter2", "picurl2", 2);

INSERT INTO Tag (hash, second_priority, article_id) VALUES
('asdfasdfasdfhash', 3.14, 1),
('asdfasdfasdhash2', 6.28, 2);
