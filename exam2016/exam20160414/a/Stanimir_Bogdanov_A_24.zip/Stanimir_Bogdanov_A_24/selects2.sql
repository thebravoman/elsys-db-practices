SELECT Category.id FROM Category JOIN Article_23
ON Category.article_id = Article_23.id JOIN Tag_part2
ON Tag_part2.article_id = Article_23.id
WHERE Tag_part2.id = 1;