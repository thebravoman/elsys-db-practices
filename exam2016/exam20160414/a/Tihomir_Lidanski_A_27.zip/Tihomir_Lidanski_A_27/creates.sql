drop database if exists exam;
create database exam;
use exam;

create table Article_26 (
	id int primary key auto_increment,
	content longtext,
	price float,
	published_on date
);

create table Category (
	id int primary key auto_increment,
	date_created_on date,
	description longtext
);

create table User (
	id int primary key auto_increment,
	created_on date,
	picture_url varchar(255),
	income float
);

create table Tag (
	id int primary key auto_increment,
	second_priority float,
	priority int
);

alter table Article_26 add column user_id int;
alter table Article_26 add foreign key (user_id) references User(id);
alter table Tag add column article_26_id int;
alter table Tag add foreign key (article_26_id) references Article_26(id);
alter table Tag add column category_id int unique;
alter table Tag add foreign key (category_id) references Category(id);

