use exam;
CREATE TABLE Article_26_part1(id INT(11) PRIMARY KEY NOT NULL AUTO_INCREMENT,published_on date);
CREATE TABLE Article_26_part2(id INT(11) PRIMARY KEY NOT NULL AUTO_INCREMENT,content longtext,price float);
INSERT INTO Article_26_part1(id,published_on) SELECT id,published_on FROM Article_26;
INSERT INTO Article_26_part2(id,content,price) SELECT id,content,price FROM Article_26;
