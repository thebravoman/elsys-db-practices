use exam;
INSERT INTO Category
	(date_created_on,description)
VALUES
	('2016-02-07 13:06:11','Erebus'),
	('2016-02-07 13:06:11','Erebus'),
	('2016-02-07 13:06:11','Erebus'),
	('2016-02-07 13:06:11','Erebus'),
	('2016-02-07 13:06:11','Erebus');

INSERT INTO User
	(created_on,picture_url,income)
VALUES
	('2016-02-07 13:06:11','Erebus',2.0),
	('2016-02-07 13:06:11','Erebus',2.0),
	('2016-02-07 13:06:11','Erebus',2.0),
	('2016-02-07 13:06:11','Erebus',2.0),
	('2016-02-07 13:06:11','Erebus',2.0);

INSERT INTO Article_26
	(content,price,published_on,user_id)
VALUES
	('Erebus',2.0,'2016-02-07 13:06:11',1),
	('Erebus',2.0,'2016-02-07 13:06:11',2),
	('Erebus',2.0,'2016-02-07 13:06:11',3),
	('Erebus',2.0,'2016-02-07 13:06:11',4),
	('Erebus',2.0,'2016-02-07 13:06:11',5);

INSERT INTO Tag
	(second_priority,priority,article_26_id,category_id)
VALUES
	(2.0,1,1,1),
	(2.0,1,2,2),
	(2.0,1,3,3),
	(2.0,1,4,4),
	(2.0,1,5,5);

