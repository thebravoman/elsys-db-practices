CREATE TABLE `exam`.`Tag_part1`(
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `hash` VARCHAR(16) NOT NULL,
  PRIMARY KEY(`id`)
);

CREATE TABLE `exam`.`Tag_part2`(
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `name` VARCHAR(255) NOT NULL,
  PRIMARY KEY(`id`)
);

INSERT INTO Tag_part1 (id, hash) SELECT id, hash FROM Tag;
INSERT INTO Tag_part2 (id, name) SELECT id, name FROM Tag;
