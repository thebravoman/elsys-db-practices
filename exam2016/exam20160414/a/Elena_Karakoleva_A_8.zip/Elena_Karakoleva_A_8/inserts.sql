INSERT INTO `aricle_tag`(`id`, `tag_id`, `article_7_id`) VALUES (1,1,1);
INSERT INTO `aricle_tag`(`id`, `tag_id`, `article_7_id`) VALUES (2,2,2);

INSERT INTO `article_7`(`id`, `content`, `published_on`, `created_on`) VALUES (1,"content1","2016-08-08","2016-08-08");
INSERT INTO `article_7`(`id`, `content`, `published_on`, `created_on`) VALUES (2,"content1","2016-08-06","2016-08-08");

INSERT INTO `category`(`id`, `date_created_on`, `created_by`, `user_id`) VALUES (1,"2015-09-07","user",1);
INSERT INTO `category`(`id`, `date_created_on`, `created_by`, `user_id`) VALUES (2,"2015-09-07","user2",2);

INSERT INTO `tag`(`id`, `hash`, `name`, `category_id`) VALUES (1,"hash1","name1",1);
INSERT INTO `tag`(`id`, `hash`, `name`, `category_id`) VALUES (2,"hash1","name1",2);

INSERT INTO `user`(`id`, `name`, `gender`, `password`) VALUES (1,"user1","gender1","pass");
INSERT INTO `user`(`id`, `name`, `gender`, `password`) VALUES (2,"user2","gender2","pass2");