drop database if exists exam;
create database exam;
use exam;

CREATE TABLE `exam`.`Article_7`(
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `content` LONGTEXT NOT NULL,
  `published_on` DATE NOT NULL,
  `created_on` DATE NOT NULL,
  PRIMARY KEY(`id`)
);

CREATE TABLE `exam`.`Category`(
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `date_created_on` DATE NOT NULL,
  `created_by` VARCHAR(255) NOT NULL,
  PRIMARY KEY(`id`)
);

CREATE TABLE `exam`.`User`(
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `name` VARCHAR(255) NOT NULL,
  `gender` VARCHAR(6) NOT NULL,
  `password` VARCHAR(255) NOT NULL,
  PRIMARY KEY(`id`)
);

CREATE TABLE `exam`.`Tag`(
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `hash` VARCHAR(16) NOT NULL,
  `name` VARCHAR(255) NOT NULL,
  PRIMARY KEY(`id`)
);

CREATE TABLE `exam`.`aricle_tag`(
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `tag_id` INT(111) NOT NULL,
  `article_7_id` INT(11) NOT NULL,
  PRIMARY KEY(`id`)
);

ALTER TABLE `tag` ADD `category_id` INT(11) NOT NULL AFTER `name`;
ALTER TABLE `category` ADD `user_id` INT(11) NOT NULL AFTER `created_by`;