SELECT * FROM `category` as a 
INNER JOIN tag as b ON b.category_id = a.id
INNER JOIN aricle_tag as c ON c.tag_id = a.id
WHERE c.article_7_id = 1;