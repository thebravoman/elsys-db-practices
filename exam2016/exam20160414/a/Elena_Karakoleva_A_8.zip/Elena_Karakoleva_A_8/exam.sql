-- phpMyAdmin SQL Dump
-- version 4.5.0.2
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: 
-- Версия на сървъра: 10.0.17-MariaDB
-- PHP Version: 5.6.14

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `exam`
--

-- --------------------------------------------------------

--
-- Структура на таблица `aricle_tag`
--

CREATE TABLE `aricle_tag` (
  `id` int(11) NOT NULL,
  `tag_id` int(111) NOT NULL,
  `article_7_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Схема на данните от таблица `aricle_tag`
--

INSERT INTO `aricle_tag` (`id`, `tag_id`, `article_7_id`) VALUES
(1, 1, 1),
(2, 2, 2);

-- --------------------------------------------------------

--
-- Структура на таблица `article_7`
--

CREATE TABLE `article_7` (
  `id` int(11) NOT NULL,
  `content` longtext NOT NULL,
  `published_on` date NOT NULL,
  `created_on` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Схема на данните от таблица `article_7`
--

INSERT INTO `article_7` (`id`, `content`, `published_on`, `created_on`) VALUES
(1, 'content1', '2016-08-08', '2016-08-08'),
(2, 'content1', '2016-08-06', '2016-08-08');

-- --------------------------------------------------------

--
-- Структура на таблица `category`
--

CREATE TABLE `category` (
  `id` int(11) NOT NULL,
  `date_created_on` date NOT NULL,
  `created_by` varchar(255) NOT NULL,
  `user_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Схема на данните от таблица `category`
--

INSERT INTO `category` (`id`, `date_created_on`, `created_by`, `user_id`) VALUES
(1, '2015-09-07', 'user', 1),
(2, '2015-09-07', 'user2', 2);

-- --------------------------------------------------------

--
-- Структура на таблица `tag`
--

CREATE TABLE `tag` (
  `id` int(11) NOT NULL,
  `hash` varchar(16) NOT NULL,
  `name` varchar(255) NOT NULL,
  `category_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Схема на данните от таблица `tag`
--

INSERT INTO `tag` (`id`, `hash`, `name`, `category_id`) VALUES
(1, 'hash1', 'name1', 1),
(2, 'hash1', 'name1', 2);

-- --------------------------------------------------------

--
-- Структура на таблица `user`
--

CREATE TABLE `user` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `gender` varchar(6) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Схема на данните от таблица `user`
--

INSERT INTO `user` (`id`, `name`, `gender`, `password`) VALUES
(1, 'user1', 'gender', 'pass'),
(2, 'user2', 'gender', 'pass2');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `aricle_tag`
--
ALTER TABLE `aricle_tag`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `article_7`
--
ALTER TABLE `article_7`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `category`
--
ALTER TABLE `category`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tag`
--
ALTER TABLE `tag`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `aricle_tag`
--
ALTER TABLE `aricle_tag`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `article_7`
--
ALTER TABLE `article_7`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `category`
--
ALTER TABLE `category`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `tag`
--
ALTER TABLE `tag`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
