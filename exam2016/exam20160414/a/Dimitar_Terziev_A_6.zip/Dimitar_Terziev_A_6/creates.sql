/*0.1 Create a database named 'exam'
If there is such a database existing delete it first
Use this database for all the instructions from now on
*/

drop database if exists exam;
create database if not exists exam;
use exam;

/*
1. Create the following tables
{
  "name" "Article_4",
  "fields" {
    "content" "long string",
    "price" "currency",
    "name" "varchar"
  }
}
{
  "name" "Category",
  "fields" {
    "name" "varchar",
    "created_by" "string"
  }
}
{
  "name" "User",
  "fields" {
    "age" "integer",
    "twitter" "varchar",
    "gender" "varchar(6)"
  }
}
{
  "name" "Tag",
  "fields" {
    "second_priority" "float",
    "priority" "int"
  }
}
As a result SQL queries must be created*/

create table Article_4 (
	id int(11) primary key not null auto_increment,
    content varchar(11),
    price int,
    name varchar(11)
);
create table Category (
	id int(11) primary key not null auto_increment,
    name varchar(11),
    created_by varchar(11)
);
create table User (
	id int(11) primary key not null auto_increment,
    age int,
    twitter varchar(11),
    gender varchar(6)
);
create table Tag (
	id int(11) primary key not null auto_increment,
    second_priority float,
    priority int
);

/*2. Connect the tables in the following way
Article_4 has a many to one connection to Category
Category has a one to many connection to User
User has a one to one connection to Tag
As a result SQL queries must be created
Write the queries from point 1 and 2 in a file called creates.sql.
It should be possible to execute this file directly in mysql without errors.*/

alter table Article_4 add column category_id int, add constraint atc_fk foreign key (category_id) references Category(id);
alter table User add column category_id int, add constraint utc_fk foreign key (category_id) references Category(id);
alter table User add column tag_id int, add constraint utt_fk foreign key (tag_id) references Tag(id);