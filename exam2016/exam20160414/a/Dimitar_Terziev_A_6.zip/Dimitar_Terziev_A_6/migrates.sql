/*6. Execute the following migration
Separate Category on two tables
Category_part1 containing created_by
Category_part2 containing all the other fields
As a result SQL queries+code in other programming language must be create.
Write the queries from points 6 in a file called migrates.sql. It should be possible to execute this file directly in mysql without errors.
*/

create table Category_part1(
	id int(11) primary key not null auto_increment,
    name varchar(11)
);

create table Category_part2(
	id int(11) primary key not null auto_increment,
    created_by varchar(11)
);

insert into Category_part1 select id, name from Category;
insert into Category_part2 select id, created_by from Category;

alter table User
	add column category_part1_id int, add foreign key(category_part1_id) references Category_part1(id),
	add column category_part2_id int, add foreign key(category_part2_id) references Category_part2(id)
;

alter table Article_4
	add column category_part1_id int, add foreign key(category_part1_id) references Category_part1(id),
	add column category_part2_id int, add foreign key(category_part2_id) references Category_part2(id)
;

update User set category_part1_id=category_id, category_part2_id=category_id;
update Article_4 set category_part1_id=category_id, category_part2_id=category_id;

alter table User drop foreign key utc_fk;
alter table Article_4 drop foreign key atc_fk;

drop table Category;
