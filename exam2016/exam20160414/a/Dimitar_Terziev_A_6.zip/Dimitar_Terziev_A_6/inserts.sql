INSERT INTO exam.Category (name, created_by) VALUES ("pesho", "gosho");
INSERT INTO exam.Category (name, created_by) VALUES ("gosho", "tosho");

INSERT INTO exam.Tag (second_priority, priority) VALUES (1, 2);
INSERT INTO exam.Tag (second_priority, priority) VALUES (4, 7);

INSERT INTO exam.Article_4 (content, price, name, category_id) VALUES ("cont1", 12, "pesho", 1);
INSERT INTO exam.Article_4 (content, price, name, category_id) VALUES ("cont2", 15, "gosho", 2);

INSERT INTO exam.User (age, twitter, gender, category_id, tag_id) VALUES (12, "twit1", "male", 1, 2);
INSERT INTO exam.User (age, twitter, gender, category_id, tag_id) VALUES (14, "twit2", "female", 2, 1);