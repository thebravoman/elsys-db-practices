/*4. Answer the following question
Which are the User(s) for a given Article_4
As a result SQL query must be created
Write the queries from points 4 in a file called selects1.sql.
It should be possible to execute this file directly in mysql without errors.*/

select User.* from User, Article_4, Category where(
	Article_4.id = 1 and
	Article_4.category_id = Category.id and
	User.category_id = Category.id
);