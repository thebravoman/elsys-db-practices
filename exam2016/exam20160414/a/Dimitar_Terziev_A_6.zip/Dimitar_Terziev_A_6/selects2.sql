/*8. Answer the following question
Which are the Tag(s) for a given Category
As a result SQL query must be created
Write the queries from points 8 in a file called selects2.sql. 
It should be possible to execute this file directly in mysql without errors.*/

select Tag.* from Category_part1, User, Tag where
	Category_part1.id = 1 and
	Category_part1.id = category_part1_id and
	tag_id = Tag.id
;