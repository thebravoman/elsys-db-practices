-- 8. Answer the following question
-- Which are the Tag(s) for a given Category
-- As a result SQL query must be created
-- Write the queries from points 8 in a file called selects2.sql. 
-- It should be possible to execute this file directly in mysql without errors.

use exam;

SELECT Tag.id, Tag.hash, Tag.name FROM Tag
JOIN Article_18 ON Article_18.tag_id = Tag.id
JOIN Category_article_18 ON Category_article_18.article_18_id = Article_18.id
JOIN Category ON Category_article_18.category_id = Category.id
WHERE Category.id = 1;