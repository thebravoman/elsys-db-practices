drop database if exists exam;
create database exam;
use exam;

create table Article_18 (
	id int primary key auto_increment,
	content longtext,
	password varchar(255),
	name varchar(255)
);

create table Category (
	id int primary key auto_increment,
	date_created_on date,
	created_by varchar(255)
);

create table User (
	id int primary key auto_increment,
	created_on date,
	password varchar(255),
	twitter varchar(255)
);

create table Tag (
	id int primary key auto_increment,
	description varchar(255),
	name varchar(255)
);

create table Article_18_Category (
	id int primary key auto_increment,
	article_18_id int not null,
	category_id int not null,
	foreign key (article_18_id) references Article_18(id),
	foreign key (category_id) references Category(id) 
);

alter table User add column category_id int;
alter table User add foreign key (category_id) references Category(id);
create table User_Tag (
	id int primary key auto_increment,
	user_id int not null,
	tag_id int not null,
	foreign key (user_id) references User(id),
	foreign key (tag_id) references Tag(id) 
);

