use exam;
INSERT INTO Article_18
	(content,password,name)
VALUES
	('Erebus','Erebus','Erebus'),
	('Erebus','Erebus','Erebus'),
	('Erebus','Erebus','Erebus'),
	('Erebus','Erebus','Erebus'),
	('Erebus','Erebus','Erebus');

INSERT INTO Category
	(date_created_on,created_by)
VALUES
	('10/15/2016 10:06:0 PM','Erebus'),
	('10/15/2016 10:06:0 PM','Erebus'),
	('10/15/2016 10:06:0 PM','Erebus'),
	('10/15/2016 10:06:0 PM','Erebus'),
	('10/15/2016 10:06:0 PM','Erebus');

INSERT INTO Tag
	(description,name)
VALUES
	('Erebus','Erebus'),
	('Erebus','Erebus'),
	('Erebus','Erebus'),
	('Erebus','Erebus'),
	('Erebus','Erebus');

INSERT INTO User
	(created_on,password,twitter,category_id)
VALUES
	('10/15/2016 10:06:0 PM','Erebus','Erebus',1),
	('10/15/2016 10:06:0 PM','Erebus','Erebus',2),
	('10/15/2016 10:06:0 PM','Erebus','Erebus',3),
	('10/15/2016 10:06:0 PM','Erebus','Erebus',4),
	('10/15/2016 10:06:0 PM','Erebus','Erebus',5);

INSERT INTO Article_18_Category
	(article_18_id,category_id)
VALUES
(1,1),
(2,2),
(3,3),
(4,4),
(5,5);

INSERT INTO User_Tag
	(user_id,tag_id)
VALUES
(1,1),
(2,2),
(3,3),
(4,4),
(5,5);

