import MySQLdb
import sys
import json
from collections import namedtuple
import os

global globalTables
global tableRelations

# SETUP:
# sudo apt-get install mysql-server
# sudo pip install sqlalchemy
# sudo pip install sqlalchemy_schemadisplay
# sudo apt-get install python-pydot
# Ako vi izleze ImportError vupreki gornite otvarqte google i pochvate :D

Files = namedtuple('Files', 'CREATES')
FILES = Files('creates.sql')

Db_Info = namedtuple('Db_Info', 'USER PASS NAME')
DB_INFO = Db_Info(raw_input("Database user: "), raw_input("Database password: "), 'exam')

Sql_Commands = namedtuple(
	'Sql_Commands',
	'DB_INIT TABLE_INIT TABLE_FIELD TABLE_FIELD_NO_COMMA TABLE_EXIT ONE_TO_ONE MANY_TO_MANY MANY_TO_ONE'
)
SQL_COMMANDS = Sql_Commands(
	'drop database if exists {0};\ncreate database {0};\nuse {0};\n\n',
	'create table {} (\n\tid int primary key auto_increment,\n',
	'\t{} {},\n',
	'\t{} {}\n',
	');\n\n',
	'alter table {0} add column {1} int unique;\nalter table {0} add foreign key ({1}) references {2}(id);\n\n',
	'create table {0}_{1} (\n\tid int primary key auto_increment,\n\t{2} int not null,\n\t{3} int not null,\n\tforeign key ({2}) references {0}(id),\n\tforeign key ({3}) references {1}(id) \n);\n\n',
	'alter table {0} add column {2} int;\nalter table {0} add foreign key ({2}) references {1}(id);\n'
)

def generate_creates(exam):
	with open(FILES.CREATES, 'w') as file:
		file.write(SQL_COMMANDS.DB_INIT.format(DB_INFO.NAME))
		
		tables = [
			json.loads(''.join(exam[5:13])),
			json.loads(''.join(exam[13:20])),
			json.loads(''.join(exam[20:28])),
			json.loads(''.join(exam[28:35]))
		]

		#AKO MITOV KAJE DA POLZVAME NEGOVITE TIPOVE GO KOMENTIRAI
		for table in tables:
			for field, ftype in table['fields'].iteritems():
				if ftype == 'string': table['fields'][field] = 'varchar(255)'
				if ftype == 'varchar': table['fields'][field] = 'varchar(255)'
				if ftype == 'long text': table['fields'][field] = 'longtext'
				if ftype == 'currency': table['fields'][field] = 'float'
				if ftype == 'long string': table['fields'][field] = 'longtext'
		#AKO MITOV KAJE DA POLZVAME NEGOVITE TIPOVE GO KOMENTIRAI

		global globalTables
		globalTables = tables

		for table in tables:
			file.write(SQL_COMMANDS.TABLE_INIT.format(table['name']))
			for index, (field, ftype) in enumerate(table['fields'].iteritems()):
				if index == len(table['fields'].keys()) - 1:
					file.write(SQL_COMMANDS.TABLE_FIELD_NO_COMMA.format(field, ftype))
				else:
					file.write(SQL_COMMANDS.TABLE_FIELD.format(field, ftype))

			file.write(SQL_COMMANDS.TABLE_EXIT)

		global tableRelations
		tableRelations = []
		
		for relation in exam[38:41]:
			table1 = relation.split()[0]
			table2 = relation.split()[-1]
			table1_id = table1.lower() + '_id'
			table2_id = table2.lower() + '_id'

			if 'one to one' in relation:
				file.write(SQL_COMMANDS.ONE_TO_ONE.format(table1, table2_id, table2))
				tableRelations.append(table1 + ' ' + table2 + ' one_to_one')
			elif 'many to many' in relation:
				file.write(SQL_COMMANDS.MANY_TO_MANY.format(table1, table2, table1_id, table2_id))
				tableRelations.append(table1 + ' ' + table2 + ' many_to_many')
			elif 'many to one' in relation:
				file.write(SQL_COMMANDS.MANY_TO_ONE.format(table2, table1, table1_id))
				tableRelations.append(table1 + ' ' + table2 + ' many_to_one')
			elif 'one to many' in relation:
				file.write(SQL_COMMANDS.MANY_TO_ONE.format(table1, table2, table2_id))
				tableRelations.append(table1 + ' ' + table2 + ' one_to_many')

def generate_inserts(exam):
	global globalTables
	global tableRelations
	tableInserts = []
	with open('inserts.sql', 'w') as file:
		file.write('use exam;\n')
		for table in globalTables:
				tableFields = []
				fields = ''
				rows = []
				addID = 0
				currentTableInserts = ''
				currentTableInserts += "INSERT INTO " + table['name'] + '\n\t('
				for index, (field, ftype) in enumerate(table['fields'].iteritems()):
					tableFields.append(field)
					row = ''
					if ftype in ['string', 'longtext', 'long string', 'long text']:
						row += "'Erebus',"
					elif 'varchar' in ftype:
						row += "'Erebus',"
					elif ftype in ['float', 'currency']:
						row += str(index) + '.0,'
					elif ftype == 'date':
						row += "'10/15/2016 10:06:{} PM',".format(index)
					elif ftype == 'boolean':
						row += 'TRUE,'
					else:
						row += str(index) + ','
					rows.append(row)
				for field in tableFields:
					fields += field + ','
				for relation in tableRelations:
						table1 = relation.split()[0]
						table2 = relation.split()[1]
						if 'one_to_many' in relation:
							if table1 == table['name']:
								fields += table2.lower() + '_id,'
								if addID >= 1:
									addID = 2
								else:
									addID = 1
						if 'many_to_one' in relation:
							if table2 == table['name']:
								fields += table1.lower() + '_id,'
								if addID >= 1:
									addID = 2
								else:
									addID = 1
						if 'one_to_one' in relation:
							if table1 == table['name']:
								fields += table2.lower() + '_id,'
								if addID >= 1:
									addID = 2
								else:
									addID = 1
				fields = fields[:-1]
				currentTableInserts += fields
				currentTableInserts += ')\nVALUES\n'
				for i in range(0, 5):
					line = '\t('
					for row in rows:
						line += row
					if addID == 1:
						line += str(i+1) + ','
					if addID == 2:
						line += str(i+1) + ',' + str(i+1) + ','
					line = line[:-1]
					if i == 4:
						line += ');\n\n'
					else:
						line += '),\n'
					currentTableInserts += line
				tableInserts.append(currentTableInserts)
		memo = []
		for currentTable in tableInserts:
			if '_id)' in currentTable:
				memo.append(currentTable)
			else:
				file.write(currentTable)

		for currentTable in memo:
			file.write(currentTable)

		for relation in tableRelations:
			table1 = relation.split()[0]
			table2 = relation.split()[1]
			if 'many_to_many' in relation:
				file.write("INSERT INTO " + table1 + '_' + table2 + '\n')
				file.write("\t(" + table1.lower() + '_id,' + table2.lower() + '_id' + ')\n')
				file.write("VALUES\n")
				file.write("(1,1),\n")
				file.write("(2,2),\n")
				file.write("(3,3),\n")
				file.write("(4,4),\n")
				file.write("(5,5);\n\n")
		
def generate_migrates(exam):
	separate_name = exam[58].split()[1]

	part1 = separate_name + '_part1'
	part2 = separate_name + '_part2'

	try:
		part1_var = exam[59].split()[-1]
		for table in globalTables:
			if part1_var in table['fields']:
				part1_vartype = table['fields'][part1_var]
				found_table = table
				break

		separation_1 = ',{} {}'.format(part1_var, part1_vartype)
		separation_2 = ','

		for field, type in found_table['fields'].iteritems():
			if field != part1_var:
				separation_2 += '{} {},'.format(field, type)

		separation_2 = separation_2[:-1]
	except Exception, err:
		print str(err)
		print 'Auto migrate failed, switching to manual'
		print exam[59],
		separation_1 = ',' + raw_input('{}_part1 containing [field], enter the field above and its type (ex. "published_on date"): '.format(separate_name))
		separation_2 = ',' + raw_input('enter all other fields (ex. "name varchar(255)"): ')

	content_1 = ''
	content_2 = ''

	for content in separation_1.split(' '):
		if ',' in content:
			content_1 += ',' +content.split(',')[1]

	for content in separation_2.split(' '):
		if ',' in content:
			content_2 += ',' +content.split(',')[1]

	file_ = open('migrates.sql', 'w')
	file_.write('use exam;\n')
	file_.write('CREATE TABLE ' + part1 + '(id INT(11) PRIMARY KEY NOT NULL AUTO_INCREMENT' + separation_1 +');\n')
	file_.write('CREATE TABLE ' + part2 + '(id INT(11) PRIMARY KEY NOT NULL AUTO_INCREMENT' + separation_2 +');\n')
	file_.write('INSERT INTO ' + part1 + '(id' + content_1 + ') ' + 'SELECT id' + content_1 + ' FROM ' + separate_name + ';\n')
	file_.write('INSERT INTO ' + part2 + '(id' + content_2 + ') ' + 'SELECT id' + content_2 + ' FROM ' + separate_name + ';\n')
	file_.close()

def generate_image():
	try:
		import ConfigParser
		from sqlalchemy import MetaData
		from sqlalchemy_schemadisplay import create_schema_graph

		config = ConfigParser.RawConfigParser()
		config.read('/etc/{0}/{0}.conf'.format(DB_INFO.NAME))

		connection = "mysql://{}:{}@127.0.0.1/{}?charset=utf8".format(DB_INFO.USER, DB_INFO.PASS, DB_INFO.NAME)

		graph = create_schema_graph(metadata=MetaData(connection),
		                 show_datatypes=False,
		                 show_indexes=False,
		                 rankdir='LR',
		                 concentrate=False)
	       
		graph.write_png('db_schema.png')
	except Exception, err:
		print str(err)
		print 'Generating image failed, try something else :/'

def main():
	with open(sys.argv[1]) as exam:
		examread = exam.readlines()

		print '4: You have to make selects1.sql and selects2.sql by hand'
		print '1-2: Creating creates.sql'
		generate_creates(examread)
		os.system("mysql exam -u root -p{} < creates.sql".format(DB_INFO.PASS))
		print '3: Creating inserts.sql'
		generate_inserts(examread)
		os.system("mysql exam -u root -p{} < inserts.sql".format(DB_INFO.PASS))
		print '5: Creating database1.sql'
		os.system("mysqldump -u root -p{} exam > database1.sql".format(DB_INFO.PASS))
		print '6: Creating migrates.sql'
		generate_migrates(examread)
		os.system("mysql exam -u root -p{} < migrates.sql".format(DB_INFO.PASS))
		print '7: Creating database2.sql'
		os.system("mysqldump -u root -p{} exam > database2.sql".format(DB_INFO.PASS))
		print '9: Creating db_schema.png'
		generate_image()

if __name__ == '__main__':
	main()