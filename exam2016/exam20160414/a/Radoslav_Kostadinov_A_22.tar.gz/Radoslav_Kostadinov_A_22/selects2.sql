Select tag.id from tag
inner join article_21 on article_21.id = tag.article_21_id
inner join category_part2 on category_part2.article_21_id = article_21.id
where category_part2.id = 1;