Select article_21.id from article_21
join user
inner join tag on article_21.id = tag.article_21_id
inner join category on category.user_id = user.id
where user.id = 1;