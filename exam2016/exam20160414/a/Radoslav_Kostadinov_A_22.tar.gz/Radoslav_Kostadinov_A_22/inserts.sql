use exam;

insert into Article_21 (url,created_on,name)
values
('Sample',curdate(),'Sample'),
('Sample',curdate(),'Sample'),
('Sample',curdate(),'Sample'),
('Sample',curdate(),'Sample'),
('Sample',curdate(),'Sample');

insert into User (gender,created_on,name)
values
('Sample',curdate(),'Sample'),
('Sample',curdate(),'Sample'),
('Sample',curdate(),'Sample'),
('Sample',curdate(),'Sample'),
('Sample',curdate(),'Sample');

insert into Category (priority,created_by, user_id, article_21_id)
values
(2.0,'Sample', 1, 1),
(2.0,'Sample', 1, 2),
(2.0,'Sample', 1 ,3),
(2.0,'Sample', 1, 4),
(2.0,'Sample', 1 , 5);



insert into Tag (second_priority,priority, article_21_id)
values
(2.0,1,1),
(2.0,1,2),
(2.0,1,3),
(2.0,1,4),
(2.0,1,5);

