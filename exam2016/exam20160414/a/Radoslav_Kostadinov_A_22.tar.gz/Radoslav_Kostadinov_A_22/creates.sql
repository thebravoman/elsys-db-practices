drop database if exists exam;
create database exam;
use exam;

create table Article_21 (
	id int primary key auto_increment,
	url varchar(255),
	created_on date,
	name varchar(255)
) ENGINE=INNODB;

create table Category (
	id int primary key auto_increment,
	priority double,
	created_by varchar(255)
)ENGINE=INNODB;

create table User (
	id int primary key auto_increment,
	gender varchar(6),
	created_on date,
	name varchar(255)
)ENGINE=INNODB;

create table Tag (
	id int primary key auto_increment,
	second_priority float,
	priority int
)ENGINE=INNODB;

alter table Category add column user_id int;
alter table Category add foreign key (user_id) references User(id);
alter table Category add column article_21_id int;
alter table Category add foreign key (article_21_id) references Article_21(id);
alter table Tag add column article_21_id int;
alter table Tag add foreign key (article_21_id) references Article_21(id);
