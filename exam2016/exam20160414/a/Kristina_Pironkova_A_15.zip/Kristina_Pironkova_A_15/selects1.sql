SELECT Tag.id FROM Tag JOIN Category
ON Tag.id = Category.tag_id JOIN User_Category
ON Category.tag_id = User_Category.category_id JOIN User
ON User_Category.user_id = User.id
WHERE User.id = 1;

