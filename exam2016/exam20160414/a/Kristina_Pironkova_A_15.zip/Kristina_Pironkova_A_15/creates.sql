DROP DATABASE IF EXISTS exam;
CREATE DATABASE IF NOT EXISTS exam;
Use exam;

CREATE TABLE `Article_14` ( `id` INT NOT NULL AUTO_INCREMENT , `password` VARCHAR(255) NOT NULL , `created_on` DATE NOT NULL , `content` LONGTEXT NOT NULL , PRIMARY KEY (`id`)) ENGINE = InnoDB;
CREATE TABLE `Category` ( `id` INT NOT NULL AUTO_INCREMENT , `description` LONGTEXT NOT NULL , `date_created_on` DATE NOT NULL , PRIMARY KEY (`id`)) ENGINE = InnoDB;
CREATE TABLE `User` ( `id` INT NOT NULL AUTO_INCREMENT , `created_on` DATE NOT NULL , `picture_url` VARCHAR(255) NOT NULL , `password` VARCHAR(255) NOT NULL , PRIMARY KEY (`id`)) ENGINE = InnoDB;
CREATE TABLE `Tag` ( `id` INT NOT NULL AUTO_INCREMENT , `second_priority` FLOAT NOT NULL , `hash` VARCHAR(16) NOT NULL , PRIMARY KEY (`id`)) ENGINE = InnoDB;

CREATE TABLE `User_Category` ( `id` INT NOT NULL AUTO_INCREMENT , `user_id` INT NOT NULL , `category_id` INT NOT NULL , PRIMARY KEY (`id`)) ENGINE = InnoDB;
ALTER TABLE `category` ADD `tag_id` INT NOT NULL AFTER `date_created_on`, ADD UNIQUE (`tag_id`);
CREATE TABLE `Tag_Article_14` ( `id` INT NOT NULL AUTO_INCREMENT , `tag_id` INT NOT NULL , `article_14_id` INT NOT NULL , PRIMARY KEY (`id`)) ENGINE = InnoDB;
