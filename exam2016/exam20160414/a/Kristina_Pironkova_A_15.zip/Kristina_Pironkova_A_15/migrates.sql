CREATE TABLE `Category_part1` ( `id` INT NOT NULL AUTO_INCREMENT , `description` LONGTEXT NOT NULL , PRIMARY KEY (`id`)) ENGINE = InnoDB;
CREATE TABLE `Category_part2` ( `id` INT NOT NULL AUTO_INCREMENT , `date_created_on` DATE NOT NULL , `tag_id` INT NOT NULL , PRIMARY KEY (`id`)) ENGINE = InnoDB;

INSERT INTO Category_part1 (id, description) SELECT id, description FROM Category;
INSERT INTO Category_part2 (id, date_created_on, tag_id) SELECT id, date_created_on, tag_id FROM Category;
DROP TABLE Category;