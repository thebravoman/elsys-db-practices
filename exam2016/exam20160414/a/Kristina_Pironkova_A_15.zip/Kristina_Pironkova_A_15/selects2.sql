--  Answer the following question
-- Which are the Article_14(s) for a given Category
-- As a result SQL query must be created
-- Write the queries from points 8 in a file called selects2.sql. It should be possible to execute this file directly in mysql without errors.

SELECT Article_14.id FROM Article_14 JOIN Tag_Article_14
ON Article_14.id = Tag_Article_14.article_14_id JOIN Tag
ON Tag.id = Tag_Article_14.tag_id JOIN Category_part2
ON Category_part2.id = Tag.id
WHERE Category_part2.id = 1;
