INSERT INTO `article_14` (`id`, `password`, `created_on`, `content`) VALUES (NULL, 'pass1', '2016-04-06', 'content1');
INSERT INTO `article_14` (`id`, `password`, `created_on`, `content`) VALUES (NULL, 'pass2', '2016-05-06', 'content2');

INSERT INTO `category` (`id`, `description`, `date_created_on`, `tag_id`) VALUES (NULL, 'desc1', '2016-04-27', '1');
INSERT INTO `category` (`id`, `description`, `date_created_on`, `tag_id`) VALUES (NULL, 'desc2', '2016-07-27', '2');

INSERT INTO `tag` (`id`, `second_priority`, `hash`) VALUES (NULL, '25.5', 'hash1');
INSERT INTO `tag` (`id`, `second_priority`, `hash`) VALUES (NULL, '25.7', 'hash2');

INSERT INTO `tag_article_14` (`id`, `tag_id`, `article_14_id`) VALUES (NULL, '1', '1');
INSERT INTO `tag_article_14` (`id`, `tag_id`, `article_14_id`) VALUES (NULL, '2', '2');

INSERT INTO `user` (`id`, `created_on`, `picture_url`, `password`) VALUES (NULL, '2016-04-06', 'url1', 'pass1');
INSERT INTO `user` (`id`, `created_on`, `picture_url`, `password`) VALUES (NULL, '2016-07-06', 'url2', 'pass2');

INSERT INTO `user_category` (`id`, `user_id`, `category_id`) VALUES (NULL, '1', '1');
INSERT INTO `user_category` (`id`, `user_id`, `category_id`) VALUES (NULL, '2', '2');