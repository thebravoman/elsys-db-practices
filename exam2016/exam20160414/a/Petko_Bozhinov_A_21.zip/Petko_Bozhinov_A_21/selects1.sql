select User.user_id
from User
inner join Article_20
on Article_20.user_id = User.user_id
inner join Article_20_Category
on Article_20.article20_id = Article_20_Category.article20_id
where Article_20_Category.category_id = 1;