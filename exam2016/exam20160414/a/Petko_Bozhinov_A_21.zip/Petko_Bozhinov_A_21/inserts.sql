insert into Article_20(article20_id, password, url, visible)
values(1, "hahaha", "123.com", true);

insert into Article_20(article20_id, password, url, visible)
values(2, "ahahah", "321.com", true);

insert into User(user_id, description, gender, article20_id)
values (1, "Dobar den evropa", 513, 1);

insert into User(user_id, description, gender, article20_id)
values (2, "Lele kak she te prebiqt v bopa", 412, 2);

insert into Tag(tag_id, second_priority, priority)
values(1, 2.3, 2);

insert into Tag(tag_id, second_priority, priority)
values(2, 1.3, 1);

insert into Category(category_id, created_by, priority)
values(1, "Pesho ot 9ti blok", 2.0);

insert into Category(category_id, created_by, priority)
values(2, "Ivan Ivanov", 1.0);

insert into Article_20_Category(rel_id, article20_id, category_id)
values (1, 1, 1);

insert into Article_20_Category(rel_id, article20_id, category_id)
values (2, 2, 1);

update Article_20
set user_id = 1
where article20_id=1;

update Article_20
set user_id = 2
where article20_id=2;

update User
set tag_id = 1
where user_id=1;

update User
set tag_id = 1
where user_id=2;