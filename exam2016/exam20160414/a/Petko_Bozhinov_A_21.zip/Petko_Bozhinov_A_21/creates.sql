drop database if exists exam;
create database exam;
use exam;

create table Article_20(
   article20_id int(5) not null primary key,
   password varchar(64) not null,
   url varchar(64) not null,
   visible boolean
);

create table Category(
   category_id int(5) not null primary key,
   created_by varchar(64) not null,
   priority float(5) not null
);

create table User(
   user_id int(5) not null primary key,
   description longtext not null,
   gender varchar(6) not null
);

create table Tag(
   tag_id int(5) not null primary key,
   second_priority float(5) not null,
   priority int(5) not null
);

create table Article_20_Category(
	rel_id int(5) not null primary key,
	article20_id int(5) not null,
	category_id int(5) not null,
	foreign key (article20_id) references Article_20(article20_id),
	foreign key (category_id) references Category(category_id)
);

alter table Article_20
add column user_id int(5),
add foreign key (user_id)
references User(user_id);

alter table User
add column article20_id int(5),
add foreign key (article20_id)
references Article_20(article20_id);

alter table User 
add column tag_id int(5),
add foreign key (tag_id)
references Tag(tag_id);