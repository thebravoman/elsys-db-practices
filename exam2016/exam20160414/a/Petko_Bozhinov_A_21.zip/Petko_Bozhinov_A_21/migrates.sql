-- Separate Article_20 on two tables
-- Article_20_part1 containing url
-- Article_20_part2 containing all the other fields
-- As a result SQL queries+code in other programming language must be create.

create table Article_20_part1(
	article20_id int(5) primary key not null,
	url varchar(64) not null
);

create table Article_20_part2(
	article20_id int(5) primary key not null,
	password varchar(64) not null,
	visible boolean
);

alter table Article_20_Category
drop FOREIGN key Article_20_Category_ibfk_1;

alter table Article_20_Category
drop FOREIGN key Article_20_Category_ibfk_2;