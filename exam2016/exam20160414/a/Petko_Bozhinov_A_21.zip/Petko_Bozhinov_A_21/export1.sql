-- phpMyAdmin SQL Dump
-- version 4.4.13.1deb1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: 14 апр 2016 в 12:09
-- Версия на сървъра: 5.6.27-0ubuntu1
-- PHP Version: 5.6.11-1ubuntu3.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `exam`
--
CREATE DATABASE IF NOT EXISTS `exam` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `exam`;

-- --------------------------------------------------------

--
-- Структура на таблица `Article_20`
--

DROP TABLE IF EXISTS `Article_20`;
CREATE TABLE IF NOT EXISTS `Article_20` (
  `article20_id` int(5) NOT NULL,
  `password` varchar(64) NOT NULL,
  `url` varchar(64) NOT NULL,
  `visible` tinyint(1) DEFAULT NULL,
  `user_id` int(5) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Схема на данните от таблица `Article_20`
--

INSERT INTO `Article_20` (`article20_id`, `password`, `url`, `visible`, `user_id`) VALUES
(1, 'hahaha', '123.com', 1, 1),
(2, 'ahahah', '321.com', 1, 2);

-- --------------------------------------------------------

--
-- Структура на таблица `Article_20_Category`
--

DROP TABLE IF EXISTS `Article_20_Category`;
CREATE TABLE IF NOT EXISTS `Article_20_Category` (
  `rel_id` int(5) NOT NULL,
  `article20_id` int(5) NOT NULL,
  `category_id` int(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Схема на данните от таблица `Article_20_Category`
--

INSERT INTO `Article_20_Category` (`rel_id`, `article20_id`, `category_id`) VALUES
(1, 1, 1),
(2, 2, 1);

-- --------------------------------------------------------

--
-- Структура на таблица `Category`
--

DROP TABLE IF EXISTS `Category`;
CREATE TABLE IF NOT EXISTS `Category` (
  `category_id` int(5) NOT NULL,
  `created_by` varchar(64) NOT NULL,
  `priority` float NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Схема на данните от таблица `Category`
--

INSERT INTO `Category` (`category_id`, `created_by`, `priority`) VALUES
(1, 'Pesho ot 9ti blok', 2),
(2, 'Ivan Ivanov', 1);

-- --------------------------------------------------------

--
-- Структура на таблица `Tag`
--

DROP TABLE IF EXISTS `Tag`;
CREATE TABLE IF NOT EXISTS `Tag` (
  `tag_id` int(5) NOT NULL,
  `second_priority` float NOT NULL,
  `priority` int(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Схема на данните от таблица `Tag`
--

INSERT INTO `Tag` (`tag_id`, `second_priority`, `priority`) VALUES
(1, 2.3, 2),
(2, 1.3, 1);

-- --------------------------------------------------------

--
-- Структура на таблица `User`
--

DROP TABLE IF EXISTS `User`;
CREATE TABLE IF NOT EXISTS `User` (
  `user_id` int(5) NOT NULL,
  `description` longtext NOT NULL,
  `gender` varchar(6) NOT NULL,
  `article20_id` int(5) DEFAULT NULL,
  `tag_id` int(5) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Схема на данните от таблица `User`
--

INSERT INTO `User` (`user_id`, `description`, `gender`, `article20_id`, `tag_id`) VALUES
(1, 'Dobar den evropa', '513', 1, 1),
(2, 'Lele kak she te prebiqt v bopa', '412', 2, 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `Article_20`
--
ALTER TABLE `Article_20`
  ADD PRIMARY KEY (`article20_id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `Article_20_Category`
--
ALTER TABLE `Article_20_Category`
  ADD PRIMARY KEY (`rel_id`),
  ADD KEY `article20_id` (`article20_id`),
  ADD KEY `category_id` (`category_id`);

--
-- Indexes for table `Category`
--
ALTER TABLE `Category`
  ADD PRIMARY KEY (`category_id`);

--
-- Indexes for table `Tag`
--
ALTER TABLE `Tag`
  ADD PRIMARY KEY (`tag_id`);

--
-- Indexes for table `User`
--
ALTER TABLE `User`
  ADD PRIMARY KEY (`user_id`),
  ADD KEY `article20_id` (`article20_id`),
  ADD KEY `tag_id` (`tag_id`);

--
-- Ограничения за дъмпнати таблици
--

--
-- Ограничения за таблица `Article_20`
--
ALTER TABLE `Article_20`
  ADD CONSTRAINT `Article_20_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `User` (`user_id`);

--
-- Ограничения за таблица `Article_20_Category`
--
ALTER TABLE `Article_20_Category`
  ADD CONSTRAINT `Article_20_Category_ibfk_1` FOREIGN KEY (`article20_id`) REFERENCES `Article_20` (`article20_id`),
  ADD CONSTRAINT `Article_20_Category_ibfk_2` FOREIGN KEY (`category_id`) REFERENCES `Category` (`category_id`);

--
-- Ограничения за таблица `User`
--
ALTER TABLE `User`
  ADD CONSTRAINT `User_ibfk_1` FOREIGN KEY (`article20_id`) REFERENCES `Article_20` (`article20_id`),
  ADD CONSTRAINT `User_ibfk_2` FOREIGN KEY (`tag_id`) REFERENCES `Tag` (`tag_id`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
