drop database if exists exam;
create database exam;
use exam;

create table Article_16 (
	id int primary key auto_increment,
	content longtext,
	password varchar(255),
	name varchar(255)
);

create table Category (
	id int primary key auto_increment,
	description longtext,
	created_by varchar(255)
);

create table User (
	id int primary key auto_increment,
	age integer,
	picture_url varchar(255),
	created_on date
);

create table Tag (
	id int primary key auto_increment,
	hash varchar(16),
	name varchar(255)
);

alter table Category add column user_id int;
alter table Category add foreign key (user_id) references User(id);
create table Category_Article_16 (
	id int primary key auto_increment,
	category_id int not null,
	article_16_id int not null,
	foreign key (category_id) references Category(id),
	foreign key (article_16_id) references Article_16(id) 
);

alter table Article_16 add column tag_id int;
alter table Article_16 add foreign key (tag_id) references Tag(id);
