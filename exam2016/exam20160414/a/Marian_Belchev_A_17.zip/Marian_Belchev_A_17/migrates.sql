use exam;
CREATE TABLE Category_part1(id INT(11) PRIMARY KEY NOT NULL AUTO_INCREMENT,created_by varchar(255));
CREATE TABLE Category_part2(id INT(11) PRIMARY KEY NOT NULL AUTO_INCREMENT,description longtext);
INSERT INTO Category_part1(id,created_by) SELECT id,created_by FROM Category;
INSERT INTO Category_part2(id,description) SELECT id,description FROM Category;
