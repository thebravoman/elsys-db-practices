use exam;

SELECT Tag.id, Tag.hash, Tag.name FROM Tag
JOIN Article_16 ON Article_16.tag_id = Tag.id
JOIN Category_article_16 ON Category_article_16.article_16_id = Article_16.id
JOIN Category ON Category_article_16.category_id = Category.id
WHERE Category.id = 1;