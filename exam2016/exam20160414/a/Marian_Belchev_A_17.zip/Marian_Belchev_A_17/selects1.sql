use exam;

SELECT Article_16.id, Article_16.content, Article_16.password, Article_16.name, Article_16.tag_id FROM Article_16
JOIN Category_article_16 ON Category_article_16.article_16_id = Article_16.id
JOIN Category ON Category_article_16.category_id = Category.id
JOIN User ON Category.user_id = User.id
WHERE User.id = 1;