use exam;
INSERT INTO User
	(age,picture_url,created_on)
VALUES
	(0,'Erebus','2016-02-07 13:06:11'),
	(0,'Erebus','2016-02-07 13:06:11'),
	(0,'Erebus','2016-02-07 13:06:11'),
	(0,'Erebus','2016-02-07 13:06:11'),
	(0,'Erebus','2016-02-07 13:06:11');

INSERT INTO Tag
	(hash,name)
VALUES
	('Erebus','Erebus'),
	('Erebus','Erebus'),
	('Erebus','Erebus'),
	('Erebus','Erebus'),
	('Erebus','Erebus');

INSERT INTO Article_16
	(content,password,name,tag_id)
VALUES
	('Erebus','Erebus','Erebus',1),
	('Erebus','Erebus','Erebus',2),
	('Erebus','Erebus','Erebus',3),
	('Erebus','Erebus','Erebus',4),
	('Erebus','Erebus','Erebus',5);

INSERT INTO Category
	(description,created_by,user_id)
VALUES
	('Erebus','Erebus',1),
	('Erebus','Erebus',2),
	('Erebus','Erebus',3),
	('Erebus','Erebus',4),
	('Erebus','Erebus',5);

INSERT INTO Category_Article_16
	(category_id,article_16_id)
VALUES
(1,1),
(2,2),
(3,3),
(4,4),
(5,5);

