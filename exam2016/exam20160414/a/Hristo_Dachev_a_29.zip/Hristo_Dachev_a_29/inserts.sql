use exam;
INSERT INTO Article_28
	(published_on,password,name)
VALUES
	('2016-02-07 13:06:11','Erebus','Erebus'),
	('2016-02-07 13:06:11','Erebus','Erebus'),
	('2016-02-07 13:06:11','Erebus','Erebus'),
	('2016-02-07 13:06:11','Erebus','Erebus'),
	('2016-02-07 13:06:11','Erebus','Erebus');

INSERT INTO Tag
	(hash,description)
VALUES
	('Erebus','Erebus'),
	('Erebus','Erebus'),
	('Erebus','Erebus'),
	('Erebus','Erebus'),
	('Erebus','Erebus');

INSERT INTO Category
	(date_created_on,created_by,article_28_id)
VALUES
	('2016-02-07 13:06:11','Erebus',1),
	('2016-02-07 13:06:11','Erebus',2),
	('2016-02-07 13:06:11','Erebus',3),
	('2016-02-07 13:06:11','Erebus',4),
	('2016-02-07 13:06:11','Erebus',5);

INSERT INTO User
	(gender,twitter,created_on,tag_id)
VALUES
	('Erebus','Erebus','2016-02-07 13:06:11',1),
	('Erebus','Erebus','2016-02-07 13:06:11',2),
	('Erebus','Erebus','2016-02-07 13:06:11',3),
	('Erebus','Erebus','2016-02-07 13:06:11',4),
	('Erebus','Erebus','2016-02-07 13:06:11',5);

INSERT INTO Tag_Article_28
	(tag_id,article_28_id)
VALUES
(1,1),
(2,2),
(3,3),
(4,4),
(5,5);

