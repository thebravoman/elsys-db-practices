drop database if exists exam;
create database exam;
use exam;

create table Article_28 (
	id int primary key auto_increment,
	published_on date,
	password varchar(255),
	name varchar(255)
);

create table Category (
	id int primary key auto_increment,
	date_created_on date,
	created_by varchar(255)
);

create table User (
	id int primary key auto_increment,
	gender varchar(6),
	twitter varchar(255),
	created_on date
);

create table Tag (
	id int primary key auto_increment,
	hash varchar(16),
	description varchar(255)
);

alter table User add column tag_id int;
alter table User add foreign key (tag_id) references Tag(id);
create table Tag_Article_28 (
	id int primary key auto_increment,
	tag_id int not null,
	article_28_id int not null,
	foreign key (tag_id) references Tag(id),
	foreign key (article_28_id) references Article_28(id) 
);

alter table Category add column article_28_id int;
alter table Category add foreign key (article_28_id) references Article_28(id);
