SELECT tag_id
FROM User;
