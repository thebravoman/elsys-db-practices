use exam;
INSERT INTO Category
	(priority,date_created_on)
VALUES
	(0,1),
	(0,1),
	(0,1),
	(0,1),
	(0,1);

INSERT INTO Article_2
	(content,url,password,category_id)
VALUES
	(0,1,2,1),
	(0,1,2,2),
	(0,1,2,3),
	(0,1,2,4),
	(0,1,2,5);

INSERT INTO Tag
	(hash,name,category_id)
VALUES
	(0,1,1),
	(0,1,2),
	(0,1,3),
	(0,1,4),
	(0,1,5);

INSERT INTO User
	(description,name,income,tag_id)
VALUES
	(0,1,2.0,1),
	(0,1,2.0,2),
	(0,1,2.0,3),
	(0,1,2.0,4),
	(0,1,2.0,5);
