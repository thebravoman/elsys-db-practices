drop database if exists exam;
create database exam;
use exam;

create table Article_2 (
	id int primary key auto_increment,
	content longtext,
	url varchar(255),
	password varchar(255)
);

create table Category (
	id int primary key auto_increment,
	priority double,
	date_created_on date
);

create table User (
	id int primary key auto_increment,
	description longtext,
	name varchar(255),
	income float
);

create table Tag (
	id int primary key auto_increment,
	hash varchar(16),
	name varchar(255)
);

alter table User add column tag_id int;
alter table User add foreign key (tag_id) references Tag(id);
alter table Tag add column category_id int unique;
alter table Tag add foreign key (category_id) references Category(id);

alter table Article_2 add column category_id int;
alter table Article_2 add foreign key (category_id) references Category(id);
