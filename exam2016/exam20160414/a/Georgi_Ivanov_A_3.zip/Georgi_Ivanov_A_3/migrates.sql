use exam;
CREATE TABLE Tag_part1(id INT(11) PRIMARY KEY NOT NULL AUTO_INCREMENT,hash varchar(16));
CREATE TABLE Tag_part2(id INT(11) PRIMARY KEY NOT NULL AUTO_INCREMENT,name varchar(255));
INSERT INTO Tag_part1(id,hash) SELECT id,hash FROM Tag;
INSERT INTO Tag_part2(id,name) SELECT id,name FROM Tag;
