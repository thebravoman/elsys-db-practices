SELECT Tag
FROM Article_1
INNER JOIN Article_1. ON Article_1.;
