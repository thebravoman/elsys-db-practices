drop database if exists exam;
create database exam;
use exam;

create table Article_1 (
	id int primary key auto_increment,
	content longtext,
	url varchar(255),
	published_on date
);

create table Category (
	id int primary key auto_increment,
	name varchar(255),
	created_by varchar(255)
);

create table User (
	id int primary key auto_increment,
	gender varchar(6),
	twitter varchar(255),
	income float
);

create table Tag (
	id int primary key auto_increment,
	hash varchar(16),
	description varchar(255)
);

alter table Category add column article_1_id int;
alter table Category add foreign key (article_1_id) references Article_1(id);
alter table Category add column tag_id int unique;
alter table Category add foreign key (tag_id) references Tag(id);

alter table User add column tag_id int;
alter table User add foreign key (tag_id) references Tag(id);
