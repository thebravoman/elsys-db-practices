use exam;
INSERT INTO Article_1
	(content,url,published_on)
VALUES
	('Erebus','Erebus','2016-02-07 13:06:11'),
	('Erebus','Erebus','2016-02-07 13:06:11'),
	('Erebus','Erebus','2016-02-07 13:06:11'),
	('Erebus','Erebus','2016-02-07 13:06:11'),
	('Erebus','Erebus','2016-02-07 13:06:11');

INSERT INTO Tag
	(hash,description)
VALUES
	('Erebus','Erebus'),
	('Erebus','Erebus'),
	('Erebus','Erebus'),
	('Erebus','Erebus'),
	('Erebus','Erebus');

INSERT INTO Category
	(name,created_by,article_1_id,tag_id)
VALUES
	('Erebus','Erebus',1,1),
	('Erebus','Erebus',2,2),
	('Erebus','Erebus',3,3),
	('Erebus','Erebus',4,4),
	('Erebus','Erebus',5,5);

INSERT INTO User
	(gender,twitter,income,tag_id)
VALUES
	('Erebus','Erebus',2.0,1),
	('Erebus','Erebus',2.0,2),
	('Erebus','Erebus',2.0,3),
	('Erebus','Erebus',2.0,4),
	('Erebus','Erebus',2.0,5);

