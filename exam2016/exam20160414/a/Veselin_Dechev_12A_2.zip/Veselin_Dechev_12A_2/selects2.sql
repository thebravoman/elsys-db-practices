SELECT User
FROM Category
INNER JOIN Category.User ON Category.User;
