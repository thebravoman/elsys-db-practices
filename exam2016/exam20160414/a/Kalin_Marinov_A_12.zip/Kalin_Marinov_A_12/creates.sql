DROP DATABASE IF EXISTS exam;
CREATE DATABASE exam;
USE exam;

CREATE TABLE Article_11 (
	id int PRIMARY KEY AUTO_INCREMENT,
	published_on DATETIME,
	visible BOOLEAN,
	created_on DATETIME,
    tag_id INT UNIQUE,
    user_id INT UNIQUE
);

CREATE TABLE Category (
	id int PRIMARY KEY AUTO_INCREMENT,
	description LONGTEXT,
	created_by VARCHAR(32),
    user_id INT
);

CREATE TABLE User (
	id int PRIMARY KEY AUTO_INCREMENT,
	picture_url VARCHAR(32),
	income FLOAT,
	password VARCHAR(16)
);

CREATE TABLE Tag (
	id int PRIMARY KEY AUTO_INCREMENT,
	second_priority FLOAT,
	priority INT
);