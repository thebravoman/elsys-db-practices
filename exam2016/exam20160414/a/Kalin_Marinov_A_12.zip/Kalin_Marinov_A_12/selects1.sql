SELECT User.* FROM User INNER JOIN Article_11
ON Article_11.user_id = User.id INNER JOIN Tag
ON Article_11.tag_id = Tag.id 
WHERE Tag.id = 1;