INSERT INTO Article_11 (published_on, visible, created_on, tag_id, user_id)
VALUES ('1990-01-01', TRUE, '1990-01-01', 1, 1),
('1990-01-01', TRUE, '1990-01-01', 2, 2),
('1990-01-01', FALSE, '1990-01-01', 3, 3);

INSERT INTO Category (description, created_by, user_id)
VALUES ('dfsafdsafdsafsdfsafsdafdsa', 'a', 1),
('fdsa', 'f', 2),
('fsa', 'f', 3);

INSERT INTO User (picture_url, income, password)
VALUES ('afff', 1.0, 'afff'),
('fdsa', 1.0, 'afff'),
('fsa', 1.0, 'afff');

INSERT INTO Tag (second_priority, priority)
VALUES (1.0, 1),
(1.0, 1),
(1.0, 1);