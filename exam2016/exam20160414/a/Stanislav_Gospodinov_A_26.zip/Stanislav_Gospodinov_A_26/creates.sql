drop database if exists exam;
create database if not exists exam;
connect exam;

create table Article_24(id int primary key auto_increment not null,
	created_on datetime,
	content text,
	visible boolean);

create table Category(id int primary key auto_increment not null,
	date_created_on datetime,
	description text);

create table User(id int primary key auto_increment not null,
	created_on datetime,
	password varchar(255),
	income float);

create table Tag(id int primary key auto_increment not null,
	description varchar(255),
	hash varchar(16));

create table Article_24_to_Tag(id int primary key auto_increment not null,
	article_24_id int,
	tag_id int);

alter table Category add column article_24_id int;

create table Category_to_User(id int primary key auto_increment not null,
	category_id int,
	user_id int);
