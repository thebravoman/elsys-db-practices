select * from Category join Article_24_to_Tag
on Category.article_24_id = Article_24_to_Tag.article_24_id join Tag
on Article_24_to_Tag.tag_id = Tag.id
where Tag.id = 1
