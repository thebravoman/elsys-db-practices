select * from User join Category_to_User
on User.id = Category_to_User.user_id join Category
on Category_to_User.category_id = Category.article_24_id join Article_24_part1
on Article_24_part1.id = Category.article_24_id
where Article_24_part1.id = 1
