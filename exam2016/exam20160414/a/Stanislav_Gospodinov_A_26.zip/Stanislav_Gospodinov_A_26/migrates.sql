create table Article_24_part1 (id int primary key auto_increment not null,
	content text);
create table Article_24_part2 (id int primary key auto_increment not null,
	created_on datetime,
	visible boolean);

insert into Article_24_part1 select id, content from Article_24;
insert into Article_24_part2 select id, created_on, visible from Article_24;
drop table Article_24;
