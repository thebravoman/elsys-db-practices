insert into Article_24(created_on, content, visible)
	values("2011-11-11 11:11:11", "text1", true),
	("2012-12-12 12:12:12", "text2", false);

insert into User(created_on, password, income)
	values("2011-11-11 11:11:11", "pass1", 111.1),
	("2012-12-12 12:12:12", "pass2", 222.2);

insert into Category(date_created_on, description, article_24_id)
	values("2011-11-11 11:11:11", "desc1", 1),
	("2012-12-12 12:12:12", "desc1", 2);

insert into Tag(description, hash)
	values("desc1", "hash1"),
	("desc2", "hash2");

insert into Article_24_to_Tag(article_24_id, tag_id)
  values(1, 1),
  (2,2);

insert into Category_to_User(category_id, user_id)
  values(1, 1),
  (2,2);
