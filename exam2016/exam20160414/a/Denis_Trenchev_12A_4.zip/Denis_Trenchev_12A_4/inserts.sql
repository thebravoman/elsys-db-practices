INSERT INTO `article_3` (`id`, `url`, `password`, `visible`) VALUES ('1', '123', 'asd', '1'), ('2', '234', 'sdf', '1')
INSERT INTO `category` (`id`, `date_created_on`, `priority`) VALUES ('1', '2016-04-14', '1'), ('2', '2016-04-13', '2')
INSERT INTO `tag` (`id`, `name`, `priority`) VALUES ('1', 'asdf', '1'), ('2', 'asdfg', '2')
INSERT INTO `user` (`id`, `name`, `description`, `twitter`) VALUES ('1', 'denis', 'asd asd asd', 'asd'), ('2', 'sined', 'asd asd asd', 'dsa')