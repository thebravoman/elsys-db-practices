CREATE DATABASE exam;

CREATE TABLE `exam`.`Article_3` ( `id` INT NOT NULL , `url` VARCHAR(255) NOT NULL , `password` VARCHAR(255) NOT NULL , `visible` BOOLEAN NOT NULL ) ENGINE = InnoDB;
CREATE TABLE `exam`.`Category` ( `id` INT NOT NULL , `date_created_on` DATE NOT NULL , `priority` DOUBLE NOT NULL ) ENGINE = InnoDB;
CREATE TABLE `exam`.`User` ( `id` INT NOT NULL , `name` VARCHAR(255) NOT NULL , `description` LONGTEXT NOT NULL , `twitter` VARCHAR(255) NOT NULL ) ENGINE = InnoDB;
CREATE TABLE `exam`.`tag` ( `id` INT NOT NULL , `name` VARCHAR(255) NOT NULL , `priority` INT NOT NULL ) ENGINE = InnoDB;

CREATE TABLE `exam`.`category_user` ( `category_id` INT NOT NULL , `user_id` INT NOT NULL ) ENGINE = InnoDB;
CREATE TABLE `exam`.`article_3_tag` ( `art_3_id` INT NOT NULL , `tag_id` INT NOT NULL ) ENGINE = InnoDB;
ALTER TABLE `user` ADD `art_3_id` INT NOT NULL ;
ALTER TABLE `article_3` ADD `user_id` INT NOT NULL ;