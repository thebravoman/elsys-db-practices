CREATE TABLE User_part1 SELECT description FROM User
CREATE TABLE User_part2 SELECT id,name,description,twitter,art_3_id FROM User