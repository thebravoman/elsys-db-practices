SELECT * FROM Article_3
INNER JOIN cat_user ON cat_user.cat_id = Category.id
INNER JOIN cat_user ON cat_user.user_id = User.id
INNER JOIN User ON user.art_3_id = Article_3.id
WHERE Article_3.id = 1