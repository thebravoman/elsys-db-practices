use exam;
INSERT INTO Article_17
	(url,created_on,password)
VALUES
	('Erebus','10/15/2016 10:06:1 PM','Erebus'),
	('Erebus','10/15/2016 10:06:1 PM','Erebus'),
	('Erebus','10/15/2016 10:06:1 PM','Erebus'),
	('Erebus','10/15/2016 10:06:1 PM','Erebus'),
	('Erebus','10/15/2016 10:06:1 PM','Erebus');

INSERT INTO Category
	(priority,name,user_id)
VALUES
	(0,'Erebus',1),
	(0,'Erebus',2),
	(0,'Erebus',3),
	(0,'Erebus',4),
	(0,'Erebus',5);

INSERT INTO User
	(created_on,password,description,article_17_id)
VALUES
	('10/15/2016 10:06:0 PM','Erebus','Erebus',1),
	('10/15/2016 10:06:0 PM','Erebus','Erebus',2),
	('10/15/2016 10:06:0 PM','Erebus','Erebus',3),
	('10/15/2016 10:06:0 PM','Erebus','Erebus',4),
	('10/15/2016 10:06:0 PM','Erebus','Erebus',5);

INSERT INTO Tag
	(second_priority,description,category_id)
VALUES
	(0.0,'Erebus',1),
	(0.0,'Erebus',2),
	(0.0,'Erebus',3),
	(0.0,'Erebus',4),
	(0.0,'Erebus',5);

