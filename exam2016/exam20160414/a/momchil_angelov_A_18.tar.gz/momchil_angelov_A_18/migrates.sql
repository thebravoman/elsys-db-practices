use exam;
CREATE TABLE Category_part1(id INT(11) PRIMARY KEY NOT NULL AUTO_INCREMENT,name varchar(255));
CREATE TABLE Category_part2(id INT(11) PRIMARY KEY NOT NULL AUTO_INCREMENT,priority double);
INSERT INTO Category_part1(id,name) SELECT id,name FROM Category;
INSERT INTO Category_part2(id,priority) SELECT id,priority FROM Category;
