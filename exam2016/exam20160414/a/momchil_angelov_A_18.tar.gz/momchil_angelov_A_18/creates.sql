drop database if exists exam;
create database exam;
use exam;

create table Article_17 (
	id int primary key auto_increment,
	url varchar(255),
	created_on date,
	password varchar(255)
);

create table Category (
	id int primary key auto_increment,
	priority double,
	name varchar(255)
);

create table User (
	id int primary key auto_increment,
	created_on date,
	password varchar(255),
	description longtext
);

create table Tag (
	id int primary key auto_increment,
	second_priority float,
	description varchar(255)
);

alter table Tag add column category_id int;
alter table Tag add foreign key (category_id) references Category(id);
alter table Category add column user_id int;
alter table Category add foreign key (user_id) references User(id);
alter table User add column article_17_id int unique;
alter table User add foreign key (article_17_id) references Article_17(id);

