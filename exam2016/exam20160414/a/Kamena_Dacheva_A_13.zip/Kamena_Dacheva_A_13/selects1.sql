USE exam;

SELECT user.id, user.name FROM article_12_category
JOIN user ON article_12_category.article_12_id = user.id
WHERE article_12_category.id = 22;
