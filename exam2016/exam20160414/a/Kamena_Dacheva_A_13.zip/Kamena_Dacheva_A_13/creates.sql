drop database if exists exam;
create database exam;
use exam;

create table Article_12 (
	id int primary key auto_increment,
	price float,
	content longtext,
	visible boolean
);

create table Category (
	id int primary key auto_increment,
	priority double,
	created_by varchar(255)
);

create table User (
	id int primary key auto_increment,
	picture_url varchar(255),
	description longtext,
	name varchar(255)
);

create table Tag (
	id int primary key auto_increment,
	priority int,
	hash varchar(16)
);

create table Article_12_Category (
	id int primary key auto_increment,
	article_12_id int not null,
	category_id int not null,
	foreign key (article_12_id) references Article_12(id),
	foreign key (category_id) references Category(id) 
);

create table Category_User (
	id int primary key auto_increment,
	category_id int not null,
	user_id int not null,
	foreign key (category_id) references Category(id),
	foreign key (user_id) references User(id) 
);

create table User_Tag (
	id int primary key auto_increment,
	user_id int not null,
	tag_id int not null,
	foreign key (user_id) references User(id),
	foreign key (tag_id) references Tag(id) 
);

