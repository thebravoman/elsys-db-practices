use exam;

insert into Article_12 (content,visible,price)
values
('Test Value',TRUE,3.0),
('Test Value',TRUE,3.0),
('Test Value',TRUE,3.0),
('Test Value',TRUE,3.0);

insert into Category (priority,created_by)
values
(2.0,'Category creator'),
(2.0,'Category creator'),
(2.0,'Category creator'),
(2.0,'Category creator');

insert into User (picture_url,description,name)
values
('URL','Description','username'),
('URL','Description','username'),
('URL','Description','username'),
('URL','Description','username');

insert into Tag (priority,hash)
values
(1,'HashTag'),
(2,'HashTag'),
(1,'HashTag'),
(3,'HashTag');

insert into Article_12_Category (category_id,article_12_id)
values
(1,1),
(2,2),
(3,3),
(4,4),
(5,5);

insert into Category_User (category_id,user_id)
values
(1,1),
(2,2),
(3,3),
(4,4),
(5,5);

insert into User_Tag (user_id,tag_id)
values
(1,1),
(2,2),
(3,3),
(4,4),
(5,5);

