use exam;
CREATE TABLE Article_27_part1(id INT(11) PRIMARY KEY NOT NULL AUTO_INCREMENT,published_on date);
CREATE TABLE Article_27_part2(id INT(11) PRIMARY KEY NOT NULL AUTO_INCREMENT,content longtext,created_on date);
INSERT INTO Article_27_part1(id,published_on) SELECT id,published_on FROM Article_27;
INSERT INTO Article_27_part2(id,content,created_on) SELECT id,content,created_on FROM Article_27;
