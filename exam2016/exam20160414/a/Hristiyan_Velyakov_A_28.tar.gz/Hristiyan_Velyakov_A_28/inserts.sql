use exam;
INSERT INTO Category
	(description,created_by)
VALUES
	('Erebus','Erebus'),
	('Erebus','Erebus'),
	('Erebus','Erebus'),
	('Erebus','Erebus'),
	('Erebus','Erebus');

INSERT INTO Article_27
	(content,created_on,published_on,tag_id)
VALUES
	('Erebus','2016-02-07 13:06:11','2016-02-07 13:06:11',1),
	('Erebus','2016-02-07 13:06:11','2016-02-07 13:06:11',2),
	('Erebus','2016-02-07 13:06:11','2016-02-07 13:06:11',3),
	('Erebus','2016-02-07 13:06:11','2016-02-07 13:06:11',4),
	('Erebus','2016-02-07 13:06:11','2016-02-07 13:06:11',5);

INSERT INTO User
	(gender,created_on,name,article_27_id)
VALUES
	('Erebus','2016-02-07 13:06:11','Erebus',1),
	('Erebus','2016-02-07 13:06:11','Erebus',2),
	('Erebus','2016-02-07 13:06:11','Erebus',3),
	('Erebus','2016-02-07 13:06:11','Erebus',4),
	('Erebus','2016-02-07 13:06:11','Erebus',5);

INSERT INTO Tag
	(priority,description,category_id)
VALUES
	(0,'Erebus',1),
	(0,'Erebus',2),
	(0,'Erebus',3),
	(0,'Erebus',4),
	(0,'Erebus',5);

