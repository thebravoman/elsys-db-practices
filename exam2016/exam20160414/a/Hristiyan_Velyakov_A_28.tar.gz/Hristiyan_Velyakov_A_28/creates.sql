drop database if exists exam;
create database exam;
use exam;

create table Article_27 (
	id int primary key auto_increment,
	content text,
	created_on date,
	published_on date
);

create table Category (
	id int primary key auto_increment,
	description text,
	created_by varchar(255)
);

create table User (
	id int primary key auto_increment,
	gender varchar(6),
	created_on date,
	name varchar(255)
);

create table Tag (
	id int primary key auto_increment,
	priority int,
	description varchar(255)
);

alter table User add column article_27_id int unique;
alter table User add foreign key (article_27_id) references Article_27(id);

alter table Article_27 add column tag_id int unique;
alter table Article_27 add foreign key (tag_id) references Tag(id);

alter table Tag add column category_id int;
alter table Tag add foreign key (category_id) references Category(id);
