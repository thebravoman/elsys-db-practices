use exam;
CREATE TABLE User_part1(id INT(11) PRIMARY KEY NOT NULL AUTO_INCREMENT,picture_url varchar(255));
CREATE TABLE User_part2(id INT(11) PRIMARY KEY NOT NULL AUTO_INCREMENT,gender varchar(6),income float);
INSERT INTO User_part1(id,picture_url) SELECT id,picture_url FROM User;
INSERT INTO User_part2(id,gender,income) SELECT id,gender,income FROM User;
