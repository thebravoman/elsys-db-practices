drop database if exists exam;
create database exam;
use exam;

create table Article_21 (
	id int primary key auto_increment,
	content longtext,
	password varchar(255),
	created_on date
	
);

create table Category (
	id int primary key auto_increment,
	priority double,
	name varchar(255)
);

create table User (
	id int primary key auto_increment,
	picture_url varchar(255),
	gender varchar(6),
	income float
);

create table Tag (
	id int primary key auto_increment,
	hash varchar(16),
	second_priority float
	
);

create table Tag_User (
	id int primary key auto_increment,
	tag_id int not null,
	user_id int not null,
	foreign key (tag_id) references Tag(id),
	foreign key (user_id) references User(id) 
);

alter table User add column article_21_id int;
alter table User add foreign key (article_21_id) references Article_21(id);
create table Article_21_Category (
	id int primary key auto_increment,
	article_21_id int not null,
	category_id int not null,
	foreign key (article_21_id) references Article_21(id),
	foreign key (category_id) references Category(id) 
);

