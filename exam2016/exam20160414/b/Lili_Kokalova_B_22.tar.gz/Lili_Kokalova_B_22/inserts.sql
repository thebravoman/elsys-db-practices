use exam;
INSERT INTO Article_21
	(content,password,created_on)
VALUES
	('Erebus','Erebus','2016-02-07 13:06:11'),
	('Erebus','Erebus','2016-02-07 13:06:11'),
	('Erebus','Erebus','2016-02-07 13:06:11'),	
	('Erebus','Erebus','2016-02-07 13:06:11'),
	('Erebus','Erebus','2016-02-07 13:06:11');

INSERT INTO Category
	(priority,name)
VALUES
	(2.0,'Erebus'),
	(2.0,'Erebus'),
	(2.0,'Erebus'),
	(2.0,'Erebus'),
	(2.0,'Erebus');

INSERT INTO Tag
	(hash,second_priority)
VALUES
	('Erebus',2.0),
	('Erebus',2.0),
	('Erebus',2.0),
	('Erebus',2.0),
	('Erebus',2.0);

INSERT INTO User
	(picture_url,gender,income,article_21_id)
VALUES
	('Erebus','Erebus',2.0,1),
	('Erebus','Erebus',2.0,2),
	('Erebus','Erebus',2.0,3),
	('Erebus','Erebus',2.0,4),
	('Erebus','Erebus',2.0,5);

INSERT INTO Tag_User
	(tag_id,user_id)
VALUES
(1,1),
(2,2),
(3,3),
(4,4),
(5,5);

INSERT INTO Article_21_Category
	(article_21_id,category_id)
VALUES
(1,1),
(2,2),
(3,3),
(4,4),
(5,5);

