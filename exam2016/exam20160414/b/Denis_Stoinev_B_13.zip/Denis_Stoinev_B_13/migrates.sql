use exam;
CREATE TABLE Tag_part1(id INT(11) PRIMARY KEY NOT NULL AUTO_INCREMENT,name varchar(255));
CREATE TABLE Tag_part2(id INT(11) PRIMARY KEY NOT NULL AUTO_INCREMENT,content longtext,visible boolean);
INSERT INTO Tag_part1(id,name) SELECT id,name FROM Tag;
INSERT INTO Tag_part2(id,content,visible) SELECT id,content,visible FROM Tag;
