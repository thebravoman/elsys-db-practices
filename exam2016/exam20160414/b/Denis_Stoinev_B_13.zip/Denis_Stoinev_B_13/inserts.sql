use exam;
INSERT INTO Category
	(priority,description)
VALUES
	(0,'Erebus'),
	(0,'Erebus'),
	(0,'Erebus'),
	(0,'Erebus'),
	(0,'Erebus');

INSERT INTO Article_12
	(content,visible,name,category_id)
VALUES
	('Erebus',TRUE,'Erebus',1),
	('Erebus',TRUE,'Erebus',2),
	('Erebus',TRUE,'Erebus',3),
	('Erebus',TRUE,'Erebus',4),
	('Erebus',TRUE,'Erebus',5);

INSERT INTO User
	(gender,description,income,tag_id)
VALUES
	('Erebus','Erebus',2.0,1),
	('Erebus','Erebus',2.0,2),
	('Erebus','Erebus',2.0,3),
	('Erebus','Erebus',2.0,4),
	('Erebus','Erebus',2.0,5);

INSERT INTO Tag
	(hash,name,article_12_id)
VALUES
	('Erebus','Erebus',1),
	('Erebus','Erebus',2),
	('Erebus','Erebus',3),
	('Erebus','Erebus',4),
	('Erebus','Erebus',5);

