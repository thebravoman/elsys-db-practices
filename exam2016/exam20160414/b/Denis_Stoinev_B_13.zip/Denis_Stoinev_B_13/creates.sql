drop database if exists exam;
create database exam;
use exam;

create table Article_12 (
	id int primary key auto_increment,
	content longtext,
	visible boolean,
	name varchar(255)
);

create table Category (
	id int primary key auto_increment,
	priority double,
	description longtext
);

create table User (
	id int primary key auto_increment,
	gender varchar(6),
	description longtext,
	income float
);

create table Tag (
	id int primary key auto_increment,
	hash varchar(16),
	name varchar(255)
);

alter table User add column tag_id int;
alter table User add foreign key (tag_id) references Tag(id);
alter table Tag add column article_12_id int;
alter table Tag add foreign key (article_12_id) references Article_12(id);
alter table Article_12 add column category_id int;
alter table Article_12 add foreign key (category_id) references Category(id);
