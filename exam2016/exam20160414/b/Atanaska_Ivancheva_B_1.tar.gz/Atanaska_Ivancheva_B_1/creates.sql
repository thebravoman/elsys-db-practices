DROP DATABASE IF EXISTS exam;
CREATE DATABASE IF NOT EXISTS exam;
USE exam;

CREATE TABLE Article_0 (
	id INT PRIMARY KEY AUTO_INCREMENT,
	content longtext,
	visible boolean,
	created_on date
);

CREATE TABLE Category (
	id INT PRIMARY KEY AUTO_INCREMENT,
	priority double,
	date_created_on date
);

CREATE TABLE User (
	id INT PRIMARY KEY AUTO_INCREMENT,
	created_on date,
	description longtext,
	income float
);

CREATE TABLE Tag (
	id INT PRIMARY KEY AUTO_INCREMENT,
	second_priority float,
	description varchar(255)
);

ALTER TABLE Article_0 ADD COLUMN user_id INT;
ALTER TABLE Article_0 ADD FOREIGN KEY (user_id) REFERENCES User(id);
ALTER TABLE Article_0 ADD COLUMN tag_id INT UNIQUE;
ALTER TABLE Article_0 ADD CONSTRAINT FOREIGN KEY (tag_id) REFERENCES Tag(id);

ALTER TABLE Category ADD COLUMN tag_id INT;
ALTER TABLE Category ADD FOREIGN KEY (tag_id) REFERENCES Tag(id);
