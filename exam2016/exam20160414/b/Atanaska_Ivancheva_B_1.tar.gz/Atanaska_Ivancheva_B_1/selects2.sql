USE exam;

SELECT Category.id, Category.priority, Category.date_created_on FROM Category
JOIN Tag ON Tag.id = Category.tag_id
JOIN Article_0_part2 ON Article_0_part2.tag_id = Tag.id
WHERE Article_0_part2.id = 1;

