use exam;
INSERT INTO User
	(created_on,description,income)
VALUES
	('14/04/2016 09:00:0 PM','asdasd',2.0),
	('14/04/2016 09:00:0 PM','asdasd',2.0),
	('14/04/2016 09:00:0 PM','asdasd',2.0),
	('14/04/2016 09:00:0 PM','asdasd',2.0),
	('14/04/2016 09:00:0 PM','asdasd',2.0);

INSERT INTO Tag
	(second_priority,description)
VALUES
	(0.0,'asdasd'),
	(0.0,'asdasd'),
	(0.0,'asdasd'),
	(0.0,'asdasd'),
	(0.0,'asdasd');

INSERT INTO Article_0
	(content,visible,created_on,user_id,tag_id)
VALUES
	('asdasd',TRUE,'14/04/2016 09:00:2 PM',1,1),
	('asdasd',TRUE,'14/04/2016 09:00:2 PM',2,2),
	('asdasd',TRUE,'14/04/2016 09:00:2 PM',3,3),
	('asdasd',TRUE,'14/04/2016 09:00:2 PM',4,4),
	('asdasd',TRUE,'14/04/2016 09:00:2 PM',5,5);

INSERT INTO Category
	(priority,date_created_on,tag_id)
VALUES
	(0,'14/04/2016 09:00:1 PM',1),
	(0,'14/04/2016 09:00:1 PM',2),
	(0,'14/04/2016 09:00:1 PM',3),
	(0,'14/04/2016 09:00:1 PM',4),
	(0,'14/04/2016 09:00:1 PM',5);

