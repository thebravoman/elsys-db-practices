USE exam;

SELECT Tag.id, Tag.second_priority, Tag.description FROM Tag
JOIN Article_0 ON Article_0.tag_id = Tag.id
JOIN User ON User.id = Article_0.user_id
WHERE User.id = 1;

