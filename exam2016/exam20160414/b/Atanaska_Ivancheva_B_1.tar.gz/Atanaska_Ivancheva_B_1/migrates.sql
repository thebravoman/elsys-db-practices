use exam;
CREATE TABLE Article_0_part1(id INT(11) PRIMARY KEY NOT NULL AUTO_INCREMENT,created_on date);
CREATE TABLE Article_0_part2(id INT(11) PRIMARY KEY NOT NULL AUTO_INCREMENT,content longtext,visible boolean,user_id int,tag_id int);
INSERT INTO Article_0_part1(id,created_on) SELECT id,created_on FROM Article_0;
INSERT INTO Article_0_part2(id,content,visible,user_id,tag_id) SELECT id,content,visible,user_id,tag_id FROM Article_0;
