INSERT INTO Article_19
	(content,visible,price)
VALUES
	(0,1,2.0),
	(0,1,2.0),
	(0,1,2.0),
	(0,1,2.0),
	(0,1,2.0);

INSERT INTO Tag
	(priority,name)
VALUES
	(0,1),
	(0,1),
	(0,1),
	(0,1),
	(0,1);

INSERT INTO Category
	(priority,description,article_19_id)
VALUES
	(0,1,1),
	(0,1,2),
	(0,1,3),
	(0,1,4),
	(0,1,5);

INSERT INTO User
	(gender,name,income,tag_id)
VALUES
	(0,1,2.0,1),
	(0,1,2.0,2),
	(0,1,2.0,3),
	(0,1,2.0,4),
	(0,1,2.0,5);

INSERT INTO Category_User
	(category_id,user_id)
VALUES
(1,1),
(2,2),
(3,3),
(4,4),
(5,5);

