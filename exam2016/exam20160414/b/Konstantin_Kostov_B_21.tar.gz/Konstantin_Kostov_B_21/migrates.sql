CREATE TABLE Category_part1(id INT(11) PRIMARY KEY NOT NULL AUTO_INCREMENT,description longtext);
CREATE TABLE Category_part2(id INT(11) PRIMARY KEY NOT NULL AUTO_INCREMENT,priority double);
INSERT INTO Category_part1(id,description) SELECT id,description FROM Category;
INSERT INTO Category_part2(id,priority) SELECT id,priority FROM Category;
