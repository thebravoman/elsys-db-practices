drop database if exists exam;
create database exam;
use exam;

create table Article_19 (
	id int primary key auto_increment,
	content longtext,
	visible boolean,
	price float
);

create table Category (
	id int primary key auto_increment,
	priority double,
	description longtext
);

create table User (
	id int primary key auto_increment,
	gender varchar(6),
	name varchar(255),
	income float
);

create table Tag (
	id int primary key auto_increment,
	priority int,
	name varchar(255)
);

alter table Category add column article_19_id int;
alter table Category add foreign key (article_19_id) references Article_19(id);
create table Category_User (
	id int primary key auto_increment,
	category_id int not null,
	user_id int not null,
	foreign key (category_id) references Category(id),
	foreign key (user_id) references User(id) 
);

alter table User add column tag_id int unique;
alter table User add foreign key (tag_id) references Tag(id);

