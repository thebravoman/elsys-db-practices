use exam;
INSERT INTO Article_6
	(url,visible,password)
VALUES
	(0,1,2),
	(0,1,2),
	(0,1,2),
	(0,1,2),
	(0,1,2);

INSERT INTO User
	(age,created_on,income)
VALUES
	(0,1,2.0),
	(0,1,2.0),
	(0,1,2.0),
	(0,1,2.0),
	(0,1,2.0);

INSERT INTO Category
	(priority,date_created_on,article_6_id)
VALUES
	(0,1,1),
	(0,1,2),
	(0,1,3),
	(0,1,4),
	(0,1,5);

INSERT INTO Tag
	(priority,second_priority,category_id)
VALUES
	(0,1.0,1),
	(0,1.0,2),
	(0,1.0,3),
	(0,1.0,4),
	(0,1.0,5);

INSERT INTO User_Tag
	(user_id,tag_id)
VALUES
(1,1),
(2,2),
(3,3),
(4,4),
(5,5);

