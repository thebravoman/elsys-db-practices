use exam;
CREATE TABLE Tag_part1(id INT(11) PRIMARY KEY NOT NULL AUTO_INCREMENT,second_priority float);
CREATE TABLE Tag_part2(id INT(11) PRIMARY KEY NOT NULL AUTO_INCREMENT,priority int);
INSERT INTO Tag_part1(id,second_priority) SELECT id,second_priority FROM Tag;
INSERT INTO Tag_part2(id,priority) SELECT id,priority FROM Tag;
