drop database if exists exam;
create database exam;
use exam;

create table Article_6 (
	id int primary key auto_increment,
	url varchar(255),
	visible boolean,
	password varchar(255)
);

create table Category (
	id int primary key auto_increment,
	priority double,
	date_created_on date
);

create table User (
	id int primary key auto_increment,
	age integer,
	created_on date,
	income float
);

create table Tag (
	id int primary key auto_increment,
	priority int,
	second_priority float
);

create table User_Tag (
	id int primary key auto_increment,
	user_id int not null,
	tag_id int not null,
	foreign key (user_id) references User(id),
	foreign key (tag_id) references Tag(id) 
);

alter table Tag add column category_id int unique;
alter table Tag add foreign key (category_id) references Category(id);

alter table Category add column article_6_id int;
alter table Category add foreign key (article_6_id) references Article_6(id);
