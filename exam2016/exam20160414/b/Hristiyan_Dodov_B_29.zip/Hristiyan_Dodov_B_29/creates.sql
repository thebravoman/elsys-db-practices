drop database if exists exam;
create database exam;
use exam;

create table Article_28 (
	id int primary key auto_increment,
	url varchar(255),
	visible boolean,
	password varchar(255)
);

create table Category (
	id int primary key auto_increment,
	priority double,
	created_by varchar(255)
);

create table User (
	id int primary key auto_increment,
	age integer,
	created_on date,
	description longtext
);

create table Tag (
	id int primary key auto_increment,
	second_priority float,
	name varchar(255)
);

alter table User add column article_28_id int unique;
alter table User add foreign key (article_28_id) references Article_28(id);

alter table Article_28 add column tag_id int;
alter table Article_28 add foreign key (tag_id) references Tag(id);
create table Tag_Category (
	id int primary key auto_increment,
	tag_id int not null,
	category_id int not null,
	foreign key (tag_id) references Tag(id),
	foreign key (category_id) references Category(id) 
);

