use exam;
CREATE TABLE Article_28_part1(id INT(11) PRIMARY KEY NOT NULL AUTO_INCREMENT,url varchar(255));
CREATE TABLE Article_28_part2(id INT(11) PRIMARY KEY NOT NULL AUTO_INCREMENT,visible boolean,password varchar(255));
INSERT INTO Article_28_part1(id,url) SELECT id,url FROM Article_28;
INSERT INTO Article_28_part2(id,visible,password) SELECT id,visible,password FROM Article_28;
