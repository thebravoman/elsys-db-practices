use exam;
INSERT INTO Category
	(priority,created_by)
VALUES
	(0,1),
	(0,1),
	(0,1),
	(0,1),
	(0,1);

INSERT INTO Tag
	(second_priority,name)
VALUES
	(0.0,1),
	(0.0,1),
	(0.0,1),
	(0.0,1),
	(0.0,1);

INSERT INTO Article_28
	(url,visible,password,tag_id)
VALUES
	(0,1,2,1),
	(0,1,2,2),
	(0,1,2,3),
	(0,1,2,4),
	(0,1,2,5);

INSERT INTO User
	(age,created_on,description,article_28_id)
VALUES
	(0,1,2,1),
	(0,1,2,2),
	(0,1,2,3),
	(0,1,2,4),
	(0,1,2,5);

INSERT INTO Tag_Category
	(tag_id,category_id)
VALUES
(1,1),
(2,2),
(3,3),
(4,4),
(5,5);

