use exam;

insert into Article_10 (published_on,password,name)
values
(1,'Sample text','Sample text'),
(1,'Sample text','Sample text'),
(1,'Sample text','Sample text'),
(1,'Sample text','Sample text'),
(1,'Sample text','Sample text');

insert into Category (priority,name)
values
(2.0,'Sample text'),
(2.0,'Sample text'),
(2.0,'Sample text'),
(2.0,'Sample text'),
(2.0,'Sample text');

insert into User (created_on,password,income)
values
(1,'Sample text',2.0),
(1,'Sample text',2.0),
(1,'Sample text',2.0),
(1,'Sample text',2.0),
(1,'Sample text',2.0);

insert into Tag (description,name)
values
('Sample text','Sample text'),
('Sample text','Sample text'),
('Sample text','Sample text'),
('Sample text','Sample text'),
('Sample text','Sample text');

insert into User_Article_10 (user_id,article_10_id)
values
(1,1),
(2,2),
(3,3),
(4,4),
(5,5);

