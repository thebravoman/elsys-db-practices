use exam;

create table Article_10_part1 (
	id int primary key auto_increment,
	password varchar(255)
);

insert into Article_10_part1 (password) select password from Article_10;
alter table Article_10 drop column password;
alter table Article_10 rename Article_10_part2;