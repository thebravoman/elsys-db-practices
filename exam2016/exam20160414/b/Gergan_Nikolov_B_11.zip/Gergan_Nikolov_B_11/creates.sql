drop database if exists exam;
create database exam;
use exam;

create table Article_10 (
	id int primary key auto_increment,
	published_on date,
	password varchar(255),
	name varchar(255)
);

create table Category (
	id int primary key auto_increment,
	priority double,
	name varchar(255)
);

create table User (
	id int primary key auto_increment,
	created_on date,
	password varchar(255),
	income float
);

create table Tag (
	id int primary key auto_increment,
	description varchar(255),
	name varchar(255)
);

create table User_Article_10 (
	id int primary key auto_increment,
	user_id int not null,
	article_10_id int not null,
	foreign key (user_id) references User(id),
	foreign key (article_10_id) references Article_10(id) 
);

alter table Tag add column article_10_id int;
alter table Tag add foreign key (article_10_id) references Article_10(id);
alter table Tag add column category_id int unique;
alter table Tag add foreign key (category_id) references Category(id);

