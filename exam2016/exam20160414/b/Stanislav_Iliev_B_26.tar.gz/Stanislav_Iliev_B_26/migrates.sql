use exam;

create table Tag_part1 (
	id int primary key auto_increment,
	name varchar(255)
);

insert into Tag_part1 (name) select name from Tag;
alter table Tag drop column name;
alter table Tag rename Tag_part2;