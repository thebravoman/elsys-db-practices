use exam;

insert into Article_25 (content,published_on,price)
values
('Sample text','2016-02-07 13:06:11',2.0),
('Sample text','2016-02-07 13:06:11',2.0),
('Sample text','2016-02-07 13:06:11',2.0),
('Sample text','2016-02-07 13:06:11',2.0),
('Sample text','2016-02-07 13:06:11',2.0);

insert into Category (date_created_on,description)
values
('2016-02-07 13:06:11','Sample text'),
('2016-02-07 13:06:11','Sample text'),
('2016-02-07 13:06:11','Sample text'),
('2016-02-07 13:06:11','Sample text'),
('2016-02-07 13:06:11','Sample text');

insert into Tag (priority,name,category_id)
values
(1,'Sample text',1),
(1,'Sample text',2),
(1,'Sample text',3),
(1,'Sample text',4),
(1,'Sample text',5);

insert into User (gender,password,name,tag_id,article_25_id)
values
('Sample text','Sample text','Sample text',1,1),
('Sample text','Sample text','Sample text',2,2),
('Sample text','Sample text','Sample text',3,3),
('Sample text','Sample text','Sample text',4,4),
('Sample text','Sample text','Sample text',5,5);
