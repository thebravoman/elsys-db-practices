drop database if exists exam;
create database exam;
use exam;

create table Article_25 (
	id int primary key auto_increment,
	content longtext,
	published_on date,
	price float
);

create table Category (
	id int primary key auto_increment,
	date_created_on date,
	description longtext
);

create table User (
	id int primary key auto_increment,
	gender varchar(6),
	password varchar(255),
	name varchar(255)
);

create table Tag (
	id int primary key auto_increment,
	priority int,
	name varchar(255)
);

alter table Tag add column category_id int;
alter table Tag add foreign key (category_id) references Category(id);
alter table User add column tag_id int;
alter table User add foreign key (tag_id) references Tag(id);
alter table User add column article_25_id int unique;
alter table User add foreign key (article_25_id) references Article_25(id);

