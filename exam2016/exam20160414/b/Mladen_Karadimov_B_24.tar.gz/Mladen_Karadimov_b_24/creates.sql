drop database if exists exam;
create database exam;
use exam;

create table Article_23 (
	id int primary key auto_increment,
	content longtext,
	visible boolean,
	created_on date
);

create table Category (
	id int primary key auto_increment,
	description longtext,
	created_by varchar(255)
);

create table User (
	id int primary key auto_increment,
	gender varchar(6),
	name varchar(255),
	income float
);

create table Tag (
	id int primary key auto_increment,
	priority int,
	hash varchar(16)
);

create table User_Article_23 (
	id int primary key auto_increment,
	user_id int not null,
	article_23_id int not null,
	foreign key (user_id) references User(id),
	foreign key (article_23_id) references Article_23(id) 
);

alter table Tag add column article_23_id int;
alter table Tag add foreign key (article_23_id) references Article_23(id);
create table Tag_Category (
	id int primary key auto_increment,
	tag_id int not null,
	category_id int not null,
	foreign key (tag_id) references Tag(id),
	foreign key (category_id) references Category(id) 
);

