use exam;

insert into Article_23 (content,visible,created_on)
values
('Sample text',TRUE,1),
('Sample text',TRUE,1),
('Sample text',TRUE,1),
('Sample text',TRUE,1),
('Sample text',TRUE,1);

insert into Category (description,created_by)
values
('Sample text','Sample text'),
('Sample text','Sample text'),
('Sample text','Sample text'),
('Sample text','Sample text'),
('Sample text','Sample text');

insert into User (gender,name,income)
values
('Sample text','Sample text',2.0),
('Sample text','Sample text',2.0),
('Sample text','Sample text',2.0),
('Sample text','Sample text',2.0),
('Sample text','Sample text',2.0);

insert into Tag (priority,hash)
values
(1,'Sample text'),
(1,'Sample text'),
(1,'Sample text'),
(1,'Sample text'),
(1,'Sample text');

insert into User_Article_23 (article_23_id,user_id)
values
(1,1),
(2,2),
(3,3),
(4,4),
(5,5);

insert into Tag_Category (category_id,tag_id)
values
(1,1),
(2,2),
(3,3),
(4,4),
(5,5);

