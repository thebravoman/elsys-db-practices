use exam;

create table Article_23_part1 (
	id int primary key auto_increment,
	visible boolean
);

insert into Article_23_part1 (visible) select visible from Article_23;
alter table Article_23 drop column visible;
alter table Article_23 rename Article_23_part2;