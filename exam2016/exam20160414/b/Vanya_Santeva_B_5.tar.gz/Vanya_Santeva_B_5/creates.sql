drop database if exists exam;
create database if not exists exam;
use exam;

create table Article_4 (
	id int primary key auto_increment,
	name varchar(100),
	url varchar(100),
	password varchar
);

create table Category (
	id int primary key auto_increment,
	name varchar(100),
	description varchar(500)
);

create table User (
	id int primary key auto_increment,
	password varchar(100),
	gender varchar(6),
	picture_url varchar(300)
);

create table Tag (
	id int primary key auto_increment,
	hash varchar(16),
	second_priority float
);


alter table Article_4 add column tag_id int unique;
alter table Article_4 add constraint foreign key (tag) references Tag(id);

alter table Tag add column category_id int unique;
alter table Tag add constraint foreign key (category_id) references Category(id);

alter table Category add user_id int unique;
alter table Category add constraint foreign key (user_id) references User(id);

