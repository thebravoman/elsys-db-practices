use exam;

insert into Category (date_created_on, name) values
	("2016-04-01", "Liam South"),
	("2016-04-03", "Liam South"),
	("2016-04-02", "Liam South"),
	("2016-04-07", "Liam South"),
	("2016-04-04", "Liam South"),
	("2016-04-06", "Liam South"),
	("2016-04-05", "Liam South");

insert into Tag (description, name, Category_id) values
	("It should have some description at page 6", "Liam South", 3),
	("It should have some description at page 5", "Liam South", 7),
	("It should have some description at page 3", "Liam South", 6),
	("It should have some description at page 1", "Liam South", 1),
	("It should have some description at page 2", "Liam South", 2),
	("It should have some description at page 4", "Liam South", 5),
	("It should have some description at page 7", "Liam South", 4);

insert into Article_15 (name, price, content) values
	("Liam South", 5.99, "It should have some content at page 6"),
	("Liam South", 2.99, "It should have some content at page 2"),
	("Liam South", 1.99, "It should have some content at page 7"),
	("Liam South", 4.99, "It should have some content at page 5"),
	("Liam South", 6.99, "It should have some content at page 1"),
	("Liam South", 3.99, "It should have some content at page 3"),
	("Liam South", 7.99, "It should have some content at page 4");

insert into User (password, name, age, Article_15_id) values
	("qweqwe1231", "Liam South", 7, 2),
	("qweqwe1232", "Liam South", 4, 5),
	("qweqwe1236", "Liam South", 6, 6),
	("qweqwe1234", "Liam South", 3, 3),
	("qweqwe1237", "Liam South", 2, 7),
	("qweqwe1235", "Liam South", 5, 1),
	("qweqwe1233", "Liam South", 1, 4);

insert into Tag_Article_15 (Article_15_id, Tag_id) values
	(3, 3),
	(1, 5),
	(2, 1),
	(4, 2),
	(7, 4),
	(5, 7),
	(6, 6);
