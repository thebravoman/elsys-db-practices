drop database if exists exam;
create database exam;
use exam;

create table Category (
	id int not null primary key auto_increment,
	date_created_on date,
	name varchar(256)
);

create table Tag (
	id int not null primary key auto_increment,
	description varchar(256),
	name varchar(256),
	Category_id int not null,
	foreign key (Category_id) references Category (id)
);

create table Article_15 (
	id int not null primary key auto_increment,
	name varchar(256),
	price float(5, 2),
	content varchar(1256)
);

create table User (
	id int not null primary key auto_increment,
	password varchar(256),
	name varchar(256),
	age int,
	Article_15_id int not null,
	foreign key (Article_15_id) references Article_15 (id)
);

create table Tag_Article_15 (
	id int not null primary key auto_increment,
	Article_15_id int not null,
	Tag_id int not null,
	foreign key (Article_15_id) references Article_15 (id),
	foreign key (Tag_id) references Tag (id)
);
