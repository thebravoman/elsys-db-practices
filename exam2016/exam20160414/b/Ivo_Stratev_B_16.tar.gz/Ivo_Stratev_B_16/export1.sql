-- MySQL dump 10.13  Distrib 5.5.47, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: exam
-- ------------------------------------------------------
-- Server version	5.5.47-0ubuntu0.14.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `Article_15`
--

DROP TABLE IF EXISTS `Article_15`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Article_15` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(256) DEFAULT NULL,
  `price` float(5,2) DEFAULT NULL,
  `content` varchar(1256) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Article_15`
--

LOCK TABLES `Article_15` WRITE;
/*!40000 ALTER TABLE `Article_15` DISABLE KEYS */;
INSERT INTO `Article_15` VALUES (1,'Liam South',5.99,'It should have some content at page 6'),(2,'Liam South',2.99,'It should have some content at page 2'),(3,'Liam South',1.99,'It should have some content at page 7'),(4,'Liam South',4.99,'It should have some content at page 5'),(5,'Liam South',6.99,'It should have some content at page 1'),(6,'Liam South',3.99,'It should have some content at page 3'),(7,'Liam South',7.99,'It should have some content at page 4');
/*!40000 ALTER TABLE `Article_15` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Category`
--

DROP TABLE IF EXISTS `Category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Category` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date_created_on` date DEFAULT NULL,
  `name` varchar(256) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Category`
--

LOCK TABLES `Category` WRITE;
/*!40000 ALTER TABLE `Category` DISABLE KEYS */;
INSERT INTO `Category` VALUES (1,'2016-04-01','Liam South'),(2,'2016-04-03','Liam South'),(3,'2016-04-02','Liam South'),(4,'2016-04-07','Liam South'),(5,'2016-04-04','Liam South'),(6,'2016-04-06','Liam South'),(7,'2016-04-05','Liam South');
/*!40000 ALTER TABLE `Category` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Tag`
--

DROP TABLE IF EXISTS `Tag`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Tag` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `description` varchar(256) DEFAULT NULL,
  `name` varchar(256) DEFAULT NULL,
  `Category_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `Category_id` (`Category_id`),
  CONSTRAINT `Tag_ibfk_1` FOREIGN KEY (`Category_id`) REFERENCES `Category` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Tag`
--

LOCK TABLES `Tag` WRITE;
/*!40000 ALTER TABLE `Tag` DISABLE KEYS */;
INSERT INTO `Tag` VALUES (1,'It should have some description at page 6','Liam South',3),(2,'It should have some description at page 5','Liam South',7),(3,'It should have some description at page 3','Liam South',6),(4,'It should have some description at page 1','Liam South',1),(5,'It should have some description at page 2','Liam South',2),(6,'It should have some description at page 4','Liam South',5),(7,'It should have some description at page 7','Liam South',4);
/*!40000 ALTER TABLE `Tag` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Tag_Article_15`
--

DROP TABLE IF EXISTS `Tag_Article_15`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Tag_Article_15` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `Article_15_id` int(11) NOT NULL,
  `Tag_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `Article_15_id` (`Article_15_id`),
  KEY `Tag_id` (`Tag_id`),
  CONSTRAINT `Tag_Article_15_ibfk_1` FOREIGN KEY (`Article_15_id`) REFERENCES `Article_15` (`id`),
  CONSTRAINT `Tag_Article_15_ibfk_2` FOREIGN KEY (`Tag_id`) REFERENCES `Tag` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Tag_Article_15`
--

LOCK TABLES `Tag_Article_15` WRITE;
/*!40000 ALTER TABLE `Tag_Article_15` DISABLE KEYS */;
INSERT INTO `Tag_Article_15` VALUES (1,3,3),(2,1,5),(3,2,1),(4,4,2),(5,7,4),(6,5,7),(7,6,6);
/*!40000 ALTER TABLE `Tag_Article_15` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `User`
--

DROP TABLE IF EXISTS `User`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `User` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `password` varchar(256) DEFAULT NULL,
  `name` varchar(256) DEFAULT NULL,
  `age` int(11) DEFAULT NULL,
  `Article_15_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `Article_15_id` (`Article_15_id`),
  CONSTRAINT `User_ibfk_1` FOREIGN KEY (`Article_15_id`) REFERENCES `Article_15` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `User`
--

LOCK TABLES `User` WRITE;
/*!40000 ALTER TABLE `User` DISABLE KEYS */;
INSERT INTO `User` VALUES (1,'qweqwe1231','Liam South',7,2),(2,'qweqwe1232','Liam South',4,5),(3,'qweqwe1236','Liam South',6,6),(4,'qweqwe1234','Liam South',3,3),(5,'qweqwe1237','Liam South',2,7),(6,'qweqwe1235','Liam South',5,1),(7,'qweqwe1233','Liam South',1,4);
/*!40000 ALTER TABLE `User` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2016-04-14  9:24:04
