#Which are the User(s) for a given Tag

use exam;

select User.id from User
inner join Article_15 on User.Article_15_id = Article_15.id
inner join Tag_Article_15 on Tag_Article_15.Article_15_id = Article_15.id
inner join Tag_part2 on Tag_Article_15.Tag_id = Tag_part2.id
where Tag_part2.id = 2;
