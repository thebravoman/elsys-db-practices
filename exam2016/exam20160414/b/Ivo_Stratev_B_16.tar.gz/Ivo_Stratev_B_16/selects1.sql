#Which are the Article_15(s) for a given Category

use exam;

select Article_15.id from Article_15
inner join Tag_Article_15 on Tag_Article_15.Article_15_id = Article_15.id
inner join Tag on  Tag_Article_15.Tag_id = Tag.id
inner join Category on Tag.Category_id = Category.id
where Category.id = 1;
