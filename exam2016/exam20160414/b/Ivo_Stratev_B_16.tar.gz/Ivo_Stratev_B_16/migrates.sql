use exam;

create table Tag_part1 (
	id int not null primary key auto_increment,
	name varchar(256)
);

insert into Tag_part1 (name) select name from Tag;
alter table Tag drop column name;
alter table Tag rename Tag_part2;
