use exam;


insert into Article_20 (Name, url, visible) values("Pesho", "pesho.com", 1);
insert into Article_20 (Name, url, visible) values("Gosho", "gosho.com", 0);
insert into Article_20 (Name, url, visible) values("Tosho", "tosho.com", 1);


insert into Category (Name, description) values("12345", "qwerty");
insert into Category (Name, description) values("67890", "asdfg");

insert into User (password, gender, income) values("qwerty", "male", 12);
insert into User (password, gender, income) values("asdfg", "female", 18);
insert into User (password, gender, income) values("zxcvb", "male", 126);

insert into Tag (name,second_priority) values("123", 123);
insert into Tag (name,second_priority) values("456", 456);
insert into Tag (name,second_priority) values("789", 789);
