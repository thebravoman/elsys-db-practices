use exam;


select * from User where Article_20.name = "123";
