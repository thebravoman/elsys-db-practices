drop database if exists exam;
create database exam;
use exam;


create table Article_20(
	id int primary key auto_increment,
	name varchar,
	url varchar,
	visible boolean
);

create table Category(
	id int primary key auto_increment,
	name varchar,
	description varchar
);

create table User(
	password varchar,
	gender varchar(6),
	income float
);

create table Tag(
	name varchar,
	second_priority float
)

alter table Article_20 add foreign key (id) references Category(id);
alter table Category add foreign key (id) references User(id);
alter table User add foreign key (id) references Tag(id);



