use exam;
CREATE TABLE User_part1(id INT(11) PRIMARY KEY NOT NULL AUTO_INCREMENT,age integer);
CREATE TABLE User_part2(id INT(11) PRIMARY KEY NOT NULL AUTO_INCREMENT,gender varchar(6),twitter varchar(255));
INSERT INTO User_part1(id,age) SELECT id,age FROM User;
INSERT INTO User_part2(id,gender,twitter) SELECT id,gender,twitter FROM User;
