drop database if exists exam;
create database exam;
use exam;

create table Article_27 (
	id int primary key auto_increment,
	created_on date,
	content longtext,
	price float
);

create table Category (
	id int primary key auto_increment,
	name varchar(255),
	description longtext
);

create table User (
	id int primary key auto_increment,
	age integer,
	twitter varchar(255),
	gender varchar(6)
);

create table Tag (
	id int primary key auto_increment,
	priority int,
	name varchar(255)
);

create table Category_User (
	id int primary key auto_increment,
	category_id int not null,
	user_id int not null,
	foreign key (category_id) references Category(id),
	foreign key (user_id) references User(id) 
);

alter table Tag add column user_id int;
alter table Tag add foreign key (user_id) references User(id);
create table Tag_Article_27 (
	id int primary key auto_increment,
	tag_id int not null,
	article_27_id int not null,
	foreign key (tag_id) references Tag(id),
	foreign key (article_27_id) references Article_27(id) 
);

