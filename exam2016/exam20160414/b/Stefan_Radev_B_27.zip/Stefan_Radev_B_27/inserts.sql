use exam;
INSERT INTO Article_27
	(content,created_on,price)
VALUES
	('Erebus','10/15/2016 10:06:1 PM',2.0),
	('Erebus','10/15/2016 10:06:1 PM',2.0),
	('Erebus','10/15/2016 10:06:1 PM',2.0),
	('Erebus','10/15/2016 10:06:1 PM',2.0),
	('Erebus','10/15/2016 10:06:1 PM',2.0);

INSERT INTO Category
	(name,description)
VALUES
	('Erebus','Erebus'),
	('Erebus','Erebus'),
	('Erebus','Erebus'),
	('Erebus','Erebus'),
	('Erebus','Erebus');

INSERT INTO User
	(gender,age,twitter)
VALUES
	('Erebus',1,'Erebus'),
	('Erebus',1,'Erebus'),
	('Erebus',1,'Erebus'),
	('Erebus',1,'Erebus'),
	('Erebus',1,'Erebus');

INSERT INTO Tag
	(priority,name,user_id)
VALUES
	(0,'Erebus',1),
	(0,'Erebus',2),
	(0,'Erebus',3),
	(0,'Erebus',4),
	(0,'Erebus',5);

INSERT INTO Category_User
	(category_id,user_id)
VALUES
(1,1),
(2,2),
(3,3),
(4,4),
(5,5);

INSERT INTO Tag_Article_27
	(tag_id,article_27_id)
VALUES
(1,1),
(2,2),
(3,3),
(4,4),
(5,5);

