
INSERT INTO Article_11
	(created_on,visible,password)
VALUES
	('1956-03-07 08:04:20',FALSE,'Here is some info'),
	('1956-03-07 08:04:20',FALSE,'Here is some info'),
	('1956-03-07 08:04:20',FALSE,'Here is some info'),
	('1956-03-07 08:04:20',FALSE,'Here is some info'),
	('1956-03-07 08:04:20',FALSE,'Here is some info');

INSERT INTO Category
	(date_created_on,description,article_id)
VALUES
	('1956-03-07 08:04:20','Here is some text... and more',1),
	('1956-03-07 08:04:20','Here is some text... and more',2),
	('1956-03-07 08:04:20','Here is some text... and more',3),
	('1956-03-07 08:04:20','Here is some text... and more',4),
	('1956-03-07 08:04:20','Here is some text... and more',5);

INSERT INTO Tag
	(hash,second_priority,category_id)
VALUES
	('Here is some info',45,1),
	('Here is some info',93,2),
	('Here is some info',47,3),
	('Here is some info',67,4),
	('Here is some info',48,5);

INSERT INTO User
	(description,age,gender,article_id)
VALUES
	('Here is some text... and more',41,'female',1),
	('Here is some text... and more',8,'female',2),
	('Here is some text... and more',19,'female',3),
	('Here is some text... and more',91,'female',4),
	('Here is some text... and more',38,'male',5);
