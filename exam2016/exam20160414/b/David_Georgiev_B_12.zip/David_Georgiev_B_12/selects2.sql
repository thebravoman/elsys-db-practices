SELECT Tag.id FROM Tag WHERE Tag.category_id IN (SELECT id FROM Category);
