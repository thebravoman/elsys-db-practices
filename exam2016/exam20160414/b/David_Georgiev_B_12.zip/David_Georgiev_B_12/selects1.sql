SELECT User.id FROM User WHERE User.article_id IN (SELECT article_id FROM Category);
