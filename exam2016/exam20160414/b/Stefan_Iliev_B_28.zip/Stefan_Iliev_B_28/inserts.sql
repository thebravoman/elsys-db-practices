use exam;
INSERT INTO Article_26
	(visible,created_on,price)
VALUES
	(TRUE,'10/15/2016 10:06:1 PM',2.0),
	(TRUE,'10/15/2016 10:06:1 PM',2.0),
	(TRUE,'10/15/2016 10:06:1 PM',2.0),
	(TRUE,'10/15/2016 10:06:1 PM',2.0),
	(TRUE,'10/15/2016 10:06:1 PM',2.0);

INSERT INTO User
	(gender,age,password)
VALUES
	('Erebus',1,'Erebus'),
	('Erebus',1,'Erebus'),
	('Erebus',1,'Erebus'),
	('Erebus',1,'Erebus'),
	('Erebus',1,'Erebus');

INSERT INTO Category
	(priority,created_by,user_id)
VALUES
	(0,'Erebus',1),
	(0,'Erebus',2),
	(0,'Erebus',3),
	(0,'Erebus',4),
	(0,'Erebus',5);

INSERT INTO Tag
	(second_priority,priority,article_26_id,category_id)
VALUES
	(0.0,1,1,1),
	(0.0,1,2,2),
	(0.0,1,3,3),
	(0.0,1,4,4),
	(0.0,1,5,5);

