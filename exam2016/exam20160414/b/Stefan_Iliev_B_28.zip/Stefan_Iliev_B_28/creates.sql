drop database if exists exam;
create database exam;
use exam;

create table Article_26 (
	id int primary key auto_increment,
	visible boolean,
	created_on date,
	price float
);

create table Category (
	id int primary key auto_increment,
	priority double,
	created_by varchar(255)
);

create table User (
	id int primary key auto_increment,
	gender varchar(6),
	age integer,
	password varchar(255)
);

create table Tag (
	id int primary key auto_increment,
	second_priority float,
	priority int
);

alter table Tag add column article_26_id int;
alter table Tag add foreign key (article_26_id) references Article_26(id);
alter table Tag add column category_id int;
alter table Tag add foreign key (category_id) references Category(id);
alter table Category add column user_id int unique;
alter table Category add foreign key (user_id) references User(id);

