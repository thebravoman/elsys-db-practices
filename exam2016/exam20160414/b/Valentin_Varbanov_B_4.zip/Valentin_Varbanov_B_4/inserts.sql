use exam;

insert into Article_2 (content,url,created_on)
values
('Sample text1','Sample text','2011-03-12'),
('Sample text2','Sample text','2011-03-12'),
('Sample text3','Sample text','2011-03-12'),
('Sample text4','Sample text','2011-03-12'),
('Sample text5','Sample text','2011-03-12');

insert into Category (date_created_on,created_by)
values
('2011-03-12','Sample text1'),
('2011-03-12','Sample text2'),
('2011-03-12','Sample text3'),
('2011-03-12','Sample text4'),
('2011-03-12','Sample text5');

insert into User (gender,twitter,name)
values
('male','Sample text','Sample text1'),
('female','Sample text','Sample text2'),
('female','Sample text','Sample text3'),
('female','Sample text','Sample text4'),
('female','Sample text','Sample text5');

insert into Tag (priority,name)
values
(1,'Sample text1'),
(2,'Sample text2'),
(1,'Sample text3'),
(5,'Sample text4'),
(1,'Sample text5');

insert into Category_User (category_id,user_id)
values
(1,1),
(2,2),
(3,3),
(4,4),
(5,5);

