use exam;

create table User_part1 (
	id int primary key auto_increment,
	twitter varchar(255)
);

insert into User_part1 (twitter) select twitter from User;
alter table User drop column twitter;
alter table User rename User_part2;