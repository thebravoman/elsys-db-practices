select tag.id, tag.name
from category 
inner join Category_user on category.id=Category_User.category_id
inner join user on user.id=category_user.user_id
inner join tag on user.tag_id=tag.id
where category.id = 1;
