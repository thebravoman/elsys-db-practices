drop database if exists exam;
create database exam;
use exam;

create table Article_2 (
	id int primary key auto_increment,
	content longtext,
	url varchar(255),
	created_on date
);

create table Category (
	id int primary key auto_increment,
	date_created_on date,
	created_by varchar(255)
);

create table User (
	id int primary key auto_increment,
	gender varchar(6),
	twitter varchar(255),
	name varchar(255)
);

create table Tag (
	id int primary key auto_increment,
	priority int,
	name varchar(255)
);

create table Category_User (
	id int primary key auto_increment,
	category_id int not null,
	user_id int not null,
	foreign key (category_id) references Category(id),
	foreign key (user_id) references User(id) 
);

alter table User add column tag_id int;
alter table User add foreign key (tag_id) references Tag(id);
alter table Tag add column article_2_id int unique;
alter table Tag add foreign key (article_2_id) references Article_2(id);

