select article_2.id
from article_2
inner join articletag on tag.article_2_id=article_2.id
inner join user_part2tag on tag.id=user.tag_id
where user.id = 2
