use exam;

insert into Article_14 (content,visible,published_on)
values
('Musala',TRUE,'2014-06-12 16:20:02'),
('Musala',TRUE,'2014-06-12 16:20:02'),
('Musala',TRUE,'2014-06-12 16:20:02'),
('Musala',TRUE,'2014-06-12 16:20:02'),
('Musala',TRUE,'2014-06-12 16:20:02');

insert into Category (priority,name)
values
(2.0,'Musala'),
(2.0,'Musala'),
(2.0,'Musala'),
(2.0,'Musala'),
(2.0,'Musala');

insert into User (gender,twitter,password)
values
('Musala','Musala','Musala'),
('Musala','Musala','Musala'),
('Musala','Musala','Musala'),
('Musala','Musala','Musala'),
('Musala','Musala','Musala');

insert into Tag (second_priority,name)
values
(2.0,'Musala'),
(2.0,'Musala'),
(2.0,'Musala'),
(2.0,'Musala'),
(2.0,'Musala');

insert into Category_Article_14 (category_id,article_14_id)
values
(1,1),
(2,2),
(3,3),
(4,4),
(5,5);

insert into Article_14_Tag (article_14_id,tag_id)
values
(1,1),
(2,2),
(3,3),
(4,4),
(5,5);

