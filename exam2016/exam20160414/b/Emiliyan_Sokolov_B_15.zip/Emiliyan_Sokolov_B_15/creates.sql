drop database if exists exam;
create database exam;
use exam;

create table Article_14 (
	id int primary key auto_increment,
	content longtext,
	visible boolean,
	published_on date
);

create table Category (
	id int primary key auto_increment,
	priority double,
	name varchar(255)
);

create table User (
	id int primary key auto_increment,
	gender varchar(6),
	twitter varchar(255),
	password varchar(255)
);

create table Tag (
	id int primary key auto_increment,
	second_priority float,
	name varchar(255)
);

create table Category_Article_14 (
	id int primary key auto_increment,
	category_id int not null,
	article_14_id int not null,
	foreign key (category_id) references Category(id),
	foreign key (article_14_id) references Article_14(id) 
);

create table Article_14_Tag (
	id int primary key auto_increment,
	article_14_id int not null,
	tag_id int not null,
	foreign key (article_14_id) references Article_14(id),
	foreign key (tag_id) references Tag(id) 
);

alter table Tag add column user_id int unique;
alter table Tag add foreign key (user_id) references User(id);

