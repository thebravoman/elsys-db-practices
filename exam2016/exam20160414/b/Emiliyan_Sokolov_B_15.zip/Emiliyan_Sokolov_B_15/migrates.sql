use exam;

create table Article_14_part1 (
	id int primary key auto_increment,
	content longtext
);

insert into Article_14_part1 (content) select content from Article_14;
alter table Article_14 drop column content;
alter table Article_14 rename Article_14_part2;