USE exam;

SELECT Tag.id, second_priority, Tag.description FROM Tag
JOIN Article_8 ON Article_8.tag_id = Tag.id

JOIN Category ON Category.id = User_Article_8.category_id
WHERE Category.id = 1;

