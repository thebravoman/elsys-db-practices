drop database if exists exam;
create database exam;
use exam;

create table Article_8 (
	id int primary key auto_increment,
	url varchar(255),
	password varchar(255),
	name varchar(255)
);

create table Category (
	id int primary key auto_increment,
	date_created_on date,
	description longtext
);

create table User (
	id int primary key auto_increment,
	twitter varchar(255),
	description longtext,
	name varchar(255)
);

create table Tag (
	id int primary key auto_increment,
	second_priority float,
	description varchar(255)
);

alter table Category add column user_id int;
alter table Category add foreign key (user_id) references User(id);
create table User_Tag (
	id int primary key auto_increment,
	user_id int not null,
	tag_id int not null,
	foreign key (user_id) references User(id),
	foreign key (tag_id) references Tag(id) 
);

alter table Tag add column article_8_id int unique;
alter table Tag add foreign key (article_8_id) references Article_8(id);

