use exam;
INSERT INTO Article_8
	(url,password,name)
VALUES
	('Erebus','Erebus','Erebus'),
	('Erebus','Erebus','Erebus'),
	('Erebus','Erebus','Erebus'),
	('Erebus','Erebus','Erebus'),
	('Erebus','Erebus','Erebus');

INSERT INTO User
	(twitter,description,name)
VALUES
	('vlady','eprosto','STRAHOTEN'),
	('Erebus','Erebus','Erebus'),
	('Erebus','Erebus','Erebus'),
	('Erebus','Erebus','Erebus'),
	('Erebus','Erebus','Erebus');

INSERT INTO Category
	(date_created_on,description,user_id)
VALUES
	('10/15/2016 10:06:0 PM','Erebus',1),
	('10/15/2016 10:06:0 PM','Erebus',2),
	('10/15/2016 10:06:0 PM','Erebus',3),
	('10/15/2016 10:06:0 PM','Erebus',4),
	('10/15/2016 10:06:0 PM','Erebus',5);

INSERT INTO Tag
	(second_priority,description,article_8_id)
VALUES
	(0.0,'Erebus',1),
	(0.0,'Erebus',2),
	(0.0,'Erebus',3),
	(0.0,'Erebus',4),
	(0.0,'Erebus',5);

INSERT INTO User_Tag
	(user_id,tag_id)
VALUES
(1,1),
(2,2),
(3,3),
(4,4),
(5,5);

