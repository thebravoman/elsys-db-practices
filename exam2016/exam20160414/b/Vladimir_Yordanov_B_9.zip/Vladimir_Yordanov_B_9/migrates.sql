use exam;
CREATE TABLE User_part1(id INT(11) PRIMARY KEY NOT NULL AUTO_INCREMENT,description longtext);
CREATE TABLE User_part2(id INT(11) PRIMARY KEY NOT NULL AUTO_INCREMENT,date_created_on date);
INSERT INTO User_part1(id,description) SELECT id,description FROM User;
INSERT INTO User_part2(id,date_created_on) SELECT id,date_created_on FROM User;
