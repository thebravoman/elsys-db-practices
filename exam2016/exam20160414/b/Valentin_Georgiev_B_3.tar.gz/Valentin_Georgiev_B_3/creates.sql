drop database if exists exam;
create database exam;
use exam;

create table Article_3 (
	id int primary key auto_increment,
	url varchar(255),
	visible boolean,
	created_on date
);

create table Category (
	id int primary key auto_increment,
	priority double,
	created_by varchar(255)
);

create table User (
	id int primary key auto_increment,
	gender varchar(6),
	twitter varchar(255),
	age integer
);

create table Tag (
	id int primary key auto_increment,
	hash varchar(16),
	description varchar(255)
);

alter table Article_3 add column tag_id int;
alter table Article_3 add foreign key (tag_id) references Tag(id);
alter table User add column tag_id int;
alter table User add foreign key (tag_id) references Tag(id);
alter table User add column category_id int;
alter table User add foreign key (category_id) references Category(id);
