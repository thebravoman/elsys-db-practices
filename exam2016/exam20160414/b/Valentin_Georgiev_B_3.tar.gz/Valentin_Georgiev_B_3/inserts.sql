use exam;
INSERT INTO Category
	(priority,created_by)
VALUES
	(0,'Erebus'),
	(0,'Erebus'),
	(0,'Erebus'),
	(0,'Erebus'),
	(0,'Erebus');

INSERT INTO Tag
	(hash,description)
VALUES
	('Erebus','Erebus'),
	('Erebus','Erebus'),
	('Erebus','Erebus'),
	('Erebus','Erebus'),
	('Erebus','Erebus');

INSERT INTO Article_3
	(url,visible,created_on,tag_id)
VALUES
	('Erebus',TRUE,'10/15/2016 10:06:2 PM',1),
	('Erebus',TRUE,'10/15/2016 10:06:2 PM',2),
	('Erebus',TRUE,'10/15/2016 10:06:2 PM',3),
	('Erebus',TRUE,'10/15/2016 10:06:2 PM',4),
	('Erebus',TRUE,'10/15/2016 10:06:2 PM',5);

INSERT INTO User
	(gender,twitter,age,tag_id,category_id)
VALUES
	('Erebus','Erebus',2,1,1),
	('Erebus','Erebus',2,2,2),
	('Erebus','Erebus',2,3,3),
	('Erebus','Erebus',2,4,4),
	('Erebus','Erebus',2,5,5);

