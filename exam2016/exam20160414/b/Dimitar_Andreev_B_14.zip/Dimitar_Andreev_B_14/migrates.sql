use exam;
CREATE TABLE Article_13_part1(id INT(11) PRIMARY KEY NOT NULL AUTO_INCREMENT,name varchar(255));
CREATE TABLE Article_13_part2(id INT(11) PRIMARY KEY NOT NULL AUTO_INCREMENT,content longtext,published_on date);
INSERT INTO Article_13_part1(id,name) SELECT id,name FROM Article_13;
INSERT INTO Article_13_part2(id,content,published_on) SELECT id,content,published_on FROM Article_13;
