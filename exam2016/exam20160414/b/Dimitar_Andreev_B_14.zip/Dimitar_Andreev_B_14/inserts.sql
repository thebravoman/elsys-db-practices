use exam;
INSERT INTO Category
	(name,created_by)
VALUES
	('Erebus','Erebus'),
	('Erebus','Erebus'),
	('Erebus','Erebus'),
	('Erebus','Erebus'),
	('Erebus','Erebus');

INSERT INTO Article_13
	(content,published_on,name,category_id)
VALUES
	('Erebus','10/15/2016 10:06:1 PM','Erebus',1),
	('Erebus','10/15/2016 10:06:1 PM','Erebus',2),
	('Erebus','10/15/2016 10:06:1 PM','Erebus',3),
	('Erebus','10/15/2016 10:06:1 PM','Erebus',4),
	('Erebus','10/15/2016 10:06:1 PM','Erebus',5);

INSERT INTO User
	(age,picture_url,created_on,article_13_id)
VALUES
	(0,'Erebus','10/15/2016 10:06:2 PM',1),
	(0,'Erebus','10/15/2016 10:06:2 PM',2),
	(0,'Erebus','10/15/2016 10:06:2 PM',3),
	(0,'Erebus','10/15/2016 10:06:2 PM',4),
	(0,'Erebus','10/15/2016 10:06:2 PM',5);

INSERT INTO Tag
	(hash,name,category_id)
VALUES
	('Erebus','Erebus',1),
	('Erebus','Erebus',2),
	('Erebus','Erebus',3),
	('Erebus','Erebus',4),
	('Erebus','Erebus',5);

