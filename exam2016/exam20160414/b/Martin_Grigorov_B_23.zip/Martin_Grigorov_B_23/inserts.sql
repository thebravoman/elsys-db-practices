use exam;
INSERT INTO Category
	(priority,date_created_on)
VALUES
	(2.0,'2016-02-07 13:06:11'),
	(2.0,'2016-02-07 13:06:11'),
	(2.0,'2016-02-07 13:06:11'),
	(2.0,'2016-02-07 13:06:11'),
	(2.0,'2016-02-07 13:06:11');

INSERT INTO User
	(picture_url,name,description)
VALUES
	('Erebus','Erebus','Erebus'),
	('Erebus','Erebus','Erebus'),
	('Erebus','Erebus','Erebus'),
	('Erebus','Erebus','Erebus'),
	('Erebus','Erebus','Erebus');

INSERT INTO Tag
	(priority,hash)
VALUES
	(0,'Erebus'),
	(0,'Erebus'),
	(0,'Erebus'),
	(0,'Erebus'),
	(0,'Erebus');

INSERT INTO Article_22
	(content,visible,published_on,category_id,user_id)
VALUES
	('Erebus',TRUE,'2016-02-07 13:06:11',1,1),
	('Erebus',TRUE,'2016-02-07 13:06:11',2,2),
	('Erebus',TRUE,'2016-02-07 13:06:11',3,3),
	('Erebus',TRUE,'2016-02-07 13:06:11',4,4),
	('Erebus',TRUE,'2016-02-07 13:06:11',5,5);

INSERT INTO User_Tag
	(user_id,tag_id)
VALUES
(1,1),
(2,2),
(3,3),
(4,4),
(5,5);

