use exam;
CREATE TABLE Article_22_part1(id INT(11) PRIMARY KEY NOT NULL AUTO_INCREMENT,content longtext);
CREATE TABLE Article_22_part2(id INT(11) PRIMARY KEY NOT NULL AUTO_INCREMENT,visible boolean,published_on date);
INSERT INTO Article_22_part1(id,content) SELECT id,content FROM Article_22;
INSERT INTO Article_22_part2(id,visible,published_on) SELECT id,visible,published_on FROM Article_22;
