SELECT User.id FROM User JOIN User_Tag 
ON User.id = User_Tag.user_id JOIN Tag 
ON User_Tag.tag_id = Tag.id JOIN Article_22 
ON Tag.article_22_id = Article_22.id 
WHERE Article_22.id = 2
