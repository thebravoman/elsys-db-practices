drop database if exists exam;
create database exam;
use exam;

create table Article_22 (
	id int primary key auto_increment,
	content longtext,
	visible boolean,
	published_on date
);

create table Category (
	id int primary key auto_increment,
	priority double,
	date_created_on date
);

create table User (
	id int primary key auto_increment,
	picture_url varchar(255),
	name varchar(255),
	description longtext
);

create table Tag (
	id int primary key auto_increment,
	priority int,
	hash varchar(16)
);

alter table Article_22 add column category_id int;
alter table Article_22 add foreign key (category_id) references Category(id);
alter table Article_22 add column user_id int;
alter table Article_22 add foreign key (user_id) references User(id);
create table User_Tag (
	id int primary key auto_increment,
	user_id int not null,
	tag_id int not null,
	foreign key (user_id) references User(id),
	foreign key (tag_id) references Tag(id) 
);

