use exam;
CREATE TABLE User_part1(id INT(11) PRIMARY KEY NOT NULL AUTO_INCREMENT,age integer);
CREATE TABLE User_part2(id INT(11) PRIMARY KEY NOT NULL AUTO_INCREMENT,gender varchar(6),password varchar(255));
INSERT INTO User_part1(id,age) SELECT id,age FROM User;
INSERT INTO User_part2(id,gender,password) SELECT id,gender,password FROM User;
