use exam;
INSERT INTO Article_7
	(url,created_on,price)
VALUES
	('Erebus','10/15/2016 10:06:1 PM',2.0),
	('Erebus','10/15/2016 10:06:1 PM',2.0),
	('Erebus','10/15/2016 10:06:1 PM',2.0),
	('Erebus','10/15/2016 10:06:1 PM',2.0),
	('Erebus','10/15/2016 10:06:1 PM',2.0);

INSERT INTO User
	(gender,age,password)
VALUES
	('Female',1,'Erebus'),
	('Female',1,'Erebus'),
	('Female',1,'Erebus'),
	('Male',1,'Erebus'),
	('Female',1,'Erebus');

INSERT INTO Category
	(description,name,user_id)
VALUES
	('Erebus','Erebus',1),
	('Erebus','Erebus',2),
	('Erebus','Erebus',3),
	('Erebus','Erebus',4),
	('Erebus','Erebus',5);

INSERT INTO Tag
	(second_priority,description,user_id,article_7_id)
VALUES
	(0.0,'Erebus',1,1),
	(0.0,'Erebus',2,2),
	(0.0,'Erebus',3,3),
	(0.0,'Erebus',4,4),
	(0.0,'Erebus',5,5);

