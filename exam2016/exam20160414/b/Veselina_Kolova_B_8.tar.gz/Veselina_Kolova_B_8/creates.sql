drop database if exists exam;
create database exam;
use exam;

create table Article_7 (
	id int primary key auto_increment,
	url varchar(255),
	created_on date,
	price float
);

create table Category (
	id int primary key auto_increment,
	description longtext,
	name varchar(255)
);

create table User (
	id int primary key auto_increment,
	gender varchar(6),
	age integer,
	password varchar(255)
);

create table Tag (
	id int primary key auto_increment,
	second_priority float,
	description varchar(255)
);

alter table Category add column user_id int unique;
alter table Category add foreign key (user_id) references User(id);

alter table Tag add column user_id int;
alter table Tag add foreign key (user_id) references User(id);
alter table Tag add column article_7_id int;
alter table Tag add foreign key (article_7_id) references Article_7(id);
