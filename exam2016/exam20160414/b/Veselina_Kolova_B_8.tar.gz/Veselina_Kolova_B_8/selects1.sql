/*
Which are the Tag(s) for a given Category
*/

SELECT Tag.id FROM Tag, Category
WHERE Tag.user_id = Category.user_id
AND Category.id = 1;
