/*
4. Answer the following question
Which are the User(s) for a given User
As a result SQL query must be created
Write the queries from points 4 in a file called selects1.sql

Which are the Article_7(s) for a given User
*/

SELECT Article_7.id FROM Article_7 JOIN Tag_User 
ON Article_7.id = Tag_Article_7.user_id JOIN Tag 
ON Tag_Article_7.tag_id = Tag.id JOIN User 
ON Tag.User_id = User.id 
WHERE User.id = 1;

