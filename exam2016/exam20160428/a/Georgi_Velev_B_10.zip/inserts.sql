use exam;
INSERT INTO Article_9
	(content,published_on,name)
VALUES
	('Erebus','2016-02-07 13:06:11','Erebus'),
	('Erebus','2016-02-07 13:06:11','Erebus'),
	('Erebus','2016-02-07 13:06:11','Erebus'),
	('Erebus','2016-02-07 13:06:11','Erebus'),
	('Erebus','2016-02-07 13:06:11','Erebus');

INSERT INTO Category
	(date_created_on,name)
VALUES
	('2016-02-07 13:06:11','Erebus'),
	('2016-02-07 13:06:11','Erebus'),
	('2016-02-07 13:06:11','Erebus'),
	('2016-02-07 13:06:11','Erebus'),
	('2016-02-07 13:06:11','Erebus');

INSERT INTO User
	(gender,description,income,tag_id)
VALUES
	('Erebus','Erebus',2.0,1),
	('Erebus','Erebus',2.0,2),
	('Erebus','Erebus',2.0,3),
	('Erebus','Erebus',2.0,4),
	('Erebus','Erebus',2.0,5);

INSERT INTO Tag
	(second_priority,hash,category_id)
VALUES
	(2.0,'Erebus',1),
	(2.0,'Erebus',2),
	(2.0,'Erebus',3),
	(2.0,'Erebus',4),
	(2.0,'Erebus',5);

INSERT INTO Category_Article_9
	(category_id,article_9_id)
VALUES
(1,1),
(2,2),
(3,3),
(4,4),
(5,5);

