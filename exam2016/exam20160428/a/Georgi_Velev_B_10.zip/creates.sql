drop database if exists exam;
create database exam;
use exam;

create table Article_9 (
	id int primary key auto_increment,
	content longtext,
	published_on date,
	name varchar(255)
);

create table Category (
	id int primary key auto_increment,
	date_created_on date,
	name varchar(255)
);

create table User (
	id int primary key auto_increment,
	gender varchar(6),
	description longtext,
	income float
);

create table Tag (
	id int primary key auto_increment,
	second_priority float,
	hash varchar(16)
);

alter table User add column tag_id int unique;
alter table User add foreign key (tag_id) references Tag(id);

alter table Tag add column category_id int;
alter table Tag add foreign key (category_id) references Category(id);
create table Category_Article_9 (
	id int primary key auto_increment,
	category_id int not null,
	article_9_id int not null,
	foreign key (category_id) references Category(id),
	foreign key (article_9_id) references Article_9(id) 
);

