use exam;

insert into Article_3 (password, published_on, price) values
	("qweqwe1232", "1989-05-11", 5.99),
	("qweqwe1235", "1989-06-11", 4.99),
	("qweqwe1236", "1989-04-11", 3.99),
	("qweqwe1233", "1989-03-11", 2.99),
	("qweqwe1234", "1989-02-11", 1.99),
	("qweqwe1231", "1989-01-11", 6.99);

insert into Category (name, created_by) values
	("Madison Ivy", "Madison Ivy"),
	("Maisy Scot", "Jacob Lawson"),
	("Mason Scot", "Liam South"),
	("Emma Watson", "Maisy Scot"),
	("Jacob Lawson", "Mason Scot"),
	("Liam South", "Emma Watson");

insert into User (picture_url, password, income, Category_id) values
	("http://imgur.com/gallery/gzr6BG", "qweqwe1235", 5.5, 4),
	("http://imgur.com/gallery/gzr4BG", "qweqwe1232", 3.3, 1),
	("http://imgur.com/gallery/gzr1BG", "qweqwe1236", 6.6, 3),
	("http://imgur.com/gallery/gzr3BG", "qweqwe1234", 2.2, 5),
	("http://imgur.com/gallery/gzr5BG", "qweqwe1233", 4.4, 6),
	("http://imgur.com/gallery/gzr2BG", "qweqwe1231", 1.1, 2);

insert into Tag (second_priority, hash, User_id) values
	(5.5, "9568243231902", 4),
	(4.4, "9568243231905", 3),
	(3.3, "9568243231904", 2),
	(2.2, "9568243231906", 1),
	(6.6, "9568243231903", 5),
	(1.1, "9568243231901", 6);

insert into Article_3_Category (Article_3_id, Category_id) values
	(3, 1),
	(1, 3),
	(4, 5),
	(5, 4),
	(2, 6),
	(6, 2);
