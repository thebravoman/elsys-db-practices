drop database if exists exam;
create database exam;
use exam;

create table Article_3 (
	id int not null primary key auto_increment,
	password varchar(256),
	published_on date,
	price float(5, 2)
);

create table Category (
	id int not null primary key auto_increment,
	name varchar(256),
	created_by varchar(256)
);

create table User (
	id int not null primary key auto_increment,
	picture_url varchar(256),
	password varchar(256),
	income float(8, 4),
	Category_id int not null,
	foreign key (Category_id) references Category (id)
);

create table Tag (
	id int not null primary key auto_increment,
	second_priority float(8, 4),
	hash varchar(16),
	User_id int not null,
	foreign key (User_id) references User (id)
);

create table Article_3_Category (
	id int not null primary key auto_increment,
	Article_3_id int not null,
	Category_id int not null,
	foreign key (Article_3_id) references Article_3 (id),
	foreign key (Category_id) references Category (id)
);
