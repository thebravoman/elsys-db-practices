use exam;

create table User_part1 (
	id int not null primary key auto_increment,
	password varchar(256)
);

insert into User_part1 (password) select password from User;
alter table User drop column password;
alter table User rename User_part2;
