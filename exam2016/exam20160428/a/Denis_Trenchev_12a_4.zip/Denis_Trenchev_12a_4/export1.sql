-- MySQL dump 10.13  Distrib 5.6.30, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: exam
-- ------------------------------------------------------
-- Server version	5.6.30-0ubuntu0.15.10.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `Article_3`
--

DROP TABLE IF EXISTS `Article_3`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Article_3` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `password` varchar(256) DEFAULT NULL,
  `published_on` date DEFAULT NULL,
  `price` float(5,2) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Article_3`
--

LOCK TABLES `Article_3` WRITE;
/*!40000 ALTER TABLE `Article_3` DISABLE KEYS */;
INSERT INTO `Article_3` VALUES (1,'qweqwe1232','1989-05-11',5.99),(2,'qweqwe1235','1989-06-11',4.99),(3,'qweqwe1236','1989-04-11',3.99),(4,'qweqwe1233','1989-03-11',2.99),(5,'qweqwe1234','1989-02-11',1.99),(6,'qweqwe1231','1989-01-11',6.99);
/*!40000 ALTER TABLE `Article_3` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Article_3_Category`
--

DROP TABLE IF EXISTS `Article_3_Category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Article_3_Category` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `Article_3_id` int(11) NOT NULL,
  `Category_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `Article_3_id` (`Article_3_id`),
  KEY `Category_id` (`Category_id`),
  CONSTRAINT `Article_3_Category_ibfk_1` FOREIGN KEY (`Article_3_id`) REFERENCES `Article_3` (`id`),
  CONSTRAINT `Article_3_Category_ibfk_2` FOREIGN KEY (`Category_id`) REFERENCES `Category` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Article_3_Category`
--

LOCK TABLES `Article_3_Category` WRITE;
/*!40000 ALTER TABLE `Article_3_Category` DISABLE KEYS */;
INSERT INTO `Article_3_Category` VALUES (1,3,1),(2,1,3),(3,4,5),(4,5,4),(5,2,6),(6,6,2);
/*!40000 ALTER TABLE `Article_3_Category` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Category`
--

DROP TABLE IF EXISTS `Category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Category` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(256) DEFAULT NULL,
  `created_by` varchar(256) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Category`
--

LOCK TABLES `Category` WRITE;
/*!40000 ALTER TABLE `Category` DISABLE KEYS */;
INSERT INTO `Category` VALUES (1,'Madison Ivy','Madison Ivy'),(2,'Maisy Scot','Jacob Lawson'),(3,'Mason Scot','Liam South'),(4,'Emma Watson','Maisy Scot'),(5,'Jacob Lawson','Mason Scot'),(6,'Liam South','Emma Watson');
/*!40000 ALTER TABLE `Category` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Tag`
--

DROP TABLE IF EXISTS `Tag`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Tag` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `second_priority` float(8,4) DEFAULT NULL,
  `hash` varchar(16) DEFAULT NULL,
  `User_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `User_id` (`User_id`),
  CONSTRAINT `Tag_ibfk_1` FOREIGN KEY (`User_id`) REFERENCES `User` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Tag`
--

LOCK TABLES `Tag` WRITE;
/*!40000 ALTER TABLE `Tag` DISABLE KEYS */;
INSERT INTO `Tag` VALUES (1,5.5000,'9568243231902',4),(2,4.4000,'9568243231905',3),(3,3.3000,'9568243231904',2),(4,2.2000,'9568243231906',1),(5,6.6000,'9568243231903',5),(6,1.1000,'9568243231901',6);
/*!40000 ALTER TABLE `Tag` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `User`
--

DROP TABLE IF EXISTS `User`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `User` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `picture_url` varchar(256) DEFAULT NULL,
  `password` varchar(256) DEFAULT NULL,
  `income` float(8,4) DEFAULT NULL,
  `Category_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `Category_id` (`Category_id`),
  CONSTRAINT `User_ibfk_1` FOREIGN KEY (`Category_id`) REFERENCES `Category` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `User`
--

LOCK TABLES `User` WRITE;
/*!40000 ALTER TABLE `User` DISABLE KEYS */;
INSERT INTO `User` VALUES (1,'http://imgur.com/gallery/gzr6BG','qweqwe1235',5.5000,4),(2,'http://imgur.com/gallery/gzr4BG','qweqwe1232',3.3000,1),(3,'http://imgur.com/gallery/gzr1BG','qweqwe1236',6.6000,3),(4,'http://imgur.com/gallery/gzr3BG','qweqwe1234',2.2000,5),(5,'http://imgur.com/gallery/gzr5BG','qweqwe1233',4.4000,6),(6,'http://imgur.com/gallery/gzr2BG','qweqwe1231',1.1000,2);
/*!40000 ALTER TABLE `User` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2016-04-28 11:48:49
