use exam;

insert into Article_12 (visible,created_on,published_on)
values
(TRUE,'2016-04-28 13:00:00','2016-04-28 13:05:00'),
(TRUE,'2016-02-07 22:22:11','2016-02-07 23:00:11'),
(TRUE,'2016-02-07 10:10:00','2016-02-07 10:50:00'),
(TRUE,'2016-02-07 01:20:25','2016-02-07 02:20:25'),
(TRUE,'2016-02-07 12:40:40','2016-02-07 13:40:40');

insert into Category (description,created_by)
values
('Description','Author'),
('Description','Author'),
('Description','Author'),
('Description','Author'),
('Description','Author');

insert into User (age,created_on,twitter)
values
(1,'2016-04-28 13:00:00','twitter'),
(1,'2016-04-28 13:00:00','twitter'),
(1,'2016-04-28 13:00:00','twitter'),
(1,'2016-04-28 13:00:00','twitter'),
(1,'2016-04-28 13:00:00','twitter');

insert into Tag (priority,hash)
values
(1,'Hash'),
(1,'Hash'),
(1,'Hash'),
(1,'Hash'),
(1,'Hash');

insert into Tag_Category (category_id,tag_id)
values
(1,1),
(2,2),
(3,3),
(4,4),
(5,5);