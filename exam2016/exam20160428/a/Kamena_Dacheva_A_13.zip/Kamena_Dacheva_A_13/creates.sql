drop database if exists exam;
create database exam;
use exam;

create table Article_12 (
	id int primary key auto_increment,
	visible boolean,
	created_on date,
	published_on date
);

create table Category (
	id int primary key auto_increment,
	description longtext,
	created_by varchar(255)
);

create table User (
	id int primary key auto_increment,
	age integer,
	created_on date,
	twitter varchar(255)
);

create table Tag (
	id int primary key auto_increment,
	priority int,
	hash varchar(16)
);

create table Tag_Category (
	id int primary key auto_increment,
	tag_id int not null,
	category_id int not null,
	foreign key (tag_id) references Tag(id),
	foreign key (category_id) references Category(id) 
);

alter table User add column category_id int;
alter table User add foreign key (category_id) references Category(id);
alter table Article_12 add column user_id int;
alter table Article_12 add foreign key (user_id) references User(id);
