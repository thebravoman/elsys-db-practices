SELECT User.id FROM User
JOIN Tag_Category ON Tag_Category.category_id = User. category_id
JOIN Tag ON Tag_Category.tag_id = Tag.id
WHERE Tag.id = 1;