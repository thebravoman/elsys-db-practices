use exam;

create table Category_part1 (
	id int primary key auto_increment,
	created_by varchar(255)
);

insert into Category_part1 (created_by) select created_by from Category;
alter table Category drop column created_by;
alter table Category rename Category_part2;