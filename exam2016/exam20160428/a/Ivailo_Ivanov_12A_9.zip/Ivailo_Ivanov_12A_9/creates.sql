drop database if exists exam;
create database exam;
use exam;

create table Article_8 (
	id int primary key auto_increment,
	content longtext,
	published_on date,
	created_on date
);

create table Category (
	id int primary key auto_increment,
	date_created_on date,
	name varchar(255)
);

create table User (
	id int primary key auto_increment,
	twitter varchar(255),
	name varchar(255),
	description longtext
);

create table Tag (
	id int primary key auto_increment,
	hash varchar(16),
	name varchar(255)
);

alter table User add column category_id int unique;
alter table User add foreign key (category_id) references Category(id);

alter table Tag add column category_id int;
alter table Tag add foreign key (category_id) references Category(id);
create table Tag_Article_8 (
	id int primary key auto_increment,
	tag_id int not null,
	article_8_id int not null,
	foreign key (tag_id) references Tag(id),
	foreign key (article_8_id) references Article_8(id) 
);

