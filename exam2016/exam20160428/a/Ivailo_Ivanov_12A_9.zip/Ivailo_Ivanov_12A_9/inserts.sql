use exam;
INSERT INTO Article_8
	(content,published_on,created_on)
VALUES
	('Erebus','2016-02-07 13:06:11','2016-02-07 13:06:11'),
	('Erebus','2016-02-07 13:06:11','2016-02-07 13:06:11'),
	('Erebus','2016-02-07 13:06:11','2016-02-07 13:06:11'),
	('Erebus','2016-02-07 13:06:11','2016-02-07 13:06:11'),
	('Erebus','2016-02-07 13:06:11','2016-02-07 13:06:11');

INSERT INTO Category
	(date_created_on,name)
VALUES
	('2016-02-07 13:06:11','Erebus'),
	('2016-02-07 13:06:11','Erebus'),
	('2016-02-07 13:06:11','Erebus'),
	('2016-02-07 13:06:11','Erebus'),
	('2016-02-07 13:06:11','Erebus');

INSERT INTO User
	(twitter,name,description,category_id)
VALUES
	('Erebus','Erebus','Erebus',1),
	('Erebus','Erebus','Erebus',2),
	('Erebus','Erebus','Erebus',3),
	('Erebus','Erebus','Erebus',4),
	('Erebus','Erebus','Erebus',5);

INSERT INTO Tag
	(hash,name,category_id)
VALUES
	('Erebus','Erebus',1),
	('Erebus','Erebus',2),
	('Erebus','Erebus',3),
	('Erebus','Erebus',4),
	('Erebus','Erebus',5);

INSERT INTO Tag_Article_8
	(tag_id,article_8_id)
VALUES
(1,1),
(2,2),
(3,3),
(4,4),
(5,5);

