-- create table Article_20 (
--   article_20_id int(5),
--   price float(5),
--   password varchar(64),
--   created_on timestamp,
--   primary key (article_20_id)
-- );
-- alter table Article_20 add column tag_id int(5);

-- create table Category (
--   category_id int(5),
--   date_created_on timestamp,
--   description longtext,
--   primary key (category_id)
-- );

-- create table User (
--   user_id int(5),
--   description longtext,
--   created_on timestamp,
--   name varchar(64),
--   primary key (user_id)
-- );
-- alter table User add column tag_id int(5);

-- create table Tag(
--   tag_id int(5),
--   name varchar(64),
--   second_priority varchar(5),
--   primary key (tag_id)
-- );
-- alter table Tag add column user_id int(5);
-- alter table Tag add column article_20_id int(5);

-- create table Category_User(
--     c_u_id int(5),
--     category_id int(5),
--     user_id int(5),
--     primary key (c_u_id),
--     foreign key (category_id) references Category(category_id),
--     foreign key (user_id) references User(user_id)
-- );

insert into Article_20
	(article_20_id, price, password, tag_id)
values(1, 25.2, "kvo stava", 1);

insert into Article_20
	(article_20_id, price, password, tag_id)
values(2, 52.2, "kak e", 2);

insert into Category
	(category_id, description)
values(1, "Dobar den evropa");

insert into Category
	(category_id, description)
values(2, "Lele kak she te prebiqt v bopa");

insert into User
	(user_id, description, name, tag_id)
values(1, "haha Da mu mislqt gospodata", "Echo123", 1);

insert into User
	(user_id, description, name, tag_id)
values(2, "haha", "Cecho123", 2);

insert into Tag
	(tag_id, name, second_priority, user_id, article_20_id)
values(1, "hahaha", "1", 1, 1);

insert into Tag
	(tag_id, name, second_priority, user_id, article_20_id)
values(2, "AGAGSA", "2", 2, 2);

insert into Category_User(c_u_id, category_id, user_id) 
	values(1, 1, 1);

insert into Category_User(c_u_id, category_id, user_id) 
	values(2, 2, 2);
