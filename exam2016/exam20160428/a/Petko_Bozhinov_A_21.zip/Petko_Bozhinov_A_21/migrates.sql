-- Separate User on two tables
-- User_part1 containing description
-- User_part2 containing all the other fields

create table User_part1 (
	user_id int(5),
	description longtext,
	primary key (user_id)
);

create table User_part2 (
	user_id int(5),
	created_on timestamp,
  	name varchar(64),
	primary key (user_id)
);

insert into User_part1(user_id, description) 
	select user_id, description
	from User;

insert into User_part2(user_id, created_on, name) 
	select user_id, created_on, name
	from User;
