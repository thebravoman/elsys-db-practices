-- Which are the Article_20(s) for a given User

select Article_20.article_20_id
from Article_20
inner join Tag
on Article_20.tag_id = Tag.tag_id
inner join User
on Tag.user_id = User.user_id
where User.user_id = 1;