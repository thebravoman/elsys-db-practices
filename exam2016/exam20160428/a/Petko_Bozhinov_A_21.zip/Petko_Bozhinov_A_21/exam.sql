-- phpMyAdmin SQL Dump
-- version 4.4.13.1deb1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: 28 апр 2016 в 11:43
-- Версия на сървъра: 5.6.27-0ubuntu1
-- PHP Version: 5.6.11-1ubuntu3.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `exam`
--

-- --------------------------------------------------------

--
-- Структура на таблица `Article_20`
--

CREATE TABLE IF NOT EXISTS `Article_20` (
  `article_20_id` int(5) NOT NULL DEFAULT '0',
  `price` float DEFAULT NULL,
  `password` varchar(64) DEFAULT NULL,
  `created_on` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `tag_id` int(5) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Схема на данните от таблица `Article_20`
--

INSERT INTO `Article_20` (`article_20_id`, `price`, `password`, `created_on`, `tag_id`) VALUES
(1, 25.2, 'kvo stava', '2016-04-28 08:38:44', 1),
(2, 52.2, 'kak e', '2016-04-28 08:38:44', 2);

-- --------------------------------------------------------

--
-- Структура на таблица `Category`
--

CREATE TABLE IF NOT EXISTS `Category` (
  `category_id` int(5) NOT NULL DEFAULT '0',
  `date_created_on` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `description` longtext
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Схема на данните от таблица `Category`
--

INSERT INTO `Category` (`category_id`, `date_created_on`, `description`) VALUES
(1, '2016-04-28 08:38:44', 'Dobar den evropa'),
(2, '2016-04-28 08:38:45', 'Lele kak she te prebiqt v bopa');

-- --------------------------------------------------------

--
-- Структура на таблица `Category_User`
--

CREATE TABLE IF NOT EXISTS `Category_User` (
  `c_u_id` int(5) NOT NULL DEFAULT '0',
  `category_id` int(5) DEFAULT NULL,
  `user_id` int(5) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Схема на данните от таблица `Category_User`
--

INSERT INTO `Category_User` (`c_u_id`, `category_id`, `user_id`) VALUES
(1, 1, 1),
(2, 2, 2);

-- --------------------------------------------------------

--
-- Структура на таблица `Tag`
--

CREATE TABLE IF NOT EXISTS `Tag` (
  `tag_id` int(5) NOT NULL DEFAULT '0',
  `name` varchar(64) DEFAULT NULL,
  `second_priority` varchar(5) DEFAULT NULL,
  `user_id` int(5) DEFAULT NULL,
  `article_20_id` int(5) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Схема на данните от таблица `Tag`
--

INSERT INTO `Tag` (`tag_id`, `name`, `second_priority`, `user_id`, `article_20_id`) VALUES
(1, 'hahaha', '1', 1, 1),
(2, 'AGAGSA', '2', 2, 2);

-- --------------------------------------------------------

--
-- Структура на таблица `User`
--

CREATE TABLE IF NOT EXISTS `User` (
  `user_id` int(5) NOT NULL DEFAULT '0',
  `description` longtext,
  `created_on` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `name` varchar(64) DEFAULT NULL,
  `tag_id` int(5) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Схема на данните от таблица `User`
--

INSERT INTO `User` (`user_id`, `description`, `created_on`, `name`, `tag_id`) VALUES
(1, 'haha Da mu mislqt gospodata', '2016-04-28 08:38:45', 'Echo123', 1),
(2, 'haha', '2016-04-28 08:38:45', 'Cecho123', 2);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `Article_20`
--
ALTER TABLE `Article_20`
  ADD PRIMARY KEY (`article_20_id`);

--
-- Indexes for table `Category`
--
ALTER TABLE `Category`
  ADD PRIMARY KEY (`category_id`);

--
-- Indexes for table `Category_User`
--
ALTER TABLE `Category_User`
  ADD PRIMARY KEY (`c_u_id`),
  ADD KEY `category_id` (`category_id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `Tag`
--
ALTER TABLE `Tag`
  ADD PRIMARY KEY (`tag_id`);

--
-- Indexes for table `User`
--
ALTER TABLE `User`
  ADD PRIMARY KEY (`user_id`);

--
-- Ограничения за дъмпнати таблици
--

--
-- Ограничения за таблица `Category_User`
--
ALTER TABLE `Category_User`
  ADD CONSTRAINT `Category_User_ibfk_1` FOREIGN KEY (`category_id`) REFERENCES `Category` (`category_id`),
  ADD CONSTRAINT `Category_User_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `User` (`user_id`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
