select Tag.tag_id
from Tag
inner join User
on Tag.tag_id = User.tag_id
inner join Category_User
on User.user_id = Category_User.user_id;