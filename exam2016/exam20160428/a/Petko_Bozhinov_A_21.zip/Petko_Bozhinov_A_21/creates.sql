-- Category has a many to many connection to User
-- User has a one to one connection to Tag
-- Tag has a one to one connection to Article_20

drop database if exists exam;
create database exam;
use exam;

create table Article_20 (
  article_20_id int(5),
  price float(5),
  password varchar(64),
  created_on timestamp,
  primary key (article_20_id)
);

create table Category (
  category_id int(5),
  date_created_on timestamp,
  description longtext,
  primary key (category_id)
);

create table User (
  user_id int(5),
  description longtext,
  created_on timestamp,
  name varchar(64),
  primary key (user_id)
);

create table Tag(
  tag_id int(5),
  name varchar(64),
  second_priority varchar(5),
  primary key (tag_id)
);

create table Category_User(
    c_u_id int(5),
    category_id int(5),
    user_id int(5),
    primary key (c_u_id),
    foreign key (category_id) references Category(category_id),
    foreign key (user_id) references User(user_id)
);

alter table User add column tag_id int(5);
alter table Tag add column user_id int(5);

alter table Article_20 add column tag_id int(5);
alter table Tag add column article_20_id int(5);