use exam;

select Category.id from Category
inner join Category_User on Category_User.Category_id = Category.id
inner join User on Category_User.User_id = User.id
inner join Tag_User on Tag_User.User_id = User.id
inner join Tag_part2 on Tag_User.Tag_id = Tag_part2.id
where Tag_part2.id = 2;
