use exam;

select User.id from User
inner join Tag_User on Tag_User.User_id = User.id
inner join Tag on Tag_User.Tag_id = Tag.id
inner join Article_5 on Article_5.Tag_id = Tag.id
where Article_5.id = 3;
