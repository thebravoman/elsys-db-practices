Create table Category (id INT NOT NULL PRIMARY KEY, description text);
INSERT INTO Category_part1 (id , description)  
SELECT Category.id, Category.description
FROM Category;

RENAME TABLE Category to Category_part2;
ALTER TABLE Category_part2 drop column description;