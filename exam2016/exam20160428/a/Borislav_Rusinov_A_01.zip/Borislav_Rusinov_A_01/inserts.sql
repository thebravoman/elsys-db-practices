insert into Article_0 (id,visible,content, password) values (1,true,"goshko","1233");
insert into Category (id, description, created_by) values (1,"gosho","2017-02-01");
insert into User (id, password, gender, picture_url) values (1,"asdffsa","male","sad.fas");
insert into Tag (id, priority, hash) values (1,2, "pesho");
insert into Article_0 (id,visible,content, password) values (2,false,"petur","2233");
insert into Category (id, description, created_by) values (2,"goshosw","2017-03-01");
insert into User (id, password, gender, picture_url) values (2,"sasfsa","female","asad.fas");
insert into Tag (id, priority, hash) values (2,3, "bb");

insert into user_tag(user_id,tag_id) values (1,1);
insert into user_tag(user_id,tag_id) values (2,2);