select User.id from User inner join user_tag on User.id=user_tag.user_id inner join Tag on user_tag.tag_id=Tag.id 
inner join Category on Tag.id=Category.id where Category.id=2;