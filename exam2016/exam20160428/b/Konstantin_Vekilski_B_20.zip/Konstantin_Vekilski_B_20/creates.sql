drop database if exists exam;
create database exam;
use exam;

create table Article_20 (
	id int primary key auto_increment,
	content longtext,
	visible boolean,
	password varchar(255)
);

create table Category (
	id int primary key auto_increment,
	priority double,
	created_by varchar(255)
);

create table User (
	id int primary key auto_increment,
	gender varchar(6),
	picture_url varchar(255),
	income float
);

create table Tag (
	id int primary key auto_increment,
	description varchar(255),
	name varchar(255)
);

alter table Article_20 add column tag_id int;
alter table Article_20 add foreign key (tag_id) references Tag(id);
alter table Tag add column user_id int unique;
alter table Tag add foreign key (user_id) references User(id);

alter table User add column category_id int unique;
alter table User add foreign key (category_id) references Category(id);

