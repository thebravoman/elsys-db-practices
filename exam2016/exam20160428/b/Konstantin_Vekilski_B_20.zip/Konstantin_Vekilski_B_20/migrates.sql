use exam;

create table Tag_part1 (
	id int primary key auto_increment,
	description varchar(255)
);

insert into Tag_part1 (description) select description from Tag;
alter table Tag drop column description;
alter table Tag rename Tag_part2;