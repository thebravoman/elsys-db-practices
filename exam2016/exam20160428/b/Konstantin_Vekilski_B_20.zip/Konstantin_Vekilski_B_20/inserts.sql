use exam;

insert into Article_20 (content,visible,password)
values
('Dont worry be happy!',TRUE,'Go home and sleep!'),
('Dont worry be happy!',TRUE,'Go home and sleep!'),
('Dont worry be happy!',TRUE,'Go home and sleep!'),
('Dont worry be happy!',TRUE,'Go home and sleep!'),
('Dont worry be happy!',TRUE,'Go home and sleep!');

insert into Category (priority,created_by)
values
(2.0,'Go home and sleep!'),
(2.0,'Go home and sleep!'),
(2.0,'Go home and sleep!'),
(2.0,'Go home and sleep!'),
(2.0,'Go home and sleep!');

insert into User (gender,picture_url,income)
values
('male','Go home and sleep!',2.0),
('male','Go home and sleep!',2.0),
('male','Go home and sleep!',2.0),
('male','Go home and sleep!',2.0),
('male','Go home and sleep!',2.0);

insert into Tag (description,name)
values
('Go home and sleep!','Go home and sleep!'),
('Go home and sleep!','Go home and sleep!'),
('Go home and sleep!','Go home and sleep!'),
('Go home and sleep!','Go home and sleep!'),
('Go home and sleep!','Go home and sleep!');

