select user.id from user where Article_20.id = 1 and Tag.user_id = user.id and Article_20.tag_id = Tag.id;
