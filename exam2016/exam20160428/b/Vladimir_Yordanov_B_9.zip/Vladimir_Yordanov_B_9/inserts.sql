use exam;
INSERT INTO Article_8
	(url,content,name)
VALUES
	('Erebus','Erebus','Erebus'),
	('Erebus','Erebus','Erebus'),
	('Erebus','Erebus','Erebus'),
	('Erebus','Erebus','Erebus'),
	('Erebus','Erebus','Erebus');

INSERT INTO Category
	(name,created_by)
VALUES
	('Erebus','Erebus'),
	('Erebus','Erebus'),
	('Erebus','Erebus'),
	('Erebus','Erebus'),
	('Erebus','Erebus');

INSERT INTO User
	(age,password,created_on)
VALUES
	(0,'Erebus','2016-02-07 13:06:11'),
	(0,'Erebus','2016-02-07 13:06:11'),
	(0,'Erebus','2016-02-07 13:06:11'),
	(0,'Erebus','2016-02-07 13:06:11'),
	(0,'Erebus','2016-02-07 13:06:11');

INSERT INTO Tag
	(priority,name,article_8_id)
VALUES
	(0,'Erebus',1),
	(0,'Erebus',2),
	(0,'Erebus',3),
	(0,'Erebus',4),
	(0,'Erebus',5);

INSERT INTO User_Article_8
	(user_id,article_8_id)
VALUES
(1,1),
(2,2),
(3,3),
(4,4),
(5,5);

INSERT INTO Tag_Category
	(tag_id,category_id)
VALUES
(1,1),
(2,2),
(3,3),
(4,4),
(5,5);

