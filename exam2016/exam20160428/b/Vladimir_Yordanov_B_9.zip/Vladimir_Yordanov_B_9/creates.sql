drop database if exists exam;
create database exam;
use exam;

create table Article_8 (
	id int primary key auto_increment,
	url varchar(255),
	content longtext,
	name varchar(255)
);

create table Category (
	id int primary key auto_increment,
	name varchar(255),
	created_by varchar(255)
);

create table User (
	id int primary key auto_increment,
	age integer,
	password varchar(255),
	created_on date
);

create table Tag (
	id int primary key auto_increment,
	priority int,
	name varchar(255)
);

create table User_Article_8 (
	id int primary key auto_increment,
	user_id int not null,
	article_8_id int not null,
	foreign key (user_id) references User(id),
	foreign key (article_8_id) references Article_8(id) 
);

alter table Tag add column article_8_id int;
alter table Tag add foreign key (article_8_id) references Article_8(id);
create table Tag_Category (
	id int primary key auto_increment,
	tag_id int not null,
	category_id int not null,
	foreign key (tag_id) references Tag(id),
	foreign key (category_id) references Category(id) 
);

