use exam;
CREATE TABLE Article_8_part1(id INT(11) PRIMARY KEY NOT NULL AUTO_INCREMENT,content longtext);
CREATE TABLE Article_8_part2(id INT(11) PRIMARY KEY NOT NULL AUTO_INCREMENT,url varchar(255),name varchar(255));
INSERT INTO Article_8_part1(id,content) SELECT id,content FROM Article_8;
INSERT INTO Article_8_part2(id,url,name) SELECT id,url,name FROM Article_8;
