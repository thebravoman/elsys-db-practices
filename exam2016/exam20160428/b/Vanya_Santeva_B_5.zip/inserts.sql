use exam;
INSERT INTO Category
	(description,name)
VALUES
	('Erebus','Erebus'),
	('Erebus','Erebus'),
	('Erebus','Erebus'),
	('Erebus','Erebus'),
	('Erebus','Erebus');

INSERT INTO User
	(gender,created_on,picture_url)
VALUES
	('Erebus','2016-02-07 13:06:11','Erebus'),
	('Erebus','2016-02-07 13:06:11','Erebus'),
	('Erebus','2016-02-07 13:06:11','Erebus'),
	('Erebus','2016-02-07 13:06:11','Erebus'),
	('Erebus','2016-02-07 13:06:11','Erebus');

INSERT INTO Article_4
	(created_on,published_on,name,user_id)
VALUES
	('2016-02-07 13:06:11','2016-02-07 13:06:11','Erebus',1),
	('2016-02-07 13:06:11','2016-02-07 13:06:11','Erebus',2),
	('2016-02-07 13:06:11','2016-02-07 13:06:11','Erebus',3),
	('2016-02-07 13:06:11','2016-02-07 13:06:11','Erebus',4),
	('2016-02-07 13:06:11','2016-02-07 13:06:11','Erebus',5);

INSERT INTO Tag
	(second_priority,name,category_id)
VALUES
	(2.0,'Erebus',1),
	(2.0,'Erebus',2),
	(2.0,'Erebus',3),
	(2.0,'Erebus',4),
	(2.0,'Erebus',5);

INSERT INTO Category_User
	(category_id,user_id)
VALUES
(1,1),
(2,2),
(3,3),
(4,4),
(5,5);

