drop database if exists exam;
create database exam;
use exam;

create table Article_4 (
	id int primary key auto_increment,
	created_on date,
	published_on date,
	name varchar(255)
);

create table Category (
	id int primary key auto_increment,
	description longtext,
	name varchar(255)
);

create table User (
	id int primary key auto_increment,
	gender varchar(6),
	created_on date,
	picture_url varchar(255)
);

create table Tag (
	id int primary key auto_increment,
	second_priority float,
	name varchar(255)
);

alter table Tag add column category_id int unique;
alter table Tag add foreign key (category_id) references Category(id);

create table Category_User (
	id int primary key auto_increment,
	category_id int not null,
	user_id int not null,
	foreign key (category_id) references Category(id),
	foreign key (user_id) references User(id) 
);

alter table Article_4 add column user_id int;
alter table Article_4 add foreign key (user_id) references User(id);
