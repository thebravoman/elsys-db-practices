USE exam;

INSERT INTO Article_5 (price, password)
VALUES (10, "12354567"),
(1000, "0093030");

INSERT INTO Category (description, priority)
VALUES ("des1", 3.1),
("des2", 14.5);

INSERT INTO User (gender, description, name)
VALUES ("male", "des1", "Gosho"),
("female", "des2", "Pesho");

INSERT INTO Tag (name, description)
VALUES ("Action", "Kicks and punches"),
("Adventure", "Tents and monsters");

INSERT INTO ArticleCategory (article, category)
VALUES (1, 1),
(1, 2);

INSERT INTO CategoryTag (category, tag)
VALUES (2, 1),
(1, 2);

INSERT INTO TagUser (tag, user)
VALUES (2, 1),
(1, 1);

