drop database if exists exam;
create database exam;
use exam;

create table Article_24 (
	id int primary key auto_increment,
	url varchar(255),
	content longtext,
	name varchar(255)
);

create table Category (
	id int primary key auto_increment,
	priority double,
	date_created_on date
);

create table User (
	id int primary key auto_increment,
	age integer,
	created_on date,
	name varchar(255)
);

create table Tag (
	id int primary key auto_increment,
	second_priority float,
	description varchar(255)
);

alter table Article_24 add column user_id int;
alter table Article_24 add foreign key (user_id) references User(id);
create table Article_24_Category (
	id int primary key auto_increment,
	article_24_id int not null,
	category_id int not null,
	foreign key (article_24_id) references Article_24(id),
	foreign key (category_id) references Category(id) 
);

alter table Category add column tag_id int;
alter table Category add foreign key (tag_id) references Tag(id);
