use exam;
INSERT INTO User
	(age,created_on,name)
VALUES
	(0,'10/15/2016 10:06:1 PM','Erebus'),
	(0,'10/15/2016 10:06:1 PM','Erebus'),
	(0,'10/15/2016 10:06:1 PM','Erebus'),
	(0,'10/15/2016 10:06:1 PM','Erebus'),
	(0,'10/15/2016 10:06:1 PM','Erebus');

INSERT INTO Tag
	(second_priority,description)
VALUES
	(0.0,'Erebus'),
	(0.0,'Erebus'),
	(0.0,'Erebus'),
	(0.0,'Erebus'),
	(0.0,'Erebus');

INSERT INTO Article_24
	(url,content,name,user_id)
VALUES
	('Erebus','Erebus','Erebus',1),
	('Erebus','Erebus','Erebus',2),
	('Erebus','Erebus','Erebus',3),
	('Erebus','Erebus','Erebus',4),
	('Erebus','Erebus','Erebus',5);

INSERT INTO Category
	(priority,date_created_on,tag_id)
VALUES
	(0,'10/15/2016 10:06:1 PM',1),
	(0,'10/15/2016 10:06:1 PM',2),
	(0,'10/15/2016 10:06:1 PM',3),
	(0,'10/15/2016 10:06:1 PM',4),
	(0,'10/15/2016 10:06:1 PM',5);

INSERT INTO Article_24_Category
	(article_24_id,category_id)
VALUES
(1,1),
(2,2),
(3,3),
(4,4),
(5,5);

