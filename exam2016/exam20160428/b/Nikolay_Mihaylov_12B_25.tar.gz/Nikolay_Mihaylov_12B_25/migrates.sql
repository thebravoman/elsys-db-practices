use exam;
CREATE TABLE Article_24_part1(id INT(11) PRIMARY KEY NOT NULL AUTO_INCREMENT,url varchar(255));
CREATE TABLE Article_24_part2(id INT(11) PRIMARY KEY NOT NULL AUTO_INCREMENT,content longtext,name varchar(255));
INSERT INTO Article_24_part1(id,url) SELECT id,url FROM Article_24;
INSERT INTO Article_24_part2(id,content,name) SELECT id,content,name FROM Article_24;
