use exam;

create table Article_1_part1 (
	id int not null primary key auto_increment,
	visible bit
);

insert into Article_1_part1 (visible) select visible from Article_1;
alter table Article_1 drop column visible;
alter table Article_1 rename Article_1_part2;
