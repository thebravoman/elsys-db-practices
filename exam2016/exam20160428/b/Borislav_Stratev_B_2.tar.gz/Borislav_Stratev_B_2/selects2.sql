use exam;

select Tag.id from Tag
inner join Category on Category.Tag_id = Tag.id
inner join Article_1_Category on Article_1_Category.Category_id = Category.id
inner join Article_1_part2 on Article_1_Category.Article_1_id = Article_1_part2.id
where Article_1_part2.id = 2;
