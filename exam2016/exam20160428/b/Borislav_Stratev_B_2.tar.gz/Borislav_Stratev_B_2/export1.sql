-- MySQL dump 10.13  Distrib 5.5.49, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: exam
-- ------------------------------------------------------
-- Server version	5.5.49-0ubuntu0.14.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `Article_1`
--

DROP TABLE IF EXISTS `Article_1`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Article_1` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `created_on` date DEFAULT NULL,
  `visible` bit(1) DEFAULT NULL,
  `price` float(5,2) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Article_1`
--

LOCK TABLES `Article_1` WRITE;
/*!40000 ALTER TABLE `Article_1` DISABLE KEYS */;
INSERT INTO `Article_1` VALUES (1,'2016-04-02','',6.99),(2,'2016-04-04','\0',1.99),(3,'2016-04-01','',5.99),(4,'2016-04-03','\0',2.99),(5,'2016-04-05','\0',3.99),(6,'2016-04-06','',4.99);
/*!40000 ALTER TABLE `Article_1` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Article_1_Category`
--

DROP TABLE IF EXISTS `Article_1_Category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Article_1_Category` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `Category_id` int(11) NOT NULL,
  `Article_1_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `Article_1_id` (`Article_1_id`),
  KEY `Category_id` (`Category_id`),
  CONSTRAINT `Article_1_Category_ibfk_1` FOREIGN KEY (`Article_1_id`) REFERENCES `Article_1` (`id`),
  CONSTRAINT `Article_1_Category_ibfk_2` FOREIGN KEY (`Category_id`) REFERENCES `Category` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Article_1_Category`
--

LOCK TABLES `Article_1_Category` WRITE;
/*!40000 ALTER TABLE `Article_1_Category` DISABLE KEYS */;
INSERT INTO `Article_1_Category` VALUES (1,6,3),(2,4,6),(3,1,4),(4,5,1),(5,3,5),(6,2,2);
/*!40000 ALTER TABLE `Article_1_Category` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Category`
--

DROP TABLE IF EXISTS `Category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Category` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `created_by` varchar(256) DEFAULT NULL,
  `name` varchar(256) DEFAULT NULL,
  `Tag_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `Tag_id` (`Tag_id`),
  CONSTRAINT `Category_ibfk_1` FOREIGN KEY (`Tag_id`) REFERENCES `Tag` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Category`
--

LOCK TABLES `Category` WRITE;
/*!40000 ALTER TABLE `Category` DISABLE KEYS */;
INSERT INTO `Category` VALUES (1,'Mason Scot','Liam South',1),(2,'Emma Watson','Jacob Lawson',3),(3,'Jacob Lawson','Madison Ivy',2),(4,'Liam South','Maisy Scot',4),(5,'Maisy Scot','Emma Watson',5),(6,'Madison Ivy','Mason Scot',6);
/*!40000 ALTER TABLE `Category` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Tag`
--

DROP TABLE IF EXISTS `Tag`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Tag` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `description` varchar(256) DEFAULT NULL,
  `priority_int` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Tag`
--

LOCK TABLES `Tag` WRITE;
/*!40000 ALTER TABLE `Tag` DISABLE KEYS */;
INSERT INTO `Tag` VALUES (1,'It should have some description at page 3',22),(2,'It should have some description at page 4',55),(3,'It should have some description at page 1',44),(4,'It should have some description at page 5',11),(5,'It should have some description at page 2',33),(6,'It should have some description at page 6',66);
/*!40000 ALTER TABLE `Tag` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `User`
--

DROP TABLE IF EXISTS `User`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `User` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `created_on` date DEFAULT NULL,
  `twitter` varchar(256) DEFAULT NULL,
  `gender` varchar(6) DEFAULT NULL,
  `Article_1_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `Article_1_id` (`Article_1_id`),
  CONSTRAINT `User_ibfk_1` FOREIGN KEY (`Article_1_id`) REFERENCES `Article_1` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `User`
--

LOCK TABLES `User` WRITE;
/*!40000 ALTER TABLE `User` DISABLE KEYS */;
INSERT INTO `User` VALUES (1,'2016-04-01','https://twitter.com/iansomerhalder/status/71606611330667316','male',6),(2,'2016-04-02','https://twitter.com/iansomerhalder/status/71606611330667313','male',2),(3,'2016-04-03','https://twitter.com/iansomerhalder/status/71606611330667314','female',5),(4,'2016-04-06','https://twitter.com/iansomerhalder/status/71606611330667312','male',3),(5,'2016-04-05','https://twitter.com/iansomerhalder/status/71606611330667311','female',1),(6,'2016-04-04','https://twitter.com/iansomerhalder/status/71606611330667315','female',4);
/*!40000 ALTER TABLE `User` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2016-04-28 10:43:25
