use exam;

select Category.id from Category
inner join Article_1_Category on Article_1_Category.Category_id = Category.id
inner join Article_1 on Article_1_Category.Article_1_id = Article_1.id
inner join User on User.Article_1_id = Article_1.id
where User.id = 3;
