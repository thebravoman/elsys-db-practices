drop database if exists exam;
create database exam;
use exam;

create table Tag (
	id int not null primary key auto_increment,
	description varchar(256),
	priority_int int
);

create table Category (
	id int not null primary key auto_increment,
	created_by varchar(256),
	name varchar(256),
	Tag_id int not null,
	foreign key (Tag_id) references Tag (id)
);

create table Article_1 (
	id int not null primary key auto_increment,
	created_on date,
	visible bit,
	price float(5, 2)
);

create table User (
	id int not null primary key auto_increment,
	created_on date,
	twitter varchar(256),
	gender varchar(6),
	Article_1_id int not null unique,
	foreign key (Article_1_id) references Article_1 (id)
);

create table Article_1_Category (
	id int not null primary key auto_increment,
	Category_id int not null,
	Article_1_id int not null,
	foreign key (Article_1_id) references Article_1 (id),
	foreign key (Category_id) references Category (id)
);
