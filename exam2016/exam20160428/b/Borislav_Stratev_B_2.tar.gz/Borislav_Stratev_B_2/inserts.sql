use exam;

insert into Tag (description, priority_int) values
	("It should have some description at page 3", 22),
	("It should have some description at page 4", 55),
	("It should have some description at page 1", 44),
	("It should have some description at page 5", 11),
	("It should have some description at page 2", 33),
	("It should have some description at page 6", 66);

insert into Category (created_by, name, Tag_id) values
	("Mason Scot", "Liam South", 1),
	("Emma Watson", "Jacob Lawson", 3),
	("Jacob Lawson", "Madison Ivy", 2),
	("Liam South", "Maisy Scot", 4),
	("Maisy Scot", "Emma Watson", 5),
	("Madison Ivy", "Mason Scot", 6);

insert into Article_1 (created_on, visible, price) values
	("2016-04-02", 1, 6.99),
	("2016-04-04", 0, 1.99),
	("2016-04-01", 1, 5.99),
	("2016-04-03", 0, 2.99),
	("2016-04-05", 0, 3.99),
	("2016-04-06", 1, 4.99);

insert into User (created_on, twitter, gender, Article_1_id) values
	("2016-04-01", "https://twitter.com/iansomerhalder/status/71606611330667316", "male", 6),
	("2016-04-02", "https://twitter.com/iansomerhalder/status/71606611330667313", "male", 2),
	("2016-04-03", "https://twitter.com/iansomerhalder/status/71606611330667314", "female", 5),
	("2016-04-06", "https://twitter.com/iansomerhalder/status/71606611330667312", "male", 3),
	("2016-04-05", "https://twitter.com/iansomerhalder/status/71606611330667311", "female", 1),
	("2016-04-04", "https://twitter.com/iansomerhalder/status/71606611330667315", "female", 4);

insert into Article_1_Category (Category_id, Article_1_id) values
	(6, 3),
	(4, 6),
	(1, 4),
	(5, 1),
	(3, 5),
	(2, 2);
