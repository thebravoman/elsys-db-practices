use exam;
INSERT INTO Article_12
	(url,visible,password)
VALUES
	('Erebus',TRUE,'Erebus'),
	('Erebus',TRUE,'Erebus'),
	('Erebus',TRUE,'Erebus'),
	('Erebus',TRUE,'Erebus'),
	('Erebus',TRUE,'Erebus');

INSERT INTO Category
	(description,name)
VALUES
	('Erebus','Erebus'),
	('Erebus','Erebus'),
	('Erebus','Erebus'),
	('Erebus','Erebus'),
	('Erebus','Erebus');

INSERT INTO Tag
	(description,name)
VALUES
	('Erebus','Erebus'),
	('Erebus','Erebus'),
	('Erebus','Erebus'),
	('Erebus','Erebus'),
	('Erebus','Erebus');

INSERT INTO User
	(age,picture_url,name,tag_id)
VALUES
	(0,'Erebus','Erebus',1),
	(0,'Erebus','Erebus',2),
	(0,'Erebus','Erebus',3),
	(0,'Erebus','Erebus',4),
	(0,'Erebus','Erebus',5);

INSERT INTO Tag_Article_12
	(tag_id,article_12_id)
VALUES
(1,1),
(2,2),
(3,3),
(4,4),
(5,5);

INSERT INTO Article_12_Category
	(article_12_id,category_id)
VALUES
(1,1),
(2,2),
(3,3),
(4,4),
(5,5);

