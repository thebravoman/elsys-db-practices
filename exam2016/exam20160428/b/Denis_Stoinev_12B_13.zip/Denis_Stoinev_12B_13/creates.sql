drop database if exists exam;
create database exam;
use exam;

create table Article_12 (
	id int primary key auto_increment,
	url varchar(255),
	visible boolean,
	password varchar(255)
);

create table Category (
	id int primary key auto_increment,
	description longtext,
	name varchar(255)
);

create table User (
	id int primary key auto_increment,
	age integer,
	picture_url varchar(255),
	name varchar(255)
);

create table Tag (
	id int primary key auto_increment,
	description varchar(255),
	name varchar(255)
);

alter table User add column tag_id int;
alter table User add foreign key (tag_id) references Tag(id);
create table Tag_Article_12 (
	id int primary key auto_increment,
	tag_id int not null,
	article_12_id int not null,
	foreign key (tag_id) references Tag(id),
	foreign key (article_12_id) references Article_12(id) 
);

create table Article_12_Category (
	id int primary key auto_increment,
	article_12_id int not null,
	category_id int not null,
	foreign key (article_12_id) references Article_12(id),
	foreign key (category_id) references Category(id) 
);

