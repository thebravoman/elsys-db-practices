use exam;

insert into Article_11 (content,visible,published_on)
values
('Dont',TRUE,1),
('Dont',TRUE,1),
('Dont',TRUE,1),
('Dont',TRUE,1),
('Dont',TRUE,1);

insert into Category (date_created_on,description)
values
(1,'Dont'),
(1,'Dont'),
(1,'Dont'),
(1,'Dont'),
(1,'Dont');

insert into User (created_on,description,name)
values
(1,'Dont','come'),
(1,'Dont','come'),
(1,'Dont','come'),
(1,'Dont','come'),
(1,'Dont','come');

insert into Tag (description,name)
values
('come','come'),
('come','come'),
('come','come'),
('come','come'),
('come','come');

