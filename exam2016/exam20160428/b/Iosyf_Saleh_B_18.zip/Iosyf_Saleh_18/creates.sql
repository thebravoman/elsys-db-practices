drop database if exists exam;
create database exam;
use exam;

create table Article_17 (
	id int primary key auto_increment,
	content longtext,
	visible boolean,
	published_on date
);

create table Category (
	id int primary key auto_increment,
	name varchar(255),
	description longtext
);

create table User (
	id int primary key auto_increment,
	age integer,
	created_on date,
	description longtext
);

create table Tag (
	id int primary key auto_increment,
	second_priority float,
	hash varchar(16)
);

alter table Tag add column category_id int;
alter table Tag add foreign key (category_id) references Category(id);
alter table Tag add column user_id int;
alter table Tag add foreign key (user_id) references User(id);
create table User_Article_17 (
	id int primary key auto_increment,
	user_id int not null,
	article_17_id int not null,
	foreign key (user_id) references User(id),
	foreign key (article_17_id) references Article_17(id) 
);

