use exam;
INSERT INTO Article_17
	(content,visible,published_on)
VALUES
	('Erebus',TRUE,'2016-02-07 13:06:11'),
	('Erebus',TRUE,'2016-02-07 13:06:11'),
	('Erebus',TRUE,'2016-02-07 13:06:11'),
	('Erebus',TRUE,'2016-02-07 13:06:11'),
	('Erebus',TRUE,'2016-02-07 13:06:11');

INSERT INTO Category
	(name,description)
VALUES
	('Erebus','Erebus'),
	('Erebus','Erebus'),
	('Erebus','Erebus'),
	('Erebus','Erebus'),
	('Erebus','Erebus');

INSERT INTO User
	(age,created_on,description)
VALUES
	(0,'2016-02-07 13:06:11','Erebus'),
	(0,'2016-02-07 13:06:11','Erebus'),
	(0,'2016-02-07 13:06:11','Erebus'),
	(0,'2016-02-07 13:06:11','Erebus'),
	(0,'2016-02-07 13:06:11','Erebus');

INSERT INTO Tag
	(second_priority,hash,category_id,user_id)
VALUES
	(2.0,'Erebus',1,1),
	(2.0,'Erebus',2,2),
	(2.0,'Erebus',3,3),
	(2.0,'Erebus',4,4),
	(2.0,'Erebus',5,5);

INSERT INTO User_Article_17
	(user_id,article_17_id)
VALUES
(1,1),
(2,2),
(3,3),
(4,4),
(5,5);

