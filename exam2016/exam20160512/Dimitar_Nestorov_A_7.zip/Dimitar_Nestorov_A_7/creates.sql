drop database if exists exam;
create database exam;
use exam;

create table Article_5 (
	id int primary key auto_increment,
	content longtext,
	visible boolean,
	price float
);

create table Category (
	id int primary key auto_increment,
	priority double,
	description longtext
);

create table User (
	id int primary key auto_increment,
	age integer,
	name varchar(255),
	income float
);

create table Tag (
	id int primary key auto_increment,
	description varchar(255),
	name varchar(255)
);

create table Category_Article_5 (
	id int primary key auto_increment,
	category_id int not null,
	article_5_id int not null,
	foreign key (category_id) references Category(id),
	foreign key (article_5_id) references Article_5(id) 
);

alter table Article_5 add column tag_id int unique;
alter table Article_5 add foreign key (tag_id) references Tag(id);

alter table Tag add column user_id int unique;
alter table Tag add foreign key (user_id) references User(id);

