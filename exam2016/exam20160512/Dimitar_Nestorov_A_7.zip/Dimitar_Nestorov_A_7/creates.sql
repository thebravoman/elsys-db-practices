drop database if exists exam;
create database exam;
use exam;

create table Category (
	id int not null primary key auto_increment,
	priority double(16, 8),
	description longtext
);

create table User (
	id int not null primary key auto_increment,
	age int,
	created_on date,
	gender varchar(6)
);

create table Tag (
	id int not null primary key auto_increment,
	priority int,
	second_priority float(8, 4)
);

create table Article_5 (
	id int not null primary key auto_increment,
	content varchar(1256),
	published_on date,
	price float(5, 2),
	Tag_id int not null,
	foreign key (Tag_id) references Tag (id)
);

create table Tag_User (
	id int not null primary key auto_increment,
	User_id int not null,
	Tag_id int not null,
	foreign key (Tag_id) references Tag (id),
	foreign key (User_id) references User (id)
);

create table Category_User (
	id int not null primary key auto_increment,
	Category_id int not null,
	User_id int not null,
	foreign key (User_id) references User (id),
	foreign key (Category_id) references Category (id)
);
