use exam;

create table Tag_part1 (
	id int not null primary key auto_increment,
	priority int
);

insert into Tag_part1 (priority) select priority from Tag;
alter table Tag drop column priority;
alter table Tag rename Tag_part2;
