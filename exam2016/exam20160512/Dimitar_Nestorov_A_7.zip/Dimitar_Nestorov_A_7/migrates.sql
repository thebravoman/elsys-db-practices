use exam;
CREATE TABLE Article_5_part1(id INT(11) PRIMARY KEY NOT NULL AUTO_INCREMENT,visible boolean);
CREATE TABLE Article_5_part2(id INT(11) PRIMARY KEY NOT NULL AUTO_INCREMENT,content longtext,price float);
INSERT INTO Article_5_part1(id,visible) SELECT id,visible FROM Article_5;
INSERT INTO Article_5_part2(id,content,price) SELECT id,content,price FROM Article_5;
