use exam;
INSERT INTO Category
	(priority,description)
VALUES
	(0,'Erebus'),
	(0,'Erebus'),
	(0,'Erebus'),
	(0,'Erebus'),
	(0,'Erebus');

INSERT INTO User
	(age,name,income)
VALUES
	(0,'Erebus',2.0),
	(0,'Erebus',2.0),
	(0,'Erebus',2.0),
	(0,'Erebus',2.0),
	(0,'Erebus',2.0);

INSERT INTO Article_5
	(content,visible,price,tag_id)
VALUES
	('Erebus',TRUE,2.0,1),
	('Erebus',TRUE,2.0,2),
	('Erebus',TRUE,2.0,3),
	('Erebus',TRUE,2.0,4),
	('Erebus',TRUE,2.0,5);

INSERT INTO Tag
	(description,name,user_id)
VALUES
	('Erebus','Erebus',1),
	('Erebus','Erebus',2),
	('Erebus','Erebus',3),
	('Erebus','Erebus',4),
	('Erebus','Erebus',5);

INSERT INTO Category_Article_5
	(category_id,article_5_id)
VALUES
(1,1),
(2,2),
(3,3),
(4,4),
(5,5);

