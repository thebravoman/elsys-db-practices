use exam;

insert into Category (priority, description) values
	(55, "It should have some description at page 4"),
	(22, "It should have some description at page 5"),
	(11, "It should have some description at page 1"),
	(66, "It should have some description at page 3"),
	(33, "It should have some description at page 6"),
	(44, "It should have some description at page 2");

insert into User (age, created_on, gender) values
	(3, "2016-04-06", "male"),
	(4, "2016-04-05", "female"),
	(6, "2016-04-01", "male"),
	(2, "2016-04-02", "male"),
	(5, "2016-04-03", "female"),
	(1, "2016-04-04", "female");

insert into Tag (priority, second_priority) values
	(33, 4.4),
	(55, 3.3),
	(44, 2.2),
	(22, 6.6),
	(11, 1.1),
	(66, 5.5);

insert into Article_5 (content, published_on, price, Tag_id) values
	("It should have some content at page 2", "1989-02-11", 6.99, 1),
	("It should have some content at page 6", "1989-06-11", 1.99, 5),
	("It should have some content at page 4", "1989-04-11", 3.99, 4),
	("It should have some content at page 5", "1989-03-11", 5.99, 6),
	("It should have some content at page 3", "1989-01-11", 2.99, 2),
	("It should have some content at page 1", "1989-05-11", 4.99, 3);

insert into Tag_User (User_id, Tag_id) values
	(1, 2),
	(4, 6),
	(6, 4),
	(2, 1),
	(5, 3),
	(3, 5);

insert into Category_User (Category_id, User_id) values
	(3, 1),
	(1, 6),
	(5, 2),
	(2, 4),
	(4, 5),
	(6, 3);
