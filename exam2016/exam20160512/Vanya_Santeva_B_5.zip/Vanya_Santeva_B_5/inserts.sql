use exam;
INSERT INTO Article_4
	(published_on,password,price)
VALUES
	('10/15/2016 10:06:0 PM','Erebus',2.0),
	('10/15/2016 10:06:0 PM','Erebus',2.0),
	('10/15/2016 10:06:0 PM','Erebus',2.0),
	('10/15/2016 10:06:0 PM','Erebus',2.0),
	('10/15/2016 10:06:0 PM','Erebus',2.0);

INSERT INTO Tag
	(description,name)
VALUES
	('Erebus','Erebus'),
	('Erebus','Erebus'),
	('Erebus','Erebus'),
	('Erebus','Erebus'),
	('Erebus','Erebus');

INSERT INTO Category
	(priority,created_by,tag_id)
VALUES
	(0,'Erebus',1),
	(0,'Erebus',2),
	(0,'Erebus',3),
	(0,'Erebus',4),
	(0,'Erebus',5);

INSERT INTO User
	(twitter,password,name,article_4_id)
VALUES
	('Erebus','Erebus','Erebus',1),
	('Erebus','Erebus','Erebus',2),
	('Erebus','Erebus','Erebus',3),
	('Erebus','Erebus','Erebus',4),
	('Erebus','Erebus','Erebus',5);

INSERT INTO Tag_User
	(tag_id,user_id)
VALUES
(1,1),
(2,2),
(3,3),
(4,4),
(5,5);

