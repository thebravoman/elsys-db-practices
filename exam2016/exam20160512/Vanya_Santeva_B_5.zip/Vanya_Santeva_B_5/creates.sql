drop database if exists exam;
create database exam;
use exam;

create table Article_4 (
	id int primary key auto_increment,
	published_on date,
	password varchar(255),
	price float
);

create table Category (
	id int primary key auto_increment,
	priority double,
	created_by varchar(255)
);

create table User (
	id int primary key auto_increment,
	twitter varchar(255),
	password varchar(255),
	name varchar(255)
);

create table Tag (
	id int primary key auto_increment,
	description varchar(255),
	name varchar(255)
);

alter table Category add column tag_id int unique;
alter table Category add foreign key (tag_id) references Tag(id);

create table Tag_User (
	id int primary key auto_increment,
	tag_id int not null,
	user_id int not null,
	foreign key (tag_id) references Tag(id),
	foreign key (user_id) references User(id) 
);

alter table User add column article_4_id int;
alter table User add foreign key (article_4_id) references Article_4(id);
