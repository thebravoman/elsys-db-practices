use exam;
INSERT INTO Article_9
	(visible,created_on,name)
VALUES
	(TRUE,'10/15/2016 10:06:1 PM','Erebus'),
	(TRUE,'10/15/2016 10:06:1 PM','Erebus'),
	(TRUE,'10/15/2016 10:06:1 PM','Erebus'),
	(TRUE,'10/15/2016 10:06:1 PM','Erebus'),
	(TRUE,'10/15/2016 10:06:1 PM','Erebus');

INSERT INTO User
	(age,picture_url,description)
VALUES
	(0,'Erebus','Erebus'),
	(0,'Erebus','Erebus'),
	(0,'Erebus','Erebus'),
	(0,'Erebus','Erebus'),
	(0,'Erebus','Erebus');

INSERT INTO Tag
	(hash,name)
VALUES
	('Erebus','Erebus'),
	('Erebus','Erebus'),
	('Erebus','Erebus'),
	('Erebus','Erebus'),
	('Erebus','Erebus');

INSERT INTO Category
	(name,created_by,user_id,article_9_id)
VALUES
	('Erebus','Erebus',1,1),
	('Erebus','Erebus',2,2),
	('Erebus','Erebus',3,3),
	('Erebus','Erebus',4,4),
	('Erebus','Erebus',5,5);

INSERT INTO Tag_User
	(tag_id,user_id)
VALUES
(1,1),
(2,2),
(3,3),
(4,4),
(5,5);

