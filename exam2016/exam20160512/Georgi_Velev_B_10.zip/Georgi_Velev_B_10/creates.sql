drop database if exists exam;
create database exam;
use exam;

create table Article_9 (
	id int primary key auto_increment,
	visible boolean,
	created_on date,
	name varchar(255)
);

create table Category (
	id int primary key auto_increment,
	name varchar(255),
	created_by varchar(255)
);

create table User (
	id int primary key auto_increment,
	age integer,
	picture_url varchar(255),
	description longtext
);

create table Tag (
	id int primary key auto_increment,
	hash varchar(16),
	name varchar(255)
);

create table Tag_User (
	id int primary key auto_increment,
	tag_id int not null,
	user_id int not null,
	foreign key (tag_id) references Tag(id),
	foreign key (user_id) references User(id) 
);

alter table Category add column user_id int;
alter table Category add foreign key (user_id) references User(id);
alter table Category add column article_9_id int;
alter table Category add foreign key (article_9_id) references Article_9(id);
