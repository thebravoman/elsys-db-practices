use exam;
CREATE TABLE User_part1(id INT(11) PRIMARY KEY NOT NULL AUTO_INCREMENT,age integer);
CREATE TABLE User_part2(id INT(11) PRIMARY KEY NOT NULL AUTO_INCREMENT,picture_url varchar(255),description longtext);
INSERT INTO User_part1(id,age) SELECT id,age FROM User;
INSERT INTO User_part2(id,picture_url,description) SELECT id,picture_url,description FROM User;
