/*
3. Insert
Add at least two records in each table
As a result SQL queries must be created
Write the queries from point 3 in a file called inserts.sql
*/

INSERT INTO User (age, income) VALUES
(18,12213.34);

INSERT INTO Tag (name, priority) VALUES
("str",12);


