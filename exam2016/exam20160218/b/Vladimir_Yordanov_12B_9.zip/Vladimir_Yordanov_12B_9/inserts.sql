INSERT INTO Article_8 (name, visible, content) VALUES
("tovaeime", 1, "tovaetekst"),
("ddz", 0, "oshtetekst");

INSERT INTO Category (date_created_on, created_by) VALUES
("2016-02-20 12:30:00", "vlady"),
("2016-02-21 12:35:00", "ddz");

INSERT INTO User (description, password, created_on) VALUES 
("tovaetext", "tovaeparola", "2016-02-20 12:30:00"),
("tovaedrugtext", "tovaeparoladddzzz", "2016-02-20 12:35:00");

INSERT INTO Tag (priority, name) VALUES
(1, "ddzime"),
(2, "ddz");

