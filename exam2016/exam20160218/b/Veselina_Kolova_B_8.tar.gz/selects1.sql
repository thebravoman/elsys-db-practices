SELECT Tag.id FROM Category 
