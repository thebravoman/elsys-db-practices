/*
3. Insert
Add at least two records in each table
As a result SQL queries must be created
Write the queries from point 3 in a file called inserts.sql
*/

INSERT INTO Article_7 (visible, password, url) VALUES
(1, "Bucks_Bunny", "http://...222");
(0, "Daffy_Duck", "http://...333");

INSERT INTO Category (date_created_on, name) VALUES
("2016-02-18 05:08:07", "Daffy Duck");
("2016-02-18 03:04:07", "Bucks Bunny");

INSERT INTO User (created_on,	 description,	 income) VALUES
("2016-02-18 05:08:07", "Daffy Duck", 12.98653218);
("2016-03-28 02:08:07", "Bucks Bunny", 18952.3218);

INSERT INTO Tag (second_priority,	 description) VALUES
(133.741, "asdkl");
(1741033.741, "asqweiodkl");
