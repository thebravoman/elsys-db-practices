INSERT INTO Article_3 (name, password, created_on) VALUES ("SSS", "advdvsdvvgd45yy4", "2016-02-01 07:08:07"), 
							  ("BBB", "ahdjshcsjdcv6", "2016-02-01 06:07:07");
INSERT INTO Category (priority, created_by) VALUES (12467.5678555, "VVVV"), 
						   (157890.345675, "Qavdbg");
INSERT INTO User (picture_url, name, age) VALUES ("www.ddd.bg", "dddddsfvfsr", 16), 
						 ("www.abd.bg", "sdfghjfd", 2);

INSERT INTO Tag (second_priority, hash) VALUES (45678.456666, "sdfghjghjfghjghj"), 
					       (22222.344677, "asdfghjk");
