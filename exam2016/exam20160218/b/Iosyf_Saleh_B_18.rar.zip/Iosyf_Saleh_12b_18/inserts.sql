INSERT INTO `mitov`.`category` (`date_created_on`, `description`, `UID`) VALUES ('2016-02-01', 'BLA', NULL);
INSERT INTO `mitov`.`category` (`date_created_on`, `description`, `UID`) VALUES ('2016-02-01', 'BLA', NULL);
INSERT INTO `mitov`.`category` (`date_created_on`, `description`, `UID`) VALUES ('2016-02-01', 'BLA', NULL);

INSERT INTO `mitov`.`tag` (`priority`, `UID`, `name`, `categoryID`) VALUES ('11', NULL, 'bla', '1');
INSERT INTO `mitov`.`tag` (`priority`, `UID`, `name`, `categoryID`) VALUES ('11', NULL, 'bla', '1');
INSERT INTO `mitov`.`tag` (`priority`, `UID`, `name`, `categoryID`) VALUES ('11', NULL, 'bla', '1');

INSERT INTO `mitov`.`article_17` (`password`, `name`, `created_on`, `UID`, `tagID`) VALUES ('bla', 'bla', '2016-02-01', NULL, '1');
INSERT INTO `mitov`.`article_17` (`password`, `name`, `created_on`, `UID`, `tagID`) VALUES ('bla', 'bla', '2016-02-01', NULL, '1');
INSERT INTO `mitov`.`article_17` (`password`, `name`, `created_on`, `UID`, `tagID`) VALUES ('bla', 'bla', '2016-02-01', NULL, '1');

INSERT INTO `mitov`.`user` (`created_on`, `inclome`, `picture_url`, `articleID`) VALUES ('2016-02-03', '12', 'no', '2');
INSERT INTO `mitov`.`user` (`created_on`, `inclome`, `picture_url`, `articleID`) VALUES ('2016-02-03', '12', 'no', '2');
INSERT INTO `mitov`.`user` (`created_on`, `inclome`, `picture_url`, `articleID`) VALUES ('2016-02-03', '12', 'no', '2');