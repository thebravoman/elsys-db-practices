
Select * FROM article_17 as x,category as y WHERE y.UID=x.categoryID