INSERT INTO Article_6 VALUES ('Test', 12.3, '18.02.2015');

INSERT INTO Category VALUES ('Test Cat', '18.02.2015');

INSERT INTO User VALUES ('myTwitter', 18, 123.24);

INSERT INTO Tag VALUES ('Test desc', 'ha7BzawQzdaa');