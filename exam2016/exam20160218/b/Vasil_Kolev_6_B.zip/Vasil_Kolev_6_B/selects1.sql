SELECT users FROM UserTag;
