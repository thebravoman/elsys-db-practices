INSERT INTO TABLE Article_5 (description, published_on, url) 
VALUES('article description one', '2015-12-30', 'http:/url.com')
('article description two', '2016-01-30', 'http:/url2.com');

INSERT INTO TABLE Category (description, date_created_on)
VALUES('category description one', '2002-12-30')
('category description two', '2022-12-30');

INSERT INTO TABLE User (income, twitter, password)
VALUES('3', 'twitter_one', 'mypassone')
('333', 'twitter_two', 'mypasstwo');

INSERT INTO TABLE Tag (name, priority)
VALUES('myname_one', '222')
('myname_two', '111');
