insert into Article_20 (url, name, created_on, tag_id)
values ("www.article1.com", "Article 1", "18.02.2016", 1)

insert into Article_20 (url, name, created_on, tag_id)
values ("www.article2.com", "Article 2", "18.02.2061", 2)

INSERT INTO Category (name)
VALUES ("Category one")

INSERT INTO Category (name)
VALUES ("Category two")

INSERT INTO Tag(priority, second_priority)
VALUES(1, 1.5)

INSERT INTO Tag(priority, second_priority)
VALUES(2, 2.0)

INSERT INTO User(name,description, age, tag_id, category_id)
VALUES ("Ivo", "ivopi4a", 20, 1, 1)

INSERT INTO User(name,description, age, tag_id, category_id)
VALUES ("Ina", "ina_", 21, 2, 2)