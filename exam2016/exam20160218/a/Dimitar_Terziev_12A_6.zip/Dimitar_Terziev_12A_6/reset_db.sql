drop database test;
create database test;
use test;
