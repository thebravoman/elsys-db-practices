/*6. Execute the following migration
Separate Article_16 on two tables
Article_16_part1 containing content
Article_16_part2 containing all the other fields
As a result SQL queries+code in other programming language must be create.
Write the queries from points 6 in a file called migrates.sql*/

CREATE TABLE Article_16_part1 (id INT(11) PRIMARY KEY NOT NULL AUTO_INCREMENT, content longtext NOT NULL);
CREATE TABLE Article_16_part2 (id INT(11) PRIMARY KEY NOT NULL AUTO_INCREMENT, price int(11) NOT NULL, published_on date NOT NULL);

INSERT INTO Article_16_part1 SELECT id, content FROM Article_16;
INSERT INTO Article_16_part2 (id, price, published_on) SELECT id, price, published_on FROM Article_16;

DROP TABLE Article_16;