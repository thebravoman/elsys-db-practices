/*8. Answer the following question
Which are the Category(s) for a given Article_16
As a result SQL query must be created
Write the queries from points 8 in a file called selects2.sql*/

