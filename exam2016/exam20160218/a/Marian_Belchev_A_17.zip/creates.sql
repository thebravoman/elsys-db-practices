/*1. Create the following tables
Create table Article_16
 with columns:
	 price->currency,	 published_on->date,	 content->long string,
Create table Category
 with columns:
	 priority->double,	 created_by->string,
Create table User
 with columns:
	 password->varchar,	 description->long text,	 created_on->date,
Create table Tag
 with columns:
	 name->varchar,	 hash->varchar(16),
As a result SQL queries must be created

2. Connect the tables in the following way
User has a many to many connection to Article_16
Article_16 has a many to one connection to Tag
Tag has a one to one connection to Category
As a result SQL queries must be created
Write the queries from point 1 and 2 in a file called creates.sql*/

CREATE TABLE Article_16 (
  `id` int(11) PRIMARY KEY NOT NULL AUTO_INCREMENT,
  `price` int(11) NOT NULL,
  `published_on` date NOT NULL,
  `content` longtext NOT NULL
);

CREATE TABLE Category (
  `id` int(11) PRIMARY KEY NOT NULL AUTO_INCREMENT,
  `priority` double NOT NULL,
  `created_by` varchar(255) NOT NULL
);

CREATE TABLE Tag (
  `id` int(11) PRIMARY KEY NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `hash` varchar(16) NOT NULL
);

CREATE TABLE User (
  `id` int(11) PRIMARY KEY NOT NULL AUTO_INCREMENT,
  `password` varchar(255) NOT NULL,
  `description` longtext NOT NULL,
  `created_on` date NOT NULL
);

CREATE TABLE User_Article_16 (
	`id` int(11) PRIMARY KEY NOT NULL AUTO_INCREMENT,
	`user_id` int(11),
	`article_16_id` int(11)
);

ALTER TABLE Article_16 ADD COLUMN tag_id INT(11);
ALTER TABLE Tag ADD COLUMN category_id INT(11);