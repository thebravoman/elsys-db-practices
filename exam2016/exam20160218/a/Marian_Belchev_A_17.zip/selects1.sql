/*4. Answer the following question
Which are the Tag(s) for a given User
As a result SQL query must be created
Write the queries from points 4 in a file called selects1.sql*/