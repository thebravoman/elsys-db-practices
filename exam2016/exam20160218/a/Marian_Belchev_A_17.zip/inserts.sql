/*3. Insert
Add at least two records in each table
As a result SQL queries must be created
Write the queries from point 3 in a file called inserts.sql*/

INSERT INTO Article_16 (price, published_on, content, tag_id) VALUES
(10, "2016-02-18", "random_content1", 1),
(999, "2016-02-18", "random_content2", 2);

INSERT INTO Category (priority, created_by) VALUES 
(1.1, "test"),
(5.5, "test123");

INSERT INTO Tag (name, hash, category_id) VALUES
("tag_name_1", "asdhasid7asdj", 1),
("tag_name_2", "129837123qweqwe", 2);

INSERT INTO User (password, description, created_on) VALUES
("j12i3uhasjdhasd", "user_desc_1", "2016-02-18"),
("asdkjasdhasdasd", "user_desc_2", "2016-02-18");

INSERT INTO User_Article_16 (user_id, article_16_id) VALUES
(1, 1),
(2, 2);