CREATE TABLE Article_5
 (
url VARCHAR(255),
content TEXT,
published_on DATE
 );

CREATE TABLE Category
 (
created_by VARCHAR(255),
name VARCHAR(254)
 );


CREATE TABLE User
 (
twitter VARCHAR(255),
created_on DATE,
picture_url VARCHAR(255)
 );

CREATE TABLE Tag
 (
priority INT(11),
name VARCHAR(255)
 );

