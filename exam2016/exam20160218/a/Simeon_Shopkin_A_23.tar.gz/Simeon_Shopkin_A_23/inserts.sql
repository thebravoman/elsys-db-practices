



INSERT INTO Article_22 (published_on, content, created_on) VALUES
("2015-04-03 05:08:07", "rygxoCAL90EkBIxZnISI", "2015-04-03 05:08:07"),
("2015-04-03 05:08:07", "a0MtKbA61KPLVaTLImzc", "2015-04-03 05:08:07");

INSERT INTO Category (date_created_on, created_by) VALUES
("2015-04-03 05:08:07", "herfs"),
("2015-04-03 05:08:07", "gahjnye");

INSERT INTO User (description, twitter, age) VALUES
("2igjkbki7", "rAL90EkBIxZnISI", 2015),
("2igkghnk5", "a0MtKbA61KPLVaTLImzc", 2);

INSERT INTO Tag (description, hash) VALUES
("afgreht", "agsh"),
("sfhgbd", "afdsg");

INSERT INTO Category_User (category_id, user_id) VALUES
(1,2),
(2,1);
