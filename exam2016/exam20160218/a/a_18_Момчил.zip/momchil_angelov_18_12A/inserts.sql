INSERT INTO `user` (`ID`, `created_on`, `picture_url`, `gender`) VALUES (NULL, '2016-02-10 00:00:00', 'na_mitaka_snimkata.jpg', 'True'), (NULL, '2016-02-17 11:28:07', 'na_denis_snimkata.png', 'False') 

INSERT INTO `tag` (`ID`, `name`, `priority`, `category_id`) VALUES (NULL, 'Deca', '1', '1'), (NULL, 'Kotki', '2', '1');

INSERT INTO `category` (`ID`, `created_by`, `date_created_on`) VALUES (NULL, 'Momchil', '2016-02-18 00:00:00'), (NULL, 'Pesho', '2016-02-16 00:00:00');

INSERT INTO `article_17` (`url`, `created_on`, `name`, `id`) VALUES ('my_perfect_blog.html', '2016-02-23 00:00:00', 'blog_za_kuchenca', NULL), ('my_kitty_blog.html', '2016-02-03 00:00:00', 'blog_za_kotki', NULL);

INSERT INTO `article17_user` (`id`, `article_id`, `user_id`) VALUES (NULL, '1', '1'), (NULL, '1', '2');

UPDATE `category` SET `tag_id` = '1' WHERE `category`.`ID` = 1;  
UPDATE `category` SET `tag_id` = '1' WHERE `category`.`ID` = 2;

INSERT INTO `tag_user` (`id`, `tag_id`, `user_id`) VALUES (NULL, '1', '1'), (NULL, '1', '2');  
