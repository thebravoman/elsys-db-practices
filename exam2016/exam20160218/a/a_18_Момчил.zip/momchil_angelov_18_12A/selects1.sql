SELECT article.id FROM article_17_user JOIN Tag_User 
ON User.id = Tag_User.user_id JOIN Tag 
ON Tag_User.tag_id = Tag.id JOIN Article_43 
ON Tag.article_43_id = Article_43.id 
WHERE Article_43.id = 1;