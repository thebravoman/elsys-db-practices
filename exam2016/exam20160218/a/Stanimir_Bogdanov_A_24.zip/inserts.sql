INSERT INTO Article_23 (price, name, published_on, user_id) VALUES
(5.00, 'first', "2016-02-18 05:08:07", 1),
(6.00, 'second', "2016-02-18 06:08:07", 1);

INSERT INTO Category (priority, description) VALUES
(1.1, 'first category'),
(1.2, 'second category');

INSERT INTO User (description, age, password) VALUES
('first user', 18, 'asdfasdfasdfasdf'),
('second user', 18, 'asdfasdfasdfasdf');

INSERT INTO Tag (description, hash, category_id) VALUES
('first tag', 'asdfasdfasdfhash', 1),
('second tag', 'asdfasdfasdhash2', 2);

INSERT INTO CategoryArticles(category_id, article_id) VALUES
(1, 1),
(1, 2);