SELECT User.id FROM User JOIN Article_23
ON User.id = Article_23.user_id JOIN CategoryArticles
ON Article_23.id = CategoryArticles.article_id JOIN Category_part2
ON CategoryArticles.category_id = Category_part2.id
WHERE Category_part2.id = 1;