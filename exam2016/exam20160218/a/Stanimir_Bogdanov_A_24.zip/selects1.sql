SELECT Article_23.id FROM Article_23 JOIN CategoryArticles
ON Article_23.id = CategoryArticles.article_id JOIN Category
ON CategoryArticles.category_id = Category.id JOIN Tag
ON Category.id = Tag.category_id
WHERE Tag.id = 1;