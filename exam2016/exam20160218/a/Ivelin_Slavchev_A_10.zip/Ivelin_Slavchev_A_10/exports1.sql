call syscs_util.syscs_export_table('APP', 'ARTICLE_9', 'article1.csv', ',', null, 'UTF-8');
call syscs_util.syscs_export_table('APP', 'CATEGORY', 'category1.csv', ',', null, 'UTF-8');
call syscs_util.syscs_export_table('APP', 'USERS', 'users1.csv', ',', null, 'UTF-8');
call syscs_util.syscs_export_table('APP', 'TAG', 'tag1.csv', ',', null, 'UTF-8');