call syscs_util.syscs_export_table('APP', 'USER_PART1', 'user_part1.csv', ',', null, 'UTF-8');
call syscs_util.syscs_export_table('APP', 'USER_PART2', 'user_part2.csv', ',', null, 'UTF-8');
call syscs_util.syscs_export_table('APP', 'ARTICLE_9', 'article2.csv', ',', null, 'UTF-8');
call syscs_util.syscs_export_table('APP', 'CATEGORY', 'category2.csv', ',', null, 'UTF-8');
call syscs_util.syscs_export_table('APP', 'TAG', 'tag2.csv', ',', null, 'UTF-8');