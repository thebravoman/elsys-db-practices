CREATE TABLE Article_6 (
	content LONGTEXT,
	url TEXT,
	name VARCHAR(12)
);

CREATE TABLE Category (
	description LONG TEXT,
	date_created_on DATE,
);

CREATE TABLE User (
	age INT,
	income FLOAT(12),
	password VARCHAR(12)
);

CREATE TABLE Tag (
	hash VARCHAR(16),
	second_priority FLOAT(12)
);

