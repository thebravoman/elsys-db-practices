-- phpMyAdmin SQL Dump
-- version 4.0.4
-- http://www.phpmyadmin.net
--
-- Хост: 127.0.0.1
-- Време на генериране: 
-- Версия на сървъра: 5.5.32
-- Версия на PHP: 5.4.16

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- БД: `subd`
--
CREATE DATABASE IF NOT EXISTS `subd` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `subd`;

-- --------------------------------------------------------

--
-- Структура на таблица `article`
--

CREATE TABLE IF NOT EXISTS `article` (
  `id` int(11) DEFAULT NULL,
  `url` varchar(50) DEFAULT NULL,
  `name` varchar(50) DEFAULT NULL,
  `create_on` date DEFAULT NULL,
  `category_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Схема на данните от таблица `article`
--

INSERT INTO `article` (`id`, `url`, `name`, `create_on`, `category_id`) VALUES
(1, 'dsgds', 'asdfzx', '0000-00-00', 1),
(2, 'fadsvcxz', 'asfdsfc', '0000-00-00', 2);

-- --------------------------------------------------------

--
-- Структура на таблица `category`
--

CREATE TABLE IF NOT EXISTS `category` (
  `id` int(11) DEFAULT NULL,
  `date_created_on` date DEFAULT NULL,
  `description` varchar(50) DEFAULT NULL,
  `tag_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Схема на данните от таблица `category`
--

INSERT INTO `category` (`id`, `date_created_on`, `description`, `tag_id`) VALUES
(1, '2010-10-20', 'afssgdasd', 1),
(2, '2011-11-20', 'afsdssg', 2);

-- --------------------------------------------------------

--
-- Структура на таблица `tag`
--

CREATE TABLE IF NOT EXISTS `tag` (
  `id` int(11) DEFAULT NULL,
  `name` varchar(50) DEFAULT NULL,
  `priority` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Схема на данните от таблица `tag`
--

INSERT INTO `tag` (`id`, `name`, `priority`) VALUES
(1, 'afsdssg', 15),
(2, 'afsdasdssg', 12);

-- --------------------------------------------------------

--
-- Структура на таблица `user`
--

CREATE TABLE IF NOT EXISTS `user` (
  `id` int(11) DEFAULT NULL,
  `age` int(11) DEFAULT NULL,
  `name` varchar(50) DEFAULT NULL,
  `created_on` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Схема на данните от таблица `user`
--

INSERT INTO `user` (`id`, `age`, `name`, `created_on`) VALUES
(1, 15, 'aasfdsf', '2004-04-20'),
(2, 16, 'sdffdsg', '0000-00-00');

-- --------------------------------------------------------

--
-- Структура на таблица `user_art`
--

CREATE TABLE IF NOT EXISTS `user_art` (
  `user_id` int(11) DEFAULT NULL,
  `art_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Схема на данните от таблица `user_art`
--

INSERT INTO `user_art` (`user_id`, `art_id`) VALUES
(1, 1),
(2, 2);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
