#!/usr/bin/env python
import datetime 
import time

import MySQLdb

def close(connection):
    connection.close()

db = MySQLdb.connect(host = "localhost", user="root", passwd="murzel", db="final_boss")
cur = db.cursor()

#cur.execute("CREATE TABLE tag_part1 (id int , second_priority double);")
#cur.execute("CREATE TABLE tag_part2 (id int,name varchar(45) , user_id int , article_id int);")
#string2 = "%d" %(row[1])

cur.execute("SELECT second_priority, id FROM Tag;")

for row in cur.fetchall():	
	string1 = "%d" %(row[1])
	string2 = "%d" %(row[0])
	cur.execute("INSERT INTO tag_part1 values('"+string1+"',"+string2+");")

cur.execute("SELECT id , name , user_id , article_id FROM Tag;")
for row in cur.fetchall():
	string1="%d" %(row[0])
	string2 = "%d" %(row[2])
	string4 = "%d" %(row[3])
	string3 = row[1]
	cur.execute("INSERT INTO tag_part2 values("+string1+",'"+string3+"',"+string2+","+string4+");")


db.commit()

close(db)
