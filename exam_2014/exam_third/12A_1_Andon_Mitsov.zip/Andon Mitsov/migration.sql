
create table Tag_part1(id int not null auto_increment primary key,second_priority decimal(10,2));
create table Tag_part2(id int not null auto_increment primary key,description varchar(128),User_id int not null);

insert into Tag_part1 select id,second_priority from Tag;
insert into Tag_part2 select id, description, User_id from Tag;

drop table  Tag; 
