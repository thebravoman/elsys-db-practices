

CREATE TABLE `article` (
  `article_id` int(11) NOT NULL AUTO_INCREMENT,
  `published_on` date DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL,
  `content` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`article_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO article VALUES("1","2012-02-11","blala1","lalalala1");
INSERT INTO article VALUES("2","2012-02-12","blala2","lalalala2");
INSERT INTO article VALUES("3","2012-02-13","blala3","lalalala3");





CREATE TABLE `category` (
  `category_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(20) DEFAULT NULL,
  `created_by` varchar(255) DEFAULT NULL,
  `tag_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`category_id`),
  UNIQUE KEY `tag_id` (`tag_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO category VALUES("1","gosho1","pesho1","1");
INSERT INTO category VALUES("2","gosho2","pesho2","2");
INSERT INTO category VALUES("3","gosho3","pesho3","3");





CREATE TABLE `tag` (
  `tag_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(20) DEFAULT NULL,
  `priority` int(11) DEFAULT NULL,
  PRIMARY KEY (`tag_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO tag VALUES("1","kon","2");
INSERT INTO tag VALUES("2","sopol","1");
INSERT INTO tag VALUES("3","gevrek","3");





CREATE TABLE `user` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `picture_url` varchar(255) DEFAULT NULL,
  `age` int(11) DEFAULT NULL,
  `income` float DEFAULT NULL,
  `tag_id` int(11) DEFAULT NULL,
  `art_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`user_id`),
  UNIQUE KEY `art_id` (`art_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO user VALUES("1","databg1","10","100.5","1","1");
INSERT INTO user VALUES("2","databg2","10","200.2","1","2");
INSERT INTO user VALUES("3","databg3","10","300.4","1","3");



--------------------------------------------------------------------------Sunday 27th of April 2014 06:30:16 AM