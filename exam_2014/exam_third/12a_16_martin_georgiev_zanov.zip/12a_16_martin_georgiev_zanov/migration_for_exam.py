#!/usr/bin/env python
import datetime 
import time

import MySQLdb

def close(connection):
    connection.close()

db = MySQLdb.connect(host = "localhost", user="root", passwd="e5wjtmbuHh95", db="exam")
cur = db.cursor()

#string2 = "%d" %(row[1])
# 4.Which are the Category(s) for a given Tag
#cur.execute("SELECT category_id FROM Article WHERE id = category_id;")
#for row in cur.fetchall():
#    print row[0]
cur.execute("CREATE TABLE Article_part1 (created_on DATE NOT NULL);")
cur.execute("CREATE TABLE Article_part2 (published_on DATE NOT NULL, price DECIMAL(15, 5) NOT NULL, article_id INT NOT NULL PRIMARY KEY UNIQUE);")

start = datetime
cur.execute("SELECT created_on FROM Article;")
for row in cur.fetchall():
	start = row[0];
	strk = str(row[0])
	start.strftime("%Y-%m-%d")
	print strk
	cur.execute("INSERT INTO Article_part1 values("+start+");")

#cur.execute("SELECT * FROM Tag_part1;")
#for row in cur.fetchall():
#    print row[0]
#cur.execute("CREATE TABLE article_part2 (price DECIMAL(30) NOT NULL, article_id INT(30) NOT NULL PRIMARY KEY AUTO_INCREMENT UNIQUE, category_id INT(30) NOT NULL UNIQUE);")
#cur.execute("INSERT INTO article_part2 SELECT Article.price, Article.id, Article.category_id FROM Article;")
start2 = datetime
cur.execute("SELECT published_on, price, article_id FROM Article;")
for row in cur.fetchall():
	start2 = row[0]
	print str(row[0])
	print str(row[1])
	start2.strftime("%Y-%m-%d")
	cur.execute("INSERT INTO Article_part2 (published_on, price, article_id) values('"+start2+"', "+str(row[1])+","+str(row[2])+");")
	#print str(row[1])
	#start2 = row[1];
	#strk = (row[0])
	#start.strftime("%Y-%m-%d")
	

cur.execute("alter table user_article drop foreign key asd2;")
cur.execute("alter table Category drop foreign key asd3;")
cur.execute("drop table Article;")
cur.execute("alter table user_article ADD CONSTRAINT asd2 FOREIGN KEY (article_id) REFERENCES Article_part2 (article_id);")
cur.execute("alter table Category ADD CONSTRAINT asd3 FOREIGN KEY (many_article_id) REFERENCES Article_part2 (article_id);")

db.commit()

#for row in cur.fetchall():
#    print row[0], row[1], row[2]
close(db)
