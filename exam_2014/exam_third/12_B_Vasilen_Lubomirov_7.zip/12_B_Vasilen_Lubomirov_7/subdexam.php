

<?php
//Separate User on two tables
//User_part1 containing age
//User_part2 containing all the other fields
//As a result SQL queries+code in other programming language must be create
$mysqli = new mysqli("localhost", "root", "", "subdexam");
if (mysqli_connect_errno()) {
	printf("Connect failed: %s\n", mysqli_connect_error());
	exit();
}

$query = "SELECT * from user";
$query_create_user_1="CREATE table user_1(id int not null ,  age int )";
$result_=$mysqli->query($query_create_user_1) or die($mysqli->error.__LINE__);
$result = $mysqli->query($query) or die($mysqli->error.__LINE__);
if($result->num_rows > 0) {
	while($row = $result->fetch_assoc()) {
		$id=$row['id'];
		$age=$row['age'];
		$result_=$mysqli->query(" INSERT INTO `user_1`(`id`, `age`) VALUES ($id,$age) ") or die($mysqli->error.__LINE__);
		
	}
	$result_=$mysqli->query("ALTER TABLE user DROP COLUMN age") or die($mysqli->error.__LINE__);
}

else {
	echo 'NO RESULTS';
}


mysqli_close($mysqli);