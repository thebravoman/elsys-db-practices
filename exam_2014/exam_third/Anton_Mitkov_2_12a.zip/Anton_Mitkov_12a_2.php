<!DOCTYPE html>
<html>
<head>
	<title> Anton Mitkov</title>
</head>
<body>
	Hello  <br/> &nbsp;&nbsp;&nbsp; Anton Mitkov 12 A, 2 number<br/>
	<br/><br/><br/>

<h3>Tips:</h3></br>
	sub_exam_backup1.sql - backup for the first part of the exam</br>
	sub_exam_backup2.sql - backup for the second part of the exam</br>

	If you refresh the page at the bottom of the file you'll see the changes and the time they are made.</br>
	It is possible when you refreshed the page to have an error with first answer because you change the database</br>
	and it affects on the result.</br></br>

<?php
	mysql_connect("localhost", "root","") or die(mysql_error());

		//mysql_query("CREATE DATABASE subd_exam_Anton") or die(mysql_error());

		mysql_select_db("subd_exam_Anton") or die(mysql_error());


/* 1-----------------------------------------------------*/
	 //  	mysql_query("CREATE TABLE Article (
		// 	article_id INT AUTO_INCREMENT,
		// 	published_on DATE,
		// 	name VARCHAR(30),
		// 	url VARCHAR(20),
		// 	user_id INT UNIQUE,
		// 	cat_id INT UNIQUE,
		// PRIMARY KEY(article_id))") Or die(mysql_error());

		// mysql_query("CREATE TABLE Category (
		// 	category_id INT AUTO_INCREMENT,
		// 	date_created_on DATE,
		// 	 created_by VARCHAR(40),
		// 	 tag_id INT ,
		// PRIMARY KEY(category_id))") Or die(mysql_error());

		// mysql_query("CREATE TABLE User (
		// 	user_id INT AUTO_INCREMENT,
		// 	income FLOAT,
		// 	created_on DATE,
		// 	password VARCHAR(40),
		// PRIMARY KEY(user_id))") Or die(mysql_error());

		// mysql_query("CREATE TABLE Tag (
		// 	tag_id INT AUTO_INCREMENT,
	 // 		priority INT,
	 // 		description VARCHAR(30),
		// PRIMARY KEY(tag_id))") Or die(mysql_error());


/*3-----------------------------------------------------------------*/
		// mysql_query("INSERT INTO Article( published_on, name, url, user_id, cat_id) VALUES ('2012-02-1','NASKO', 'blala', 2, 3)");
		// mysql_query("INSERT INTO Article( published_on, name, url, user_id, cat_id) VALUES ('2012-02-1','NASKO', 'blala', 3, 1)");
		// mysql_query("INSERT INTO Article( published_on, name, url, user_id, cat_id) VALUES ('2012-02-1','NASKO', 'blala', 1, 2)");

		mysql_query("INSERT INTO Category( date_created_on, created_by, tag_id) VALUES ('2012-02-1','GOGO', 2)");
		mysql_query("INSERT INTO Category( date_created_on, created_by, tag_id) VALUES ('2012-02-1','GOGO', 2)");
		mysql_query("INSERT INTO Category( date_created_on, created_by, tag_id) VALUES ('2012-02-1','GOGO', 1)");

		// mysql_query("INSERT INTO USER( income, created_on, password) VALUES ('100.50', '2012-02-1', 'zxcvbnm')");
		// mysql_query("INSERT INTO USER( income, created_on, password) VALUES ('100.50', '2012-02-1', 'asdfghjk')");
		// mysql_query("INSERT INTO USER( income, created_on, password) VALUES ('100.50', '2012-02-1', 'qwertyuiop')");

		// mysql_query("INSERT INTO tag(priority, description) VALUES (2,'kon')");
		// mysql_query("INSERT INTO tag(priority, description) VALUES (1,'kon')");
		// mysql_query("INSERT INTO tag(priority, description) VALUES (3,'kon')");


/*4------------------------------------------------------------------------------------*/

/*Which are the Category(s) for a given User -->  cat art user*/

		 // $pena =  mysql_query("SELECT * FROM Category INNER JOIN Article ON Article.cat_id = Category.category_id 
		 // 	 INNER JOIN User ON Article.user_id = User.user_id WHERE User.user_id = 1");  

		 // ?> THE ANSWER OF THE FIRST QUESTION IS : <br/><?php
		 // while($row = mysql_fetch_array($pena)){
		 // 	echo $row["user_id"];		
		 // 	echo $row["category_id"];
		 // 	echo $row["cat_id"];
	
			// ?> <br/> <?php
		 // }

 /*5-----------------------------------------------------------------------------------------*/
 		//backup_tables('localhost','root','subd_exam_Anton','sub_exam_backup1');	

/*6-------------------------------------------------------------------------------------------*/
		// mysql_query(" CREATE TABLE Article_part1 (
		// 	art_part1_id INT AUTO_INCREMENT,
		// 	name VARCHAR(30),
		// 	PRIMARY KEY(art_part1_id))") Or die(mysql_error());

		// mysql_query("INSERT INTO Article_part1 (name) SELECT name FROM Article");
		// mysql_query("ALTER TABLE Article DROP name");
		// mysql_query("ALTER TABLE Article RENAME TO Article_part2");


 /*7--------------------------------------------------------------------------------------------*/
		 backup_tables('localhost','root','subd_exam_Anton','sub_exam_backup2');

/*8-----------------------------------------------------------------------------------------------*/

/*Which are the Tag(s) for a given Article -->  tag cat art*/

		 $pena =  mysql_query("SELECT * FROM Tag INNER JOIN Category ON Tag.tag_id = Category.tag_id 
		 	INNER JOIN Article_part2 ON Article_part2.cat_id = Category.category_id
		 	INNER JOIN Article_part1 ON Article_part1.art_part1_id = Article_part2.article_id
		 	  WHERE Article_part2.article_id = 1");  // SELECT 2

		 ?> THE ANSWER OF THE SECONT QUESTION IS : <br/><?php
		 while($row = mysql_fetch_array($pena)){		
		 	echo $row["article_id"];
		 	echo $row["category_id"];
		 	echo $row["tag_id"];

			?> <br/> <?php
		 }

		 


?>
</body>
</html>


<?php

	
/* backup the db OR just a table */
function backup_tables($host,$user,$name,$place,$tables = '*')
{
	
	$link = mysql_connect($host,$user,"");
	mysql_select_db($name,$link);
	
	//get all of the tables
	if($tables == '*')
	{
		$tables = array();
		$result = mysql_query('SHOW TABLES');
		//var_dump($result);
		while($row = mysql_fetch_row($result))
		{
			$tables[] = $row[0];
		}
	}
	else
	{
		$tables = is_array($tables) ? $tables : explode(',',$tables);
	}
	

	//cycle through
	foreach($tables as $table)
	{
		$result = mysql_query('SELECT * FROM '.$table);
		$num_fields = mysql_num_fields($result);
		
		$return = 'DROP TABLE '.$table.';';
		$row2 = mysql_fetch_row(mysql_query('SHOW CREATE TABLE '.$table));
		$return = "\n\n".$row2[1].";\n\n";
		
		for ($i = 0; $i < $num_fields; $i++) 
		{
			while($row = mysql_fetch_row($result))
			{
				$return.= 'INSERT INTO '.$table.' VALUES(';
				for($j=0; $j<$num_fields; $j++) 
				{
					$row[$j] = addslashes($row[$j]);
					$row[$j] = ereg_replace("\n","\\n",$row[$j]);
					if (isset($row[$j])) { $return.= '"'.$row[$j].'"' ; } else { $return.= '""'; }
					if ($j<($num_fields-1)) { $return.= ','; }
				}
				$return.= ");\n";
			}
		}
		$return.="\n\n\n";

	$handle = fopen($place.'.sql','a+');
	fwrite($handle,$return);

	}
	fwrite($handle,"--------------------------------------------------------------------------".date('l jS \of F Y h:i:s A'));
	fclose($handle);
}
?>