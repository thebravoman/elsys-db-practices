

CREATE TABLE `article_part1` (
  `art_part1_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`art_part1_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO article_part1 VALUES("1","NASKO");
INSERT INTO article_part1 VALUES("2","NASKO");
INSERT INTO article_part1 VALUES("3","NASKO");





CREATE TABLE `article_part2` (
  `article_id` int(11) NOT NULL AUTO_INCREMENT,
  `published_on` date DEFAULT NULL,
  `url` varchar(20) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `cat_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`article_id`),
  UNIQUE KEY `user_id` (`user_id`),
  UNIQUE KEY `cat_id` (`cat_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO article_part2 VALUES("1","2012-02-01","dfgh","1","2");
INSERT INTO article_part2 VALUES("2","2012-02-01","dfgh","2","3");
INSERT INTO article_part2 VALUES("3","2012-02-01","dfghj","3","1");





CREATE TABLE `category` (
  `category_id` int(11) NOT NULL AUTO_INCREMENT,
  `date_created_on` date DEFAULT NULL,
  `created_by` varchar(40) DEFAULT NULL,
  `tag_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`category_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO category VALUES("1","2012-02-01","dfghj","2");
INSERT INTO category VALUES("2","2012-02-01","ghj","1");
INSERT INTO category VALUES("3","2012-02-01","uiklui","3");





CREATE TABLE `tag` (
  `tag_id` int(11) NOT NULL AUTO_INCREMENT,
  `priority` int(11) DEFAULT NULL,
  `description` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`tag_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO tag VALUES("1","2","kon");
INSERT INTO tag VALUES("2","1","kon");
INSERT INTO tag VALUES("3","3","kon");





CREATE TABLE `user` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `income` float DEFAULT NULL,
  `created_on` date DEFAULT NULL,
  `password` varchar(40) DEFAULT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO user VALUES("1","100.5","2012-02-01","zxcvbnm");
INSERT INTO user VALUES("2","100.5","2012-02-01","asdfghjk");
INSERT INTO user VALUES("3","100.5","2012-02-01","qwertyuiop");



--------------------------------------------------------------------------Sunday 27th of April 2014 06:37:57 AM

CREATE TABLE `article_part1` (
  `art_part1_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`art_part1_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO article_part1 VALUES("1","NASKO");
INSERT INTO article_part1 VALUES("2","NASKO");
INSERT INTO article_part1 VALUES("3","NASKO");





CREATE TABLE `article_part2` (
  `article_id` int(11) NOT NULL AUTO_INCREMENT,
  `published_on` date DEFAULT NULL,
  `url` varchar(20) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `cat_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`article_id`),
  UNIQUE KEY `user_id` (`user_id`),
  UNIQUE KEY `cat_id` (`cat_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO article_part2 VALUES("1","2012-02-01","dfgh","1","2");
INSERT INTO article_part2 VALUES("2","2012-02-01","dfgh","2","3");
INSERT INTO article_part2 VALUES("3","2012-02-01","dfghj","3","1");





CREATE TABLE `category` (
  `category_id` int(11) NOT NULL AUTO_INCREMENT,
  `date_created_on` date DEFAULT NULL,
  `created_by` varchar(40) DEFAULT NULL,
  `tag_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`category_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO category VALUES("1","2012-02-01","dfghj","2");
INSERT INTO category VALUES("2","2012-02-01","ghj","1");
INSERT INTO category VALUES("3","2012-02-01","uiklui","3");





CREATE TABLE `tag` (
  `tag_id` int(11) NOT NULL AUTO_INCREMENT,
  `priority` int(11) DEFAULT NULL,
  `description` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`tag_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO tag VALUES("1","2","kon");
INSERT INTO tag VALUES("2","1","kon");
INSERT INTO tag VALUES("3","3","kon");





CREATE TABLE `user` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `income` float DEFAULT NULL,
  `created_on` date DEFAULT NULL,
  `password` varchar(40) DEFAULT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO user VALUES("1","100.5","2012-02-01","zxcvbnm");
INSERT INTO user VALUES("2","100.5","2012-02-01","asdfghjk");
INSERT INTO user VALUES("3","100.5","2012-02-01","qwertyuiop");



--------------------------------------------------------------------------Sunday 27th of April 2014 06:41:20 AM

CREATE TABLE `article_part1` (
  `art_part1_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`art_part1_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO article_part1 VALUES("1","NASKO");
INSERT INTO article_part1 VALUES("2","NASKO");
INSERT INTO article_part1 VALUES("3","NASKO");





CREATE TABLE `article_part2` (
  `article_id` int(11) NOT NULL AUTO_INCREMENT,
  `published_on` date DEFAULT NULL,
  `url` varchar(20) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `cat_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`article_id`),
  UNIQUE KEY `user_id` (`user_id`),
  UNIQUE KEY `cat_id` (`cat_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO article_part2 VALUES("1","2012-02-01","dfgh","1","2");
INSERT INTO article_part2 VALUES("2","2012-02-01","dfgh","2","3");
INSERT INTO article_part2 VALUES("3","2012-02-01","dfghj","3","1");





CREATE TABLE `category` (
  `category_id` int(11) NOT NULL AUTO_INCREMENT,
  `date_created_on` date DEFAULT NULL,
  `created_by` varchar(40) DEFAULT NULL,
  `tag_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`category_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO category VALUES("1","2012-02-01","dfghj","2");
INSERT INTO category VALUES("2","2012-02-01","ghj","1");
INSERT INTO category VALUES("3","2012-02-01","uiklui","3");





CREATE TABLE `tag` (
  `tag_id` int(11) NOT NULL AUTO_INCREMENT,
  `priority` int(11) DEFAULT NULL,
  `description` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`tag_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO tag VALUES("1","2","kon");
INSERT INTO tag VALUES("2","1","kon");
INSERT INTO tag VALUES("3","3","kon");





CREATE TABLE `user` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `income` float DEFAULT NULL,
  `created_on` date DEFAULT NULL,
  `password` varchar(40) DEFAULT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO user VALUES("1","100.5","2012-02-01","zxcvbnm");
INSERT INTO user VALUES("2","100.5","2012-02-01","asdfghjk");
INSERT INTO user VALUES("3","100.5","2012-02-01","qwertyuiop");



--------------------------------------------------------------------------Sunday 27th of April 2014 06:43:56 AM

CREATE TABLE `article_part1` (
  `art_part1_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`art_part1_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO article_part1 VALUES("1","NASKO");
INSERT INTO article_part1 VALUES("2","NASKO");
INSERT INTO article_part1 VALUES("3","NASKO");





CREATE TABLE `article_part2` (
  `article_id` int(11) NOT NULL AUTO_INCREMENT,
  `published_on` date DEFAULT NULL,
  `url` varchar(20) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `cat_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`article_id`),
  UNIQUE KEY `user_id` (`user_id`),
  UNIQUE KEY `cat_id` (`cat_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO article_part2 VALUES("1","2012-02-01","dfgh","1","2");
INSERT INTO article_part2 VALUES("2","2012-02-01","dfgh","2","3");
INSERT INTO article_part2 VALUES("3","2012-02-01","dfghj","3","1");





CREATE TABLE `category` (
  `category_id` int(11) NOT NULL AUTO_INCREMENT,
  `date_created_on` date DEFAULT NULL,
  `created_by` varchar(40) DEFAULT NULL,
  `tag_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`category_id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

INSERT INTO category VALUES("1","2012-02-01","dfghj","2");
INSERT INTO category VALUES("2","2012-02-01","ghj","1");
INSERT INTO category VALUES("3","2012-02-01","uiklui","3");
INSERT INTO category VALUES("4","2012-02-01","GOGO","2");
INSERT INTO category VALUES("5","2012-02-01","GOGO","2");
INSERT INTO category VALUES("6","2012-02-01","GOGO","1");





CREATE TABLE `tag` (
  `tag_id` int(11) NOT NULL AUTO_INCREMENT,
  `priority` int(11) DEFAULT NULL,
  `description` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`tag_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO tag VALUES("1","2","kon");
INSERT INTO tag VALUES("2","1","kon");
INSERT INTO tag VALUES("3","3","kon");





CREATE TABLE `user` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `income` float DEFAULT NULL,
  `created_on` date DEFAULT NULL,
  `password` varchar(40) DEFAULT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO user VALUES("1","100.5","2012-02-01","zxcvbnm");
INSERT INTO user VALUES("2","100.5","2012-02-01","asdfghjk");
INSERT INTO user VALUES("3","100.5","2012-02-01","qwertyuiop");



--------------------------------------------------------------------------Sunday 27th of April 2014 06:44:52 AM