#!/usr/bin/env python


import MySQLdb

def close(connection):
    connection.close()

db = MySQLdb.connect(host = "localhost", user="root", passwd="plamen92", db="Exam")
cur = db.cursor()
#run the create only once!!!!
#cur.execute("CREATE TABLE Tag_part1(name VARCHAR(32));")
#cur.execute("CREATE TABLE Tag_part2(priority INT,A_id INT,T_id INT,Article_id INT);")
#string2 = "%d" %(row[1])
# 4.Which are the Category(s) for a given Tag
#cur.execute("SELECT category_id FROM Article WHERE id = category_id;")
#for row in cur.fetchall():
#    print row[0]
#cur.execute("CREATE TABLE article_part1 (published_on DATE);")
#cur.execute("CREATE TABLE article_part2 (name varchar(32) , user_id int);")



cur.execute("SELECT name FROM Tag;")
for row in cur.fetchall():
	cur.execute("INSERT INTO Tag_part1 values('"+row[0]+"');")

#cur.execute("CREATE TABLE article_part2 (price DECIMAL(30) NOT NULL, article_id INT(30) NOT NULL PRIMARY KEY AUTO_INCREMENT UNIQUE, category_id INT(30) NOT NULL UNIQUE);")
#cur.execute("INSERT INTO article_part2 SELECT Article.price, Article.id, Article.category_id FROM Article;")

cur.execute("SELECT priority,A_id,T_id,Article_id FROM Tag;")
for row in cur.fetchall():
	print str(row[1])
	string1 = "%d" %(row[0])
	string2 = "%d" %(row[1])
	string3 = "%d" %(row[2])
	string4 = "%d" %(row[3])
	cur.execute("INSERT INTO Tag_part2 values('"+string1+"' ,"+string2+","+string3+","+string4+");")

cur.execute("DROP TABLE Tag;")
db.commit()
#cur.execute("SELECT * FROM article_part2;")
#for row in cur.fetchall():
#    print row[0], row[1], row[2]
close(db)
