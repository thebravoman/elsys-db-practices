-- phpMyAdmin SQL Dump
-- version 4.1.12
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Apr 27, 2014 at 06:47 AM
-- Server version: 5.6.16
-- PHP Version: 5.5.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `task`
--

-- --------------------------------------------------------

--
-- Table structure for table `article`
--

CREATE TABLE IF NOT EXISTS `article` (
  `created_on` date DEFAULT NULL,
  `price` int(11) DEFAULT NULL,
  `published_on` date DEFAULT NULL,
  `article_id` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`article_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `article`
--

INSERT INTO `article` (`created_on`, `price`, `published_on`, `article_id`) VALUES
('2000-01-01', 100, '2001-01-01', 1),
('2002-01-01', 200, '2003-01-01', 2);

-- --------------------------------------------------------

--
-- Table structure for table `articlecategory`
--

CREATE TABLE IF NOT EXISTS `articlecategory` (
  `article_id` int(11) DEFAULT NULL,
  `category_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `articlecategory`
--

INSERT INTO `articlecategory` (`article_id`, `category_id`) VALUES
(1, 2),
(1, 1),
(2, 1);

-- --------------------------------------------------------

--
-- Table structure for table `category_part1`
--

CREATE TABLE IF NOT EXISTS `category_part1` (
  `category_id` int(11) NOT NULL AUTO_INCREMENT,
  `priority` int(11) DEFAULT NULL,
  PRIMARY KEY (`category_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `category_part1`
--

INSERT INTO `category_part1` (`category_id`, `priority`) VALUES
(1, 2),
(2, 3);

-- --------------------------------------------------------

--
-- Table structure for table `category_part2`
--

CREATE TABLE IF NOT EXISTS `category_part2` (
  `date_created_on` date DEFAULT NULL,
  `category_id` int(11) NOT NULL AUTO_INCREMENT,
  `tag_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`category_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `category_part2`
--

INSERT INTO `category_part2` (`date_created_on`, `category_id`, `tag_id`) VALUES
('2004-01-01', 1, 1),
('2005-01-01', 2, 2);

-- --------------------------------------------------------

--
-- Table structure for table `tag`
--

CREATE TABLE IF NOT EXISTS `tag` (
  `second_priority` int(11) DEFAULT NULL,
  `description` varchar(40) DEFAULT NULL,
  `tag_id` int(11) NOT NULL AUTO_INCREMENT,
  `users_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`tag_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `tag`
--

INSERT INTO `tag` (`second_priority`, `description`, `tag_id`, `users_id`) VALUES
(4, 'dsfds', 1, 1),
(5, 'sdfsdf', 2, 2);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `created_on` date DEFAULT NULL,
  `name` varchar(40) DEFAULT NULL,
  `income` int(11) DEFAULT NULL,
  `users_id` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`users_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`created_on`, `name`, `income`, `users_id`) VALUES
('2006-01-01', 'dsgrsgds', 196, 1),
('2007-01-01', 'sdmgjkgfsdf', 223, 2);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
