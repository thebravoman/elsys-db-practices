#!/usr/bin/env python

import MySQLdb
import sys

sys.dont_write_bytecode = True # don't cluster source folder
# create an export

# write your own migration
db = MySQLdb.connect(unix_socket='/home/ico/Programs/mysql/socket', user="root", passwd="mono", db="exam_database")
db.autocommit(False)
cur = db.cursor()

try:
    cur.execute("CREATE TABLE IF NOT EXISTS User_part1 (created_on DATE NOT NULL);")
    cur.execute("INSERT INTO User_part1 SELECT User.created_on FROM User;")
except MySQLdb.Error,e:
    db.rollback()
    print e
    cur.close()
    db.close()
    
try:
    cur.execute("CREATE TABLE IF NOT EXISTS User_part2 (age INT NOT NULL, income FLOAT(15, 5) NOT NULL, user_id INT NOT NULL PRIMARY KEY UNIQUE, many_category_id INT NOT NULL);");
    cur.execute("INSERT INTO User_part2 SELECT User.age, User.income, User.user_id, User.many_category_id FROM User;")
except MySQLdb.Error,e:
    db.rollback()
    print e
    cur.close()
    db.close()
db.commit()
db.close()
# done !
