CREATE DATABASE `krasi` DEFAULT CHARSET UTF8;
USE krasi;
CREATE TABLE `article` (
        `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
	`published_on` DATE,
	`content` LONG VARCHAR,
	`name` VARCHAR(42),
	PRIMARY KEY (`id`)
);
CREATE TABLE `category` (
        `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
	`name` VARCHAR(42),
	`created_by` VARCHAR(42),
	PRIMARY KEY (`id`)
);
CREATE TABLE `user` (
        `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
	`age` INTEGER,
	`password` VARCHAR(42),
	`name` VARCHAR(42),
	PRIMARY KEY (`id`)
);
CREATE TABLE `tag` (
        `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
	`name` VARCHAR(42),
	`description` VARCHAR(42),
	PRIMARY KEY (`id`)
);
CREATE TABLE `user_article` (
            `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
            `article_id` INT UNSIGNED NOT NULL,
            `user_id` INT UNSIGNED NOT NULL,
            PRIMARY KEY(`id`)
         );
ALTER TABLE `category` ADD FOREIGN KEY (id) REFERENCES article(id);
CREATE TABLE `tag_user` (
            `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
            `user_id` INT UNSIGNED NOT NULL,
            `tag_id` INT UNSIGNED NOT NULL,
            PRIMARY KEY(`id`)
         );

INSERT INTO article (`id`,`published_on`,`content`,`name`) VALUES
	('1','2014-04-04','c1','n1'),
	('2','2014-04-04','c2','n2');
INSERT INTO category (`id`,`name`,`created_by`) VALUES
	('1','n1','c1'),
	('2','n2','c2');
INSERT INTO user (`id`,`age`,`password`,`name`) VALUES
	('1','11','p1','n1'),
	('2','12','p2','n2');
INSERT INTO tag (`id`,`name`,`description`) VALUES
	('1','n1','d1'),
	('2','n2','d2');
INSERT INTO `user_article` (`id`, `article_id`, `user_id`) VALUES
	('1', '1', '1'),
	('2', '1', '1');
INSERT INTO `tag_user` (`id`, `user_id`, `tag_id`) VALUES
	('1', '1', '1'),
	('2', '2', '1');
	
SELECT DISTINCT user_article.user_id FROM user_article WHERE user_article.article_id IN 
(SELECT article.id FROM article, category WHERE article.id = category.id);

CREATE TABLE Article_part1 (`id` INT UNSIGNED NOT NULL AUTO_INCREMENT, `name` VARCHAR(42), PRIMARY KEY (`id`));
CREATE TABLE Article_part2 (`id` INT UNSIGNED NOT NULL AUTO_INCREMENT, `published_on` DATE, `content` LONG VARCHAR, PRIMARY KEY (`id`));
INSERT INTO Article_part1 (`id`, `name`) SELECT `id`, `name` FROM Article;
INSERT INTO Article_part2 (`id`, `published_on`, `content`) SELECT `id`, `published_on`, `content` FROM Article;

SET foreign_key_checks = 0;

DROP TABLE Article;

SET foreign_key_checks = 0;

SELECT DISTINCT tag_user.tag_id FROM tag_user WHERE tag_user.user_id IN
(SELECT user_article.user_id FROM user_article, article_part1 WHERE user_article.article_id = article_part1.id);
