import MySQLdb as mdb

con = mdb.connect('localhost', 'root', '123456', 'exam')

cur = con.cursor()
cur.execute("create table Category_part1(id INT NOT NULL, description VARCHAR(255) , PRIMARY KEY (`id`), FOREIGN KEY (id) REFERENCES Category(id));");
cur.execute("insert into Category_part1 (id, description) select id, description from Category;");
cur.execute("alter table Category rename Category_part2;");
cur.execute("alter table Category_part2 drop column description;");

rows = cur.fetchall()
