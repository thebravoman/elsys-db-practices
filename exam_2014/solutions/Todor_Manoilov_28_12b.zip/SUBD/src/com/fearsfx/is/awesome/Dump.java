package com.fearsfx.is.awesome;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class Dump {

	static String root = "root", databaseName = "subd_exam",
			fileName = "todor.txt";
	static List<String> table_queries = new ArrayList<String>();
	static List<String> relation_queries = new ArrayList<String>();
	static List<String> insert_queries = new ArrayList<String>();

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub

//		createDatabase();
//
//		generateCreates();
//
//		createTables();
//
//		generateRelations();
//
//		createRelations();
//
//		generateInserts();
//
//		doInserts();
//
		 dumpDatabase(root, root, databaseName);

//		doMigration();

//		dumpDatabase(root, root, databaseName);

		System.out.println("end??");
	}

	public static void doMigration() {
		String table = "User";
		String new_table1 = "User_part1";
		String new_table2 = "User_part2";
		ArrayList<MigrateHelper> list = new ArrayList<MigrateHelper>();
		Statement stmt = null;
		ResultSet rs = null;
		Connection conn = null;

		String dbUrl = "jdbc:mysql://localhost:3306/" + databaseName;
		String dbDriverClass = "com.mysql.jdbc.Driver";
		String userName = "root", password = "root";

		try {
			Class.forName(dbDriverClass);
			conn = DriverManager.getConnection(dbUrl, userName, password);

		} catch (SQLException ex) {
			// handle any errors
			System.out.println("SQLException: " + ex.getMessage());
			System.out.println("SQLState: " + ex.getSQLState());
			System.out.println("VendorError: " + ex.getErrorCode());
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		try {
			stmt = conn.createStatement();
			rs = stmt.executeQuery("SELECT * FROM " + table);
			while (rs.next()) {
				String name = rs.getString(2);
				String price = rs.getString(3);
				int id = rs.getInt(1);
				list.add(new MigrateHelper(id, name, price));
			}
			stmt = conn.createStatement();
			stmt.execute("CREATE TABLE " + new_table1
					+ " (id int,password varchar(20)) ");
			stmt = conn.createStatement();
			stmt.execute("CREATE TABLE " + new_table2
					+ " (id int, age int, name varchar(20))");
			stmt = conn.createStatement();
			// stmt.execute("DROP TABLE " + table );

			stmt = conn.createStatement();
			for (MigrateHelper mh : list) {

				stmt = conn.createStatement();
				stmt.execute("INSERT INTO " + new_table1 + " values(\""
						+ mh.getId() + "\",\"" + mh.getField_2() + "\");");
				stmt = conn.createStatement();
				stmt.execute("INSERT INTO " + new_table2 + " values(\""
						+ mh.getId() + "\",\"" + mh.getField_1() + "\");");

			}
		} catch (SQLException ex) {
			// handle any errors
			System.out.println("SQLException: " + ex.getMessage());
			System.out.println("SQLState: " + ex.getSQLState());
			System.out.println("VendorError: " + ex.getErrorCode());
		}

		// try{
		// stmt = conn.createStatement();
		// rs = stmt.executeQuery("SELECT * FROM " + new_table1);
		// while(rs.next()){
		// String name = rs.getString(2);
		// //String price = rs.getString(3);
		// int id = rs.getInt(1);
		// list.add(new MigrateHelper(id,name));
		// }
		//
		//
		// stmt = conn.createStatement();
		// stmt.execute("ALTER TABLE " + new_table2 + " ADD name varchar(20)");
		//
		// for(int i = 1; i <= list.size(); i++){
		//
		// stmt = conn.createStatement();
		// stmt.execute("UPDATE " + new_table2 + " SET name = '" +
		// list.get(i-1).getField_1() + "' WHERE "+ new_table2+".id" + " = " +
		// i);
		// //stmt = conn.createStatement();
		// // stmt.execute("ALTER TABLE " + new_table2 + " RENAME TO "+ table);
		//
		// }
		//
		// }
		// catch(SQLException ex){
		// // handle any errors
		// System.out.println("SQLException: " + ex.getMessage());
		// System.out.println("SQLState: " + ex.getSQLState());
		// System.out.println("VendorError: " + ex.getErrorCode());
		// }

	}

	public static void doInserts() {

		String dbUrl = "jdbc:mysql://localhost:3306/" + databaseName;
		String dbDriverClass = "com.mysql.jdbc.Driver";
		String userName = "root", password = "root";

		for (String s : insert_queries)
			try {
				Class.forName(dbDriverClass);
				Connection conn = DriverManager.getConnection(dbUrl, userName,
						password);
				Statement st = conn.createStatement();
				st.executeUpdate(s);
			} catch (SQLException e) {
				e.printStackTrace();
			} catch (ClassNotFoundException e) {
				e.printStackTrace();
			}

	}

	public static void generateInserts() {

		String dbUrl = "jdbc:mysql://localhost:3306/" + databaseName;
		String dbDriverClass = "com.mysql.jdbc.Driver";
		String userName = "root", password = "root";

		try {
			Class.forName(dbDriverClass);
			Connection conn = DriverManager.getConnection(dbUrl, userName,
					password);
			Statement st = conn.createStatement();

			DatabaseMetaData md = conn.getMetaData();

			ResultSet rs = md.getTables(null, null, "%", null);
			while (rs.next()) {

				ResultSet res = st.executeQuery("select * from "
						+ rs.getString("TABLE_NAME"));
				ResultSetMetaData rsmd = res.getMetaData();

				int columnCount = rsmd.getColumnCount();

				int a = 1;
				while (a < 6) {
					String query = "INSERT INTO " + rs.getString("TABLE_NAME")
							+ " VALUES(";

					for (int i = 1; i < columnCount + 1; i++) {
						String type = rsmd.getColumnTypeName(i);
						if (type.equals("INT"))
							if (i == 1)
								query += "NULL";
							else
								query += ", " + a;
						if (type.equals("FLOAT"))
							query += ", " + new Float(i);
						if (type.equals("DATE"))
							query += ", NOW()";
						if (type.equals("VARCHAR"))
							switch (a) {
							case 1:
								query += ", \"AAAA\"";
								break;
							case 2:
								query += ", \"BBBB\"";
								break;
							case 3:
								query += ", \"CCCC\"";
								break;
							case 4:
								query += ", \"DDDD\"";
								break;
							case 5:
								query += ", \"EEEE\"";
								break;
							}
					}
					query += ")";
					insert_queries.add(query);
					System.out.println(query);
					a++;
				}
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}

	}

	public static void createRelations() {

		String dbUrl = "jdbc:mysql://localhost:3306/" + databaseName;
		String dbDriverClass = "com.mysql.jdbc.Driver";
		String userName = "root", password = "root";

		for (String s : relation_queries)
			try {
				Class.forName(dbDriverClass);
				Connection conn = DriverManager.getConnection(dbUrl, userName,
						password);
				Statement st = conn.createStatement();
				st.executeUpdate(s);
			} catch (SQLException e) {
				e.printStackTrace();
			} catch (ClassNotFoundException e) {
				e.printStackTrace();
			}

	}

	public static void generateRelations() throws IOException {

		BufferedReader br = new BufferedReader(new FileReader(fileName));
		String line;
		while ((line = br.readLine()) != null) {
			if (line.contains("connection")) {

				String rels[] = { " has a one to one connection to ",
						" has a one to many connection to ",
						" has a many to one connection to ",
						" has a many to many connection to " };

				int i = 0;
				for (; !line.contains(rels[i]); i++) {
				}
				switch (i) {
				case 0: {
					String query = "ALTER TABLE " + line.split(rels[i])[0]
							+ " ADD " + line.split(rels[i])[1] + "_id int";
					relation_queries.add(query);
					System.out.println(query);
					query = "ALTER TABLE " + line.split(rels[i])[0]
							+ " ADD UNIQUE (" + line.split(rels[i])[1] + "_id)";
					relation_queries.add(query);
					System.out.println(query);
				}
					break;
				case 1: {
					String query = "ALTER TABLE " + line.split(rels[i])[1]
							+ " ADD " + line.split(rels[i])[0] + "_id int";
					relation_queries.add(query);
					System.out.println(query);
				}
					break;
				case 2: {
					String query = "ALTER TABLE " + line.split(rels[i])[0]
							+ " ADD " + line.split(rels[i])[1] + "_id int";
					relation_queries.add(query);
					System.out.println(query);
				}
					break;
				case 3: {
					String query = "CREATE TABLE " + line.split(rels[i])[0]
							+ "_to_" + line.split(rels[i])[1]
							+ "(id int AUTO_INCREMENT, "
							+ line.split(rels[i])[0] + "_id int, "
							+ line.split(rels[i])[1]
							+ "_id int, PRIMARY KEY (id))";
					relation_queries.add(query);
					System.out.println(query);
				}
					break;
				}
			}
		}
		br.close();

	}

	public static void createTables() {

		String dbUrl = "jdbc:mysql://localhost:3306/" + databaseName;
		String dbDriverClass = "com.mysql.jdbc.Driver";
		String userName = "root", password = "root";

		for (String s : table_queries)
			try {
				Class.forName(dbDriverClass);
				Connection conn = DriverManager.getConnection(dbUrl, userName,
						password);
				Statement st = conn.createStatement();
				st.executeUpdate(s);
			} catch (SQLException e) {
				e.printStackTrace();
			} catch (ClassNotFoundException e) {
				e.printStackTrace();
			}

	}

	public static void createDatabase() {

		String dbDriverClass = "com.mysql.jdbc.Driver";

		try {
			Class.forName(dbDriverClass);
			Connection conn = DriverManager
					.getConnection("jdbc:mysql://localhost/?user=root&password=root");
			Statement st = conn.createStatement();
			st.executeUpdate("CREATE DATABASE IF NOT EXISTS " + databaseName);
		} catch (SQLException e) {
			// e.printStackTrace();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
	}

	public static void generateCreates() throws IOException {

		List<String> columns = new ArrayList<String>(), types = new ArrayList<String>();

		BufferedReader br = new BufferedReader(new FileReader(fileName));
		String line;
		while ((line = br.readLine()) != null) {
			String que[] = line.split("Create table");
			if (que.length != 1) {
				que = que[1].split(" ");
				String line2;
				BufferedReader br2 = br;
				while (!(line2 = br2.readLine()).equals("")) {
					String col[] = line2.replaceAll("\\s+", "").split(":");
					System.out.println(col[0]);
					columns.add(col[0]);
					if (col[1].equals("varchar"))
						col[1] += "(255)";
					types.add(col[1].replaceAll("currency", "float"));
				}

				String query = "CREATE TABLE IF NOT EXISTS " + que[1]
						+ "(id int AUTO_INCREMENT";
				for (int i = 0; i < columns.size(); i++) {
					query += ", " + columns.get(i) + " " + types.get(i);
				}
				query += ", PRIMARY KEY (id))";
				table_queries.add(query);
				System.out.println(query);
				columns = new ArrayList<String>();
				types = new ArrayList<String>();
			}
		}
		br.close();
	}

	public static void dumpDatabase(String aUser, String aPasswd,
			String aDatabase) throws IOException {

		String executeCmd = String.format(
				"mysqldump -u %s -p%s --database %s -r %s_dump.sql", aUser,
				aPasswd, aDatabase, aDatabase);

		Process runtimeProcess;
		try {
			runtimeProcess = Runtime.getRuntime().exec(executeCmd);
			int processComplete = runtimeProcess.waitFor();

			if (processComplete == 0)
				System.out.println("Exported.");
			else
				System.out.println("Failed to export.");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}