import MySQLdb as mdb

con = mdb.connect('localhost', 'root', 'password', 'subdexam')

cur = con.cursor()
cur.execute("CREATE TABLE Tag_part1(id int, second_priority float)");
cur.execute("CREATE TABLE Tag_part2(id int, priority int)");
cur.execute("INSERT INTO Tag_part1 (id, second_priority) SELECT Tag.id, Tag.second_priority FROM Tag");
cur.execute("INSERT INTO Tag_part2 (id, priority) SELECT Tag.id, Tag.priority FROM Tag");

rows = cur.fetchall()

