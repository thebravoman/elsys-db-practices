package code;
import java.sql.DriverManager;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Date;

public class MySQLTest {
	public static void main(String[] args) {
		Connection connection = null;
		Statement statement = null;
		ResultSet rs = null;
		
		try {
			Class.forName("com.mysql.jdbc.Driver");
		} catch (ClassNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		
		String url = "jdbc:mysql://localhost:9999/blog";
		String username = "root";
		String password = "1234";
		
		ArrayList<String> descriptionList = new ArrayList<String>();
		
		ArrayList<Double> priorityList = new ArrayList<Double>();
		
		
		try {
			connection = DriverManager.getConnection(url, username, password);
			
			statement = connection.createStatement();
			
			statement.executeUpdate("CREATE TABLE IF NOT EXISTS category_part1 (id INT NOT NULL AUTO_INCREMENT, priority DOUBLE, PRIMARY KEY(id))");
			statement.executeUpdate("CREATE TABLE IF NOT EXISTS category_part2 (id INT NOT NULL AUTO_INCREMENT,  description VARCHAR(255), PRIMARY KEY(id))");
			
			
			rs = statement.executeQuery("select * from category");
			while(rs.next()) {
				descriptionList.add(rs.getString("description"));
				
				priorityList.add(rs.getDouble("priority"));
			}
			
			for(int i = 0; i < descriptionList.size(); i++) {
				statement.executeUpdate("INSERT INTO category_part1 (priority) VALUES (" + "'" + priorityList.get(i) + "'" + ")");
				statement.executeUpdate("INSERT INTO category_part2 (description) VALUES (" + "'" + descriptionList.get(i) + "'" +")");			
			}
			
			statement.executeUpdate("DROP TABLE category");
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
}
