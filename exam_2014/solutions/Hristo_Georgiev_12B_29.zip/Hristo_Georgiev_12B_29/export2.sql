CREATE TABLE "articles" ("id" INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, "name" varchar(255), "price" float, "created_on" date);
CREATE TABLE "categories" ("id" INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, "date_created_on" date, "priority" float);
CREATE TABLE "users" ("id" INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, "password" varchar(255), "age" integer, "name" varchar(255), "category_id" integer);
CREATE TABLE "tags" ("id" INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, "tags_name_id" integer, "priority" integer, "article_id" integer);
CREATE TABLE "categorys_tags" ("id" INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, "category_id" integer, "tag_id" integer);
CREATE TABLE "tag_name" ("id" INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, "name" varchar(255));

INSERT INTO articles VALUES(1,"blqblq", 25.02,'21/10/2014');
INSERT INTO articles VALUES(2,"blqblq2", 13.03,'22/5/2012');
INSERT INTO categories VALUES(1,'21/10/2014', 1,4);
INSERT INTO categories VALUES(2,'22/5/2012', 1.9);
INSERT INTO users VALUES(1,'pass',2,"blqblq");
INSERT INTO users VALUES(2,'pass2',1,"blqblq2");
INSERT INTO tags VALUES(1,1,3.1);
INSERT INTO tags VALUES(2,2,2.1);
INSERT INTO tag_name VALUES(1, "blqblq");
INSERT INTO tag_name VALUES(2, "blqblq2");
