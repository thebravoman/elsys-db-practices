CREATE TABLE Article (
	id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
	name VARCHAR(140),
	published_on DATE,
	created_on DATE
);

CREATE TABLE User (
	id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
	picture_url VARCHAR(140),
	password VARCHAR(140),
	age INT
);

CREATE TABLE Category (
	id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
	description VARCHAR(140),
	date_created_on DATE,
	user_id INT
);

CREATE TABLE Tag (
	id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
	second_priority NUMERIC(10,4),
	name VARCHAR(70),
	category_id INT
);

CREATE TABLE User_Article (
	id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
	user_id INT,
	article_id INT
);

## Create the one-one, many-one relationship !!!

INSERT INTO User (picture_url, password, age) VALUES ("url1", "pass1", 18);
INSERT INTO User (picture_url, password, age) VALUES ("url2", "pass2", 19);

INSERT INTO Article (name, published_on, created_on) VALUES ("Article1", NOW(), NOW());
INSERT INTO Article (name, published_on, created_on) VALUES ("Article2", NOW(), NOW());

INSERT INTO Category (description, date_created_on, user_id) VALUES ("Desc1", NOW(), 1);
INSERT INTO Category (description, date_created_on, user_id) VALUES ("Desc2", NOW(), 2);

INSERT INTO Tag (second_priority, name, category_id) VALUES (3.23, "Tag1", 1);
INSERT INTO Tag (second_priority, name, category_id) VALUES (4.23, "Tag2", 2);

INSERT INTO User_Article (user_id, article_id) VALUES (1,1);
INSERT INTO User_Article (user_id, article_id) VALUES (2,2);



SELECT DISTINCT user.id from user, category, tag where tag.category_id = category.id and category.user_id = user.id and user_id = 1;