-- phpMyAdmin SQL Dump
-- version 3.5.2.2
-- http://www.phpmyadmin.net
--
-- Хост: 127.0.0.1
-- Време на генериране: 
-- Версия на сървъра: 5.5.27
-- Версия на PHP: 5.4.7

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- БД: `subdexam`
--

-- --------------------------------------------------------

--
-- Структура на таблица `articles`
--

CREATE TABLE IF NOT EXISTS `articles` (
  `article_id` int(11) NOT NULL AUTO_INCREMENT,
  `tag_id` int(11) NOT NULL,
  `content` text NOT NULL,
  `url` varchar(100) NOT NULL,
  `price` decimal(10,2) NOT NULL,
  PRIMARY KEY (`article_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Ссхема на данните от таблица `articles`
--

INSERT INTO `articles` (`article_id`, `tag_id`, `content`, `url`, `price`) VALUES
(1, 1, 'asdasdasd', 'asdasdasd', 200.00),
(2, 2, 'dddddddd', 'asddddddd', 2200.00);

-- --------------------------------------------------------

--
-- Структура на таблица `cateogry`
--

CREATE TABLE IF NOT EXISTS `cateogry` (
  `category_id` int(11) NOT NULL AUTO_INCREMENT,
  `date_created_on` date NOT NULL,
  `priority` double NOT NULL,
  PRIMARY KEY (`category_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Ссхема на данните от таблица `cateogry`
--

INSERT INTO `cateogry` (`category_id`, `date_created_on`, `priority`) VALUES
(1, '0000-00-00', 200),
(2, '0000-00-00', 2020);

-- --------------------------------------------------------

--
-- Структура на таблица `tags`
--

CREATE TABLE IF NOT EXISTS `tags` (
  `tag_id` int(11) NOT NULL AUTO_INCREMENT,
  `category_id` int(11) NOT NULL,
  `description` varchar(100) NOT NULL,
  `second_priority` float NOT NULL,
  PRIMARY KEY (`tag_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Ссхема на данните от таблица `tags`
--

INSERT INTO `tags` (`tag_id`, `category_id`, `description`, `second_priority`) VALUES
(1, 1, 'sdfsdfsdf', 200),
(2, 2, 'sdfsdfqwdasdaeqwsdf', 2200);

-- --------------------------------------------------------

--
-- Структура на таблица `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `picture_url` varchar(100) NOT NULL,
  `age` int(11) NOT NULL,
  `income` float NOT NULL,
  `category_id` int(11) NOT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Ссхема на данните от таблица `users`
--

INSERT INTO `users` (`user_id`, `picture_url`, `age`, `income`, `category_id`) VALUES
(1, 'asdasdasdasda', 23, 4232, 1),
(2, 'asdasdasdasda', 233, 423322, 2);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
