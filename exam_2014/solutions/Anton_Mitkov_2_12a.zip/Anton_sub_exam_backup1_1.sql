

CREATE TABLE `article` (
  `article_id` int(11) NOT NULL AUTO_INCREMENT,
  `price` varchar(20) DEFAULT NULL,
  `url` varchar(50) DEFAULT NULL,
  `content` varchar(150) DEFAULT NULL,
  PRIMARY KEY (`article_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO article VALUES("1","5","jkbdsvc.abv","qwert");
INSERT INTO article VALUES("2","5.54","kon.com","asdfg");
INSERT INTO article VALUES("3","5.84","ddz.net","zxcv");





CREATE TABLE `category` (
  `category_id` int(11) NOT NULL AUTO_INCREMENT,
  `created_by` varchar(20) DEFAULT NULL,
  `description` varchar(20) DEFAULT NULL,
  `art_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`category_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;






CREATE TABLE `tag` (
  `tag_id` int(11) NOT NULL AUTO_INCREMENT,
  `second_priority` float DEFAULT NULL,
  `description` varchar(20) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`tag_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

INSERT INTO tag VALUES("1","1.87","gevrek","3");





CREATE TABLE `tag_art` (
  `tag_id` int(11) DEFAULT NULL,
  `art_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;






CREATE TABLE `user` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `income` float DEFAULT NULL,
  `created_on` date DEFAULT NULL,
  `password` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO user VALUES("1","1.25","2012-12-03","1536");
INSERT INTO user VALUES("2","1.78","2012-05-12","534");
INSERT INTO user VALUES("3","1.05","2012-09-02","78");



--------------------------------------------------------------------------Friday 4th of April 2014 07:20:59 AM

CREATE TABLE `article` (
  `article_id` int(11) NOT NULL AUTO_INCREMENT,
  `price` varchar(20) DEFAULT NULL,
  `url` varchar(50) DEFAULT NULL,
  `content` varchar(150) DEFAULT NULL,
  PRIMARY KEY (`article_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO article VALUES("1","5","jkbdsvc.abv","qwert");
INSERT INTO article VALUES("2","5.54","kon.com","asdfg");
INSERT INTO article VALUES("3","5.84","ddz.net","zxcv");





CREATE TABLE `category` (
  `category_id` int(11) NOT NULL AUTO_INCREMENT,
  `created_by` varchar(20) DEFAULT NULL,
  `description` varchar(20) DEFAULT NULL,
  `art_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`category_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;






CREATE TABLE `tag` (
  `tag_id` int(11) NOT NULL AUTO_INCREMENT,
  `second_priority` float DEFAULT NULL,
  `description` varchar(20) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`tag_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

INSERT INTO tag VALUES("1","1.87","gevrek","3");





CREATE TABLE `tag_art` (
  `tag_id` int(11) DEFAULT NULL,
  `art_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;






CREATE TABLE `user` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `income` float DEFAULT NULL,
  `created_on` date DEFAULT NULL,
  `password` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO user VALUES("1","1.25","2012-12-03","1536");
INSERT INTO user VALUES("2","1.78","2012-05-12","534");
INSERT INTO user VALUES("3","1.05","2012-09-02","78");



--------------------------------------------------------------------------Friday 4th of April 2014 07:22:35 AM

CREATE TABLE `article` (
  `article_id` int(11) NOT NULL AUTO_INCREMENT,
  `price` varchar(20) DEFAULT NULL,
  `url` varchar(50) DEFAULT NULL,
  `content` varchar(150) DEFAULT NULL,
  PRIMARY KEY (`article_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO article VALUES("1","5","jkbdsvc.abv","qwert");
INSERT INTO article VALUES("2","5.54","kon.com","asdfg");
INSERT INTO article VALUES("3","5.84","ddz.net","zxcv");





CREATE TABLE `category` (
  `category_id` int(11) NOT NULL AUTO_INCREMENT,
  `created_by` varchar(20) DEFAULT NULL,
  `description` varchar(20) DEFAULT NULL,
  `art_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`category_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO category VALUES("1","GOGO","Krimi","1");
INSERT INTO category VALUES("2","NASKO","Biznes","2");
INSERT INTO category VALUES("3","ERIK","Sport","3");





CREATE TABLE `tag` (
  `tag_id` int(11) NOT NULL AUTO_INCREMENT,
  `second_priority` float DEFAULT NULL,
  `description` varchar(20) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`tag_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

INSERT INTO tag VALUES("1","1.87","gevrek","3");





CREATE TABLE `tag_art` (
  `tag_id` int(11) DEFAULT NULL,
  `art_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;






CREATE TABLE `user` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `income` float DEFAULT NULL,
  `created_on` date DEFAULT NULL,
  `password` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO user VALUES("1","1.25","2012-12-03","1536");
INSERT INTO user VALUES("2","1.78","2012-05-12","534");
INSERT INTO user VALUES("3","1.05","2012-09-02","78");



--------------------------------------------------------------------------Friday 4th of April 2014 07:23:20 AM

CREATE TABLE `article` (
  `article_id` int(11) NOT NULL AUTO_INCREMENT,
  `price` varchar(20) DEFAULT NULL,
  `url` varchar(50) DEFAULT NULL,
  `content` varchar(150) DEFAULT NULL,
  PRIMARY KEY (`article_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO article VALUES("1","5","jkbdsvc.abv","qwert");
INSERT INTO article VALUES("2","5.54","kon.com","asdfg");
INSERT INTO article VALUES("3","5.84","ddz.net","zxcv");





CREATE TABLE `category` (
  `category_id` int(11) NOT NULL AUTO_INCREMENT,
  `created_by` varchar(20) DEFAULT NULL,
  `description` varchar(20) DEFAULT NULL,
  `art_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`category_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO category VALUES("1","GOGO","Krimi","1");
INSERT INTO category VALUES("2","NASKO","Biznes","2");
INSERT INTO category VALUES("3","ERIK","Sport","3");





CREATE TABLE `tag` (
  `tag_id` int(11) NOT NULL AUTO_INCREMENT,
  `second_priority` float DEFAULT NULL,
  `description` varchar(20) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`tag_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

INSERT INTO tag VALUES("1","1.87","gevrek","3");





CREATE TABLE `tag_art` (
  `tag_id` int(11) DEFAULT NULL,
  `art_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO tag_art VALUES("1","2");
INSERT INTO tag_art VALUES("1","1");
INSERT INTO tag_art VALUES("2","3");





CREATE TABLE `user` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `income` float DEFAULT NULL,
  `created_on` date DEFAULT NULL,
  `password` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO user VALUES("1","1.25","2012-12-03","1536");
INSERT INTO user VALUES("2","1.78","2012-05-12","534");
INSERT INTO user VALUES("3","1.05","2012-09-02","78");



--------------------------------------------------------------------------Friday 4th of April 2014 07:23:55 AM

CREATE TABLE `article` (
  `article_id` int(11) NOT NULL AUTO_INCREMENT,
  `price` varchar(20) DEFAULT NULL,
  `url` varchar(50) DEFAULT NULL,
  `content` varchar(150) DEFAULT NULL,
  PRIMARY KEY (`article_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO article VALUES("1","5","jkbdsvc.abv","qwert");
INSERT INTO article VALUES("2","5.54","kon.com","asdfg");
INSERT INTO article VALUES("3","5.84","ddz.net","zxcv");





CREATE TABLE `category` (
  `category_id` int(11) NOT NULL AUTO_INCREMENT,
  `created_by` varchar(20) DEFAULT NULL,
  `description` varchar(20) DEFAULT NULL,
  `art_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`category_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO category VALUES("1","GOGO","Krimi","1");
INSERT INTO category VALUES("2","NASKO","Biznes","2");
INSERT INTO category VALUES("3","ERIK","Sport","3");





CREATE TABLE `tag` (
  `tag_id` int(11) NOT NULL AUTO_INCREMENT,
  `second_priority` float DEFAULT NULL,
  `description` varchar(20) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`tag_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

INSERT INTO tag VALUES("1","1.87","gevrek","3");





CREATE TABLE `tag_art` (
  `tag_id` int(11) DEFAULT NULL,
  `art_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO tag_art VALUES("1","2");
INSERT INTO tag_art VALUES("1","1");
INSERT INTO tag_art VALUES("2","3");





CREATE TABLE `user` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `income` float DEFAULT NULL,
  `created_on` date DEFAULT NULL,
  `password` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO user VALUES("1","1.25","2012-12-03","1536");
INSERT INTO user VALUES("2","1.78","2012-05-12","534");
INSERT INTO user VALUES("3","1.05","2012-09-02","78");



--------------------------------------------------------------------------Friday 4th of April 2014 07:30:07 AM

CREATE TABLE `article` (
  `article_id` int(11) NOT NULL AUTO_INCREMENT,
  `price` varchar(20) DEFAULT NULL,
  `url` varchar(50) DEFAULT NULL,
  `content` varchar(150) DEFAULT NULL,
  PRIMARY KEY (`article_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO article VALUES("1","5","jkbdsvc.abv","qwert");
INSERT INTO article VALUES("2","5.54","kon.com","asdfg");
INSERT INTO article VALUES("3","5.84","ddz.net","zxcv");





CREATE TABLE `category` (
  `category_id` int(11) NOT NULL AUTO_INCREMENT,
  `created_by` varchar(20) DEFAULT NULL,
  `description` varchar(20) DEFAULT NULL,
  `art_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`category_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO category VALUES("1","GOGO","Krimi","1");
INSERT INTO category VALUES("2","NASKO","Biznes","2");
INSERT INTO category VALUES("3","ERIK","Sport","3");





CREATE TABLE `tag` (
  `tag_id` int(11) NOT NULL AUTO_INCREMENT,
  `second_priority` float DEFAULT NULL,
  `description` varchar(20) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`tag_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

INSERT INTO tag VALUES("1","1.87","gevrek","3");





CREATE TABLE `tag_art` (
  `tag_id` int(11) DEFAULT NULL,
  `art_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO tag_art VALUES("1","2");
INSERT INTO tag_art VALUES("1","1");
INSERT INTO tag_art VALUES("2","3");





CREATE TABLE `user` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `income` float DEFAULT NULL,
  `created_on` date DEFAULT NULL,
  `password` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO user VALUES("1","1.25","2012-12-03","1536");
INSERT INTO user VALUES("2","1.78","2012-05-12","534");
INSERT INTO user VALUES("3","1.05","2012-09-02","78");



--------------------------------------------------------------------------Friday 4th of April 2014 07:31:31 AM