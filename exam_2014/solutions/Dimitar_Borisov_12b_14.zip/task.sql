CREATE TABLE Article (
	id INT PRIMARY KEY auto_increment
	,name VARCHAR(10)
	,published_on DATE
	,url TEXT
);

CREATE TABLE Category (
	id INT PRIMARY KEY auto_increment
	,created_by TEXT
	,date_created_on DATE
	,article_id INT
);

CREATE TABLE User (
	id INT PRIMARY KEY auto_increment
	,age INT
	,income DOUBLE
	,created_on DATE
);

CREATE TABLE Tag (
	id INT PRIMARY KEY auto_increment
	,priority INT
	,description VARCHAR(10)
);

CREATE TABLE category_tag (
	category_id INT
	,tag_id INT
);

CREATE TABLE tag_user (
	tag_id INT
	,user_id INT

);
	
insert into Article values ("","asd",NOW(),"www");
insert into Article values ("","dsa",NOW(),"zzz");
                    
insert into Category values ("","asd",NOW(),1);
insert into Category values ("","dsa",NOW(),2);
                    
insert into User values ("",18,2.50,NOW());
insert into User values ("",19,2.60,NOW());
                    
insert into Tag values ("",1,"old");
insert into Tag values ("",2,"new");

insert into category_tag values (1,1);
insert into category_tag values (1,2);

insert into tag_user values (1,1);
insert into tag_user values (1,2);

select * from tag,article,category,category_tag where article.id = category.article_id and category_tag.tag_id = tag.id and category_tag.category_id = category.id and article.name ="asd"
select * from user, category_part1,category_part2,category_tag,tag, tag_user where category_part1.id = category_part2.id and tag.id = tag_user.tag_id and user.id = tag_user.user_id and category_part1.id = category_tag.category_id and category_tag.tag_id = tag.id and category_part1.created_by = "asd"; 