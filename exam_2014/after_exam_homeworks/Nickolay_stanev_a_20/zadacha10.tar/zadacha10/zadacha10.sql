-- phpMyAdmin SQL Dump
-- version 4.0.4
-- http://www.phpmyadmin.net
--
-- Хост: 127.0.0.1
-- Време на генериране: 
-- Версия на сървъра: 5.5.32
-- Версия на PHP: 5.4.16

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- БД: `task10`
--
CREATE DATABASE IF NOT EXISTS `task10` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `task10`;

-- --------------------------------------------------------

--
-- Структура на таблица `article`
--

CREATE TABLE IF NOT EXISTS `article` (
  `id` int(11) DEFAULT NULL,
  `price` int(11) DEFAULT NULL,
  `name` varchar(50) DEFAULT NULL,
  `content` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Схема на данните от таблица `article`
--

INSERT INTO `article` (`id`, `price`, `name`, `content`) VALUES
(1, 12, 'afssg', 'afsdssg'),
(2, 30, 'sdffdsdasg', 'addsfssg');

-- --------------------------------------------------------

--
-- Структура на таблица `category`
--

CREATE TABLE IF NOT EXISTS `category` (
  `id` int(11) DEFAULT NULL,
  `created_by` varchar(50) DEFAULT NULL,
  `description` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Схема на данните от таблица `category`
--

INSERT INTO `category` (`id`, `created_by`, `description`) VALUES
(1, 'afssgdasd', 'xzcafsgcx'),
(2, 'afscxzvx', 'sagxvz');

-- --------------------------------------------------------

--
-- Структура на таблица `tag`
--

CREATE TABLE IF NOT EXISTS `tag` (
  `id` int(11) DEFAULT NULL,
  `privority` int(11) DEFAULT NULL,
  `description` varchar(50) DEFAULT NULL,
  `article_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Схема на данните от таблица `tag`
--

INSERT INTO `tag` (`id`, `privority`, `description`, `article_id`) VALUES
(1, 132, 'afssg', 1),
(2, 312, 'afssgsad', 2);

-- --------------------------------------------------------

--
-- Структура на таблица `user`
--

CREATE TABLE IF NOT EXISTS `user` (
  `id` int(11) DEFAULT NULL,
  `picture_url` varchar(50) DEFAULT NULL,
  `description` varchar(50) DEFAULT NULL,
  `password` varchar(50) DEFAULT NULL,
  `article_id` int(11) DEFAULT NULL,
  `category_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Схема на данните от таблица `user`
--

INSERT INTO `user` (`id`, `picture_url`, `description`, `password`, `article_id`, `category_id`) VALUES
(1, 'afssgdsvcxzv', 'sdffdsdasg', 'sdffdsg', 1, 1),
(2, 'afssg', 'sdffdsdasg', 'sdffdsg', 2, 2);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
