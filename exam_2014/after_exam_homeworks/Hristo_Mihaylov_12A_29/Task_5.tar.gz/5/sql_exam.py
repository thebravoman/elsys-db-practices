#!/usr/bin/env python

import MySQLdb

def close(connection):
    connection.close()

db = MySQLdb.connect(unix_socket='/home/ico/Programs/mysql/socket', user="root", passwd="mono", db="exam_database")
db.autocommit(False)
cur = db.cursor()

# 4.Which are the article(s) for a given Tag
cur.execute("SELECT * FROM article;")
for row in cur.fetchall():
    print row[0]
try:
    cur.execute("CREATE TABLE article_part1 (published_on DATE NOT NULL);")
    cur.execute("INSERT INTO article_part1 SELECT article.published_on FROM article;")
except MySQLdb.Error,e:
    print e[0],e[1]
    db.rollback()
    cur.close()
    db.close()
    
cur.execute("SELECT * FROM article_part1;")
for row in cur.fetchall():
    print row[0]
    
try:
    cur.execute("CREATE TABLE article_part2 (price DECIMAL(30, 30) NOT NULL, created_on DATE NOT NULL, article_id INT(30) NOT NULL PRIMARY KEY AUTO_INCREMENT UNIQUE);");
    cur.execute("INSERT INTO article_part2 SELECT article.created_on, article.published_on, article.article_id FROM article;")
except MySQLdb.Error,e:
    print e[0],e[1]
    db.rollback()
    cur.close()
    db.close()
    
cur.execute("SELECT * FROM article_part2;")
for row in cur.fetchall():
    print row[0], row[1], row[2]
db.commit()
close(db)
