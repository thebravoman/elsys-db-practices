#!/usr/bin/env python

import MySQLdb

def close(connection):
    connection.close()

db = MySQLdb.connect(unix_socket='/home/ico/Programs/mysql/socket', user="root", passwd="mono", db="exam_database")
db.autocommit(False)
cur = db.cursor()

# 4.Which are the Category(s) for a given Tag
cur.execute("SELECT * FROM category;")
for row in cur.fetchall():
    print row[0]
try:
    cur.execute("CREATE TABLE category_part1 (description VARCHAR(30) NOT NULL);")
    cur.execute("INSERT INTO category_part1 SELECT category.description FROM category;")
except MySQLdb.Error,e:
    print e[0],e[1]
    db.rollback()
    cur.close()
    db.close()
    
cur.execute("SELECT * FROM category_part1;")
for row in cur.fetchall():
    print row[0]
    
try:
    cur.execute("CREATE TABLE category_part2 (created_by TEXT NOT NULL, user_id INT(30) NOT NULL, category_id INT(30) NOT NULL PRIMARY KEY AUTO_INCREMENT UNIQUE);");
    cur.execute("INSERT INTO category_part2 SELECT category.created_by, category.user_id, category.category_id FROM category;")
except MySQLdb.Error,e:
    print e[0],e[1]
    db.rollback()
    cur.close()
    db.close()
    
cur.execute("SELECT * FROM category_part2;")
for row in cur.fetchall():
    print row[0], row[1], row[2]
db.commit()
close(db)
