#!/usr/bin/env python

import MySQLdb

def close(connection):
    connection.close()

db = MySQLdb.connect(unix_socket='/home/ico/Programs/mysql/socket', user="root", passwd="mono", db="exam_database")
db.autocommit(False)
cur = db.cursor()

# 4.Which are the Category(s) for a given Tag
cur.execute("SELECT * FROM Category;")
for row in cur.fetchall():
    print row[0]
try:
    cur.execute("CREATE TABLE Category_part1 (description VARCHAR(30) NOT NULL);")
    cur.execute("INSERT INTO Category_part1 SELECT Category.description FROM Category;")
except MySQLdb.Error,e:
    db.rollback()
    print e[0],e[1]
    cur.close()
    db.close()
    
cur.execute("SELECT * FROM Category_part1;")
for row in cur.fetchall():
    print row[0]
    
try:
    cur.execute("CREATE TABLE Category_part2 (priority DOUBLE(30, 30), category_id INT(30) NOT NULL PRIMARY KEY AUTO_INCREMENT UNIQUE, user_id INT(30) NOT NULL);");
    cur.execute("INSERT INTO Category_part2 SELECT Category.priority, Category.category_id FROM Category);")
except MySQLdb.Error,e:
    db.rollback()
    print e[0],e[1]
    cur.close()
    db.close()
    
cur.execute("SELECT * FROM Category_part2;")
for row in cur.fetchall():
    print row[0], row[1], row[2]
db.commit()
close(db)
