#!/usr/bin/env python

import MySQLdb

db = MySQLdb.connect(unix_socket='/home/ico/Programs/mysql/socket', user="root", passwd="mono", db="exam_database")
db.autocommit(False)
cur = db.cursor()

# 4.Which are the Category(s) for a given Tag
cur.execute("SELECT * FROM Category;")
for row in cur.fetchall():
    print row[0]
try:
    cur.execute("CREATE TABLE Category_part1 (priority INT(30) NOT NULL);")
    cur.execute("INSERT INTO Category_part1 SELECT Category.priority FROM Category;")
except MySQLdb.Error,e:
    db.rollback()
    print e[0],e[1]
    cur.close()
    db.close()
    
cur.execute("SELECT * FROM Category_part1;")
for row in cur.fetchall():
    print row[0]
    
try:
    cur.execute("CREATE TABLE Category_part2 (name VARCHAR(30) NOT NULL, category_id INT(30) NOT NULL PRIMARY KEY AUTO_INCREMENT);");
    cur.execute("INSERT INTO Category_part2 SELECT Category.name, Category.category_id FROM Category;")
except MySQLdb.Error,e:
    db.rollback()
    print e[0],e[1]
    cur.close()
    db.close()
    
cur.execute("SELECT * FROM Category_part2;")
for row in cur.fetchall():
    print row
db.commit()
db.close()
