#!/usr/bin/env python

"""
6. Execute the following migration
Separate Article on two tables
Article_part1 containing published_on
Article_part2 containing all the other fields
"""

import MySQLdb

def close(connection):
    connection.close()

db = MySQLdb.connect(unix_socket='/home/ico/Programs/mysql/socket', user="root", passwd="mono", db="exam_database")
db.autocommit(False)
cur = db.cursor()

# 4.Which are the Category(s) for a given Tag
cur.execute("SELECT * FROM category;")
for row in cur.fetchall():
    print row[0]
try:
    cur.execute("CREATE TABLE category_part1 (date_created DATE NOT NULL);")
    cur.execute("INSERT INTO category_part1 SELECT category.date_created FROM category;")
except MySQLdb.Error,e:
    print e[0],e[1]
    db.rollback()
    cur.close()
    db.close()
    
cur.execute("SELECT * FROM category_part1;")
for row in cur.fetchall():
    print row[0]
    
try:
    cur.execute("CREATE TABLE category_part2 (name VARCHAR(30) NOT NULL, category_id INT(30) NOT NULL PRIMARY KEY AUTO_INCREMENT UNIQUE, user_id INT(30) NOT NULL);");
    cur.execute("INSERT INTO category_part2 SELECT category.name, category.category_id, category.user_id FROM category;")
except MySQLdb.Error,e:
    print e[0],e[1]
    db.rollback()
    cur.close()
    db.close()
    
cur.execute("SELECT * FROM category_part2;")
for row in cur.fetchall():
    print row[0], row[1], row[2]
db.commit()
close(db)
