#!/usr/bin/env python

import MySQLdb

db = MySQLdb.connect(unix_socket='/home/ico/Programs/mysql/socket', user="root", passwd="mono", db="exam_database")
db.autocommit(False)
cur = db.cursor()

# 4.Which are the Tag(s) for a given Tag
cur.execute("SELECT * FROM Tag;")
for row in cur.fetchall():
    print row[0]
try:
    cur.execute("CREATE TABLE Tag_part1 (description VARCHAR(30) NOT NULL);")
    cur.execute("INSERT INTO Tag_part1 SELECT Tag.description FROM Tag;")
except MySQLdb.Error,e:
    db.rollback()
    print e[0],e[1]
    cur.close()
    db.close()
    
cur.execute("SELECT * FROM Tag_part1;")
for row in cur.fetchall():
    print row[0]
    
try:
    cur.execute("CREATE TABLE Tag_part2 (priority INT NOT NULL, tag_id INT NOT NULL PRIMARY KEY AUTO_INCREMENT);");
    cur.execute("INSERT INTO Tag_part2 SELECT Tag.priority, Tag.tag_id FROM Tag;")
except MySQLdb.Error,e:
    db.rollback()
    print e[0],e[1]
    cur.close()
    db.close()
    
cur.execute("SELECT * FROM Tag_part2;")
for row in cur.fetchall():
    print row
db.commit()
db.close()
