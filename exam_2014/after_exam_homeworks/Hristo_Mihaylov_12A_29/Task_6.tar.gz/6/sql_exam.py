#!/usr/bin/env python

import MySQLdb

def close(connection):
    connection.close()

db = MySQLdb.connect(unix_socket='/home/ico/Programs/mysql/socket', user="root", passwd="mono", db="exam_database")
db.autocommit(False)
cur = db.cursor()

# 4.Which are the Article(s) for a given Tag
cur.execute("SELECT * FROM Article;")
for row in cur.fetchall():
    print row[0]
try:
    cur.execute("CREATE TABLE Article_part1 (content LONGTEXT NOT NULL);")
    cur.execute("INSERT INTO Article_part1 SELECT Article.content FROM Article;")
except MySQLdb.Error,e:
    print e[0],e[1]
    db.rollback()
    cur.close()
    db.close()
    
cur.execute("SELECT * FROM Article_part1;")
for row in cur.fetchall():
    print row[0]
    
try:
    cur.execute("CREATE TABLE Article_part2 (published_on DATE NOT NULL,  created_on DATE NOT NULL, Article_id INT(30) NOT NULL PRIMARY KEY AUTO_INCREMENT UNIQUE);");
    cur.execute("INSERT INTO Article_part2 SELECT Article.published_on, Article.created_on, Article.Article_id FROM Article;")
except MySQLdb.Error,e:
    print e[0],e[1]
    db.rollback()
    cur.close()
    db.close()
    
cur.execute("SELECT * FROM Article_part2;")
for row in cur.fetchall():
    print row[0], row[1], row[2]
db.commit()
close(db)
