-- phpMyAdmin SQL Dump
-- version 4.0.4
-- http://www.phpmyadmin.net
--
-- Хост: 127.0.0.1
-- Време на генериране: 
-- Версия на сървъра: 5.5.32
-- Версия на PHP: 5.4.16

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- БД: `task6`
--
CREATE DATABASE IF NOT EXISTS `task6` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `task6`;

-- --------------------------------------------------------

--
-- Структура на таблица `article_part1`
--

CREATE TABLE IF NOT EXISTS `article_part1` (
  `id` int(11) DEFAULT NULL,
  `name` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Схема на данните от таблица `article_part1`
--

INSERT INTO `article_part1` (`id`, `name`) VALUES
(1, 'dsgds'),
(2, 'fadsvcxz');

-- --------------------------------------------------------

--
-- Структура на таблица `article_part2`
--

CREATE TABLE IF NOT EXISTS `article_part2` (
  `id` int(11) DEFAULT NULL,
  `url` varchar(50) DEFAULT NULL,
  `created_on` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Схема на данните от таблица `article_part2`
--

INSERT INTO `article_part2` (`id`, `url`, `created_on`) VALUES
(1, 'afsdssg', '0000-00-00'),
(2, 'addsfssg', '0000-00-00');

-- --------------------------------------------------------

--
-- Структура на таблица `category`
--

CREATE TABLE IF NOT EXISTS `category` (
  `id` int(11) DEFAULT NULL,
  `description` varchar(50) DEFAULT NULL,
  `priority` double DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Схема на данните от таблица `category`
--

INSERT INTO `category` (`id`, `description`, `priority`, `user_id`) VALUES
(1, 'afssgdasd', 2.12, 1),
(2, 'afscxzvx', 2.351, 2);

-- --------------------------------------------------------

--
-- Структура на таблица `tag`
--

CREATE TABLE IF NOT EXISTS `tag` (
  `id` int(11) DEFAULT NULL,
  `description` varchar(50) DEFAULT NULL,
  `name` varchar(50) DEFAULT NULL,
  `article_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Схема на данните от таблица `tag`
--

INSERT INTO `tag` (`id`, `description`, `name`, `article_id`) VALUES
(1, 'afssg', 'sdfcx', 1),
(2, 'afssgsad', 'dsvxc', 2);

-- --------------------------------------------------------

--
-- Структура на таблица `user`
--

CREATE TABLE IF NOT EXISTS `user` (
  `id` int(11) DEFAULT NULL,
  `age` int(11) DEFAULT NULL,
  `password` varchar(50) DEFAULT NULL,
  `created_on` date DEFAULT NULL,
  `category_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Схема на данните от таблица `user`
--

INSERT INTO `user` (`id`, `age`, `password`, `created_on`, `category_id`) VALUES
(1, 15, 'sdffdsg', '0000-00-00', 1),
(2, 18, 'sdffdsg', '0000-00-00', 2);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
