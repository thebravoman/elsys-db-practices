-- phpMyAdmin SQL Dump
-- version 4.0.4
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Apr 12, 2014 at 12:18 PM
-- Server version: 5.5.32
-- PHP Version: 5.4.16

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `task2`
--
CREATE DATABASE IF NOT EXISTS `task2` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `task2`;

-- --------------------------------------------------------

--
-- Table structure for table `article`
--

CREATE TABLE IF NOT EXISTS `article` (
  `id` int(11) DEFAULT NULL,
  `price` int(11) DEFAULT NULL,
  `created_on` date DEFAULT NULL,
  `url` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `article`
--

INSERT INTO `article` (`id`, `price`, `created_on`, `url`) VALUES
(1, 150, '2006-02-02', 'sdffdsg'),
(2, 50, '2010-05-05', 'sdfzx');

-- --------------------------------------------------------

--
-- Table structure for table `category_part1`
--

CREATE TABLE IF NOT EXISTS `category_part1` (
  `id` int(11) DEFAULT NULL,
  `description` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `category_part1`
--

INSERT INTO `category_part1` (`id`, `description`) VALUES
(1, 'dasfzsx'),
(2, 'dsvvzxc');

-- --------------------------------------------------------

--
-- Table structure for table `category_part2`
--

CREATE TABLE IF NOT EXISTS `category_part2` (
  `id` int(11) DEFAULT NULL,
  `created_by` varchar(50) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `category_part2`
--

INSERT INTO `category_part2` (`id`, `created_by`, `user_id`) VALUES
(1, 'bobi', 1),
(2, 'tony', 2);

-- --------------------------------------------------------

--
-- Table structure for table `tag`
--

CREATE TABLE IF NOT EXISTS `tag` (
  `id` int(11) DEFAULT NULL,
  `description` varchar(100) DEFAULT NULL,
  `priority` int(11) DEFAULT NULL,
  `category_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tag`
--

INSERT INTO `tag` (`id`, `description`, `priority`, `category_id`) VALUES
(1, 'random', 12, 1),
(2, 'tag2', 21, 2);

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE IF NOT EXISTS `user` (
  `id` int(11) DEFAULT NULL,
  `password` varchar(50) DEFAULT NULL,
  `age` int(11) DEFAULT NULL,
  `name` varchar(100) DEFAULT NULL,
  `article_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `password`, `age`, `name`, `article_id`) VALUES
(1, 'asd', 18, 'qkarabota', 1),
(2, 'asdsd', 19, 'ofoakasd', 2);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
