-- phpMyAdmin SQL Dump
-- version 4.0.4
-- http://www.phpmyadmin.net
--
-- Хост: 127.0.0.1
-- Време на генериране: 
-- Версия на сървъра: 5.5.32
-- Версия на PHP: 5.4.16

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- БД: `task3`
--
CREATE DATABASE IF NOT EXISTS `task3` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `task3`;

-- --------------------------------------------------------

--
-- Структура на таблица `article`
--

CREATE TABLE IF NOT EXISTS `article` (
  `id` int(11) DEFAULT NULL,
  `url` varchar(50) DEFAULT NULL,
  `price` int(11) DEFAULT NULL,
  `content` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Схема на данните от таблица `article`
--

INSERT INTO `article` (`id`, `url`, `price`, `content`) VALUES
(1, 'qkarabota', 15, 'sdffdsg'),
(2, 'asdffg', 15, 'sdfzx');

-- --------------------------------------------------------

--
-- Структура на таблица `article_category`
--

CREATE TABLE IF NOT EXISTS `article_category` (
  `article_id` int(11) DEFAULT NULL,
  `category_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Структура на таблица `category`
--

CREATE TABLE IF NOT EXISTS `category` (
  `id` int(11) DEFAULT NULL,
  `priority` double DEFAULT NULL,
  `data_created_on` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Схема на данните от таблица `category`
--

INSERT INTO `category` (`id`, `priority`, `data_created_on`) VALUES
(1, 3.54, '2003-04-20'),
(2, 5.41, '2003-04-20');

-- --------------------------------------------------------

--
-- Структура на таблица `tag`
--

CREATE TABLE IF NOT EXISTS `tag` (
  `id` int(11) DEFAULT NULL,
  `second_priority` double DEFAULT NULL,
  `description` varchar(50) DEFAULT NULL,
  `category_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Схема на данните от таблица `tag`
--

INSERT INTO `tag` (`id`, `second_priority`, `description`, `category_id`) VALUES
(1, 13.5, 'asdsdaf', 1),
(2, 13.7, 'asddas', 2);

-- --------------------------------------------------------

--
-- Структура на таблица `user`
--

CREATE TABLE IF NOT EXISTS `user` (
  `id` int(11) DEFAULT NULL,
  `description` varchar(50) DEFAULT NULL,
  `password` varchar(50) DEFAULT NULL,
  `age` int(11) DEFAULT NULL,
  `article_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Схема на данните от таблица `user`
--

INSERT INTO `user` (`id`, `description`, `password`, `age`, `article_id`) VALUES
(1, 'asd', 'asdfsd', 15, 1),
(2, 'asdsd', 'asdasf', 19, 2);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
