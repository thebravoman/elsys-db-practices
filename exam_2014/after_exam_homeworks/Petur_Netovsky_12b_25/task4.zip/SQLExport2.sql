-- phpMyAdmin SQL Dump
-- version 4.1.6
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Apr 17, 2014 at 01:48 PM
-- Server version: 5.6.16
-- PHP Version: 5.5.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";

--
-- Database: `tasks`
--

-- --------------------------------------------------------

--
-- Table structure for table `article`
--

CREATE TABLE IF NOT EXISTS `article` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `content` longtext NOT NULL,
  `name` varchar(100) NOT NULL,
  `url` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `article`
--

INSERT INTO `article` (`id`, `content`, `name`, `url`) VALUES
(1, 'SOME CONTENT', 'MyName', 'MyNameurl.com'),
(2, 'SOME CONTENT AGAIN', 'MyName1', 'MyNameudhndjnrl.com');

-- --------------------------------------------------------

--
-- Table structure for table `category_part1`
--

CREATE TABLE IF NOT EXISTS `category_part1` (
  `id` int(11) NOT NULL,
  `priority` double NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `category_part1`
--

INSERT INTO `category_part1` (`id`, `priority`) VALUES
(1, 6421642.64216),
(2, 5754.751751);

-- --------------------------------------------------------

--
-- Table structure for table `category_part2`
--

CREATE TABLE IF NOT EXISTS `category_part2` (
  `id` int(11) NOT NULL,
  `description` varchar(150) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `category_part2`
--

INSERT INTO `category_part2` (`id`, `description`) VALUES
(1, 'JNFGSJKGBB'),
(2, 'HBFAGBJD');

-- --------------------------------------------------------

--
-- Table structure for table `tag`
--

CREATE TABLE IF NOT EXISTS `tag` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `second_priority` float NOT NULL,
  `category_id` int(11) DEFAULT NULL,
  `article_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `category_id` (`category_id`),
  KEY `article_id` (`article_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `tag`
--

INSERT INTO `tag` (`id`, `name`, `second_priority`, `category_id`, `article_id`) VALUES
(1, 'fghkjdfhndh', 6512.17, 1, 2),
(2, 'ftkukytuk', 5451.45, 2, 1);

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE IF NOT EXISTS `user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `created_on` date NOT NULL,
  `age` int(11) NOT NULL,
  `description` longtext NOT NULL,
  `category_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `category_id` (`category_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `created_on`, `age`, `description`, `category_id`) VALUES
(1, '2014-04-16', 54, 'HJRBGKSRBGIKSRBKGJBSNGH', 1),
(2, '2014-04-09', 44, 'HJRBGKSRBGIKSRBKGJBSNGHedhjter', 1);
