-- phpMyAdmin SQL Dump
-- version 4.1.6
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Apr 17, 2014 at 03:29 PM
-- Server version: 5.6.16
-- PHP Version: 5.5.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";

--
-- Database: `tasks`
--

-- --------------------------------------------------------

--
-- Table structure for table `category_part2`
--

CREATE TABLE IF NOT EXISTS `category_part2` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `created_by` tinytext NOT NULL,
  `article_id` int(11) NOT NULL,
  `tag_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `article_id` (`article_id`),
  KEY `tag_id` (`tag_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `category_part2`
--

INSERT INTO `category_part2` (`id`, `created_by`, `article_id`, `tag_id`) VALUES
(1, 'Me', 1, 2),
(2, 'MeAswell', 1, 1);
