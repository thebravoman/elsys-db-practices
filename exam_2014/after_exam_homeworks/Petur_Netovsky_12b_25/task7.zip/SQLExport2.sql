-- phpMyAdmin SQL Dump
-- version 4.1.6
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Apr 17, 2014 at 09:51 PM
-- Server version: 5.6.16
-- PHP Version: 5.5.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";

--
-- Database: `tasks`
--

-- --------------------------------------------------------

--
-- Table structure for table `article`
--

CREATE TABLE IF NOT EXISTS `article` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `created_on` date NOT NULL,
  `name` varchar(70) NOT NULL,
  `url` tinytext NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `article`
--

INSERT INTO `article` (`id`, `created_on`, `name`, `url`) VALUES
(1, '2144-04-14', 'Name16', 'nope.html'),
(2, '2571-04-15', 'Name17', 'nope1.com');

-- --------------------------------------------------------

--
-- Table structure for table `category_part1`
--

CREATE TABLE IF NOT EXISTS `category_part1` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `description` varchar(250) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `category_part1`
--

INSERT INTO `category_part1` (`id`, `description`) VALUES
(1, 'description3'),
(2, 'description3');

-- --------------------------------------------------------

--
-- Table structure for table `category_part2`
--

CREATE TABLE IF NOT EXISTS `category_part2` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `created_by` tinytext NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `tag_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `tag_id` (`tag_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `category_part2`
--

INSERT INTO `category_part2` (`id`, `created_by`, `user_id`, `tag_id`) VALUES
(1, 'ME', 1, 2),
(2, 'MEALSO', 1, 2);

-- --------------------------------------------------------

--
-- Table structure for table `tag`
--

CREATE TABLE IF NOT EXISTS `tag` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `description` varchar(200) NOT NULL,
  `name` varchar(70) NOT NULL,
  `article_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `article_id` (`article_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `tag`
--

INSERT INTO `tag` (`id`, `description`, `name`, `article_id`) VALUES
(1, 'description1', 'Name14', 1),
(2, 'description2', 'Name15', 2);

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE IF NOT EXISTS `user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `picture_url` tinytext,
  `income` float NOT NULL,
  `created_on` date NOT NULL,
  `category_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `category_id` (`category_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `picture_url`, `income`, `created_on`, `category_id`) VALUES
(1, 'nope.jpg', 15.36, '2254-04-14', 2),
(2, 'nope.gif', 25.32, '2784-04-14', 1);
