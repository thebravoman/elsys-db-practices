

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;



CREATE TABLE IF NOT EXISTS `article` (
  `id` int(11) DEFAULT NULL,
  `content` varchar(200) DEFAULT NULL,
  `created_on` date DEFAULT NULL,
  `url` varchar(50) DEFAULT NULL,
  `category_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



INSERT INTO `article` (`id`, `content`, `created_on`, `url`, `category_id`) VALUES
(1, 'Content1', '2014-04-02', 'www.myblog.com', 1),
(2, 'Content2', '2014-04-02', 'www.myblog.com', 2);


CREATE TABLE IF NOT EXISTS `article_to_tag` (
  `article_id` int(11) DEFAULT NULL,
  `tag_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


INSERT INTO `article_to_tag` (`article_id`, `tag_id`) VALUES
(1, 1),
(2, 2);


CREATE TABLE IF NOT EXISTS `category` (
  `id` int(11) DEFAULT NULL,
  `created_by` varchar(30) DEFAULT NULL,
  `description` varchar(200) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


INSERT INTO `category` (`id`, `created_by`, `description`) VALUES
(1, 'Nguen', 'Random description 1'),
(2, 'ALex', 'Random description 2');



CREATE TABLE IF NOT EXISTS `tag` (
  `id` int(11) DEFAULT NULL,
  `second_priority` int(11) DEFAULT NULL,
  `name` varchar(40) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


INSERT INTO `tag` (`id`, `second_priority`, `name`) VALUES
(1, 1, 'Name1'),
(2, 2, 'Name2');



CREATE TABLE IF NOT EXISTS `user` (
  `id` int(11) DEFAULT NULL,
  `password` varchar(30) DEFAULT NULL,
  `name` varchar(40) DEFAULT NULL,
  `age` int(11) DEFAULT NULL,
  `category_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


INSERT INTO `user` (`id`, `password`, `name`, `age`, `category_id`) VALUES
(1, 'pass', 'Simeon', 19, 1),
(2, 'word', 'Nguen', 37, 2);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
