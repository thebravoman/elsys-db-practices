

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;



CREATE TABLE IF NOT EXISTS `article` (
  `id` int(11) DEFAULT NULL,
  `price` int(11) DEFAULT NULL,
  `created_on` date DEFAULT NULL,
  `published_on` date DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  UNIQUE KEY `user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


INSERT INTO `article` (`id`, `price`, `created_on`, `published_on`, `user_id`) VALUES
(1, 16, '2014-04-02', '2014-04-02', 1),
(2, 21, '2014-04-02', '2014-04-02', 2);


CREATE TABLE IF NOT EXISTS `category` (
  `id` int(11) DEFAULT NULL,
  `priority` float DEFAULT NULL,
  `created_by` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


INSERT INTO `category` (`id`, `priority`, `created_by`) VALUES
(1, 1.1, 'Random name 1'),
(2, 1.2, 'Random name 2');



CREATE TABLE IF NOT EXISTS `tag` (
  `id` int(11) DEFAULT NULL,
  `description` varchar(200) DEFAULT NULL,
  `name` varchar(50) DEFAULT NULL,
  `category_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


INSERT INTO `tag` (`id`, `description`, `name`, `category_id`) VALUES
(1, 'Random description 1', 'Random name 1', 1),
(2, 'Random description 2', 'Random name 2', 2);



CREATE TABLE IF NOT EXISTS `user` (
  `id` int(11) DEFAULT NULL,
  `picture_url` varchar(50) DEFAULT NULL,
  `created_on` date DEFAULT NULL,
  `age` int(11) DEFAULT NULL,
  `tag_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


INSERT INTO `user` (`id`, `picture_url`, `created_on`, `age`, `tag_id`) VALUES
(1, 'www.blog.com/pic1', '2014-04-02', 19, 1),
(2, 'www.blog.com/pic2', '2014-04-02', 24, 2);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
