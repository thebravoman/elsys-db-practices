

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;


CREATE TABLE IF NOT EXISTS `article` (
  `id` int(11) DEFAULT NULL,
  `created_on` date DEFAULT NULL,
  `content` varchar(200) DEFAULT NULL,
  `name` varchar(50) DEFAULT NULL,
  `category_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


INSERT INTO `article` (`id`, `created_on`, `content`, `name`, `category_id`) VALUES
(1, '2014-04-02', 'Random content', 'Random name', 1),
(2, '2014-04-02', 'Random content', 'Random name', 2);


CREATE TABLE IF NOT EXISTS `category` (
  `id` int(11) DEFAULT NULL,
  `created_by` varchar(50) DEFAULT NULL,
  `priority` double DEFAULT NULL,
  `article_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


INSERT INTO `category` (`id`, `created_by`, `priority`, `article_id`) VALUES
(1, 'Nguen', 1.1, 1),
(2, 'Simeon', 2.2, 2);


CREATE TABLE IF NOT EXISTS `tag` (
  `id` int(11) DEFAULT NULL,
  `privority` int(11) DEFAULT NULL,
  `description` varchar(50) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


INSERT INTO `tag` (`id`, `privority`, `description`, `user_id`) VALUES
(1, 11, 'Random description 1', 1),
(2, 22, 'Random description 2', 2);


CREATE TABLE IF NOT EXISTS `user` (
  `id` int(11) DEFAULT NULL,
  `password` varchar(50) DEFAULT NULL,
  `income` double DEFAULT NULL,
  `description` varchar(200) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


INSERT INTO `user` (`id`, `password`, `income`, `description`) VALUES
(1, 'password', 1024.50, 'Random description 1'),
(2, 'passwordwoop', 5001.70, 'Random description 2');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
