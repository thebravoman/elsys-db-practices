
SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;



CREATE TABLE IF NOT EXISTS `article` (
  `id` int(11) DEFAULT NULL,
  `content` varchar(50) DEFAULT NULL,
  `published_on` date DEFAULT NULL,
  `url` varchar(50) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



INSERT INTO `article` (`id`, `content`, `published_on`, `url`, `user_id`) VALUES
(1, 'Content1', '2014-04-02', 'www.myblog.com', 1),
(2, 'Content2', '2014-04-02', 'www.myblog.com', 2);



CREATE TABLE IF NOT EXISTS `article_to_tag` (
  `article_id` int(11) DEFAULT NULL,
  `tag_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


INSERT INTO `article_to_tag` (`article_id`, `tag_id`) VALUES
(1, 1),
(2, 2);



CREATE TABLE IF NOT EXISTS `category` (
  `id` int(11) DEFAULT NULL,
  `date_created_on` date DEFAULT NULL,
  `priotity` double DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


INSERT INTO `category` (`id`, `date_created_on`, `priotity`) VALUES
(1, '2014-04-02', 1.1),
(2, '2014-04-02', 1.2);



CREATE TABLE IF NOT EXISTS `category_to_user` (
  `cateogry_id` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


INSERT INTO `category_to_user` (`cateogry_id`, `user_id`) VALUES
(1, 1),
(2, 2);



CREATE TABLE IF NOT EXISTS `tag` (
  `id` int(11) DEFAULT NULL,
  `privority` int(11) DEFAULT NULL,
  `description` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


INSERT INTO `tag` (`id`, `privority`, `description`) VALUES
(1, 1, 'Description1'),
(2, 2, 'Description2');



CREATE TABLE IF NOT EXISTS `user` (
  `id` int(11) DEFAULT NULL,
  `age` int(11) DEFAULT NULL,
  `password` varchar(50) DEFAULT NULL,
  `name` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



INSERT INTO `user` (`id`, `age`, `password`, `name`) VALUES
(1, 35, 'pass', 'Name1'),
(2, 19, 'word', 'name2');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
