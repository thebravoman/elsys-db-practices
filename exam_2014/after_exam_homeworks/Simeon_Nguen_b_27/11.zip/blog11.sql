

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;



CREATE TABLE IF NOT EXISTS `article` (
  `id` int(11) DEFAULT NULL,
  `name` varchar(50) DEFAULT NULL,
  `url` varchar(50) DEFAULT NULL,
  `created_on` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


INSERT INTO `article` (`id`, `name`, `url`, `created_on`) VALUES
(1, 'Random name 1', 'www.blog.com', '2014-04-02'),
(2, 'Random name 2', 'www.blog.com', '2014-04-02');


CREATE TABLE IF NOT EXISTS `category` (
  `id` int(11) DEFAULT NULL,
  `description` varchar(200) DEFAULT NULL,
  `priority` double DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


INSERT INTO `category` (`id`, `description`, `priority`, `user_id`) VALUES
(1, 'Random description 1', 1.1, 1),
(2, 'Random description 2', 1.2, 2);


CREATE TABLE IF NOT EXISTS `tag` (
  `id` int(11) DEFAULT NULL,
  `description` varchar(200) DEFAULT NULL,
  `name` varchar(50) DEFAULT NULL,
  `article_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



INSERT INTO `tag` (`id`, `description`, `name`, `article_id`) VALUES
(1, 'Random description 1', 'Random name 1', 1),
(2, 'Random description 2', 'Random name 2', 2);


CREATE TABLE IF NOT EXISTS `user` (
  `id` int(11) DEFAULT NULL,
  `age` int(11) DEFAULT NULL,
  `password` varchar(30) DEFAULT NULL,
  `created_on` date DEFAULT NULL,
  `category_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



INSERT INTO `user` (`id`, `age`, `password`, `created_on`, `category_id`) VALUES
(1, 19, 'password1', '2014-04-02', 1),
(2, 11, 'password2', '2014-04-02', 2);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
