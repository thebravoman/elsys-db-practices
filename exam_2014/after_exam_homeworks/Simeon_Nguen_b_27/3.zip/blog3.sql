
SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;



CREATE TABLE IF NOT EXISTS `article` (
  `id` int(11) DEFAULT NULL,
  `url` varchar(100) DEFAULT NULL,
  `created_on` date DEFAULT NULL,
  `published_on` date DEFAULT NULL,
  `tag_id` int(11) DEFAULT NULL,
  UNIQUE KEY `tag_id` (`tag_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



INSERT INTO `article` (`id`, `url`, `created_on`, `published_on`, `tag_id`) VALUES
(1, 'www.myblog.com', '2014-04-02', '2014-04-03', 1),
(2, 'www.myblog.com', '2014-04-07', '2014-04-08', 2);


CREATE TABLE IF NOT EXISTS `category` (
  `id` int(11) DEFAULT NULL,
  `created_on` date DEFAULT NULL,
  `created_by` varchar(50) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  UNIQUE KEY `user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


INSERT INTO `category` (`id`, `created_on`, `created_by`, `user_id`) VALUES
(1, '2014-04-02', 'nguen', 1),
(2, '2014-04-02', 'alex', 2);


CREATE TABLE IF NOT EXISTS `tag` (
  `id` int(11) DEFAULT NULL,
  `name` varchar(100) DEFAULT NULL,
  `second_priority` float DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



INSERT INTO `tag` (`id`, `name`, `second_priority`) VALUES
(1, 'Kden', 1.1),
(2, 'Ohwell', 1.2);


CREATE TABLE IF NOT EXISTS `user` (
  `id` int(11) DEFAULT NULL,
  `password` varchar(50) DEFAULT NULL,
  `picture_url` varchar(50) DEFAULT NULL,
  `description` varchar(100) DEFAULT NULL,
  `article_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


INSERT INTO `user` (`id`, `password`, `picture_url`, `description`, `article_id`) VALUES
(1, 'password1', 'www.picurl.com', 'Random Description', 1),
(2, 'password2', 'www.picurl2.com', 'Random Description2', 2);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
