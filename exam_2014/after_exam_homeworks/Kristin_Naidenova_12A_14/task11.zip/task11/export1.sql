--------------------------------------------------------
--  File created - ����������-�����-14-2014   
--------------------------------------------------------
--------------------------------------------------------
--  DDL for Table ARTICLE
--------------------------------------------------------

  CREATE TABLE "ELSYS"."ARTICLE" 
   (	"ID" NUMBER, 
	"published_on" DATE, 
	"price" NUMBER(*,0), 
	"content" VARCHAR2(20 BYTE), 
	"CATEGORY_ID" NUMBER
   ) SEGMENT CREATION IMMEDIATE 
  PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSTEM" ;
--------------------------------------------------------
--  DDL for Table CATEGORY
--------------------------------------------------------

  CREATE TABLE "ELSYS"."CATEGORY" 
   (	"ID" NUMBER, 
	"description" VARCHAR2(20 BYTE), 
	"priority" NUMBER(*,0), 
	"TAG_ID" NUMBER
   ) SEGMENT CREATION IMMEDIATE 
  PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSTEM" ;
--------------------------------------------------------
--  DDL for Table TAG
--------------------------------------------------------

  CREATE TABLE "ELSYS"."TAG" 
   (	"ID" NUMBER, 
	"name" VARCHAR2(20 BYTE), 
	"priority" NUMBER(*,0)
   ) SEGMENT CREATION IMMEDIATE 
  PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSTEM" ;
--------------------------------------------------------
--  DDL for Table USERS
--------------------------------------------------------

  CREATE TABLE "ELSYS"."USERS" 
   (	"ID" NUMBER, 
	"age" NUMBER(*,0), 
	"picture_url" VARCHAR2(20 BYTE), 
	"description" VARCHAR2(20 BYTE), 
	"ARTICLE_ID" NUMBER
   ) SEGMENT CREATION IMMEDIATE 
  PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSTEM" ;
REM INSERTING into ELSYS.ARTICLE
SET DEFINE OFF;
Insert into ELSYS.ARTICLE (ID,"published_on","price","content",CATEGORY_ID) values (1,to_date('2012-02-05','RRRR-MM-DD'),5,'jk',1);
Insert into ELSYS.ARTICLE (ID,"published_on","price","content",CATEGORY_ID) values (2,to_date('2012-02-06','RRRR-MM-DD'),55,'mk;',2);
REM INSERTING into ELSYS.CATEGORY
SET DEFINE OFF;
Insert into ELSYS.CATEGORY (ID,"description","priority",TAG_ID) values (1,'khg',2,1);
Insert into ELSYS.CATEGORY (ID,"description","priority",TAG_ID) values (2,'kgh',2,2);
REM INSERTING into ELSYS.TAG
SET DEFINE OFF;
Insert into ELSYS.TAG (ID,"name","priority") values (1,'jjpo',11);
Insert into ELSYS.TAG (ID,"name","priority") values (2,'jl',1);
REM INSERTING into ELSYS.USERS
SET DEFINE OFF;
Insert into ELSYS.USERS (ID,"age","picture_url","description",ARTICLE_ID) values (11,12,'kjl','kkjl',null);
Insert into ELSYS.USERS (ID,"age","picture_url","description",ARTICLE_ID) values (1,1,'nvm','n',null);
