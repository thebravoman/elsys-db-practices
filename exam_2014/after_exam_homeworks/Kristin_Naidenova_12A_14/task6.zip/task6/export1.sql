--------------------------------------------------------
--  File created - ����������-�����-14-2014   
--------------------------------------------------------
--------------------------------------------------------
--  DDL for Table ARTICLE
--------------------------------------------------------

  CREATE TABLE "ELSYS"."ARTICLE" 
   (	"ID" NUMBER, 
	"name" VARCHAR2(20 BYTE), 
	"created_on" DATE, 
	"url" VARCHAR2(20 BYTE), 
	"CATEGOTY_ID" NUMBER
   ) SEGMENT CREATION IMMEDIATE 
  PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSTEM" ;
--------------------------------------------------------
--  DDL for Table CATEGORY
--------------------------------------------------------

  CREATE TABLE "ELSYS"."CATEGORY" 
   (	"ID" NUMBER, 
	"priority" NUMBER(*,0), 
	"DATE_CREATED_ON" DATE
   ) SEGMENT CREATION IMMEDIATE 
  PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSTEM" ;
--------------------------------------------------------
--  DDL for Table TAG
--------------------------------------------------------

  CREATE TABLE "ELSYS"."TAG" 
   (	"ID" NUMBER, 
	"description" VARCHAR2(20 BYTE), 
	"NAME" VARCHAR2(20 BYTE)
   ) SEGMENT CREATION IMMEDIATE 
  PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSTEM" ;
--------------------------------------------------------
--  DDL for Table Tag_user
--------------------------------------------------------

  CREATE TABLE "ELSYS"."Tag_user" 
   (	"tag_id" NUMBER, 
	"user_id" NUMBER
   ) SEGMENT CREATION IMMEDIATE 
  PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSTEM" ;
--------------------------------------------------------
--  DDL for Table USERS
--------------------------------------------------------

  CREATE TABLE "ELSYS"."USERS" 
   (	"ID" NUMBER, 
	"age" NUMBER(*,0), 
	"DESCRIPTION" VARCHAR2(20 BYTE), 
	"picture_url" VARCHAR2(20 BYTE)
   ) SEGMENT CREATION IMMEDIATE 
  PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSTEM" ;
REM INSERTING into ELSYS.ARTICLE
SET DEFINE OFF;
Insert into ELSYS.ARTICLE (ID,"name","created_on","url",CATEGOTY_ID) values (1,'dfg',to_date('2011-12-21','RRRR-MM-DD'),'ere',11);
Insert into ELSYS.ARTICLE (ID,"name","created_on","url",CATEGOTY_ID) values (2,'fh',to_date('2014-01-05','RRRR-MM-DD'),'dg',2);
REM INSERTING into ELSYS.CATEGORY
SET DEFINE OFF;
Insert into ELSYS.CATEGORY (ID,"priority",DATE_CREATED_ON) values (1,2,to_date('2012-02-21','RRRR-MM-DD'));
Insert into ELSYS.CATEGORY (ID,"priority",DATE_CREATED_ON) values (2,22,to_date('2012-02-21','RRRR-MM-DD'));
REM INSERTING into ELSYS.TAG
SET DEFINE OFF;
Insert into ELSYS.TAG (ID,"description",NAME) values (1,'dds','ddg');
Insert into ELSYS.TAG (ID,"description",NAME) values (2,'fh','fh');
REM INSERTING into ELSYS."Tag_user"
SET DEFINE OFF;
Insert into ELSYS."Tag_user" ("tag_id","user_id") values (1,1);
Insert into ELSYS."Tag_user" ("tag_id","user_id") values (2,2);
REM INSERTING into ELSYS.USERS
SET DEFINE OFF;
Insert into ELSYS.USERS (ID,"age",DESCRIPTION,"picture_url") values (1,23,'ddfg','fg');
Insert into ELSYS.USERS (ID,"age",DESCRIPTION,"picture_url") values (2,45,'fh','ddfg');
