--------------------------------------------------------
--  File created - ����������-�����-14-2014   
--------------------------------------------------------
--------------------------------------------------------
--  DDL for Table ARTICLE
--------------------------------------------------------

  CREATE TABLE "ELSYS"."ARTICLE" 
   (	"ID" NUMBER, 
	"created_on" DATE, 
	"price" NUMBER(*,0), 
	"content" VARCHAR2(20 BYTE)
   ) SEGMENT CREATION IMMEDIATE 
  PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSTEM" ;
--------------------------------------------------------
--  DDL for Table CATEGORY
--------------------------------------------------------

  CREATE TABLE "ELSYS"."CATEGORY" 
   (	"ID" NUMBER, 
	"name" VARCHAR2(20 BYTE), 
	"DATE_CREATED_ON" DATE
   ) SEGMENT CREATION IMMEDIATE 
  PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSTEM" ;
--------------------------------------------------------
--  DDL for Table TAG
--------------------------------------------------------

  CREATE TABLE "ELSYS"."TAG" 
   (	"ID" NUMBER, 
	"priority" NUMBER(*,0), 
	"description" VARCHAR2(20 BYTE)
   ) SEGMENT CREATION IMMEDIATE 
  PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSTEM" ;
--------------------------------------------------------
--  DDL for Table USERS
--------------------------------------------------------

  CREATE TABLE "ELSYS"."USERS" 
   (	"ID" NUMBER, 
	"income" NUMBER(*,0), 
	"picture_url" VARCHAR2(20 BYTE), 
	"name" VARCHAR2(20 BYTE), 
	"ARTICLE_ID" NUMBER
   ) SEGMENT CREATION IMMEDIATE 
  PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSTEM" ;
--------------------------------------------------------
--  DDL for Table USERS_TAG
--------------------------------------------------------

  CREATE TABLE "ELSYS"."USERS_TAG" 
   (	"USER_ID" NUMBER, 
	"TAG_ID" NUMBER
   ) SEGMENT CREATION IMMEDIATE 
  PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSTEM" ;
REM INSERTING into ELSYS.ARTICLE
SET DEFINE OFF;
Insert into ELSYS.ARTICLE (ID,"created_on","price","content") values (1,to_date('2011-02-05','RRRR-MM-DD'),24,'DG');
Insert into ELSYS.ARTICLE (ID,"created_on","price","content") values (2,to_date('2013-05-07','RRRR-MM-DD'),34,'DDD');
REM INSERTING into ELSYS.CATEGORY
SET DEFINE OFF;
Insert into ELSYS.CATEGORY (ID,"name",DATE_CREATED_ON) values (1,'DG',to_date('2011-01-04','RRRR-MM-DD'));
Insert into ELSYS.CATEGORY (ID,"name",DATE_CREATED_ON) values (2,'ffg',to_date('2013-02-01','RRRR-MM-DD'));
REM INSERTING into ELSYS.TAG
SET DEFINE OFF;
Insert into ELSYS.TAG (ID,"priority","description") values (1,2,'dfg');
Insert into ELSYS.TAG (ID,"priority","description") values (2,3,'hhg');
REM INSERTING into ELSYS.USERS
SET DEFINE OFF;
Insert into ELSYS.USERS (ID,"income","picture_url","name",ARTICLE_ID) values (1,1,'dg','fgh',1);
Insert into ELSYS.USERS (ID,"income","picture_url","name",ARTICLE_ID) values (3,3,'ffh','hf',1);
REM INSERTING into ELSYS.USERS_TAG
SET DEFINE OFF;
Insert into ELSYS.USERS_TAG (USER_ID,TAG_ID) values (1,1);
Insert into ELSYS.USERS_TAG (USER_ID,TAG_ID) values (2,2);
