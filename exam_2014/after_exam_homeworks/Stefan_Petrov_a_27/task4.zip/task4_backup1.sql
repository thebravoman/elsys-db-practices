

CREATE TABLE `article` (
  `article_id` int(11) NOT NULL AUTO_INCREMENT,
  `price` varchar(20) DEFAULT NULL,
  `url` varchar(255) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`article_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO article VALUES("1","5","erty.com","dsfghjk");
INSERT INTO article VALUES("2","5.04","erty.com","asdfghj");
INSERT INTO article VALUES("3","5.04","erty.com","qwertyui");





CREATE TABLE `category` (
  `category_id` int(11) NOT NULL AUTO_INCREMENT,
  `date_created_on` date DEFAULT NULL,
  `priority` double DEFAULT NULL,
  PRIMARY KEY (`category_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO category VALUES("1","2012-12-03","12.5");
INSERT INTO category VALUES("2","2012-05-12","25.9");
INSERT INTO category VALUES("3","2012-09-02","78.5");





CREATE TABLE `tag` (
  `tag_id` int(11) NOT NULL AUTO_INCREMENT,
  `priority` varchar(220) DEFAULT NULL,
  `second_priority` float DEFAULT NULL,
  `cat_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`tag_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO tag VALUES("1","kon","2.15","2");
INSERT INTO tag VALUES("2","sopol","1.89","1");
INSERT INTO tag VALUES("3","gevrek","6.45","3");





CREATE TABLE `user` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `password` varchar(90) DEFAULT NULL,
  `income` float DEFAULT NULL,
  `picture_url` varchar(200) DEFAULT NULL,
  `art_id` int(11) DEFAULT NULL,
  `tag_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO user VALUES("1","sdfds","1.25","GOGO","1","2");
INSERT INTO user VALUES("2","sdfdsfyukj","1.58","PACO","2","3");
INSERT INTO user VALUES("3","sdfdsio","1.29","NASKO","3","1");



--------------------------------------------------------------------------Sunday 13th of April 2014 06:17:00 PM