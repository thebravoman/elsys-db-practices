

CREATE TABLE `article_part1` (
  `article_part1_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`article_part1_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO article_part1 VALUES("1","blala");
INSERT INTO article_part1 VALUES("2","blala");
INSERT INTO article_part1 VALUES("3","blala");





CREATE TABLE `article_part2` (
  `article_id` int(11) NOT NULL AUTO_INCREMENT,
  `created_on` date DEFAULT NULL,
  `published_on` date DEFAULT NULL,
  PRIMARY KEY (`article_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO article_part2 VALUES("1","2012-02-03","2011-02-03");
INSERT INTO article_part2 VALUES("2","2012-02-04","2011-02-04");
INSERT INTO article_part2 VALUES("3","2012-02-05","2011-02-05");





CREATE TABLE `category` (
  `category_id` int(11) NOT NULL AUTO_INCREMENT,
  `created_by` varchar(200) DEFAULT NULL,
  `date_created_on` date DEFAULT NULL,
  PRIMARY KEY (`category_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO category VALUES("1","kon","2010-03-04");
INSERT INTO category VALUES("2","sop","2010-03-05");
INSERT INTO category VALUES("3","ban","2010-03-06");





CREATE TABLE `tag` (
  `tag_id` int(11) NOT NULL AUTO_INCREMENT,
  `priority` int(11) DEFAULT NULL,
  `name` varchar(200) DEFAULT NULL,
  `art_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`tag_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO tag VALUES("1","2","kon","1");
INSERT INTO tag VALUES("2","1","sopol","2");
INSERT INTO tag VALUES("3","3","gevrek","3");





CREATE TABLE `tag_category` (
  `tag_cat_id` int(11) NOT NULL AUTO_INCREMENT,
  `tag_id` int(11) DEFAULT NULL,
  `cat_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`tag_cat_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO tag_category VALUES("1","1","1");
INSERT INTO tag_category VALUES("2","2","2");
INSERT INTO tag_category VALUES("3","3","3");





CREATE TABLE `user` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `description` varchar(200) DEFAULT NULL,
  `name` varchar(200) DEFAULT NULL,
  `age` int(11) DEFAULT NULL,
  `art_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO user VALUES("1","dont touch me","GOGO","1","1");
INSERT INTO user VALUES("2","dont touch it","PACO","2","2");
INSERT INTO user VALUES("3","dont touch","NASKO","3","3");



--------------------------------------------------------------------------Monday 14th of April 2014 01:12:37 PM