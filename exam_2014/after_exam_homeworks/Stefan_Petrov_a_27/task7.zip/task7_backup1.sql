

CREATE TABLE `article` (
  `article_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) DEFAULT NULL,
  `url` varchar(200) DEFAULT NULL,
  `created_on` date DEFAULT NULL,
  PRIMARY KEY (`article_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO article VALUES("1","son1","data.bg","2011-02-03");
INSERT INTO article VALUES("2","son2","data.bg","2011-02-04");
INSERT INTO article VALUES("3","son3","data.bg","2011-02-05");





CREATE TABLE `category` (
  `category_id` int(11) NOT NULL AUTO_INCREMENT,
  `created_by` varchar(200) DEFAULT NULL,
  `description` varchar(200) DEFAULT NULL,
  `tag_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`category_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO category VALUES("1","kon","dont touch1!","1");
INSERT INTO category VALUES("2","sop","dont touch2!","2");
INSERT INTO category VALUES("3","ban","dont touch3!","3");





CREATE TABLE `tag` (
  `tag_id` int(11) NOT NULL AUTO_INCREMENT,
  `priority` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `description` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`tag_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO tag VALUES("1","1","1","dont do it1");
INSERT INTO tag VALUES("2","2","2","dont do it2");
INSERT INTO tag VALUES("3","3","3","dont do it3");





CREATE TABLE `user` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `created_on` date DEFAULT NULL,
  `income` float DEFAULT NULL,
  `age` int(11) DEFAULT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO user VALUES("1","2010-03-21","100.1","0");
INSERT INTO user VALUES("2","2010-03-22","200.2","0");
INSERT INTO user VALUES("3","2010-03-23","300.3","0");





CREATE TABLE `user_article` (
  `user_art_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `art_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`user_art_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO user_article VALUES("1","1","1");
INSERT INTO user_article VALUES("2","2","2");
INSERT INTO user_article VALUES("3","3","3");



--------------------------------------------------------------------------Monday 14th of April 2014 01:52:46 PM