<!DOCTYPE html>
<html>
<head>
	<title>Stefan Petrov</title>
</head>
<body>
	Hello  <br/> &nbsp;&nbsp;&nbsp; Stefan Petrov 12 A, 27 number<br/>
	<br/><br/><br/>

<h3>Tips:</h3></br>
	task7_backup1.sql - backup for the first part of the exam</br>
	task7_backup2.sql - backup for the second part of the exam</br>

	If you refresh the page at the bottom of the file you'll see the changes and the time they are made.</br>
	It is possible when you refreshed the page to have an error with first answer because you change the database</br>
	and it affects on the result.</br></br>

<?php
	mysql_connect("localhost", "root","") or die(mysql_error());

/* Create table, ones I create table i shoud comment that line and uncoment the "mysql_selecet_db" line to connect */
		// mysql_query("CREATE DATABASE task7") or die(mysql_error());

/*Select the database that was created*/
		mysql_select_db("task7") or die(mysql_error());


/* That's how I create the tables*/
	 // 	mysql_query("CREATE TABLE Article (
		// 	  article_id INT AUTO_INCREMENT,
		// 	  name VARCHAR (200),
		// 	  url VARCHAR (200),
		// 	  created_on DATE,
		// 	  PRIMARY KEY(article_id))") Or die(mysql_error());

		// mysql_query("CREATE TABLE Category (
		// 	  category_id INT AUTO_INCREMENT,
		// 	  created_by VARCHAR (200),
		// 	  description VARCHAR (200),
		// 	  tag_id INT,
		// 	  PRIMARY KEY(category_id))") Or die(mysql_error());

		// mysql_query("CREATE TABLE User (
		// 	  user_id INT AUTO_INCREMENT,
		// 	  created_on DATE,
		// 	  income FLOAT,
		// 	  age INT,
		// 	  PRIMARY KEY(user_id))") Or die(mysql_error());

		// mysql_query("CREATE TABLE Tag (
		// 	  tag_id INT AUTO_INCREMENT,
		// 	  priority INT,
		// 	  user_id INT,
		// 	  description VARCHAR (200),
		// 	  PRIMARY KEY(tag_id))") Or die(mysql_error());

		// mysql_query("CREATE TABLE User_Article (
		// 	  user_art_id INT AUTO_INCREMENT,
		// 	  user_id INT,
		// 	  art_id INT,
		// 	  PRIMARY KEY(user_art_id))") Or die(mysql_error());


// /*INSERTIN SHITS*/
		// mysql_query("INSERT INTO Article( name, url, created_on) VALUES ('son1', 'data.bg', '2011-02-3')");
		// mysql_query("INSERT INTO Article( name, url, created_on) VALUES ('son2', 'data.bg', '2011-02-4')");
		// mysql_query("INSERT INTO Article( name, url, created_on) VALUES ('son3', 'data.bg', '2011-02-5')");

		// mysql_query("INSERT INTO Category( created_by, description, tag_id) VALUES ('kon', 'dont touch1!', 1)");
		// mysql_query("INSERT INTO Category( created_by, description, tag_id) VALUES ('sop', 'dont touch2!', 2)");
		// mysql_query("INSERT INTO Category( created_by, description, tag_id) VALUES ('ban', 'dont touch3!', 3)");

		// mysql_query("INSERT INTO User( created_on, income, age) VALUES ('2010-03-21', '100.10', 'GOGO')");
		// mysql_query("INSERT INTO User( created_on, income, age) VALUES ('2010-03-22', '200.20', 'PACO')");
		// mysql_query("INSERT INTO User( created_on, income, age) VALUES ('2010-03-23', '300.30', 'NASKO')");

		// mysql_query("INSERT INTO tag( priority, user_id, description) VALUES (1, 1, 'dont do it1')");
		// mysql_query("INSERT INTO tag( priority, user_id, description) VALUES (2, 2, 'dont do it2')");
		// mysql_query("INSERT INTO tag( priority, user_id, description) VALUES (3, 3, 'dont do it3')");

		// mysql_query("INSERT INTO User_Article( user_id, art_id) VALUES (1, 1)");
		// mysql_query("INSERT INTO User_Article( user_id, art_id) VALUES (2, 2)");
		// mysql_query("INSERT INTO User_Article( user_id, art_id) VALUES (3, 3)");


/*Which are the User(s) for a given Category --> SELECT 1*/

		 // $pena =  mysql_query("SELECT * FROM User INNER JOIN Tag, Category WHERE User.user_id = Tag.user_id 
		 // 	AND Tag.tag_id = Category.tag_id AND Category.category_id = 1");  // SELECT 1

		 // ?> THE ANSWER OF THE FIRST QUESTION IS : <br/><?php
		 // while($row = mysql_fetch_array($pena)){		
		 // 	echo $row["user_id"];
	
			// ?> <br/> <?php
		 // }

// /*Call the function that export the database*/
		// backup_tables('localhost','root','task7','task7_backup1');	

/*Migration*/
		// mysql_query(" CREATE TABLE Tag_part1 (
		// 	Tag_part1_id INT AUTO_INCREMENT,
		// 	priority INT,
		// 	PRIMARY KEY(Tag_part1_id))") Or die(mysql_error());

		// mysql_query("INSERT INTO Tag_part1 (priority) SELECT priority FROM Tag");
		// mysql_query("ALTER TABLE Tag DROP priority");
		// mysql_query("ALTER TABLE Tag RENAME TO Tag_part2");


// /*Second of export the database*/
		// backup_tables('localhost','root','task7','task7_backup2');

/*Which are the Article(s) for a given Tag --> SELECT 2*/

		 // $pena =  mysql_query("SELECT * FROM Article INNER JOIN Tag_part2, User_Article WHERE Article.article_id = User_Article.art_id 
		 // 	AND User_Article.user_id = Tag_part2.user_id AND Tag_part2.tag_id = 1");  // SELECT 2

		 // ?> THE ANSWER OF THE SECONT QUESTION IS : <br/><?php
		 // while($row = mysql_fetch_array($pena)){		
		 // 	echo $row["name"];

			// ?> <br/> <?php
		 // }

		 


?>
</body>
</html>


<?php

	
/* backup the db OR just a table */
function backup_tables($host,$user,$name,$place,$tables = '*')
{
	
	$link = mysql_connect($host,$user,"");
	mysql_select_db($name,$link);
	
	//get all of the tables
	if($tables == '*')
	{
		$tables = array();
		$result = mysql_query('SHOW TABLES');
		//var_dump($result);
		while($row = mysql_fetch_row($result))
		{
			$tables[] = $row[0];
		}
	}
	else
	{
		$tables = is_array($tables) ? $tables : explode(',',$tables);
	}
	

	//cycle through
	foreach($tables as $table)
	{
		$result = mysql_query('SELECT * FROM '.$table);
		$num_fields = mysql_num_fields($result);
		
		$return = 'DROP TABLE '.$table.';';
		$row2 = mysql_fetch_row(mysql_query('SHOW CREATE TABLE '.$table));
		$return = "\n\n".$row2[1].";\n\n";
		
		for ($i = 0; $i < $num_fields; $i++) 
		{
			while($row = mysql_fetch_row($result))
			{
				$return.= 'INSERT INTO '.$table.' VALUES(';
				for($j=0; $j<$num_fields; $j++) 
				{
					$row[$j] = addslashes($row[$j]);
					$row[$j] = ereg_replace("\n","\\n",$row[$j]);
					if (isset($row[$j])) { $return.= '"'.$row[$j].'"' ; } else { $return.= '""'; }
					if ($j<($num_fields-1)) { $return.= ','; }
				}
				$return.= ");\n";
			}
		}
		$return.="\n\n\n";

	$handle = fopen($place.'.sql','a+');
	fwrite($handle,$return);

	}
	fwrite($handle,"--------------------------------------------------------------------------".date('l jS \of F Y h:i:s A'));
	fclose($handle);
}
?>