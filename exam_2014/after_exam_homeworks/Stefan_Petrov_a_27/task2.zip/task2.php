<!DOCTYPE html>
<html>
<head>
	<title>Stefan Petrov</title>
</head>
<body>
	Hello  <br/> &nbsp;&nbsp;&nbsp; Stefan Petrov 12 A, 27 number<br/>
	<br/><br/><br/>

<h3>Tips:</h3></br>
	task2_backup1.sql - backup for the first part of the exam</br>
	task2_backup2.sql - backup for the second part of the exam</br>

	If you refresh the page at the bottom of the file you'll see the changes and the time they are made.</br>
	It is possible when you refreshed the page to have an error with first answer because you change the database</br>
	and it affects on the result.</br></br>

<?php
	mysql_connect("localhost", "root","") or die(mysql_error());

/* Create table, ones I create table i shoud comment that line and uncoment the "mysql_selecet_db" line to connect */
		// mysql_query("CREATE DATABASE task2") or die(mysql_error());

/*Select the database that was created*/
		mysql_select_db("task2") or die(mysql_error());


/* That's how I create the tables*/
	 	// mysql_query("CREATE TABLE Article (
			//   article_id INT AUTO_INCREMENT,
			//   price VARCHAR (20),
			//   created_on DATE,
			//   content INT,
			//   tag_id INT UNIQUE,
			//   PRIMARY KEY(article_id))") Or die(mysql_error());

		// mysql_query("CREATE TABLE Category (
		// 	  category_id INT AUTO_INCREMENT,
		// 	  priority DOUBLE,
		// 	  name VARCHAR (20),
		// 	  PRIMARY KEY(category_id))") Or die(mysql_error());

		// mysql_query("CREATE TABLE User (
		// 	  user_id INT AUTO_INCREMENT,
		// 	  description VARCHAR(200),
		// 	  created_on DATE,
		// 	  password VARCHAR(90),
		// 	  PRIMARY KEY(user_id))") Or die(mysql_error());

		// mysql_query("CREATE TABLE Tag (
		// 	  tag_id INT AUTO_INCREMENT,
		// 	  description VARCHAR (220),
		// 	  second_priority FLOAT,
		// 	  cat_id INT,
		// 	  PRIMARY KEY(tag_id))") Or die(mysql_error());

		// mysql_query("CREATE TABLE Cat_User (
		// 	  cat_id INT,
		// 	  user_id INT
		// 	  )") Or die(mysql_error());	


/*INSERTIN SHITS*/
		// mysql_query("INSERT INTO Article( price, created_on, content, tag_id) VALUES ('5.04','2012-02-1',1 ,1)");
		// mysql_query("INSERT INTO Article( price, created_on, content, tag_id) VALUES ('5.04','2012-02-1',2,2)");
		// mysql_query("INSERT INTO Article( price, created_on, content, tag_id) VALUES ('5.04','2012-02-1',3,3)");

		// mysql_query("INSERT INTO Category( priority, name) VALUES ('2012-12-03','Krimi')");
		// mysql_query("INSERT INTO Category( priority, name) VALUES ('2012-05-12','Biznes')");
		// mysql_query("INSERT INTO Category( priority, name) VALUES ('2012-09-02','Sport')");

		// mysql_query("INSERT INTO USER(description, created_on, password) VALUES ('gfhjk','2012-12-03','GOGO')");
		// mysql_query("INSERT INTO USER(description, created_on, password) VALUES ('grdthfyukj','2012-05-12','PACO')");
		// mysql_query("INSERT INTO USER(description, created_on, password) VALUES ('rteyuio','2012-09-02','NASKO'");

		// mysql_query("INSERT INTO tag( description, second_priority, cat_id) VALUES ('kon','2.15', 2)");
		// mysql_query("INSERT INTO tag( description, second_priority, cat_id) VALUES ('sopol','1.89', 1)");
		// mysql_query("INSERT INTO tag( description, second_priority, cat_id) VALUES ('gevrek','6.45', 3)");

		// mysql_query("INSERT INTO Cat_User( cat_id, user_id) VALUES (1,2)");
		// mysql_query("INSERT INTO Cat_User( cat_id, user_id) VALUES (1,1)");
		// mysql_query("INSERT INTO Cat_User( cat_id, user_id) VALUES (2,3)");

/*Which are the Category(s) for a given Article*/


		// $pena =  mysql_query("SELECT * FROM Article INNER JOIN Tag ON Article.tag_id = Tag.tag_id 
		// 	 INNER JOIN Category ON Tag.cat_id = Category.category_id WHERE Article.article_id = 2");


		//  ?> THE ANSWER OF THE FIRST QUESTION IS : <br/><?php
		// while($row = mysql_fetch_array($pena)){		
		// 	echo $row["category_id"];


		// 	?> <br/> <?php
		// }

// /*Call the function that export the database*/
		// backup_tables('localhost','root','task2','task2_backup1');	

// /*Migration*/
		// mysql_query(" CREATE TABLE Tag1 (
		// 	tag1_id INT AUTO_INCREMENT,
		// 	description DATE,
		// 	PRIMARY KEY(tag1_id))") Or die(mysql_error());

		// mysql_query("INSERT INTO Tag1 (description) SELECT description FROM Tag");
		// mysql_query("ALTER TABLE Tag DROP description");
		// mysql_query("ALTER TABLE Tag RENAME TO Tag2");

// /*Secon of export the database*/
		// backup_tables('localhost','root','task2','task2_backup2');

// /*Which are the User(s) for a given Tag*/
		// 	$kon =  mysql_query("SELECT * FROM Tag2 INNER JOIN Cat_User ON Tag2.cat_id = Cat_User.cat_id 
		// 	 INNER JOIN User ON User.user_id = Cat_User.user_id WHERE Tag2.tag_id = 2");	 

		//   ?><br/> THE ANSWER OF THE SECOND QUESTION IS : <br/><?php
		// while($row2 = mysql_fetch_array($kon)){	
		// 	echo $row2["user_id"];


		// 	?> <br/> <?php
		// }

?>
</body>
</html>


<?php

	
/* backup the db OR just a table */
function backup_tables($host,$user,$name,$place,$tables = '*')
{
	
	$link = mysql_connect($host,$user,"");
	mysql_select_db($name,$link);
	
	//get all of the tables
	if($tables == '*')
	{
		$tables = array();
		$result = mysql_query('SHOW TABLES');
		//var_dump($result);
		while($row = mysql_fetch_row($result))
		{
			$tables[] = $row[0];
		}
	}
	else
	{
		$tables = is_array($tables) ? $tables : explode(',',$tables);
	}
	

	//cycle through
	foreach($tables as $table)
	{
		$result = mysql_query('SELECT * FROM '.$table);
		$num_fields = mysql_num_fields($result);
		
		$return = 'DROP TABLE '.$table.';';
		$row2 = mysql_fetch_row(mysql_query('SHOW CREATE TABLE '.$table));
		$return = "\n\n".$row2[1].";\n\n";
		
		for ($i = 0; $i < $num_fields; $i++) 
		{
			while($row = mysql_fetch_row($result))
			{
				$return.= 'INSERT INTO '.$table.' VALUES(';
				for($j=0; $j<$num_fields; $j++) 
				{
					$row[$j] = addslashes($row[$j]);
					$row[$j] = ereg_replace("\n","\\n",$row[$j]);
					if (isset($row[$j])) { $return.= '"'.$row[$j].'"' ; } else { $return.= '""'; }
					if ($j<($num_fields-1)) { $return.= ','; }
				}
				$return.= ");\n";
			}
		}
		$return.="\n\n\n";

	$handle = fopen($place.'.sql','a+');
	fwrite($handle,$return);

	}
	fwrite($handle,"--------------------------------------------------------------------------".date('l jS \of F Y h:i:s A'));
	fclose($handle);
}
?>