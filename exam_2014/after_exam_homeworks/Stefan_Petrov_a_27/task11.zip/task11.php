<!DOCTYPE html>
<html>
<head>
	<title>Stefan Petrov</title>
</head>
<body>
	Hello  <br/> &nbsp;&nbsp;&nbsp; Stefan Petrov 12 A, 27 number<br/>
	<br/><br/><br/>

<h3>Tips:</h3></br>
	task11_backup1.sql - backup for the first part of the exam</br>
	task11_backup2.sql - backup for the second part of the exam</br>

	If you refresh the page at the bottom of the file you'll see the changes and the time they are made.</br>
	It is possible when you refreshed the page to have an error with first answer because you change the database</br>
	and it affects on the result.</br></br>

<?php
	mysql_connect("localhost", "root","") or die(mysql_error());

/* Create table, ones I create table i shoud comment that line and uncoment the "mysql_selecet_db" line to connect */
		// mysql_query("CREATE DATABASE task11") or die(mysql_error());

/*Select the database that was created*/
		mysql_select_db("task11") or die(mysql_error());


/* That's how I create the tables*/
	 // 	mysql_query("CREATE TABLE Article (
		// 	  article_id INT AUTO_INCREMENT,
		// 	  created_on DATE,
		// 	  content VARCHAR (200),
		// 	  url VARCHAR (200),
		// 	  PRIMARY KEY(article_id))") Or die(mysql_error());

		// mysql_query("CREATE TABLE Category (
		// 	  category_id INT AUTO_INCREMENT,
		// 	  name VARCHAR (200),
		// 	  description VARCHAR(200),
		// 	  tag_id INT,
		// 	  art_id INT,
		// 	  PRIMARY KEY(category_id))") Or die(mysql_error());

		// mysql_query("CREATE TABLE User (
		// 	  user_id INT AUTO_INCREMENT,
		// 	  picture_url VARCHAR (200),
		// 	  name VARCHAR (200),
		// 	  income FLOAT,
		// 	  art_id INT,
		// 	  PRIMARY KEY(user_id))") Or die(mysql_error());

		// mysql_query("CREATE TABLE Tag (
		// 	  tag_id INT AUTO_INCREMENT,
		// 	  second_priority FLOAT,
		// 	  priority INT,
		// 	  PRIMARY KEY(tag_id))") Or die(mysql_error());


// /*INSERTIN SHITS*/
		// mysql_query("INSERT INTO Article( content, url, created_on) VALUES ('son1', 'data.bg', '2013-01-02')");
		// mysql_query("INSERT INTO Article( content, url, created_on) VALUES ('son2', 'data.bg', '2013-01-03')");
		// mysql_query("INSERT INTO Article( content, url, created_on) VALUES ('son3', 'data.bg', '2013-01-04')");

		// mysql_query("INSERT INTO Category( name, description, art_id, tag_id) VALUES ('gogo', '1', 1, 1)");
		// mysql_query("INSERT INTO Category( name, description, art_id, tag_id) VALUES ('toni', '2', 2, 2)");
		// mysql_query("INSERT INTO Category( name, description, art_id, tag_id) VALUES ('ico', '3', 3, 3)");

		// mysql_query("INSERT INTO User( picture_url, name, income, art_id) VALUES ('databg', 'gogo', '10.10', 1)");
		// mysql_query("INSERT INTO User( picture_url, name, income, art_id) VALUES ('databg', 'toni', '20.20', 2)");
		// mysql_query("INSERT INTO User( picture_url, name, income, art_id) VALUES ('databg', 'ico', '30.30', 3)");

		// mysql_query("INSERT INTO tag( second_priority, priority) VALUES ('1', 1)");
		// mysql_query("INSERT INTO tag( second_priority, priority) VALUES ('2', 2)");
		// mysql_query("INSERT INTO tag( second_priority, priority) VALUES ('3', 3)");


/* Which are the Article(s) for a given Tag --> SELECT 1*/

		 // $pena =  mysql_query("SELECT * FROM Article INNER JOIN Category, Tag WHERE Article.article_id = Category.art_id
		 // 	AND Category.tag_id = Tag.tag_id AND Tag.tag_id = 1");  // SELECT 1

		 // ?> THE ANSWER OF THE FIRST QUESTION IS : <br/><?php
		 // while($row = mysql_fetch_array($pena)){		
		 // 	echo $row["article_id"];
	
			// ?> <br/> <?php
		 // }

// /*Call the function that export the database*/
		// backup_tables('localhost','root','task11','task11_backup1');	

/*Migration*/
		// mysql_query(" CREATE TABLE Category_part1 (
		// 	Category_part1_id INT AUTO_INCREMENT,
		// 	description VARCHAR (200),
		// 	PRIMARY KEY(Category_part1_id))") Or die(mysql_error());

		// mysql_query("INSERT INTO Category_part1 (description) SELECT description FROM Category");
		// mysql_query("ALTER TABLE Category DROP description");
		// mysql_query("ALTER TABLE Category RENAME TO Category_part2");


// /*Second of export the database*/
		// backup_tables('localhost','root','task11','task11_backup2');

/* Which are the Tag(s) for a given Category --> SELECT 2*/

		 // $pena =  mysql_query("SELECT * FROM Tag INNER JOIN Category_part2 WHERE Tag.tag_id = Category_part2.tag_id AND Category_part2.category_id = 1");  // SELECT 2

		 // ?> THE ANSWER OF THE SECONT QUESTION IS : <br/><?php
		 // while($row = mysql_fetch_array($pena)){		
		 // 	echo $row["tag_id"];

			// ?> <br/> <?php
		 // }

		 


?>
</body>
</html>


<?php

	
/* backup the db OR just a table */
function backup_tables($host,$user,$name,$place,$tables = '*')
{
	
	$link = mysql_connect($host,$user,"");
	mysql_select_db($name,$link);
	
	//get all of the tables
	if($tables == '*')
	{
		$tables = array();
		$result = mysql_query('SHOW TABLES');
		//var_dump($result);
		while($row = mysql_fetch_row($result))
		{
			$tables[] = $row[0];
		}
	}
	else
	{
		$tables = is_array($tables) ? $tables : explode(',',$tables);
	}
	

	//cycle through
	foreach($tables as $table)
	{
		$result = mysql_query('SELECT * FROM '.$table);
		$num_fields = mysql_num_fields($result);
		
		$return = 'DROP TABLE '.$table.';';
		$row2 = mysql_fetch_row(mysql_query('SHOW CREATE TABLE '.$table));
		$return = "\n\n".$row2[1].";\n\n";
		
		for ($i = 0; $i < $num_fields; $i++) 
		{
			while($row = mysql_fetch_row($result))
			{
				$return.= 'INSERT INTO '.$table.' VALUES(';
				for($j=0; $j<$num_fields; $j++) 
				{
					$row[$j] = addslashes($row[$j]);
					$row[$j] = ereg_replace("\n","\\n",$row[$j]);
					if (isset($row[$j])) { $return.= '"'.$row[$j].'"' ; } else { $return.= '""'; }
					if ($j<($num_fields-1)) { $return.= ','; }
				}
				$return.= ");\n";
			}
		}
		$return.="\n\n\n";

	$handle = fopen($place.'.sql','a+');
	fwrite($handle,$return);

	}
	fwrite($handle,"--------------------------------------------------------------------------".date('l jS \of F Y h:i:s A'));
	fclose($handle);
}
?>