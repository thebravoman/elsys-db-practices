

CREATE TABLE `article` (
  `article_id` int(11) NOT NULL AUTO_INCREMENT,
  `created_on` date DEFAULT NULL,
  `content` varchar(200) DEFAULT NULL,
  `url` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`article_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO article VALUES("1","2013-01-02","son1","data.bg");
INSERT INTO article VALUES("2","2013-01-03","son2","data.bg");
INSERT INTO article VALUES("3","2013-01-04","son3","data.bg");





CREATE TABLE `category_part1` (
  `Category_part1_id` int(11) NOT NULL AUTO_INCREMENT,
  `description` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`Category_part1_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO category_part1 VALUES("1","1");
INSERT INTO category_part1 VALUES("2","2");
INSERT INTO category_part1 VALUES("3","3");





CREATE TABLE `category_part2` (
  `category_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) DEFAULT NULL,
  `tag_id` int(11) DEFAULT NULL,
  `art_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`category_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO category_part2 VALUES("1","gogo","1","1");
INSERT INTO category_part2 VALUES("2","toni","2","2");
INSERT INTO category_part2 VALUES("3","ico","3","3");





CREATE TABLE `tag` (
  `tag_id` int(11) NOT NULL AUTO_INCREMENT,
  `second_priority` float DEFAULT NULL,
  `priority` int(11) DEFAULT NULL,
  PRIMARY KEY (`tag_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO tag VALUES("1","1","1");
INSERT INTO tag VALUES("2","2","2");
INSERT INTO tag VALUES("3","3","3");





CREATE TABLE `user` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `picture_url` varchar(200) DEFAULT NULL,
  `name` varchar(200) DEFAULT NULL,
  `income` float DEFAULT NULL,
  `art_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO user VALUES("1","databg","gogo","10.1","1");
INSERT INTO user VALUES("2","databg","toni","20.2","2");
INSERT INTO user VALUES("3","databg","ico","30.3","3");



--------------------------------------------------------------------------Monday 14th of April 2014 03:09:42 PM