

CREATE TABLE `article` (
  `article_id` int(11) NOT NULL AUTO_INCREMENT,
  `created_on` date DEFAULT NULL,
  `content` varchar(200) DEFAULT NULL,
  `name` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`article_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO article VALUES("1","2013-01-02","son1","data.bg");
INSERT INTO article VALUES("2","2013-01-03","son2","data.bg");
INSERT INTO article VALUES("3","2013-01-04","son3","data.bg");





CREATE TABLE `category` (
  `category_id` int(11) NOT NULL AUTO_INCREMENT,
  `date_created_on` date DEFAULT NULL,
  `priority` double DEFAULT NULL,
  `art_id` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`category_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO category VALUES("1","2014-01-01","1","1","1");
INSERT INTO category VALUES("2","2014-01-01","2","2","2");
INSERT INTO category VALUES("3","2014-01-01","3","3","3");





CREATE TABLE `tag` (
  `tag_id` int(11) NOT NULL AUTO_INCREMENT,
  `second_priority` int(11) DEFAULT NULL,
  `description` varchar(200) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`tag_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO tag VALUES("1","1","dont do it1","1");
INSERT INTO tag VALUES("2","2","dont do it2","2");
INSERT INTO tag VALUES("3","3","dont do it3","3");





CREATE TABLE `user` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `age` int(11) DEFAULT NULL,
  `created_on` date DEFAULT NULL,
  `description` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO user VALUES("1","10","2010-03-21","100.10");
INSERT INTO user VALUES("2","12","2010-03-22","200.20");
INSERT INTO user VALUES("3","13","2010-03-23","300.30");



--------------------------------------------------------------------------Monday 14th of April 2014 03:28:01 PM