

CREATE TABLE `article` (
  `article_id` int(11) NOT NULL AUTO_INCREMENT,
  `price` float DEFAULT NULL,
  `created_on` date DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL,
  `tag_id` int(11) DEFAULT NULL,
  `cat_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`article_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO article VALUES("1","5.04","2012-02-01","blala","1","1");
INSERT INTO article VALUES("2","5.04","2012-02-01","blala","2","2");
INSERT INTO article VALUES("3","5.04","2012-02-01","blala","3","3");





CREATE TABLE `category` (
  `category_id` int(11) NOT NULL AUTO_INCREMENT,
  `date_created_on` date DEFAULT NULL,
  `priority` double DEFAULT NULL,
  PRIMARY KEY (`category_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO category VALUES("1","2012-12-03","2");
INSERT INTO category VALUES("2","2012-05-12","2");
INSERT INTO category VALUES("3","2012-09-02","1");





CREATE TABLE `tag` (
  `tag_id` int(11) NOT NULL AUTO_INCREMENT,
  `description` varchar(200) DEFAULT NULL,
  `priority` int(11) DEFAULT NULL,
  PRIMARY KEY (`tag_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO tag VALUES("1","kon","2");
INSERT INTO tag VALUES("2","sopol","1");
INSERT INTO tag VALUES("3","gevrek","3");





CREATE TABLE `user` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `description` varchar(200) DEFAULT NULL,
  `income` float DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL,
  `cat_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO user VALUES("1","dont use","100.5","GOGO","1");
INSERT INTO user VALUES("2","dont use","200.2","PACO","2");
INSERT INTO user VALUES("3","dont use","300.4","NASKO","3");



--------------------------------------------------------------------------Monday 14th of April 2014 03:15:15 PM