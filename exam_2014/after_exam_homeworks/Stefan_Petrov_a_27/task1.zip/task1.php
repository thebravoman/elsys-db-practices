<!DOCTYPE html>
<html>
<head>
	<title>Stefan Petrov</title>
</head>
<body>
	Hello  <br/> &nbsp;&nbsp;&nbsp; Stefan Petrov 12 A, 27 number<br/>
	<br/><br/><br/>

<h3>Tips:</h3></br>
	task1_backup1.sql - backup for the first part of the exam</br>
	task1_backup2.sql - backup for the second part of the exam</br>

	If you refresh the page at the bottom of the file you'll see the changes and the time they are made.</br>
	It is possible when you refreshed the page to have an error with first answer because you change the database</br>
	and it affects on the result.</br></br>

<?php
	mysql_connect("localhost", "root","") or die(mysql_error());

/* Create table, ones I create table i shoud comment that line and uncoment the "mysql_selecet_db" line to connect */
		// mysql_query("CREATE DATABASE task1") or die(mysql_error());

/*Select the database that was created*/
		mysql_select_db("task1") or die(mysql_error());


/* That's how I create the tables*/
	 // 	mysql_query("CREATE TABLE Article (
		// 	  article_id INT AUTO_INCREMENT,
		// 	  price FLOAT,
		// 	  created_on DATE,
		// 	  name VARCHAR (20),
		// 	  tag_id INT,
		// 	  cat_id INT,
		// 	  PRIMARY KEY(article_id))") Or die(mysql_error());

		// mysql_query("CREATE TABLE Category (
		// 	  category_id INT AUTO_INCREMENT,
		// 	  date_created_on DATE,
		// 	  priority DOUBLE,
		// 	  PRIMARY KEY(category_id))") Or die(mysql_error());

		// mysql_query("CREATE TABLE User (
		// 	  user_id INT AUTO_INCREMENT,
		// 	  description VARCHAR (200),
		// 	  income FLOAT,
		// 	  name VARCHAR (20),
		// 	  cat_id INT,
		// 	  PRIMARY KEY(user_id))") Or die(mysql_error());

		// mysql_query("CREATE TABLE Tag (
		// 	  tag_id INT AUTO_INCREMENT,
		// 	  description VARCHAR (200),
		// 	  priority INT,
		// 	  PRIMARY KEY(tag_id))") Or die(mysql_error());


/*INSERTIN SHITS*/
		// mysql_query("INSERT INTO Article( price, created_on, name, cat_id, tag_id) VALUES ('5.04','2012-02-1', 'blala', 1, 1)");
		// mysql_query("INSERT INTO Article( price, created_on, name, cat_id, tag_id) VALUES ('5.04','2012-02-1', 'blala', 2, 2)");
		// mysql_query("INSERT INTO Article( price, created_on, name, cat_id, tag_id) VALUES ('5.04','2012-02-1', 'blala', 3, 3)");

		// mysql_query("INSERT INTO Category( date_created_on, priority) VALUES ('2012-12-03', 2)");
		// mysql_query("INSERT INTO Category( date_created_on, priority) VALUES ('2012-05-12', 2)");
		// mysql_query("INSERT INTO Category( date_created_on, priority) VALUES ('2012-09-02', 1)");

		// mysql_query("INSERT INTO USER( description, income, name, cat_id) VALUES ('dont use', '100.50', 'GOGO', 1)");
		// mysql_query("INSERT INTO USER( description, income, name, cat_id) VALUES ('dont use', '200.20', 'PACO', 2)");
		// mysql_query("INSERT INTO USER( description, income, name, cat_id) VALUES ('dont use', '300.40', 'NASKO', 3)");

		// mysql_query("INSERT INTO tag( description, priority) VALUES ('kon',2)");
		// mysql_query("INSERT INTO tag( description, priority) VALUES ('sopol',1)");
		// mysql_query("INSERT INTO tag( description, priority) VALUES ('gevrek',3)");


/*Which are the Category(s) for a given Tag --> SELECT 1*/

		 // $pena =  mysql_query("SELECT * FROM Article INNER JOIN Tag,Category WHERE Article.tag_id = Tag.tag_id 
		 // 	 AND Article.article_id = Category.category_id AND Tag.tag_id = 1");  // SELECT 1

		 // ?> THE ANSWER OF THE FIRST QUESTION IS : <br/><?php
		 // while($row = mysql_fetch_array($pena)){
		 // 	echo $row["category_id"];		
	
			// ?> <br/> <?php
		 // }

// /*Call the function that export the database*/
		// backup_tables('localhost','root','task1','task1_backup1');	

/*Migration*/
		// mysql_query(" CREATE TABLE Article_part1 (
		// 	art_part1_id INT AUTO_INCREMENT,
		// 	created_on DATE,
		// 	PRIMARY KEY(art_part1_id))") Or die(mysql_error());

		// mysql_query("INSERT INTO Article_part1 (created_on) SELECT created_on FROM Article");
		// mysql_query("ALTER TABLE Article DROP created_on");
		// mysql_query("ALTER TABLE Article RENAME TO Article_part2");


// /*Second of export the database*/
		// backup_tables('localhost','root','task1','task1_backup2');

/*Which are the User(s) for a given Article --> SELECT 2*/

		 // $pena =  mysql_query("SELECT * FROM User INNER JOIN Article_part2 WHERE User.cat_id = Article_part2.cat_id 
		 // 	  AND Article_part2.article_id = 1");  // SELECT 2

		 // ?> THE ANSWER OF THE SECONT QUESTION IS : <br/><?php
		 // while($row = mysql_fetch_array($pena)){		
		 // 	echo $row["user_id"];

			// ?> <br/> <?php
		 // }

		 


?>
</body>
</html>


<?php

	
/* backup the db OR just a table */
function backup_tables($host,$user,$name,$place,$tables = '*')
{
	
	$link = mysql_connect($host,$user,"");
	mysql_select_db($name,$link);
	
	//get all of the tables
	if($tables == '*')
	{
		$tables = array();
		$result = mysql_query('SHOW TABLES');
		//var_dump($result);
		while($row = mysql_fetch_row($result))
		{
			$tables[] = $row[0];
		}
	}
	else
	{
		$tables = is_array($tables) ? $tables : explode(',',$tables);
	}
	

	//cycle through
	foreach($tables as $table)
	{
		$result = mysql_query('SELECT * FROM '.$table);
		$num_fields = mysql_num_fields($result);
		
		$return = 'DROP TABLE '.$table.';';
		$row2 = mysql_fetch_row(mysql_query('SHOW CREATE TABLE '.$table));
		$return = "\n\n".$row2[1].";\n\n";
		
		for ($i = 0; $i < $num_fields; $i++) 
		{
			while($row = mysql_fetch_row($result))
			{
				$return.= 'INSERT INTO '.$table.' VALUES(';
				for($j=0; $j<$num_fields; $j++) 
				{
					$row[$j] = addslashes($row[$j]);
					$row[$j] = ereg_replace("\n","\\n",$row[$j]);
					if (isset($row[$j])) { $return.= '"'.$row[$j].'"' ; } else { $return.= '""'; }
					if ($j<($num_fields-1)) { $return.= ','; }
				}
				$return.= ");\n";
			}
		}
		$return.="\n\n\n";

	$handle = fopen($place.'.sql','a+');
	fwrite($handle,$return);

	}
	fwrite($handle,"--------------------------------------------------------------------------".date('l jS \of F Y h:i:s A'));
	fclose($handle);
}
?>