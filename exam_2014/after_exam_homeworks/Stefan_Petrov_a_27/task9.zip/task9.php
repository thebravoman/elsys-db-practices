<!DOCTYPE html>
<html>
<head>
	<title>Stefan Petrov</title>
</head>
<body>
	Hello  <br/> &nbsp;&nbsp;&nbsp; Stefan Petrov 12 A, 27 number<br/>
	<br/><br/><br/>

<h3>Tips:</h3></br>
	task9_backup1.sql - backup for the first part of the exam</br>
	task9_backup2.sql - backup for the second part of the exam</br>

	If you refresh the page at the bottom of the file you'll see the changes and the time they are made.</br>
	It is possible when you refreshed the page to have an error with first answer because you change the database</br>
	and it affects on the result.</br></br>

<?php
	mysql_connect("localhost", "root","") or die(mysql_error());

/* Create table, ones I create table i shoud comment that line and uncoment the "mysql_selecet_db" line to connect */
		// mysql_query("CREATE DATABASE task9") or die(mysql_error());

/*Select the database that was created*/
		mysql_select_db("task9") or die(mysql_error());


/* That's how I create the tables*/
	 // 	mysql_query("CREATE TABLE Article (
		// 	  article_id INT AUTO_INCREMENT,
		// 	  price FLOAT,
		// 	  content VARCHAR (200),
		// 	  name VARCHAR (200),
		// 	  cat_id INT,
		// 	  user_id INT,
		// 	  PRIMARY KEY(article_id))") Or die(mysql_error());

		// mysql_query("CREATE TABLE Category (
		// 	  category_id INT AUTO_INCREMENT,
		// 	  name VARCHAR (200),
		// 	  created_by VARCHAR (200),
		// 	  PRIMARY KEY(category_id))") Or die(mysql_error());

		// mysql_query("CREATE TABLE User (
		// 	  user_id INT AUTO_INCREMENT,
		// 	  age INT,
		// 	  created_on DATE,
		// 	  description VARCHAR (200),
		// 	  PRIMARY KEY(user_id))") Or die(mysql_error());

		// mysql_query("CREATE TABLE Tag (
		// 	  tag_id INT AUTO_INCREMENT,
		// 	  second_priority INT,
		// 	  description VARCHAR (200),
		// 	  user_id INT,
		// 	  PRIMARY KEY(tag_id))") Or die(mysql_error());


// /*INSERTIN SHITS*/
		// mysql_query("INSERT INTO Article( content, name, price, cat_id, user_id) VALUES ('son1', 'data.bg', '100.10', 1, 1)");
		// mysql_query("INSERT INTO Article( content, name, price, cat_id, user_id) VALUES ('son2', 'data.bg', '200.20', 2, 2)");
		// mysql_query("INSERT INTO Article( content, name, price, cat_id, user_id) VALUES ('son3', 'data.bg', '300.30', 3, 3)");

		// mysql_query("INSERT INTO Category( name, created_by) VALUES ('dont touch1!', 'google.com')");
		// mysql_query("INSERT INTO Category( name, created_by) VALUES ('dont touch2!', 'google.com')");
		// mysql_query("INSERT INTO Category( name, created_by) VALUES ('dont touch3!', 'google.com')");

		// mysql_query("INSERT INTO User( created_on, description, age) VALUES ('2010-03-21', '100.10', 10)");
		// mysql_query("INSERT INTO User( created_on, description, age) VALUES ('2010-03-22', '200.20', 12)");
		// mysql_query("INSERT INTO User( created_on, description, age) VALUES ('2010-03-23', '300.30', 13)");

		// mysql_query("INSERT INTO tag( second_priority, user_id, description) VALUES (1, 1, 'dont do it1')");
		// mysql_query("INSERT INTO tag( second_priority, user_id, description) VALUES (2, 2, 'dont do it2')");
		// mysql_query("INSERT INTO tag( second_priority, user_id, description) VALUES (3, 3, 'dont do it3')");


/* Which are the User(s) for a given Category --> SELECT 1*/

		 // $pena =  mysql_query("SELECT * FROM User INNER JOIN Category, Article WHERE User.user_id = Article.user_id
		 // 	AND Article.cat_id = Category.category_id AND Category.category_id = 1");  // SELECT 1

		 // ?> THE ANSWER OF THE FIRST QUESTION IS : <br/><?php
		 // while($row = mysql_fetch_array($pena)){		
		 // 	echo $row["user_id"];
	
			// ?> <br/> <?php
		 // }

// /*Call the function that export the database*/
		// backup_tables('localhost','root','task9','task9_backup1');	

/*Migration*/
		// mysql_query(" CREATE TABLE Article_part1 (
		// 	Article_part1_id INT AUTO_INCREMENT,
		// 	content VARCHAR (200),
		// 	PRIMARY KEY(Article_part1_id))") Or die(mysql_error());

		// mysql_query("INSERT INTO Article_part1 (content) SELECT content FROM Article");
		// mysql_query("ALTER TABLE Article DROP content");
		// mysql_query("ALTER TABLE Article RENAME TO Article_part2");


// /*Second of export the database*/
		// backup_tables('localhost','root','task9','task9_backup2');

/* Which are the Tag(s) for a given Article --> SELECT 2*/

		 // $pena =  mysql_query("SELECT * FROM Tag INNER JOIN Article_part2 WHERE Tag.user_id = Article_part2.user_id AND Article_part2.user_id = 1");  // SELECT 2

		 // ?> THE ANSWER OF THE SECONT QUESTION IS : <br/><?php
		 // while($row = mysql_fetch_array($pena)){		
		 // 	echo $row["tag_id"];

			// ?> <br/> <?php
		 // }

		 


?>
</body>
</html>


<?php

	
/* backup the db OR just a table */
function backup_tables($host,$user,$name,$place,$tables = '*')
{
	
	$link = mysql_connect($host,$user,"");
	mysql_select_db($name,$link);
	
	//get all of the tables
	if($tables == '*')
	{
		$tables = array();
		$result = mysql_query('SHOW TABLES');
		//var_dump($result);
		while($row = mysql_fetch_row($result))
		{
			$tables[] = $row[0];
		}
	}
	else
	{
		$tables = is_array($tables) ? $tables : explode(',',$tables);
	}
	

	//cycle through
	foreach($tables as $table)
	{
		$result = mysql_query('SELECT * FROM '.$table);
		$num_fields = mysql_num_fields($result);
		
		$return = 'DROP TABLE '.$table.';';
		$row2 = mysql_fetch_row(mysql_query('SHOW CREATE TABLE '.$table));
		$return = "\n\n".$row2[1].";\n\n";
		
		for ($i = 0; $i < $num_fields; $i++) 
		{
			while($row = mysql_fetch_row($result))
			{
				$return.= 'INSERT INTO '.$table.' VALUES(';
				for($j=0; $j<$num_fields; $j++) 
				{
					$row[$j] = addslashes($row[$j]);
					$row[$j] = ereg_replace("\n","\\n",$row[$j]);
					if (isset($row[$j])) { $return.= '"'.$row[$j].'"' ; } else { $return.= '""'; }
					if ($j<($num_fields-1)) { $return.= ','; }
				}
				$return.= ");\n";
			}
		}
		$return.="\n\n\n";

	$handle = fopen($place.'.sql','a+');
	fwrite($handle,$return);

	}
	fwrite($handle,"--------------------------------------------------------------------------".date('l jS \of F Y h:i:s A'));
	fclose($handle);
}
?>