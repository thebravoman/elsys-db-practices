<!DOCTYPE html>
<html>
<head>
	<title>Stefan Petrov</title>
</head>
<body>
	Hello  <br/> &nbsp;&nbsp;&nbsp; Stefan Petrov 12 A, 27 number<br/>
	<br/><br/><br/>

<h3>Tips:</h3></br>
	task5_backup1.sql - backup for the first part of the exam</br>
	task5_backup2.sql - backup for the second part of the exam</br>

	If you refresh the page at the bottom of the file you'll see the changes and the time they are made.</br>
	It is possible when you refreshed the page to have an error with first answer because you change the database</br>
	and it affects on the result.</br></br>

<?php
	mysql_connect("localhost", "root","") or die(mysql_error());

/* Create table, ones I create table i shoud comment that line and uncoment the "mysql_selecet_db" line to connect */
		// mysql_query("CREATE DATABASE task5") or die(mysql_error());

/*Select the database that was created*/
		mysql_select_db("task5") or die(mysql_error());


/* That's how I create the tables*/
	 // 	mysql_query("CREATE TABLE Article (
		// 	  article_id INT AUTO_INCREMENT,
		// 	  published_on DATE,
		// 	  name VARCHAR (200),
		// 	  url VARCHAR (200),
		// 	  PRIMARY KEY(article_id))") Or die(mysql_error());

		// mysql_query("CREATE TABLE Category (
		// 	  category_id INT AUTO_INCREMENT,
		// 	  name VARCHAR (200),
		// 	  created_by VARCHAR (200),
		// 	  PRIMARY KEY(category_id))") Or die(mysql_error());

		// mysql_query("CREATE TABLE User (
		// 	  user_id INT AUTO_INCREMENT,
		// 	  created_on DATE,
		// 	  name VARCHAR (200),
		// 	  age INT,
		// 	  PRIMARY KEY(user_id))") Or die(mysql_error());

		// mysql_query("CREATE TABLE Tag (
		// 	  tag_id INT AUTO_INCREMENT,
		// 	  description VARCHAR (200),
		// 	  priority INT,
		// 	  art_id INT UNIQUE,
		// 	  PRIMARY KEY(tag_id))") Or die(mysql_error());

		// mysql_query("CREATE TABLE Category_User (
		// 	  cat_user_id INT AUTO_INCREMENT,
		// 	  cat_id INT,
		// 	  user_id INT,
		// 	  PRIMARY KEY(cat_user_id))") Or die(mysql_error());

		// mysql_query("CREATE TABLE User_Tag (
		// 	  user_tag_id INT AUTO_INCREMENT,
		// 	  user_id INT,
		// 	  tag_id INT,
		// 	  PRIMARY KEY(user_tag_id))") Or die(mysql_error());


// /*INSERTIN SHITS*/
		// mysql_query("INSERT INTO Article( published_on, name, url) VALUES ('2012-02-3', 'blala', 'data.bg')");
		// mysql_query("INSERT INTO Article( published_on, name, url) VALUES ('2012-02-4', 'blala', 'data.bg')");
		// mysql_query("INSERT INTO Article( published_on, name, url) VALUES ('2012-02-5', 'blala', 'data.bg')");

		// mysql_query("INSERT INTO Category( name, created_by) VALUES ('kon', 'ibrahiM')");
		// mysql_query("INSERT INTO Category( name, created_by) VALUES ('sopol', 'paco')");
		// mysql_query("INSERT INTO Category( name, created_by) VALUES ('banica', 'anton')");

		// mysql_query("INSERT INTO USER( created_on, name, age) VALUES ('2010-02-3', 'GOGO', 1)");
		// mysql_query("INSERT INTO USER( created_on, name, age) VALUES ('2010-02-4', 'PACO', 2)");
		// mysql_query("INSERT INTO USER( created_on, name, age) VALUES ('2010-02-5', 'NASKO', 3)");

		// mysql_query("INSERT INTO tag( description, priority, art_id) VALUES ('kon', 2, 1)");
		// mysql_query("INSERT INTO tag( description, priority, art_id) VALUES ('sopol', 1, 2)");
		// mysql_query("INSERT INTO tag( description, priority, art_id) VALUES ('gevrek', 3, 3)");

		// mysql_query("INSERT INTO Category_User( cat_id, user_id) VALUES (1, 1)");
		// mysql_query("INSERT INTO Category_User( cat_id, user_id) VALUES (2, 2)");
		// mysql_query("INSERT INTO Category_User( cat_id, user_id) VALUES (3, 3)");

		// mysql_query("INSERT INTO User_Tag( tag_id, user_id) VALUES (1, 1)");
		// mysql_query("INSERT INTO User_Tag( tag_id, user_id) VALUES (2, 2)");
		// mysql_query("INSERT INTO User_Tag( tag_id, user_id) VALUES (3, 3)");

/*Which are the Tag(s) for a given Category --> SELECT 1*/

		 // $pena =  mysql_query("SELECT * FROM Tag INNER JOIN Category_User, User_Tag, Category WHERE Category.category_id = Category_User.cat_id
		 // 	AND Category_User.user_id = User_Tag.user_id AND User_Tag.tag_id = Tag.tag_id AND Category.category_id = 1");  // SELECT 1

		 // ?> THE ANSWER OF THE FIRST QUESTION IS : <br/><?php
		 // while($row = mysql_fetch_array($pena)){		
		 // 	echo $row["tag_id"];
	
			// ?> <br/> <?php
		 // }

// /*Call the function that export the database*/
// 		backup_tables('localhost','root','task5','task5_backup1');	

/*Migration*/
		// mysql_query(" CREATE TABLE User_part1 (
		// 	user_part1_id INT AUTO_INCREMENT,
		// 	created_on DATE,
		// 	PRIMARY KEY(user_part1_id))") Or die(mysql_error());

		// mysql_query("INSERT INTO User_part1 (created_on) SELECT created_on FROM User");
		// mysql_query("ALTER TABLE User DROP created_on");
		// mysql_query("ALTER TABLE User RENAME TO User_part2");


// /*Second of export the database*/
		// backup_tables('localhost','root','task5','task5_backup2');

/*Which are the Article(s) for a given User --> SELECT 2*/

		 // $pena =  mysql_query("SELECT * FROM Article INNER JOIN User_part2, User_Tag, Tag WHERE Article.article_id = Tag.art_id AND Tag.tag_id = User_Tag.tag_id
		 // 	AND User_Tag.user_id = User_part2.user_id AND User_part2.user_id = 1");  // SELECT 2

		 // ?> THE ANSWER OF THE SECONT QUESTION IS : <br/><?php
		 // while($row = mysql_fetch_array($pena)){		
		 // 	echo $row["article_id"];

			// ?> <br/> <?php
		 // }

		 


?>
</body>
</html>


<?php

	
/* backup the db OR just a table */
function backup_tables($host,$user,$name,$place,$tables = '*')
{
	
	$link = mysql_connect($host,$user,"");
	mysql_select_db($name,$link);
	
	//get all of the tables
	if($tables == '*')
	{
		$tables = array();
		$result = mysql_query('SHOW TABLES');
		//var_dump($result);
		while($row = mysql_fetch_row($result))
		{
			$tables[] = $row[0];
		}
	}
	else
	{
		$tables = is_array($tables) ? $tables : explode(',',$tables);
	}
	

	//cycle through
	foreach($tables as $table)
	{
		$result = mysql_query('SELECT * FROM '.$table);
		$num_fields = mysql_num_fields($result);
		
		$return = 'DROP TABLE '.$table.';';
		$row2 = mysql_fetch_row(mysql_query('SHOW CREATE TABLE '.$table));
		$return = "\n\n".$row2[1].";\n\n";
		
		for ($i = 0; $i < $num_fields; $i++) 
		{
			while($row = mysql_fetch_row($result))
			{
				$return.= 'INSERT INTO '.$table.' VALUES(';
				for($j=0; $j<$num_fields; $j++) 
				{
					$row[$j] = addslashes($row[$j]);
					$row[$j] = ereg_replace("\n","\\n",$row[$j]);
					if (isset($row[$j])) { $return.= '"'.$row[$j].'"' ; } else { $return.= '""'; }
					if ($j<($num_fields-1)) { $return.= ','; }
				}
				$return.= ");\n";
			}
		}
		$return.="\n\n\n";

	$handle = fopen($place.'.sql','a+');
	fwrite($handle,$return);

	}
	fwrite($handle,"--------------------------------------------------------------------------".date('l jS \of F Y h:i:s A'));
	fclose($handle);
}
?>