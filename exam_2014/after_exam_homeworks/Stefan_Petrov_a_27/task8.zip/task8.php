<!DOCTYPE html>
<html>
<head>
	<title>Stefan Petrov</title>
</head>
<body>
	Hello  <br/> &nbsp;&nbsp;&nbsp; Stefan Petrov 12 A, 27 number<br/>
	<br/><br/><br/>

<h3>Tips:</h3></br>
	task8_backup1.sql - backup for the first part of the exam</br>
	task8_backup2.sql - backup for the second part of the exam</br>

	If you refresh the page at the bottom of the file you'll see the changes and the time they are made.</br>
	It is possible when you refreshed the page to have an error with first answer because you change the database</br>
	and it affects on the result.</br></br>

<?php
	mysql_connect("localhost", "root","") or die(mysql_error());

/* Create table, ones I create table i shoud comment that line and uncoment the "mysql_selecet_db" line to connect */
		// mysql_query("CREATE DATABASE task8") or die(mysql_error());

/*Select the database that was created*/
		mysql_select_db("task8") or die(mysql_error());


/* That's how I create the tables*/
	 // 	mysql_query("CREATE TABLE Article (
		// 	  article_id INT AUTO_INCREMENT,
		// 	  created_on DATE,
		// 	  content VARCHAR (200),
		// 	  url VARCHAR (200),
		// 	  PRIMARY KEY(article_id))") Or die(mysql_error());

		// mysql_query("CREATE TABLE Category (
		// 	  category_id INT AUTO_INCREMENT,
		// 	  date_created_on DATE,
		// 	  art_id INT,
		// 	  description VARCHAR (200),
		// 	  PRIMARY KEY(category_id))") Or die(mysql_error());

		// mysql_query("CREATE TABLE User (
		// 	  user_id INT AUTO_INCREMENT,
		// 	  created_on DATE,
		// 	  description VARCHAR (200),
		// 	  picture_url VARCHAR (200),
		// 	  PRIMARY KEY(user_id))") Or die(mysql_error());

		// mysql_query("CREATE TABLE Tag (
		// 	  tag_id INT AUTO_INCREMENT,
		// 	  priority INT,
		// 	  user_id INT,
		// 	  art_id INT,
		// 	  description VARCHAR (200),
		// 	  PRIMARY KEY(tag_id))") Or die(mysql_error());


// /*INSERTIN SHITS*/
		// mysql_query("INSERT INTO Article( content, url, created_on) VALUES ('son1', 'data.bg', '2011-02-3')");
		// mysql_query("INSERT INTO Article( content, url, created_on) VALUES ('son2', 'data.bg', '2011-02-4')");
		// mysql_query("INSERT INTO Article( content, url, created_on) VALUES ('son3', 'data.bg', '2011-02-5')");

		// mysql_query("INSERT INTO Category( date_created_on, description, art_id) VALUES ('2009-10-15', 'dont touch1!', 1)");
		// mysql_query("INSERT INTO Category( date_created_on, description, art_id) VALUES ('2009-10-16', 'dont touch2!', 2)");
		// mysql_query("INSERT INTO Category( date_created_on, description, art_id) VALUES ('2009-10-17', 'dont touch3!', 3)");

		// mysql_query("INSERT INTO User( created_on, description, picture_url) VALUES ('2010-03-21', '100.10', 'data.bg')");
		// mysql_query("INSERT INTO User( created_on, description, picture_url) VALUES ('2010-03-22', '200.20', 'data.bg')");
		// mysql_query("INSERT INTO User( created_on, description, picture_url) VALUES ('2010-03-23', '300.30', 'data.bg')");

		// mysql_query("INSERT INTO tag( priority, user_id, art_id, description) VALUES (1, 1, 1, 'dont do it1')");
		// mysql_query("INSERT INTO tag( priority, user_id, art_id, description) VALUES (2, 2, 2, 'dont do it2')");
		// mysql_query("INSERT INTO tag( priority, user_id, art_id, description) VALUES (3, 3, 3, 'dont do it3')");


/*Which are the Article(s) for a given User --> SELECT 1*/

		 // $pena =  mysql_query("SELECT * FROM Article INNER JOIN User, Tag WHERE Article.article_id = Tag.art_id
		 // 	AND Tag.art_id = Tag.user_id AND Tag.user_id = User.user_id AND User.user_id = 1");  // SELECT 1

		 // ?> THE ANSWER OF THE FIRST QUESTION IS : <br/><?php
		 // while($row = mysql_fetch_array($pena)){		
		 // 	echo $row["article_id"];
	
			// ?> <br/> <?php
		 // }

// /*Call the function that export the database*/
		// backup_tables('localhost','root','task8','task8_backup1');	

/*Migration*/
		// mysql_query(" CREATE TABLE Tag_part1 (
		// 	Tag_part1_id INT AUTO_INCREMENT,
		// 	description VARCHAR (200),
		// 	PRIMARY KEY(Tag_part1_id))") Or die(mysql_error());

		// mysql_query("INSERT INTO Tag_part1 (description) SELECT description FROM Tag");
		// mysql_query("ALTER TABLE Tag DROP description");
		// mysql_query("ALTER TABLE Tag RENAME TO Tag_part2");


// /*Second of export the database*/
		// backup_tables('localhost','root','task8','task8_backup2');

/* Which are the Category(s) for a given Tag --> SELECT 2*/

		 // $pena =  mysql_query("SELECT * FROM Category INNER JOIN Tag_part2 WHERE Category.art_id = Tag_part2.art_id AND Tag_part2.tag_id = 1");  // SELECT 2

		 // ?> THE ANSWER OF THE SECONT QUESTION IS : <br/><?php
		 // while($row = mysql_fetch_array($pena)){		
		 // 	echo $row["category_id"];

			// ?> <br/> <?php
		 // }

		 


?>
</body>
</html>


<?php

	
/* backup the db OR just a table */
function backup_tables($host,$user,$name,$place,$tables = '*')
{
	
	$link = mysql_connect($host,$user,"");
	mysql_select_db($name,$link);
	
	//get all of the tables
	if($tables == '*')
	{
		$tables = array();
		$result = mysql_query('SHOW TABLES');
		//var_dump($result);
		while($row = mysql_fetch_row($result))
		{
			$tables[] = $row[0];
		}
	}
	else
	{
		$tables = is_array($tables) ? $tables : explode(',',$tables);
	}
	

	//cycle through
	foreach($tables as $table)
	{
		$result = mysql_query('SELECT * FROM '.$table);
		$num_fields = mysql_num_fields($result);
		
		$return = 'DROP TABLE '.$table.';';
		$row2 = mysql_fetch_row(mysql_query('SHOW CREATE TABLE '.$table));
		$return = "\n\n".$row2[1].";\n\n";
		
		for ($i = 0; $i < $num_fields; $i++) 
		{
			while($row = mysql_fetch_row($result))
			{
				$return.= 'INSERT INTO '.$table.' VALUES(';
				for($j=0; $j<$num_fields; $j++) 
				{
					$row[$j] = addslashes($row[$j]);
					$row[$j] = ereg_replace("\n","\\n",$row[$j]);
					if (isset($row[$j])) { $return.= '"'.$row[$j].'"' ; } else { $return.= '""'; }
					if ($j<($num_fields-1)) { $return.= ','; }
				}
				$return.= ");\n";
			}
		}
		$return.="\n\n\n";

	$handle = fopen($place.'.sql','a+');
	fwrite($handle,$return);

	}
	fwrite($handle,"--------------------------------------------------------------------------".date('l jS \of F Y h:i:s A'));
	fclose($handle);
}
?>