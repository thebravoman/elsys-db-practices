

CREATE TABLE `article` (
  `article_id` int(11) NOT NULL AUTO_INCREMENT,
  `created_on` date DEFAULT NULL,
  `content` varchar(200) DEFAULT NULL,
  `url` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`article_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO article VALUES("1","2011-02-03","son1","data.bg");
INSERT INTO article VALUES("2","2011-02-04","son2","data.bg");
INSERT INTO article VALUES("3","2011-02-05","son3","data.bg");





CREATE TABLE `category` (
  `category_id` int(11) NOT NULL AUTO_INCREMENT,
  `date_created_on` date DEFAULT NULL,
  `art_id` int(11) DEFAULT NULL,
  `description` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`category_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO category VALUES("1","2009-10-15","1","dont touch1!");
INSERT INTO category VALUES("2","2009-10-16","2","dont touch2!");
INSERT INTO category VALUES("3","2009-10-17","3","dont touch3!");





CREATE TABLE `tag_part1` (
  `Tag_part1_id` int(11) NOT NULL AUTO_INCREMENT,
  `description` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`Tag_part1_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO tag_part1 VALUES("1","dont do it1");
INSERT INTO tag_part1 VALUES("2","dont do it2");
INSERT INTO tag_part1 VALUES("3","dont do it3");





CREATE TABLE `tag_part2` (
  `tag_id` int(11) NOT NULL AUTO_INCREMENT,
  `priority` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `art_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`tag_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO tag_part2 VALUES("1","1","1","1");
INSERT INTO tag_part2 VALUES("2","2","2","2");
INSERT INTO tag_part2 VALUES("3","3","3","3");





CREATE TABLE `user` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `created_on` date DEFAULT NULL,
  `description` varchar(200) DEFAULT NULL,
  `picture_url` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO user VALUES("1","2010-03-21","100.10","data.bg");
INSERT INTO user VALUES("2","2010-03-22","200.20","data.bg");
INSERT INTO user VALUES("3","2010-03-23","300.30","data.bg");



--------------------------------------------------------------------------Monday 14th of April 2014 02:05:58 PM