#!/usr/bin/env python
import datetime 
import time

import MySQLdb

def close(connection):
    connection.close()

db = MySQLdb.connect(host = "localhost", user="root", passwd="e5wjtmbuHh95", db="exam6")
cur = db.cursor()

#string2 = "%d" %(row[1])
# 4.Which are the Category(s) for a given Tag
#cur.execute("SELECT category_id FROM Article WHERE id = category_id;")
#for row in cur.fetchall():
#    print row[0]
cur.execute("CREATE TABLE Category_part1 (date_created_on date);")
cur.execute("CREATE TABLE Category_part2 (description varchar(30), category_id int(30));")

cur.execute("SELECT date_created_on FROM Category;")
start = datetime
for row in cur.fetchall():
	start = row[0];
	strk = start.strftime("%1Y-%m-%d")
	print strk
	cur.execute("INSERT INTO Category_part1 values('"+strk+"');")

#cur.execute("SELECT * FROM tag_part1;")
#for row in cur.fetchall():
#    print row[0]
#cur.execute("CREATE TABLE article_part2 (price DECIMAL(30) NOT NULL, article_id INT(30) NOT NULL PRIMARY KEY AUTO_INCREMENT UNIQUE, category_id INT(30) NOT NULL UNIQUE);")
#cur.execute("INSERT INTO article_part2 SELECT Article.price, Article.id, Article.category_id FROM Article;")

cur.execute("SELECT descripti	on, category_id FROM Category;")
for row in cur.fetchall():
	print str(row[0])
	print str(row[1])
	cur.execute("INSERT INTO Category_part2 values('"+str(row[0])+","+str(row[1])+"');")

cur.execute("drop table Category;")
db.commit()

#for row in cur.fetchall():
#    print row[0], row[1], row[2]
close(db)
