#!/usr/bin/env python
import datetime 
import time

import MySQLdb

def close(connection):
    connection.close()

db = MySQLdb.connect(host = "localhost", user="root", passwd="e5wjtmbuHh95", db="exam2")
cur = db.cursor()

#string2 = "%d" %(row[1])
# 4.Which are the Category(s) for a given Tag
#cur.execute("SELECT category_id FROM Article WHERE id = category_id;")
#for row in cur.fetchall():
#    print row[0]
cur.execute("CREATE TABLE User_part1 (description longtext);")
cur.execute("CREATE TABLE User_part2 (password VARCHAR(30), income FLOAT(30, 30), tag_id int(30), article_id int(30));")

cur.execute("SELECT description FROM User;")
#= datetime
for row in cur.fetchall():
	start = row[0]
	strk = (row[0])
	#start.strftime("%Y-%m-%d")
	print strk
	cur.execute("INSERT INTO User_part1 values('"+strk+"');")

cur.execute("SELECT password, income, tag_id, article_id FROM User;")
for row in cur.fetchall():
    print row[0]
#cur.execute("CREATE TABLE article_part2 (price DECIMAL(30) NOT NULL, article_id INT(30) NOT NULL PRIMARY KEY AUTO_INCREMENT UNIQUE, category_id INT(30) NOT NULL UNIQUE);")
cur.execute("INSERT INTO User_part2 SELECT User.password, User.income, User.tag_id, User.article_id FROM Article;")

#
#

#cur.execute("SELECT second_priority FROM Tag;")
#for row in cur.fetchall():
#	print str(row[0])
#	cur.execute("INSERT INTO tag_part2 values('"+str(row[0])+"');")


db.commit()
#cur.execute("SELECT * FROM article_part2;")
#for row in cur.fetchall():
#    print row[0], row[1], row[2]
close(db)
