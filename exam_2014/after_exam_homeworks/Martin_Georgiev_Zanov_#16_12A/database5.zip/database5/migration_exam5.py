#!/usr/bin/env python
import datetime 
import time

import MySQLdb

def close(connection):
    connection.close()

db = MySQLdb.connect(host = "localhost", user="root", passwd="e5wjtmbuHh95", db="exam7")
cur = db.cursor()

#string2 = "%d" %(row[1])
# 4.Which are the Category(s) for a given Tag
#cur.execute("SELECT category_id FROM Article WHERE id = category_id;")
#for row in cur.fetchall():
#    print row[0]
cur.execute("CREATE TABLE User_part1 (name varchar(30));")
cur.execute("CREATE TABLE User_part2 (second_priority float(30.30));")

cur.execute("SELECT name FROM User;")
#start = datetime
for row in cur.fetchall():
	#start = row[0];
	strk = (row[0])
	#start.strftime("%Y-%m-%d")
	print strk
	cur.execute("INSERT INTO User_part1 values('"+strk+"');")

#cur.execute("SELECT * FROM User_part1;")
#for row in cur.fetchall():
#    print row[0]
#cur.execute("CREATE TABLE article_part2 (price DECIMAL(30) NOT NULL, article_id INT(30) NOT NULL PRIMARY KEY AUTO_INCREMENT UNIQUE, category_id INT(30) NOT NULL UNIQUE);")
#cur.execute("INSERT INTO article_part2 SELECT Article.price, Article.id, Article.category_id FROM Article;")

cur.execute("SELECT age, created_on, tag_id, user_id FROM User;")
for row in cur.fetchall():
	print str(row[0])
	cur.execute("INSERT INTO User_part2 values('"+str(row[0])+","+str(row[1])+","+str(row[2])+","+str(row[3])+"');")

cur.execute("drop table User;")

db.commit()
#for row in cur.fetchall():
#    print row[0], row[1], row[2]
close(db)
