#!/usr/bin/env python
import datetime 
import time

import MySQLdb

def close(connection):
    connection.close()

db = MySQLdb.connect(host = "localhost", user="root", passwd="e5wjtmbuHh95", db="exam3")
cur = db.cursor()

#string2 = "%d" %(row[1])
# 4.Which are the Category(s) for a given Tag
#cur.execute("SELECT category_id FROM Article WHERE id = category_id;")
#for row in cur.fetchall():
#    print row[0]
cur.execute("CREATE TABLE Tag_part1 (name VARCHAR(30));")
cur.execute("CREATE TABLE Tag_part2 (description VARCHAR(30));")

cur.execute("SELECT name FROM Tag;")
#start = datetime
for row in cur.fetchall():
	#start = row[0];
	strk = (row[0])
	#start.strftime("%Y-%m-%d")
	print strk
	cur.execute("INSERT INTO Tag_part1 values('"+strk+"');")

cur.execute("SELECT description FROM Tag;")
for row in cur.fetchall():
	strk1 = (row[0])
	print strk
	cur.execute("INSERT INTO Tag_part2 values('"+strk1+"');")
    #print row[0]
#cur.execute("CREATE TABLE article_part2 (price DECIMAL(30) NOT NULL, article_id INT(30) NOT NULL PRIMARY KEY AUTO_INCREMENT UNIQUE, category_id INT(30) NOT NULL UNIQUE);")
#cur.execute("INSERT INTO article_part2 SELECT Article.price, Article.id, Article.category_id FROM Article;")

#cur.execute("SELECT second_priority FROM Tag;")
#for row in cur.fetchall():
#	print str(row[0])
#	cur.execute("INSERT INTO Tag_part2 values('"+str(row[0])+"');")


db.commit()
#cur.execute("SELECT * FROM article_part2;")
#for row in cur.fetchall():
#    print row[0], row[1], row[2]
close(db)
