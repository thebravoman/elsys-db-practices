#!/usr/bin/env python
import datetime 
import time

import MySQLdb

def close(connection):
    connection.close()

db = MySQLdb.connect(host = "localhost", user="root", passwd="e5wjtmbuHh95", db="exam11")
cur = db.cursor()

#string2 = "%d" %(row[1])
# 4.Which are the Category(s) for a given Tag
#cur.execute("SELECT category_id FROM Article WHERE id = category_id;")
#for row in cur.fetchall():
#    print row[0]
cur.execute("CREATE TABLE Article_part1 (url TEXT);")
cur.execute("CREATE TABLE Article_part2 (content LONGTEXT, published_on DATE, article_id int(30), tag_id int(30));")

cur.execute("SELECT url FROM Article;")
#start = datetime
for row in cur.fetchall():
	#start = row[0];
	strk = (row[0])
	#start.strftime("%Y-%m-%d")
	print strk
	cur.execute("INSERT INTO Article_part1 values('"+strk+"');")

#cur.execute("SELECT * FROM tag_part1;")
#for row in cur.fetchall():
#    print row[0]
#cur.execute("CREATE TABLE article_part2 (price DECIMAL(30) NOT NULL, article_id INT(30) NOT NULL PRIMARY KEY AUTO_INCREMENT UNIQUE, category_id INT(30) NOT NULL UNIQUE);")
#cur.execute("INSERT INTO article_part2 SELECT Article.price, Article.id, Article.category_id FROM Article;")

cur.execute("SELECT content, published_on, article_id, tag_id FROM Article;")
start2 = datetime
for row in cur.fetchall():
	start2 = row[1];
	strk2 = start2.strftime("%Y-%m-%d")
	print str(row[0])
	cur.execute("INSERT INTO Article_part2 values('"+str(row[0])+","+strk2+","+str(row[2])+","+str(row[3])+"');")

cur.execute("drop table Article;")
db.commit()
#cur.execute("SELECT * FROM article_part2;")
#for row in cur.fetchall():
#    print row[0], row[1], row[2]
close(db)
