Separate User on two tables
User_part1 containing name
User_part2 containing all the other fields
As a result SQL queries+code in other programming language must be create

create table User(id int,age int,name varchar(30), income float, article_id int, unique (article_id))

<?php
$table_name = "User";
$db = new mysqli("localhost", "root", "123", "home_10");


$db->query(sprintf("create table %s_part1(id int,name varchar(50))", $table_name));
$db->query(sprintf("create table %s_part2(id int,age int,income float,article_id int, unique(article_id))", $table_name));

$result = $db->query("select * from " . $table_name);

while($row = $result->fetch_assoc()) {
	$db->query(sprintf("insert into %s_part1 values(%d, '%s')", $table_name, $row["id"], $row["name"]));
	$db->query(sprintf("insert into %s_part2 values(%d, %d, %f, %d)", $table_name, $row["id"], $row["age"],$row["income"], $row["article_id"]));
}

$db->query("drop table " . $table_name);
$db->close();
