-- phpMyAdmin SQL Dump
-- version 3.4.10.1deb1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Apr 14, 2014 at 01:55 PM
-- Server version: 5.5.34
-- PHP Version: 5.3.10-1ubuntu3.9

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `home_7`
--

-- --------------------------------------------------------

--
-- Table structure for table `article`
--

CREATE TABLE IF NOT EXISTS `article` (
  `id` int(11) DEFAULT NULL,
  `url` varchar(50) DEFAULT NULL,
  `price` float DEFAULT NULL,
  `created_on` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `article`
--

INSERT INTO `article` (`id`, `url`, `price`, `created_on`) VALUES
(1, 'asd.com', 100.2, '2006-02-03'),
(2, 'asd.com', 100.2, '2006-02-04');

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

CREATE TABLE IF NOT EXISTS `category` (
  `id` int(11) DEFAULT NULL,
  `date_created_on` date DEFAULT NULL,
  `created_by` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`id`, `date_created_on`, `created_by`) VALUES
(1, '2006-02-03', 'asd'),
(2, '2006-02-04', 'asd');

-- --------------------------------------------------------

--
-- Table structure for table `tag`
--

CREATE TABLE IF NOT EXISTS `tag` (
  `id` int(11) DEFAULT NULL,
  `second_priority` float DEFAULT NULL,
  `priority` int(11) DEFAULT NULL,
  `article_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tag`
--

INSERT INTO `tag` (`id`, `second_priority`, `priority`, `article_id`) VALUES
(1, 1.12, 2, 1),
(2, 1.12, 2, 2);

-- --------------------------------------------------------

--
-- Table structure for table `user_part1`
--

CREATE TABLE IF NOT EXISTS `user_part1` (
  `id` int(11) DEFAULT NULL,
  `income` float DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user_part1`
--

INSERT INTO `user_part1` (`id`, `income`) VALUES
(1, 12.2),
(2, 12.2);

-- --------------------------------------------------------

--
-- Table structure for table `user_part2`
--

CREATE TABLE IF NOT EXISTS `user_part2` (
  `id` int(11) DEFAULT NULL,
  `picture_url` varchar(50) DEFAULT NULL,
  `created_on` date DEFAULT NULL,
  `category_id` int(11) DEFAULT NULL,
  `article_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user_part2`
--

INSERT INTO `user_part2` (`id`, `picture_url`, `created_on`, `category_id`, `article_id`) VALUES
(1, 'asd.com', '2006-02-03', 1, 1),
(2, 'asd.com', '2006-02-03', 2, 2);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
