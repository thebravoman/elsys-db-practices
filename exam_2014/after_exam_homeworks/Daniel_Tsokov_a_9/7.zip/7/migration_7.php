Separate User on two tables
User_part1 containing income
User_part2 containing all the other fields
As a result SQL queries+code in other programming language must be create

CREATE TABLE User(id int, picture_url varchar(50), created_on date, income float, category_id int, article_id int)

<?php
$table_name = "User";
$db = new mysqli("localhost", "root", "123", "home_7");


$db->query(sprintf("create table %s_part1(id int, income float)", $table_name));
$db->query(sprintf("create table %s_part2(id int, picture_url varchar(50), created_on date, category_id int, article_id int)", $table_name));

$result = $db->query("select * from " . $table_name);

while($row = $result->fetch_assoc()) {
	$db->query(sprintf("insert into %s_part1 values(%d, %f)", $table_name, $row["id"], $row["income"]));
	$db->query(sprintf("insert into %s_part2 values(%d, '%s', '%s', %d, %d)", $table_name, $row["id"], $row["picture_url"],$row["created_on"], $row["category_id"], $row["article_id"]));
}

$db->query("drop table " . $table_name);
$db->close();
