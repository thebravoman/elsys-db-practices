<html>
<title> Kontrolno </title>

<body>

	Georgi Neychev - 12a

<?php
mysql_connect("localhost","root","");

//mysql_query("CREATE DATABASE subd_11") or die(mysql_error());

mysql_select_db("subd_11") or die(mysql_error());

// mysql_query("CREATE TABLE Article (
// 	 	  article_id INT AUTO_INCREMENT,
// 	 	  content VARCHAR(43), 
// 	 	  price VARCHAR(23),
// 	 	  published_on DATE,
// 	 	  PRIMARY KEY(article_id))") Or die(mysql_error());
	  
// mysql_query("CREATE TABLE Category (
// 	      cat_id INT AUTO_INCREMENT,
// 		  created_by VARCHAR(34),
// 		  name VARCHAR(53),
// 		  PRIMARY KEY(cat_id))") Or die(mysql_error());
		  
// mysql_query("CREATE TABLE User (
// 		  user_id INT AUTO_INCREMENT,
// 		  age INT,
// 		  picture_url VARCHAR(32),
// 		  income VARCHAR(23),
// 	 	  PRIMARY KEY(user_id))") Or die(mysql_error());
		  
// mysql_query("CREATE TABLE Tag (
// 		  tag_id INT AUTO_INCREMENT, 
// 		  second_priority VARCHAR(13),
// 		  priority INT,
// 		  PRIMARY KEY(tag_id))") Or die(mysql_error());

	// mysql_query("INSERT INTO Article( content, price, published_on) VALUES ('addafd','fdsfsd','2013-03-11')");
	// mysql_query("INSERT INTO Article( content, price, published_on) VALUES ('fdsgads','sdaas','2013-03-13')");	

	// mysql_query("INSERT INTO Category( created_by, name) VALUES ('dasdas','sport')");	
	// mysql_query("INSERT INTO Category( created_by, name) VALUES ('dasdasd','kdakjdk')");

	// mysql_query("INSERT INTO User( age, picture_url, income) VALUES (1,'dasdad','dawdwa')");	
	// mysql_query("INSERT INTO User( age, picture_url, income) VALUES (2,'dasda','feafa')");
	
	// mysql_query("INSERT INTO Tag( second_priority, priority) VALUES ('dadsa',2)");
	// mysql_query("INSERT INTO Tag( second_priority, priority) VALUES ('dsadafas',1)");

backup_tables('localhost','root','subd_11','sub_exam2_1');

backup_tables('localhost','root','subd_11','sub_exam2_2');


function backup_tables($host,$user,$name,$place,$tables = '*')
{
	
	$link = mysql_connect($host,$user,"");
	mysql_select_db($name,$link);
	
	//get all of the tables
	if($tables == '*')
	{
		$tables = array();
		$result = mysql_query('SHOW TABLES');
		//var_dump($result);
		while($row = mysql_fetch_row($result))
		{
			$tables[] = $row[0];
		}
	}
	else
	{
		$tables = is_array($tables) ? $tables : explode(',',$tables);
	}
	
	//cycle through
	foreach($tables as $table)
	{
		$result = mysql_query('SELECT * FROM '.$table);
		$num_fields = mysql_num_fields($result);
		
		$return = 'DROP TABLE '.$table.';';
		$row2 = mysql_fetch_row(mysql_query('SHOW CREATE TABLE '.$table));
		$return = "\n\n".$row2[1].";\n\n";
		
	$handle = fopen($place.'.sql','a+');
	fwrite($handle,$return);

	}
	fwrite($handle,"***************************************************************");
	fclose($handle);
}


?>
</body>

</html>