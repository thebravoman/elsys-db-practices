<html>
<title> Kontrolno </title>

<body>

	Georgi Neychev - 12a

<?php
mysql_connect("localhost","root","");

//mysql_query("CREATE DATABASE subd_3") or die(mysql_error());

mysql_select_db("subd_3") or die(mysql_error());

// mysql_query("CREATE TABLE Article (
// 	 	  article_id INT AUTO_INCREMENT,
// 	 	  price VARCHAR(32), 
// 	 	  created_on DATE,
// 	 	  published_on DATE,
// 	 	  cat_id INT,
// 	 	  PRIMARY KEY(article_id))") Or die(mysql_error());
	  
// mysql_query("CREATE TABLE Category (
// 	      cat_id INT AUTO_INCREMENT,
// 		  priority VARCHAR(23),
// 		  description VARCHAR(54),
// 		  PRIMARY KEY(cat_id))") Or die(mysql_error());
		  
// mysql_query("CREATE TABLE User (
// 		  user_id INT AUTO_INCREMENT,
// 		  picture_url VARCHAR(54),
// 		  description VARCHAR(43),
// 		  password VARCHAR(32),
// 		  article_id INT,
// 	 	  PRIMARY KEY(user_id))") Or die(mysql_error());
		  
// mysql_query("CREATE TABLE Tag (
// 		  tag_id INT AUTO_INCREMENT, 
// 		  name VARCHAR(43),
// 		  description VARCHAR(42),
// 		  user_id INT UNIQUE,
// 		  PRIMARY KEY(tag_id))") Or die(mysql_error());

	// mysql_query("INSERT INTO Article( price, created_on, published_on, cat_id) VALUES ('dfsdsd','2013-03-12','2013-03-15',1)");
	// mysql_query("INSERT INTO Article( price, created_on, published_on, cat_id) VALUES ('fsdsgsf','2013-03-12','2013-03-13',2)");	

	// mysql_query("INSERT INTO Category( priority, description) VALUES ('dasdas','sport')");	
	// mysql_query("INSERT INTO Category( priority, description) VALUES ('faaf','kdakjdk')");

	// mysql_query("INSERT INTO User( picture_url, description, password, article_id) VALUES ('cddssdc','fdsdf','googo',3)");	
	// mysql_query("INSERT INTO User( picture_url, description, password, article_id) VALUES ('descassac','fdsgs','kdajakjdk',2)");
	
	// mysql_query("INSERT INTO Tag( name, description, user_id) VALUES ('aadafdadfd','dcdc',1)");
	// mysql_query("INSERT INTO Tag( name, description, user_id) VALUES ('adsfdsffsd','dsdfds',3)");

	$gogo= mysql_query("SELECT * FROM User INNER JOIN Tag_art ON User.art_id = Tag_art.art_id 
		INNER JOIN Tag ON Tag.tag_id = Tag_art.tag_id
		WHERE Tag.tag_id = 2
		");

backup_tables('localhost','root','subd_1','sub_exam2_1');

		mysql_query(" CREATE TABLE Article1 (
			art1_id INT AUTO_INCREMENT,
			price VARCHAR (35),
			PRIMARY KEY(art1_id))") Or die(mysql_error());

		mysql_query("INSERT INTO Article1 (price) SELECT price FROM Article");
		mysql_query("ALTER TABLE Article DROP price");
		mysql_query("ALTER TABLE Article RENAME TO Article2");	

backup_tables('localhost','root','subd_1','sub_exam2_2');


function backup_tables($host,$user,$name,$place,$tables = '*')
{
	
	$link = mysql_connect($host,$user,"");
	mysql_select_db($name,$link);
	
	//get all of the tables
	if($tables == '*')
	{
		$tables = array();
		$result = mysql_query('SHOW TABLES');
		//var_dump($result);
		while($row = mysql_fetch_row($result))
		{
			$tables[] = $row[0];
		}
	}
	else
	{
		$tables = is_array($tables) ? $tables : explode(',',$tables);
	}
	
	//cycle through
	foreach($tables as $table)
	{
		$result = mysql_query('SELECT * FROM '.$table);
		$num_fields = mysql_num_fields($result);
		
		$return = 'DROP TABLE '.$table.';';
		$row2 = mysql_fetch_row(mysql_query('SHOW CREATE TABLE '.$table));
		$return = "\n\n".$row2[1].";\n\n";
		
	$handle = fopen($place.'.sql','a+');
	fwrite($handle,$return);

	}
	fwrite($handle,"***************************************************************");
	fclose($handle);
}


?>
</body>

</html>