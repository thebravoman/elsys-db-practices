<html>
<title> Kontrolno </title>

<body>

	Georgi Neychev - 12a

<?php
mysql_connect("localhost","root","");

//mysql_query("CREATE DATABASE subd_1") or die(mysql_error());

mysql_select_db("subd_1") or die(mysql_error());

// mysql_query("CREATE TABLE Article (
// 	 	  article_id INT AUTO_INCREMENT,
// 	 	  published_on DATE, 
// 	 	  price varchar(32),
// 		  name VARCHAR(23),
// 	 	  PRIMARY KEY(article_id))") Or die(mysql_error());
		  
// mysql_query("CREATE TABLE Category (
// 	      cat_id INT AUTO_INCREMENT,
// 		  name VARCHAR (35),
// 		  created_by VARCHAR(34),
// 		  PRIMARY KEY(cat_id))") Or die(mysql_error());
		  
// mysql_query("CREATE TABLE User (
// 		  user_id INT AUTO_INCREMENT,
// 		  age INT,
// 		  password VARCHAR (12),
// 		  description VARCHAR(34),
// 		  art_id INT,
// 	 	  PRIMARY KEY(user_id))") Or die(mysql_error());
		  
// mysql_query("CREATE TABLE Tag (
// 		  tag_id INT AUTO_INCREMENT, 
// 		  description VARCHAR (35),
// 		  second_priority VARCHAR(43),
// 		  PRIMARY KEY(tag_id))") Or die(mysql_error());
		  		  
// mysql_query("CREATE TABLE Tag_art (
// 		  tag_id INT, 
// 		  art_id INT 
// 		  )") Or die(mysql_error()); 

// mysql_query("CREATE TABLE User_cat (
// 		  user_id INT, 
// 		  cat_id INT 
// 		  )") Or die(mysql_error()); 

	// mysql_query("INSERT INTO Article( price, published_on, name) VALUES ('5','2012-02-1','ksjdakjdas')");
	// mysql_query("INSERT INTO Article( price, published_on, name) VALUES ('5.04','2012-02-1','jkfdkj')");	

	// mysql_query("INSERT INTO Category( created_by, name) VALUES ('dasdas','sport')");	
	// mysql_query("INSERT INTO Category( created_by, name) VALUES ('faaf','kdakjdk')");

	// mysql_query("INSERT INTO User( password, age, description) VALUES ('cddssdc',12,'googo')");	
	// mysql_query("INSERT INTO User( password, age, description) VALUES ('descassac',18,'kdajakjdk')");
	
	// mysql_query("INSERT INTO Tag( description, second_priority) VALUES ('aadafdadfd','dcdc')");
	// mysql_query("INSERT INTO Tag( description, second_priority) VALUES ('adsfdsffsd','dsdfds')");
	
	// mysql_query("INSERT INTO Tag_art( tag_id, art_id) VALUES (1,1)");
	// mysql_query("INSERT INTO Tag_art( tag_id, art_id) VALUES (1,2)");

	// mysql_query("INSERT INTO User_cat( user_id, cat_id) VALUES (1,1)");
	// mysql_query("INSERT INTO User_cat( user_id, cat_id) VALUES (1,2)");


backup_tables('localhost','root','subd_1','sub_exam2_1');

//Which are the User(s) for a given Tag

	$gogo= mysql_query("SELECT * FROM User INNER JOIN Tag_art ON User.art_id = Tag_art.art_id 
		INNER JOIN Tag ON Tag.tag_id = Tag_art.tag_id
		WHERE Tag.tag_id = 2
		");



backup_tables('localhost','root','subd_1','sub_exam2_2');


function backup_tables($host,$user,$name,$place,$tables = '*')
{
	
	$link = mysql_connect($host,$user,"");
	mysql_select_db($name,$link);
	
	//get all of the tables
	if($tables == '*')
	{
		$tables = array();
		$result = mysql_query('SHOW TABLES');
		//var_dump($result);
		while($row = mysql_fetch_row($result))
		{
			$tables[] = $row[0];
		}
	}
	else
	{
		$tables = is_array($tables) ? $tables : explode(',',$tables);
	}
	
	//cycle through
	foreach($tables as $table)
	{
		$result = mysql_query('SELECT * FROM '.$table);
		$num_fields = mysql_num_fields($result);
		
		$return = 'DROP TABLE '.$table.';';
		$row2 = mysql_fetch_row(mysql_query('SHOW CREATE TABLE '.$table));
		$return = "\n\n".$row2[1].";\n\n";
		
	$handle = fopen($place.'.sql','a+');
	fwrite($handle,$return);

	}
	fwrite($handle,"***************************************************************");
	fclose($handle);
}


?>
</body>

</html>