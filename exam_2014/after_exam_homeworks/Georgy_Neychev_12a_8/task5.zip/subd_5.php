<html>
<title> Kontrolno </title>

<body>

	Georgi Neychev - 12a

<?php
mysql_connect("localhost","root","");

//mysql_query("CREATE DATABASE subd_5") or die(mysql_error());

mysql_select_db("subd_5") or die(mysql_error());

// mysql_query("CREATE TABLE Article (
// 	 	  article_id INT AUTO_INCREMENT,
// 	 	  name VARCHAR(23), 
// 	 	  published_on DATE,
// 	 	  url VARCHAR(43),
// 	 	  PRIMARY KEY(article_id))") Or die(mysql_error());
	  
// mysql_query("CREATE TABLE Category (
// 	      cat_id INT AUTO_INCREMENT,
// 		  date_created_on DATE,
// 		  name VARCHAR(53),
// 		  user_id INT,
// 		  PRIMARY KEY(cat_id))") Or die(mysql_error());
		  
// mysql_query("CREATE TABLE User (
// 		  user_id INT AUTO_INCREMENT,
// 		  name VARCHAR(42),
// 		  age INT,
// 		  income VARCHAR(43),
// 	 	  PRIMARY KEY(user_id))") Or die(mysql_error());
		  
// mysql_query("CREATE TABLE Tag (
// 		  tag_id INT AUTO_INCREMENT, 
// 		  priority INT,
// 		  description VARCHAR(44),
// 		  PRIMARY KEY(tag_id))") Or die(mysql_error());

// mysql_query("CREATE TABLE Article_user (
// 		  article_id INT, 
// 		  user_id INT 
// 		  )") Or die(mysql_error());

// mysql_query("CREATE TABLE Cat_tag (
// 		  cat_id INT, 
// 		  tag_id INT 
// 		  )") Or die(mysql_error());

	// mysql_query("INSERT INTO Article( name, published_on, url) VALUES ('dfsdsd','2013-03-12','fsdfa')");
	// mysql_query("INSERT INTO Article( name, published_on, url) VALUES ('fsdsgsf','2013-03-15','dasdfvad')");	

	// mysql_query("INSERT INTO Category( date_created_on, name, user_id) VALUES ('2013-03-12','sport',2)");	
	// mysql_query("INSERT INTO Category( date_created_on, name, user_id) VALUES ('2013-03-14','kdakjdk',3)");

	// mysql_query("INSERT INTO User( name, age, income) VALUES ('fdsdf',2,'fssf')");	
	// mysql_query("INSERT INTO User( name, age, income) VALUES ('fdsgs',1,'fsdfsddfd')");
	
	// mysql_query("INSERT INTO Tag( priority, description) VALUES (1,'dcdc')");
	// mysql_query("INSERT INTO Tag( priority, description) VALUES (2,'dsdfds')");

	// mysql_query("INSERT INTO Cat_user( article_id, user_id) VALUES (3,1)");
	// mysql_query("INSERT INTO Cat_user( article_id, user_id) VALUES (1,2)");

	// mysql_query("INSERT INTO Cat_user( cat_id, tag_id) VALUES (1,2)");
	// mysql_query("INSERT INTO Cat_user( cat_id, tag_id) VALUES (1,3)");

backup_tables('localhost','root','subd_5','sub_exam2_1');

backup_tables('localhost','root','subd_5','sub_exam2_2');


function backup_tables($host,$user,$name,$place,$tables = '*')
{
	
	$link = mysql_connect($host,$user,"");
	mysql_select_db($name,$link);
	
	//get all of the tables
	if($tables == '*')
	{
		$tables = array();
		$result = mysql_query('SHOW TABLES');
		//var_dump($result);
		while($row = mysql_fetch_row($result))
		{
			$tables[] = $row[0];
		}
	}
	else
	{
		$tables = is_array($tables) ? $tables : explode(',',$tables);
	}
	
	//cycle through
	foreach($tables as $table)
	{
		$result = mysql_query('SELECT * FROM '.$table);
		$num_fields = mysql_num_fields($result);
		
		$return = 'DROP TABLE '.$table.';';
		$row2 = mysql_fetch_row(mysql_query('SHOW CREATE TABLE '.$table));
		$return = "\n\n".$row2[1].";\n\n";
		
	$handle = fopen($place.'.sql','a+');
	fwrite($handle,$return);

	}
	fwrite($handle,"***************************************************************");
	fclose($handle);
}


?>
</body>

</html>