<html>
<title> Kontrolno </title>

<body>

	Georgi Neychev - 12a

<?php
mysql_connect("localhost","root","");

//mysql_query("CREATE DATABASE subd_7") or die(mysql_error());

mysql_select_db("subd_7") or die(mysql_error());

// mysql_query("CREATE TABLE Article (
// 	 	  article_id INT AUTO_INCREMENT,
// 	 	  created_on DATE, 
// 	 	  published_on DATE,
// 	 	  url VARCHAR(43),
// 	 	  PRIMARY KEY(article_id))") Or die(mysql_error());
	  
// mysql_query("CREATE TABLE Category (
// 	      cat_id INT AUTO_INCREMENT,
// 		  description VARCHAR(34),
// 		  name VARCHAR(53),
// 		  PRIMARY KEY(cat_id))") Or die(mysql_error());
		  
// mysql_query("CREATE TABLE User (
// 		  user_id INT AUTO_INCREMENT,
// 		  name VARCHAR(32),
// 		  age INT,
// 		  password VARCHAR(43),
// 	 	  PRIMARY KEY(user_id))") Or die(mysql_error());
		  
// mysql_query("CREATE TABLE Tag (
// 		  tag_id INT AUTO_INCREMENT, 
// 		  priority INT,
// 		  name VARCHAR(44),
// 		  PRIMARY KEY(tag_id))") Or die(mysql_error());

	// mysql_query("INSERT INTO Article( created_on, published_on, url) VALUES ('2013-03-12','2013-03-13','fsdfa')");
	// mysql_query("INSERT INTO Article( created_on, published_on, url) VALUES ('2013-03-11','2013-03-14','dasdfvad')");	

	// mysql_query("INSERT INTO Category( description, name) VALUES ('dasdas','sport')");	
	// mysql_query("INSERT INTO Category( description, name) VALUES ('dasdasd','kdakjdk')");

	// mysql_query("INSERT INTO User( name, age, password) VALUES ('saSa',2,'fssf')");	
	// mysql_query("INSERT INTO User( name, age, password) VALUES ('fadsasf',1,'fsdfsddfd')");
	
	// mysql_query("INSERT INTO Tag( priority, name) VALUES (1,'dcdc')");
	// mysql_query("INSERT INTO Tag( priority, name) VALUES (2,'dsdfds')");

backup_tables('localhost','root','subd_7','sub_exam2_1');

backup_tables('localhost','root','subd_7','sub_exam2_2');


function backup_tables($host,$user,$name,$place,$tables = '*')
{
	
	$link = mysql_connect($host,$user,"");
	mysql_select_db($name,$link);
	
	//get all of the tables
	if($tables == '*')
	{
		$tables = array();
		$result = mysql_query('SHOW TABLES');
		//var_dump($result);
		while($row = mysql_fetch_row($result))
		{
			$tables[] = $row[0];
		}
	}
	else
	{
		$tables = is_array($tables) ? $tables : explode(',',$tables);
	}
	
	//cycle through
	foreach($tables as $table)
	{
		$result = mysql_query('SELECT * FROM '.$table);
		$num_fields = mysql_num_fields($result);
		
		$return = 'DROP TABLE '.$table.';';
		$row2 = mysql_fetch_row(mysql_query('SHOW CREATE TABLE '.$table));
		$return = "\n\n".$row2[1].";\n\n";
		
	$handle = fopen($place.'.sql','a+');
	fwrite($handle,$return);

	}
	fwrite($handle,"***************************************************************");
	fclose($handle);
}


?>
</body>

</html>