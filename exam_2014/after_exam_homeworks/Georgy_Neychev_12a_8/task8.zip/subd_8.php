<html>
<title> Kontrolno </title>

<body>

	Georgi Neychev - 12a

<?php
mysql_connect("localhost","root","");

//mysql_query("CREATE DATABASE subd_8") or die(mysql_error());

mysql_select_db("subd_8") or die(mysql_error());

// mysql_query("CREATE TABLE Article (
// 	 	  article_id INT AUTO_INCREMENT,
// 	 	  created_on DATE, 
// 	 	  price VARCHAR(34),
// 	 	  url VARCHAR(43),
// 	 	  PRIMARY KEY(article_id))") Or die(mysql_error());
	  
// mysql_query("CREATE TABLE Category (
// 	      cat_id INT AUTO_INCREMENT,
// 		  description VARCHAR(34),
// 		  name VARCHAR(53),
// 		  PRIMARY KEY(cat_id))") Or die(mysql_error());
		  
// mysql_query("CREATE TABLE User (
// 		  user_id INT AUTO_INCREMENT,
// 		  created_on DATE,
// 		  income VARCHAR(32),
// 		  password VARCHAR(43),
// 	 	  PRIMARY KEY(user_id))") Or die(mysql_error());
		  
// mysql_query("CREATE TABLE Tag (
// 		  tag_id INT AUTO_INCREMENT, 
// 		  second_priority VARCHAR(13),
// 		  name VARCHAR(44),
// 		  PRIMARY KEY(tag_id))") Or die(mysql_error());

	// mysql_query("INSERT INTO Article( created_on, price, url) VALUES ('2013-03-12','fdfds','fsdfa')");
	// mysql_query("INSERT INTO Article( created_on, price, url) VALUES ('2013-03-11','fdsdsfdsf','dasdfvad')");	

	// mysql_query("INSERT INTO Category( description, name) VALUES ('dasdas','sport')");	
	// mysql_query("INSERT INTO Category( description, name) VALUES ('dasdasd','kdakjdk')");

	// mysql_query("INSERT INTO User( created_on, income, password) VALUES ('2013-03-11','dasds','fssf')");	
	// mysql_query("INSERT INTO User( created_on, income, password) VALUES ('2013-03-10','dsadaf','fsdfsddfd')");
	
	// mysql_query("INSERT INTO Tag( second_priority, name) VALUES ('dadsa','dcdc')");
	// mysql_query("INSERT INTO Tag( second_priority, name) VALUES ('dsadafas','dsdfds')");

backup_tables('localhost','root','subd_8','sub_exam2_1');

backup_tables('localhost','root','subd_8','sub_exam2_2');


function backup_tables($host,$user,$name,$place,$tables = '*')
{
	
	$link = mysql_connect($host,$user,"");
	mysql_select_db($name,$link);
	
	//get all of the tables
	if($tables == '*')
	{
		$tables = array();
		$result = mysql_query('SHOW TABLES');
		//var_dump($result);
		while($row = mysql_fetch_row($result))
		{
			$tables[] = $row[0];
		}
	}
	else
	{
		$tables = is_array($tables) ? $tables : explode(',',$tables);
	}
	
	//cycle through
	foreach($tables as $table)
	{
		$result = mysql_query('SELECT * FROM '.$table);
		$num_fields = mysql_num_fields($result);
		
		$return = 'DROP TABLE '.$table.';';
		$row2 = mysql_fetch_row(mysql_query('SHOW CREATE TABLE '.$table));
		$return = "\n\n".$row2[1].";\n\n";
		
	$handle = fopen($place.'.sql','a+');
	fwrite($handle,$return);

	}
	fwrite($handle,"***************************************************************");
	fclose($handle);
}


?>
</body>

</html>