CREATE DATABASE exam_database;
USE exam_database;
CREATE TABLE Article ( name VARCHAR(30) NOT NULL, published_on DATE NOT NULL, content LONGTEXT NOT NULL);
CREATE TABLE Category ( priority DOUBLE(30, 30) NOT NULL, name VARCHAR(30) NOT NULL);
CREATE TABLE User ( name VARCHAR(30) NOT NULL, description LONGTEXT, password VARCHAR(30) NOT NULL);
CREATE TABLE Tag ( priority INT NOT NULL, name VARCHAR(30) NOT NULL);
CREATE TABLE user_category (user_id INT(30) NOT NULL, category_id INT(30) NOT NULL);
ALTER TABLE user_category ADD CONSTRAINT FOREIGN KEY (user_id) REFERENCES User (many_user_id);
ALTER TABLE user_category ADD CONSTRAINT FOREIGN KEY (category_id) REFERENCES Category (many_category_id);
ALTER TABLE Category ADD CONSTRAINT FOREIGN KEY (category_id) REFERENCES Article (category_id);
ALTER TABLE Article ADD CONSTRAINT FOREIGN KEY (tag_id) REFERENCES Tag (tag_id);
INSERT INTO Article VALUES ('is', '1234-07-05', 'hahjkhjha');
INSERT INTO Article VALUES ('just', '9102-03-12', 'hjkhj');
INSERT INTO Category VALUES (12342.12443, 'kjhk');
INSERT INTO Category VALUES (632.2, 'to');
INSERT INTO Tag VALUES (121, 'hjkhj');
INSERT INTO Tag VALUES (634, 'hjkkhj');
INSERT INTO User VALUES ('khjkhj', 'fghfg', 'yuiuy');
INSERT INTO User VALUES ('jghgj', 'ghjghjg', 'jghjdf');


