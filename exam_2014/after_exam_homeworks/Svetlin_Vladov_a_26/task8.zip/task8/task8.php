Separate Article on two tables
Article_part1 containing published_on
Article_part2 containing all the other fields
As a result SQL queries+code in other programming language must be create

CREATE TABLE Article(id int, price float, url varchar(50), published_on date, category_id int)

<?php
$table_name = "Article";
$db = new mysqli("localhost", "root", "123", "task8");

$db->query(sprintf("create table %s_part1(id int, published_on date)", $table_name));
$db->query(sprintf("create table %s_part2(id int, price float, url varchar(50), category_id int)", $table_name));

$result = $db->query("select * from " . $table_name);

while($row = $result->fetch_assoc()) {
	$db->query(sprintf("insert into %s_part1 values(%d, '%s')", $table_name, $row["id"], $row["published_on"]));
	$db->query(sprintf("insert into %s_part2 values(%d, %f, '%s', %d)", $table_name, $row["id"], $row["price"], $row["url"], $row["category_id"]));
}

$db->query("drop table " . $table_name);
$db->close();
