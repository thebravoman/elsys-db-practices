-- phpMyAdmin SQL Dump
-- version 3.3.10deb1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Apr 14, 2014 at 01:10 PM
-- Server version: 5.1.62
-- PHP Version: 5.3.5-1ubuntu7.8

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `subd_home2`
--

-- --------------------------------------------------------

--
-- Структура на таблица `article`
--

CREATE TABLE IF NOT EXISTS `article` (
  `id` int(11) DEFAULT NULL,
  `created_on` date DEFAULT NULL,
  `price` float DEFAULT NULL,
  `category_id` int(11) DEFAULT NULL,
  UNIQUE KEY `category_id` (`category_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Схема на данните от таблица `article`
--

INSERT INTO `article` (`id`, `created_on`, `price`, `category_id`) VALUES
(1, '2006-02-02', 1, 1),
(2, '2010-05-05', 2, 2);

-- --------------------------------------------------------

--
-- Структура на таблица `category`
--

CREATE TABLE IF NOT EXISTS `category` (
  `id` int(11) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL,
  `created_by` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Схема на данните от таблица `category`
--

INSERT INTO `category` (`id`, `name`, `created_by`) VALUES
(1, 'cat1', 'first'),
(2, 'cat2', 'second');

-- --------------------------------------------------------

--
-- Структура на таблица `tag`
--

CREATE TABLE IF NOT EXISTS `tag` (
  `id` int(11) DEFAULT NULL,
  `description` varchar(30) DEFAULT NULL,
  `priority` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  UNIQUE KEY `user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Схема на данните от таблица `tag`
--

INSERT INTO `tag` (`id`, `description`, `priority`, `user_id`) VALUES
(1, 'tag1', 1, 1),
(2, 'tag2', 2, 2);

-- --------------------------------------------------------

--
-- Структура на таблица `user_part1`
--

CREATE TABLE IF NOT EXISTS `user_part1` (
  `id` int(11) DEFAULT NULL,
  `name` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Схема на данните от таблица `user_part1`
--

INSERT INTO `user_part1` (`id`, `name`) VALUES
(1, 'Pesho'),
(2, 'Gosho');

-- --------------------------------------------------------

--
-- Структура на таблица `user_part2`
--

CREATE TABLE IF NOT EXISTS `user_part2` (
  `id` int(11) DEFAULT NULL,
  `age` int(11) DEFAULT NULL,
  `income` float DEFAULT NULL,
  `article_id` int(11) DEFAULT NULL,
  UNIQUE KEY `article_id` (`article_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Схема на данните от таблица `user_part2`
--

INSERT INTO `user_part2` (`id`, `age`, `income`, `article_id`) VALUES
(1, 20, 1, 1),
(2, 22, 2, 2);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
