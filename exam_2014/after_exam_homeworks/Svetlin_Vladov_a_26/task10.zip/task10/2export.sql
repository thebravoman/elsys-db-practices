-- phpMyAdmin SQL Dump
-- version 3.3.10deb1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Apr 14, 2014 at 05:01 PM
-- Server version: 5.1.62
-- PHP Version: 5.3.5-1ubuntu7.8

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `subd_home10`
--
-- --------------------------------------------------------

--
-- Table structure for table `article`
--

CREATE TABLE IF NOT EXISTS `article` (
  `id` int(11) DEFAULT NULL,
  `content` longtext,
  `url` varchar(50) DEFAULT NULL,
  `created_on` date DEFAULT NULL,
  `category_id` int(11) DEFAULT NULL,
  UNIQUE KEY `category_id` (`category_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `article`
--

INSERT INTO `article` (`id`, `content`, `url`, `created_on`, `category_id`) VALUES
(1, 'long content', 'dota.com', '2006-02-02', 1),
(2, 'long content', 'dota.com', '2006-02-02', 2);

-- --------------------------------------------------------

--
-- Table structure for table `category_part1`
--

CREATE TABLE IF NOT EXISTS `category_part1` (
  `id` int(11) DEFAULT NULL,
  `created_by` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `category_part1`
--

INSERT INTO `category_part1` (`id`, `created_by`) VALUES
(1, 'name'),
(2, 'name2');

-- --------------------------------------------------------

--
-- Table structure for table `category_part2`
--

CREATE TABLE IF NOT EXISTS `category_part2` (
  `id` int(11) DEFAULT NULL,
  `priority` double DEFAULT NULL,
  `tag_id` int(11) DEFAULT NULL,
  UNIQUE KEY `tag_id` (`tag_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `category_part2`
--

INSERT INTO `category_part2` (`id`, `priority`, `tag_id`) VALUES
(1, 1000000, 1),
(2, 99999999, 2);

-- --------------------------------------------------------

--
-- Table structure for table `tag`
--

CREATE TABLE IF NOT EXISTS `tag` (
  `id` int(11) DEFAULT NULL,
  `name` varchar(50) DEFAULT NULL,
  `second_priority` float DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tag`
--

INSERT INTO `tag` (`id`, `name`, `second_priority`) VALUES
(1, 'name', 1.1),
(2, 'name2', 2.2);

-- --------------------------------------------------------

--
-- Table structure for table `tag_user`
--

CREATE TABLE IF NOT EXISTS `tag_user` (
  `tag_id` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tag_user`
--

INSERT INTO `tag_user` (`tag_id`, `user_id`) VALUES
(1, 1),
(2, 2);

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE IF NOT EXISTS `user` (
  `id` int(11) DEFAULT NULL,
  `age` int(11) DEFAULT NULL,
  `password` varchar(50) DEFAULT NULL,
  `name` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `age`, `password`, `name`) VALUES
(1, 10, '123wessr', 'name'),
(2, 10, '123wessr', 'name2');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
