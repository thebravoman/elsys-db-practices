Separate User on two tables
User_part1 containing created_on
User_part2 containing all the other fields
As a result SQL queries+code in other programming language must be create

CREATE TABLE User(id int, name varchar(50), description longtext, created_on date, article_id int, unique(article_id))

<?php
$table_name = "User";
$db = new mysqli("localhost", "root", "123", "task11");

$db->query(sprintf("create table %s_part1(id int, created_on date)", $table_name));
$db->query(sprintf("create table %s_part2(id int, name varchar(50), description longtext, article_id int, unique(article_id))", $table_name));

$result = $db->query("select * from " . $table_name);

while($row = $result->fetch_assoc()) {
	$db->query(sprintf("insert into %s_part1 values(%d, '%s')", $table_name, $row["id"], $row["created_on"]));
	$db->query(sprintf("insert into %s_part2 values(%d, '%s', '%s', %d)", $table_name, $row["id"], $row["name"], $row["description"], $row["article_id"]));
}

$db->query("drop table " . $table_name);
$db->close();
