

CREATE TABLE `article` (
  `article_id` int(11) NOT NULL AUTO_INCREMENT,
  `url` varchar(200) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL,
  `content` varchar(200) DEFAULT NULL,
  `cat_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`article_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;






CREATE TABLE `category` (
  `category_id` int(11) NOT NULL AUTO_INCREMENT,
  `date_created_on` date DEFAULT NULL,
  `description` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`category_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;






CREATE TABLE `tag` (
  `tag_id` int(11) NOT NULL AUTO_INCREMENT,
  `priority` int(11) DEFAULT NULL,
  `second_priority` float DEFAULT NULL,
  `art_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`tag_id`),
  UNIQUE KEY `art_id` (`art_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;






CREATE TABLE `user` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `picture_url` varchar(200) DEFAULT NULL,
  `password` varchar(20) DEFAULT NULL,
  `income` float DEFAULT NULL,
  `tag_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;




--------------------------------------------------------------------------Sunday 13th of April 2014 10:54:29 AM

CREATE TABLE `article` (
  `article_id` int(11) NOT NULL AUTO_INCREMENT,
  `url` varchar(200) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL,
  `content` varchar(200) DEFAULT NULL,
  `cat_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`article_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO article VALUES("1","pena","GOG","dsfghjk","2");
INSERT INTO article VALUES("2","fghjk","NASKO","asdfghj","1");
INSERT INTO article VALUES("3","cdfvgbhnj","VASIL","qwertyui","3");





CREATE TABLE `category` (
  `category_id` int(11) NOT NULL AUTO_INCREMENT,
  `date_created_on` date DEFAULT NULL,
  `description` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`category_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO category VALUES("1","2012-12-03","Krimi");
INSERT INTO category VALUES("2","2012-05-12","Biznes");
INSERT INTO category VALUES("3","2012-09-02","Sport");





CREATE TABLE `tag` (
  `tag_id` int(11) NOT NULL AUTO_INCREMENT,
  `priority` int(11) DEFAULT NULL,
  `second_priority` float DEFAULT NULL,
  `art_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`tag_id`),
  UNIQUE KEY `art_id` (`art_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO tag VALUES("1","19","2.15","1");
INSERT INTO tag VALUES("2","22","1.89","2");
INSERT INTO tag VALUES("3","312","6.45","3");





CREATE TABLE `user` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `picture_url` varchar(200) DEFAULT NULL,
  `password` varchar(20) DEFAULT NULL,
  `income` float DEFAULT NULL,
  `tag_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

INSERT INTO user VALUES("1","gfhjk","31312531321","1.25","1");
INSERT INTO user VALUES("2","grdthfyukj","56431321","1.9","2");



--------------------------------------------------------------------------Sunday 13th of April 2014 10:58:52 AM

CREATE TABLE `article` (
  `article_id` int(11) NOT NULL AUTO_INCREMENT,
  `url` varchar(200) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL,
  `content` varchar(200) DEFAULT NULL,
  `cat_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`article_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO article VALUES("1","pena","GOG","dsfghjk","2");
INSERT INTO article VALUES("2","fghjk","NASKO","asdfghj","1");
INSERT INTO article VALUES("3","cdfvgbhnj","VASIL","qwertyui","3");





CREATE TABLE `category` (
  `category_id` int(11) NOT NULL AUTO_INCREMENT,
  `date_created_on` date DEFAULT NULL,
  `description` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`category_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO category VALUES("1","2012-12-03","Krimi");
INSERT INTO category VALUES("2","2012-05-12","Biznes");
INSERT INTO category VALUES("3","2012-09-02","Sport");





CREATE TABLE `tag` (
  `tag_id` int(11) NOT NULL AUTO_INCREMENT,
  `priority` int(11) DEFAULT NULL,
  `second_priority` float DEFAULT NULL,
  `art_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`tag_id`),
  UNIQUE KEY `art_id` (`art_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO tag VALUES("1","19","2.15","1");
INSERT INTO tag VALUES("2","22","1.89","2");
INSERT INTO tag VALUES("3","312","6.45","3");





CREATE TABLE `user` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `picture_url` varchar(200) DEFAULT NULL,
  `password` varchar(20) DEFAULT NULL,
  `income` float DEFAULT NULL,
  `tag_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

INSERT INTO user VALUES("1","gfhjk","31312531321","1.25","1");
INSERT INTO user VALUES("2","grdthfyukj","56431321","1.9","2");



--------------------------------------------------------------------------Sunday 13th of April 2014 11:01:06 AM

CREATE TABLE `article` (
  `article_id` int(11) NOT NULL AUTO_INCREMENT,
  `url` varchar(200) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL,
  `content` varchar(200) DEFAULT NULL,
  `cat_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`article_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO article VALUES("1","pena","GOG","dsfghjk","2");
INSERT INTO article VALUES("2","fghjk","NASKO","asdfghj","1");
INSERT INTO article VALUES("3","cdfvgbhnj","VASIL","qwertyui","3");





CREATE TABLE `category` (
  `category_id` int(11) NOT NULL AUTO_INCREMENT,
  `date_created_on` date DEFAULT NULL,
  `description` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`category_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO category VALUES("1","2012-12-03","Krimi");
INSERT INTO category VALUES("2","2012-05-12","Biznes");
INSERT INTO category VALUES("3","2012-09-02","Sport");





CREATE TABLE `tag_part1` (
  `tag1_id` int(11) NOT NULL AUTO_INCREMENT,
  `second_priority` float DEFAULT NULL,
  PRIMARY KEY (`tag1_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO tag_part1 VALUES("1","2.15");
INSERT INTO tag_part1 VALUES("2","1.89");
INSERT INTO tag_part1 VALUES("3","6.45");





CREATE TABLE `tag_part2` (
  `tag_id` int(11) NOT NULL AUTO_INCREMENT,
  `priority` int(11) DEFAULT NULL,
  `art_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`tag_id`),
  UNIQUE KEY `art_id` (`art_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO tag_part2 VALUES("1","19","1");
INSERT INTO tag_part2 VALUES("2","22","2");
INSERT INTO tag_part2 VALUES("3","312","3");





CREATE TABLE `user` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `picture_url` varchar(200) DEFAULT NULL,
  `password` varchar(20) DEFAULT NULL,
  `income` float DEFAULT NULL,
  `tag_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

INSERT INTO user VALUES("1","gfhjk","31312531321","1.25","1");
INSERT INTO user VALUES("2","grdthfyukj","56431321","1.9","2");



--------------------------------------------------------------------------Sunday 13th of April 2014 11:03:25 AM

CREATE TABLE `article` (
  `article_id` int(11) NOT NULL AUTO_INCREMENT,
  `url` varchar(200) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL,
  `content` varchar(200) DEFAULT NULL,
  `cat_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`article_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO article VALUES("1","pena","GOG","dsfghjk","2");
INSERT INTO article VALUES("2","fghjk","NASKO","asdfghj","1");
INSERT INTO article VALUES("3","cdfvgbhnj","VASIL","qwertyui","3");





CREATE TABLE `category` (
  `category_id` int(11) NOT NULL AUTO_INCREMENT,
  `date_created_on` date DEFAULT NULL,
  `description` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`category_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO category VALUES("1","2012-12-03","Krimi");
INSERT INTO category VALUES("2","2012-05-12","Biznes");
INSERT INTO category VALUES("3","2012-09-02","Sport");





CREATE TABLE `tag_part1` (
  `tag1_id` int(11) NOT NULL AUTO_INCREMENT,
  `second_priority` float DEFAULT NULL,
  PRIMARY KEY (`tag1_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO tag_part1 VALUES("1","2.15");
INSERT INTO tag_part1 VALUES("2","1.89");
INSERT INTO tag_part1 VALUES("3","6.45");





CREATE TABLE `tag_part2` (
  `tag_id` int(11) NOT NULL AUTO_INCREMENT,
  `priority` int(11) DEFAULT NULL,
  `art_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`tag_id`),
  UNIQUE KEY `art_id` (`art_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO tag_part2 VALUES("1","19","1");
INSERT INTO tag_part2 VALUES("2","22","2");
INSERT INTO tag_part2 VALUES("3","312","3");





CREATE TABLE `user` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `picture_url` varchar(200) DEFAULT NULL,
  `password` varchar(20) DEFAULT NULL,
  `income` float DEFAULT NULL,
  `tag_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

INSERT INTO user VALUES("1","gfhjk","31312531321","1.25","1");
INSERT INTO user VALUES("2","grdthfyukj","56431321","1.9","2");



--------------------------------------------------------------------------Sunday 13th of April 2014 11:06:18 AM