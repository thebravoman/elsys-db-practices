

CREATE TABLE `article` (
  `article_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(20) DEFAULT NULL,
  `created_on` date DEFAULT NULL,
  `price` varchar(20) DEFAULT NULL,
  `tag_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`article_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO article VALUES("1","KON","2012-02-01","5","1");
INSERT INTO article VALUES("2","SOPOL","2012-02-01","5.04","2");
INSERT INTO article VALUES("3","KRAVA","2012-02-01","5.04","3");





CREATE TABLE `cat_tag` (
  `cat_id` int(11) DEFAULT NULL,
  `tag_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO cat_tag VALUES("1","2");
INSERT INTO cat_tag VALUES("1","3");
INSERT INTO cat_tag VALUES("2","1");





CREATE TABLE `category` (
  `category_id` int(11) NOT NULL AUTO_INCREMENT,
  `date_created_on` date DEFAULT NULL,
  `priority` double DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`category_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO category VALUES("1","2012-12-03","1.5","3");
INSERT INTO category VALUES("2","2012-05-12","1.26","1");
INSERT INTO category VALUES("3","2012-09-02","1.05","2");





CREATE TABLE `tag_part1` (
  `tag1_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` double DEFAULT NULL,
  PRIMARY KEY (`tag1_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO tag_part1 VALUES("1","0");
INSERT INTO tag_part1 VALUES("2","0");
INSERT INTO tag_part1 VALUES("3","0");





CREATE TABLE `tag_part2` (
  `tag_id` int(11) NOT NULL AUTO_INCREMENT,
  `priority` int(11) DEFAULT NULL,
  PRIMARY KEY (`tag_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO tag_part2 VALUES("1","28");
INSERT INTO tag_part2 VALUES("2","26");
INSERT INTO tag_part2 VALUES("3","92");





CREATE TABLE `user` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `password` varchar(20) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL,
  `age` int(11) DEFAULT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

INSERT INTO user VALUES("1","gfhjk","GOGO","21");
INSERT INTO user VALUES("2","grdthfyukj","PACO","152");



--------------------------------------------------------------------------Sunday 13th of April 2014 06:05:56 PM

CREATE TABLE `article` (
  `article_id` int(11) NOT NULL AUTO_INCREMENT,
  `content` varchar(220) DEFAULT NULL,
  `url` varchar(30) DEFAULT NULL,
  `price` varchar(30) DEFAULT NULL,
  `tag_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`article_id`),
  UNIQUE KEY `tag_id` (`tag_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;






CREATE TABLE `category` (
  `category_id` int(11) NOT NULL AUTO_INCREMENT,
  `priority` double DEFAULT NULL,
  `date_created_on` date DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`category_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;






CREATE TABLE `tag` (
  `tag_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) DEFAULT NULL,
  `description` varchar(120) DEFAULT NULL,
  PRIMARY KEY (`tag_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;






CREATE TABLE `user` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `picture_url` varchar(30) DEFAULT NULL,
  `age` int(11) DEFAULT NULL,
  `description` varchar(120) DEFAULT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;






CREATE TABLE `user_tag` (
  `user_id` int(11) DEFAULT NULL,
  `tag_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;




--------------------------------------------------------------------------Sunday 13th of April 2014 06:11:49 PM

CREATE TABLE `article` (
  `article_id` int(11) NOT NULL AUTO_INCREMENT,
  `content` varchar(220) DEFAULT NULL,
  `url` varchar(30) DEFAULT NULL,
  `price` varchar(30) DEFAULT NULL,
  `tag_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`article_id`),
  UNIQUE KEY `tag_id` (`tag_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;






CREATE TABLE `category` (
  `category_id` int(11) NOT NULL AUTO_INCREMENT,
  `priority` double DEFAULT NULL,
  `date_created_on` date DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`category_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;






CREATE TABLE `tag` (
  `tag_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) DEFAULT NULL,
  `description` varchar(120) DEFAULT NULL,
  PRIMARY KEY (`tag_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;






CREATE TABLE `user` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `picture_url` varchar(30) DEFAULT NULL,
  `age` int(11) DEFAULT NULL,
  `description` varchar(120) DEFAULT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;






CREATE TABLE `user_tag` (
  `user_id` int(11) DEFAULT NULL,
  `tag_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;




--------------------------------------------------------------------------Sunday 13th of April 2014 06:12:22 PM

CREATE TABLE `article` (
  `article_id` int(11) NOT NULL AUTO_INCREMENT,
  `content` varchar(220) DEFAULT NULL,
  `url` varchar(30) DEFAULT NULL,
  `price` varchar(30) DEFAULT NULL,
  `tag_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`article_id`),
  UNIQUE KEY `tag_id` (`tag_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO article VALUES("1","KON","dfghj","5","1");
INSERT INTO article VALUES("2","SOPOL","dfghj","5.04","2");
INSERT INTO article VALUES("3","KRAVA","dfghj","5.04","3");





CREATE TABLE `category` (
  `category_id` int(11) NOT NULL AUTO_INCREMENT,
  `priority` double DEFAULT NULL,
  `date_created_on` date DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`category_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO category VALUES("1","9.06","2012-12-03","3");
INSERT INTO category VALUES("2","3.05","2012-05-12","1");
INSERT INTO category VALUES("3","1.02","2012-09-02","2");





CREATE TABLE `tag` (
  `tag_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) DEFAULT NULL,
  `description` varchar(120) DEFAULT NULL,
  PRIMARY KEY (`tag_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO tag VALUES("1","fghj","kon");
INSERT INTO tag VALUES("2","gfhj","sopol");
INSERT INTO tag VALUES("3","fghjk","gevrek");





CREATE TABLE `user` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `picture_url` varchar(30) DEFAULT NULL,
  `age` int(11) DEFAULT NULL,
  `description` varchar(120) DEFAULT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO user VALUES("1","gfhjk","21","GOGO");
INSERT INTO user VALUES("2","grdthfyukj","21","PACO");
INSERT INTO user VALUES("3","rteyuio","21","NASKO");





CREATE TABLE `user_tag` (
  `user_id` int(11) DEFAULT NULL,
  `tag_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;




--------------------------------------------------------------------------Sunday 13th of April 2014 06:23:56 PM

CREATE TABLE `article` (
  `article_id` int(11) NOT NULL AUTO_INCREMENT,
  `content` varchar(220) DEFAULT NULL,
  `url` varchar(30) DEFAULT NULL,
  `price` varchar(30) DEFAULT NULL,
  `tag_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`article_id`),
  UNIQUE KEY `tag_id` (`tag_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO article VALUES("1","KON","dfghj","5","1");
INSERT INTO article VALUES("2","SOPOL","dfghj","5.04","2");
INSERT INTO article VALUES("3","KRAVA","dfghj","5.04","3");





CREATE TABLE `category` (
  `category_id` int(11) NOT NULL AUTO_INCREMENT,
  `priority` double DEFAULT NULL,
  `date_created_on` date DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`category_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO category VALUES("1","9.06","2012-12-03","3");
INSERT INTO category VALUES("2","3.05","2012-05-12","1");
INSERT INTO category VALUES("3","1.02","2012-09-02","2");





CREATE TABLE `tag` (
  `tag_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) DEFAULT NULL,
  `description` varchar(120) DEFAULT NULL,
  PRIMARY KEY (`tag_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO tag VALUES("1","fghj","kon");
INSERT INTO tag VALUES("2","gfhj","sopol");
INSERT INTO tag VALUES("3","fghjk","gevrek");





CREATE TABLE `user` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `picture_url` varchar(30) DEFAULT NULL,
  `age` int(11) DEFAULT NULL,
  `description` varchar(120) DEFAULT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO user VALUES("1","gfhjk","21","GOGO");
INSERT INTO user VALUES("2","grdthfyukj","21","PACO");
INSERT INTO user VALUES("3","rteyuio","21","NASKO");





CREATE TABLE `user_tag` (
  `user_id` int(11) DEFAULT NULL,
  `tag_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO user_tag VALUES("1","2");
INSERT INTO user_tag VALUES("1","3");
INSERT INTO user_tag VALUES("2","1");



--------------------------------------------------------------------------Sunday 13th of April 2014 06:26:37 PM

CREATE TABLE `article` (
  `article_id` int(11) NOT NULL AUTO_INCREMENT,
  `content` varchar(220) DEFAULT NULL,
  `url` varchar(30) DEFAULT NULL,
  `price` varchar(30) DEFAULT NULL,
  `tag_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`article_id`),
  UNIQUE KEY `tag_id` (`tag_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO article VALUES("1","KON","dfghj","5","1");
INSERT INTO article VALUES("2","SOPOL","dfghj","5.04","2");
INSERT INTO article VALUES("3","KRAVA","dfghj","5.04","3");





CREATE TABLE `category` (
  `category_id` int(11) NOT NULL AUTO_INCREMENT,
  `priority` double DEFAULT NULL,
  `date_created_on` date DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`category_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO category VALUES("1","9.06","2012-12-03","3");
INSERT INTO category VALUES("2","3.05","2012-05-12","1");
INSERT INTO category VALUES("3","1.02","2012-09-02","2");





CREATE TABLE `tag` (
  `tag_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) DEFAULT NULL,
  `description` varchar(120) DEFAULT NULL,
  PRIMARY KEY (`tag_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO tag VALUES("1","fghj","kon");
INSERT INTO tag VALUES("2","gfhj","sopol");
INSERT INTO tag VALUES("3","fghjk","gevrek");





CREATE TABLE `user` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `picture_url` varchar(30) DEFAULT NULL,
  `age` int(11) DEFAULT NULL,
  `description` varchar(120) DEFAULT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO user VALUES("1","gfhjk","21","GOGO");
INSERT INTO user VALUES("2","grdthfyukj","21","PACO");
INSERT INTO user VALUES("3","rteyuio","21","NASKO");





CREATE TABLE `user_tag` (
  `user_id` int(11) DEFAULT NULL,
  `tag_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO user_tag VALUES("1","2");
INSERT INTO user_tag VALUES("1","3");
INSERT INTO user_tag VALUES("2","1");



--------------------------------------------------------------------------Sunday 13th of April 2014 06:35:00 PM

CREATE TABLE `article` (
  `article_id` int(11) NOT NULL AUTO_INCREMENT,
  `content` varchar(220) DEFAULT NULL,
  `url` varchar(30) DEFAULT NULL,
  `price` varchar(30) DEFAULT NULL,
  `tag_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`article_id`),
  UNIQUE KEY `tag_id` (`tag_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO article VALUES("1","KON","dfghj","5","1");
INSERT INTO article VALUES("2","SOPOL","dfghj","5.04","2");
INSERT INTO article VALUES("3","KRAVA","dfghj","5.04","3");





CREATE TABLE `category` (
  `category_id` int(11) NOT NULL AUTO_INCREMENT,
  `priority` double DEFAULT NULL,
  `date_created_on` date DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`category_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO category VALUES("1","9.06","2012-12-03","3");
INSERT INTO category VALUES("2","3.05","2012-05-12","1");
INSERT INTO category VALUES("3","1.02","2012-09-02","2");





CREATE TABLE `tag_part1` (
  `tag1_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` double DEFAULT NULL,
  PRIMARY KEY (`tag1_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO tag_part1 VALUES("1","0");
INSERT INTO tag_part1 VALUES("2","0");
INSERT INTO tag_part1 VALUES("3","0");





CREATE TABLE `tag_part2` (
  `tag_id` int(11) NOT NULL AUTO_INCREMENT,
  `description` varchar(120) DEFAULT NULL,
  PRIMARY KEY (`tag_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO tag_part2 VALUES("1","kon");
INSERT INTO tag_part2 VALUES("2","sopol");
INSERT INTO tag_part2 VALUES("3","gevrek");





CREATE TABLE `user` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `picture_url` varchar(30) DEFAULT NULL,
  `age` int(11) DEFAULT NULL,
  `description` varchar(120) DEFAULT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO user VALUES("1","gfhjk","21","GOGO");
INSERT INTO user VALUES("2","grdthfyukj","21","PACO");
INSERT INTO user VALUES("3","rteyuio","21","NASKO");





CREATE TABLE `user_tag` (
  `user_id` int(11) DEFAULT NULL,
  `tag_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO user_tag VALUES("1","2");
INSERT INTO user_tag VALUES("1","3");
INSERT INTO user_tag VALUES("2","1");



--------------------------------------------------------------------------Sunday 13th of April 2014 06:38:04 PM

CREATE TABLE `article` (
  `article_id` int(11) NOT NULL AUTO_INCREMENT,
  `content` varchar(220) DEFAULT NULL,
  `url` varchar(30) DEFAULT NULL,
  `price` varchar(30) DEFAULT NULL,
  `tag_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`article_id`),
  UNIQUE KEY `tag_id` (`tag_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO article VALUES("1","KON","dfghj","5","1");
INSERT INTO article VALUES("2","SOPOL","dfghj","5.04","2");
INSERT INTO article VALUES("3","KRAVA","dfghj","5.04","3");





CREATE TABLE `category` (
  `category_id` int(11) NOT NULL AUTO_INCREMENT,
  `priority` double DEFAULT NULL,
  `date_created_on` date DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`category_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO category VALUES("1","9.06","2012-12-03","3");
INSERT INTO category VALUES("2","3.05","2012-05-12","1");
INSERT INTO category VALUES("3","1.02","2012-09-02","2");





CREATE TABLE `tag_part1` (
  `tag1_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` double DEFAULT NULL,
  PRIMARY KEY (`tag1_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO tag_part1 VALUES("1","0");
INSERT INTO tag_part1 VALUES("2","0");
INSERT INTO tag_part1 VALUES("3","0");





CREATE TABLE `tag_part2` (
  `tag_id` int(11) NOT NULL AUTO_INCREMENT,
  `description` varchar(120) DEFAULT NULL,
  PRIMARY KEY (`tag_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO tag_part2 VALUES("1","kon");
INSERT INTO tag_part2 VALUES("2","sopol");
INSERT INTO tag_part2 VALUES("3","gevrek");





CREATE TABLE `user` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `picture_url` varchar(30) DEFAULT NULL,
  `age` int(11) DEFAULT NULL,
  `description` varchar(120) DEFAULT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO user VALUES("1","gfhjk","21","GOGO");
INSERT INTO user VALUES("2","grdthfyukj","21","PACO");
INSERT INTO user VALUES("3","rteyuio","21","NASKO");





CREATE TABLE `user_tag` (
  `user_id` int(11) DEFAULT NULL,
  `tag_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO user_tag VALUES("1","2");
INSERT INTO user_tag VALUES("1","3");
INSERT INTO user_tag VALUES("2","1");



--------------------------------------------------------------------------Sunday 13th of April 2014 06:48:38 PM