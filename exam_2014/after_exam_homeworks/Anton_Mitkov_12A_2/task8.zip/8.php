
<!DOCTYPE html>
<html>
<head>
	<title>Anton Mitkov</title>
</head>
<body>
	Hello  <br/> &nbsp;&nbsp;&nbsp; Anton Mitkov 12 A, number in class 2 <br/>
	<br/><br/><br/>

<h3>Tips:</h3></br>
	sub_exam_backup1_1.sql - backup for the first part of the exam</br>
	sub_exam_backup1_2.sql - backup for the second part of the exam</br>

	If you refresh the page at the bottom of the file you'll see the changes and the time they are made.</br>
	It is possible when you refreshed the page to have an error with first answer because you change the database</br>
	and it affects on the result.</br></br>

<?php
	mysql_connect("localhost", "root","") or die(mysql_error());

/* Create table, ones I create table i shoud comment that line and uncoment the "mysql_selecet_db" line to connect */
		//mysql_query("CREATE DATABASE subd8") or die(mysql_error());

/*Select the database that was created*/
		mysql_select_db("subd8") or die(mysql_error());


/* That's how I create the tables*/
	 // 	mysql_query("CREATE TABLE Article (
		// 	  article_id INT AUTO_INCREMENT,
		// 	 	 content VARCHAR(220),
		// 	 	 url VARCHAR(30),
		// 	 	 price VARCHAR(30),
		// 	 	 tag_id INT UNIQUE,
		// 	  PRIMARY KEY(article_id))") Or die(mysql_error());

		// mysql_query("CREATE TABLE Category (
		// 	  category_id INT AUTO_INCREMENT,
		// 	  priority DOUBLE,
		// 	  date_created_on DATE,
		// 	  user_id INT,
		// 	  PRIMARY KEY(category_id))") Or die(mysql_error());

		// mysql_query("CREATE TABLE User (
		// 	  user_id INT AUTO_INCREMENT,
		// 	  picture_url VARCHAR(30),
		// 	  age INT,
		// 	  description VARCHAR(120),
		// 	  PRIMARY KEY(user_id))") Or die(mysql_error());

		// mysql_query("CREATE TABLE Tag (
		// 	  tag_id INT AUTO_INCREMENT,
		// 	  name VARCHAR(50),
		// 	  description VARCHAR(120),
		// 	  PRIMARY KEY(tag_id))") Or die(mysql_error());

		// mysql_query("CREATE TABLE User_tag (
		// 	  user_id INT,
		// 	  tag_id INT
		// 	  )") Or die(mysql_error());
		


/*INSERTIN SHITS*/
		// mysql_query("INSERT INTO Article( content, url, price, tag_id) VALUES ('KON','dfghj','5',1)");
		// mysql_query("INSERT INTO Article( content, url, price, tag_id) VALUES ('SOPOL','dfghj','5.04',2)");
		// mysql_query("INSERT INTO Article( content, url, price, tag_id) VALUES ('KRAVA','dfghj','5.04',3)");

		// mysql_query("INSERT INTO Category(  priority, date_created_on, user_id) VALUES ('9.06','2012-12-03',3)");
		// mysql_query("INSERT INTO Category(  priority, date_created_on, user_id) VALUES ('3.05','2012-05-12',1)");
		// mysql_query("INSERT INTO Category(  priority, date_created_on, user_id) VALUES ('1.02','2012-09-02',2)");

		// mysql_query("INSERT INTO USER(picture_url, age, description) VALUES ('gfhjk',21,'GOGO')");
		// mysql_query("INSERT INTO USER(picture_url, age, description) VALUES ('grdthfyukj',21,'PACO')");
		// mysql_query("INSERT INTO USER(picture_url, age, description) VALUES ('rteyuio',21,'NASKO')");

		// mysql_query("INSERT INTO tag(name, description) VALUES ('fghj','kon')");
		// mysql_query("INSERT INTO tag(name, description) VALUES ('gfhj','sopol')");
		// mysql_query("INSERT INTO tag(name, description) VALUES ('fghjk','gevrek')");

		// mysql_query("INSERT INTO User_tag( user_id, tag_id) VALUES (1,2)");
		// mysql_query("INSERT INTO User_tag( user_id, tag_id) VALUES (1,3)");
		// mysql_query("INSERT INTO User_tag( user_id, tag_id) VALUES (2,1)");



/*Which are the User(s) for a given Article -> user user_tag art*/


		// $pena =  mysql_query("SELECT * FROM User INNER JOIN user_tag ON User.user_id = user_tag.user_id
		// 	 INNER JOIN Article ON User_tag.tag_id = Article.tag_id 
		// 	  WHERE Article.article_id = 2");

		//   ?> THE ANSWER OF THE FIRST QUESTION IS : <br/><?php
		// while($row = mysql_fetch_array($pena)){
		// 	echo $row["article_id"];		
		// 	echo $row["tag_id"];
		// 	echo $row["user_id"];


		// 	?> <br/> <?php
		// }

/*Call the function that export the database*/
		backup_tables('localhost','root','subd8','sub_exam_backup2');	

/*Migration*/
		// mysql_query(" CREATE TABLE Tag_part1 (
		// 	tag1_id INT AUTO_INCREMENT,
		// 	name DOUBLE,
		// 	PRIMARY KEY(tag1_id))") Or die(mysql_error());

		// mysql_query("INSERT INTO Tag_part1 (name) SELECT name FROM Tag");
		// mysql_query("ALTER TABLE Tag DROP name");
		// mysql_query("ALTER TABLE Tag RENAME TO Tag_part2");

/*Secon of export the database*/
		backup_tables('localhost','root','subd8','sub_exam_backup2_1');

/*Which are the Category(s) for a given Tag - >cat user User_tag tag1*/

			$kon =  mysql_query("SELECT * FROM User_tag INNER JOIN Category ON User_tag.user_id = Category.user_id 
			  INNER JOIN Tag_part2 ON User_tag.tag_id = Tag_part2.tag_id 
			 WHERE Tag_part2.tag_id = 2");	 

		  ?><br/><br/><br/> THE ANSWER OF THE SECOND QUESTION IS : <br/><?php
		while($row2 = mysql_fetch_array($kon)){
			echo $row2["tag_id"];		
			echo $row2["category_id"];
			echo $row2["user_id"];


			?> <br/> <?php
		}

?>
</body>
</html>


<?php

	
/* backup the db OR just a table */
function backup_tables($host,$user,$name,$place,$tables = '*')
{
	
	$link = mysql_connect($host,$user,"");
	mysql_select_db($name,$link);
	
	//get all of the tables
	if($tables == '*')
	{
		$tables = array();
		$result = mysql_query('SHOW TABLES');
		//var_dump($result);
		while($row = mysql_fetch_row($result))
		{
			$tables[] = $row[0];
		}
	}
	else
	{
		$tables = is_array($tables) ? $tables : explode(',',$tables);
	}
	

	//cycle through
	foreach($tables as $table)
	{
		$result = mysql_query('SELECT * FROM '.$table);
		$num_fields = mysql_num_fields($result);
		
		$return = 'DROP TABLE '.$table.';';
		$row2 = mysql_fetch_row(mysql_query('SHOW CREATE TABLE '.$table));
		$return = "\n\n".$row2[1].";\n\n";
		
		for ($i = 0; $i < $num_fields; $i++) 
		{
			while($row = mysql_fetch_row($result))
			{
				$return.= 'INSERT INTO '.$table.' VALUES(';
				for($j=0; $j<$num_fields; $j++) 
				{
					$row[$j] = addslashes($row[$j]);
					$row[$j] = ereg_replace("\n","\\n",$row[$j]);
					if (isset($row[$j])) { $return.= '"'.$row[$j].'"' ; } else { $return.= '""'; }
					if ($j<($num_fields-1)) { $return.= ','; }
				}
				$return.= ");\n";
			}
		}
		$return.="\n\n\n";

	$handle = fopen($place.'.sql','a+');
	fwrite($handle,$return);

	}
	fwrite($handle,"--------------------------------------------------------------------------".date('l jS \of F Y h:i:s A'));
	fclose($handle);
}
?>