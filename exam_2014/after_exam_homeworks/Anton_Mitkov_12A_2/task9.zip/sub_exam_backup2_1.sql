

CREATE TABLE `article` (
  `article_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(220) DEFAULT NULL,
  `published_on` date DEFAULT NULL,
  `url` varchar(200) DEFAULT NULL,
  `cat_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`article_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO article VALUES("1","KON","2012-12-03","sacsd","1");
INSERT INTO article VALUES("2","SOPOL","2012-12-03","gvhbjn","2");
INSERT INTO article VALUES("3","KRAVA","2012-12-03","qwerty","3");





CREATE TABLE `cat_tag` (
  `cat_id` int(11) DEFAULT NULL,
  `tag_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO cat_tag VALUES("1","1");
INSERT INTO cat_tag VALUES("2","2");
INSERT INTO cat_tag VALUES("3","3");





CREATE TABLE `category` (
  `category_id` int(11) NOT NULL AUTO_INCREMENT,
  `created_by` varchar(120) DEFAULT NULL,
  `date_created_on` date DEFAULT NULL,
  PRIMARY KEY (`category_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO category VALUES("1","user1","2012-12-03");
INSERT INTO category VALUES("2","user2","2012-12-03");
INSERT INTO category VALUES("3","user3","2012-12-03");





CREATE TABLE `tag` (
  `tag_id` int(11) NOT NULL AUTO_INCREMENT,
  `description` varchar(120) DEFAULT NULL,
  `priority` int(11) DEFAULT NULL,
  PRIMARY KEY (`tag_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO tag VALUES("1","fghj","2");
INSERT INTO tag VALUES("2","gfhj","9");
INSERT INTO tag VALUES("3","fghjk","5");





CREATE TABLE `tag_user` (
  `tag_id` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO tag_user VALUES("3","1");
INSERT INTO tag_user VALUES("1","3");
INSERT INTO tag_user VALUES("2","2");





CREATE TABLE `user` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `income` float DEFAULT NULL,
  `age` int(11) DEFAULT NULL,
  `created_on` date DEFAULT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO user VALUES("1","1.06","21","2012-12-03");
INSERT INTO user VALUES("2","9.03","21","2012-12-03");
INSERT INTO user VALUES("3","10.8","21","2012-12-03");



--------------------------------------------------------------------------Sunday 13th of April 2014 08:23:55 PM

CREATE TABLE `article` (
  `article_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(220) DEFAULT NULL,
  `published_on` date DEFAULT NULL,
  `url` varchar(200) DEFAULT NULL,
  `cat_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`article_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO article VALUES("1","KON","2012-12-03","sacsd","1");
INSERT INTO article VALUES("2","SOPOL","2012-12-03","gvhbjn","2");
INSERT INTO article VALUES("3","KRAVA","2012-12-03","qwerty","3");





CREATE TABLE `cat_tag` (
  `cat_id` int(11) DEFAULT NULL,
  `tag_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO cat_tag VALUES("1","1");
INSERT INTO cat_tag VALUES("2","2");
INSERT INTO cat_tag VALUES("3","3");





CREATE TABLE `category` (
  `category_id` int(11) NOT NULL AUTO_INCREMENT,
  `created_by` varchar(120) DEFAULT NULL,
  `date_created_on` date DEFAULT NULL,
  PRIMARY KEY (`category_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO category VALUES("1","user1","2012-12-03");
INSERT INTO category VALUES("2","user2","2012-12-03");
INSERT INTO category VALUES("3","user3","2012-12-03");





CREATE TABLE `tag` (
  `tag_id` int(11) NOT NULL AUTO_INCREMENT,
  `description` varchar(120) DEFAULT NULL,
  `priority` int(11) DEFAULT NULL,
  PRIMARY KEY (`tag_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO tag VALUES("1","fghj","2");
INSERT INTO tag VALUES("2","gfhj","9");
INSERT INTO tag VALUES("3","fghjk","5");





CREATE TABLE `tag_user` (
  `tag_id` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO tag_user VALUES("3","1");
INSERT INTO tag_user VALUES("1","3");
INSERT INTO tag_user VALUES("2","2");





CREATE TABLE `user` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `income` float DEFAULT NULL,
  `age` int(11) DEFAULT NULL,
  `created_on` date DEFAULT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO user VALUES("1","1.06","21","2012-12-03");
INSERT INTO user VALUES("2","9.03","21","2012-12-03");
INSERT INTO user VALUES("3","10.8","21","2012-12-03");



--------------------------------------------------------------------------Sunday 13th of April 2014 08:27:34 PM

CREATE TABLE `article` (
  `article_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(220) DEFAULT NULL,
  `published_on` date DEFAULT NULL,
  `url` varchar(200) DEFAULT NULL,
  `cat_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`article_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO article VALUES("1","KON","2012-12-03","sacsd","1");
INSERT INTO article VALUES("2","SOPOL","2012-12-03","gvhbjn","2");
INSERT INTO article VALUES("3","KRAVA","2012-12-03","qwerty","3");





CREATE TABLE `cat_tag` (
  `cat_id` int(11) DEFAULT NULL,
  `tag_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO cat_tag VALUES("1","1");
INSERT INTO cat_tag VALUES("2","2");
INSERT INTO cat_tag VALUES("3","3");





CREATE TABLE `category` (
  `category_id` int(11) NOT NULL AUTO_INCREMENT,
  `created_by` varchar(120) DEFAULT NULL,
  `date_created_on` date DEFAULT NULL,
  PRIMARY KEY (`category_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO category VALUES("1","user1","2012-12-03");
INSERT INTO category VALUES("2","user2","2012-12-03");
INSERT INTO category VALUES("3","user3","2012-12-03");





CREATE TABLE `tag` (
  `tag_id` int(11) NOT NULL AUTO_INCREMENT,
  `description` varchar(120) DEFAULT NULL,
  `priority` int(11) DEFAULT NULL,
  PRIMARY KEY (`tag_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO tag VALUES("1","fghj","2");
INSERT INTO tag VALUES("2","gfhj","9");
INSERT INTO tag VALUES("3","fghjk","5");





CREATE TABLE `tag_user` (
  `tag_id` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO tag_user VALUES("3","1");
INSERT INTO tag_user VALUES("1","3");
INSERT INTO tag_user VALUES("2","2");





CREATE TABLE `user` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `income` float DEFAULT NULL,
  `age` int(11) DEFAULT NULL,
  `created_on` date DEFAULT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO user VALUES("1","1.06","21","2012-12-03");
INSERT INTO user VALUES("2","9.03","21","2012-12-03");
INSERT INTO user VALUES("3","10.8","21","2012-12-03");



--------------------------------------------------------------------------Sunday 13th of April 2014 08:30:55 PM

CREATE TABLE `article` (
  `article_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(220) DEFAULT NULL,
  `published_on` date DEFAULT NULL,
  `url` varchar(200) DEFAULT NULL,
  `cat_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`article_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO article VALUES("1","KON","2012-12-03","sacsd","1");
INSERT INTO article VALUES("2","SOPOL","2012-12-03","gvhbjn","2");
INSERT INTO article VALUES("3","KRAVA","2012-12-03","qwerty","3");





CREATE TABLE `cat_tag` (
  `cat_id` int(11) DEFAULT NULL,
  `tag_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO cat_tag VALUES("1","1");
INSERT INTO cat_tag VALUES("2","2");
INSERT INTO cat_tag VALUES("3","3");





CREATE TABLE `category_part1` (
  `cat1_id` int(11) NOT NULL AUTO_INCREMENT,
  `created_by` double DEFAULT NULL,
  PRIMARY KEY (`cat1_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO category_part1 VALUES("1","0");
INSERT INTO category_part1 VALUES("2","0");
INSERT INTO category_part1 VALUES("3","0");





CREATE TABLE `category_part2` (
  `category_id` int(11) NOT NULL AUTO_INCREMENT,
  `date_created_on` date DEFAULT NULL,
  PRIMARY KEY (`category_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO category_part2 VALUES("1","2012-12-03");
INSERT INTO category_part2 VALUES("2","2012-12-03");
INSERT INTO category_part2 VALUES("3","2012-12-03");





CREATE TABLE `tag` (
  `tag_id` int(11) NOT NULL AUTO_INCREMENT,
  `description` varchar(120) DEFAULT NULL,
  `priority` int(11) DEFAULT NULL,
  PRIMARY KEY (`tag_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO tag VALUES("1","fghj","2");
INSERT INTO tag VALUES("2","gfhj","9");
INSERT INTO tag VALUES("3","fghjk","5");





CREATE TABLE `tag_user` (
  `tag_id` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO tag_user VALUES("3","1");
INSERT INTO tag_user VALUES("1","3");
INSERT INTO tag_user VALUES("2","2");





CREATE TABLE `user` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `income` float DEFAULT NULL,
  `age` int(11) DEFAULT NULL,
  `created_on` date DEFAULT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO user VALUES("1","1.06","21","2012-12-03");
INSERT INTO user VALUES("2","9.03","21","2012-12-03");
INSERT INTO user VALUES("3","10.8","21","2012-12-03");



--------------------------------------------------------------------------Sunday 13th of April 2014 08:32:43 PM

CREATE TABLE `article` (
  `article_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(220) DEFAULT NULL,
  `published_on` date DEFAULT NULL,
  `url` varchar(200) DEFAULT NULL,
  `cat_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`article_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO article VALUES("1","KON","2012-12-03","sacsd","1");
INSERT INTO article VALUES("2","SOPOL","2012-12-03","gvhbjn","2");
INSERT INTO article VALUES("3","KRAVA","2012-12-03","qwerty","3");





CREATE TABLE `cat_tag` (
  `cat_id` int(11) DEFAULT NULL,
  `tag_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO cat_tag VALUES("1","1");
INSERT INTO cat_tag VALUES("2","2");
INSERT INTO cat_tag VALUES("3","3");





CREATE TABLE `category_part1` (
  `cat1_id` int(11) NOT NULL AUTO_INCREMENT,
  `created_by` double DEFAULT NULL,
  PRIMARY KEY (`cat1_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO category_part1 VALUES("1","0");
INSERT INTO category_part1 VALUES("2","0");
INSERT INTO category_part1 VALUES("3","0");





CREATE TABLE `category_part2` (
  `category_id` int(11) NOT NULL AUTO_INCREMENT,
  `date_created_on` date DEFAULT NULL,
  PRIMARY KEY (`category_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO category_part2 VALUES("1","2012-12-03");
INSERT INTO category_part2 VALUES("2","2012-12-03");
INSERT INTO category_part2 VALUES("3","2012-12-03");





CREATE TABLE `tag` (
  `tag_id` int(11) NOT NULL AUTO_INCREMENT,
  `description` varchar(120) DEFAULT NULL,
  `priority` int(11) DEFAULT NULL,
  PRIMARY KEY (`tag_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO tag VALUES("1","fghj","2");
INSERT INTO tag VALUES("2","gfhj","9");
INSERT INTO tag VALUES("3","fghjk","5");





CREATE TABLE `tag_user` (
  `tag_id` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO tag_user VALUES("3","1");
INSERT INTO tag_user VALUES("1","3");
INSERT INTO tag_user VALUES("2","2");





CREATE TABLE `user` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `income` float DEFAULT NULL,
  `age` int(11) DEFAULT NULL,
  `created_on` date DEFAULT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO user VALUES("1","1.06","21","2012-12-03");
INSERT INTO user VALUES("2","9.03","21","2012-12-03");
INSERT INTO user VALUES("3","10.8","21","2012-12-03");



--------------------------------------------------------------------------Sunday 13th of April 2014 08:39:24 PM

CREATE TABLE `article` (
  `article_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(220) DEFAULT NULL,
  `published_on` date DEFAULT NULL,
  `url` varchar(200) DEFAULT NULL,
  `cat_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`article_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO article VALUES("1","KON","2012-12-03","sacsd","1");
INSERT INTO article VALUES("2","SOPOL","2012-12-03","gvhbjn","2");
INSERT INTO article VALUES("3","KRAVA","2012-12-03","qwerty","3");





CREATE TABLE `cat_tag` (
  `cat_id` int(11) DEFAULT NULL,
  `tag_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO cat_tag VALUES("1","1");
INSERT INTO cat_tag VALUES("2","2");
INSERT INTO cat_tag VALUES("3","3");





CREATE TABLE `category_part1` (
  `cat1_id` int(11) NOT NULL AUTO_INCREMENT,
  `created_by` double DEFAULT NULL,
  PRIMARY KEY (`cat1_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO category_part1 VALUES("1","0");
INSERT INTO category_part1 VALUES("2","0");
INSERT INTO category_part1 VALUES("3","0");





CREATE TABLE `category_part2` (
  `category_id` int(11) NOT NULL AUTO_INCREMENT,
  `date_created_on` date DEFAULT NULL,
  PRIMARY KEY (`category_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO category_part2 VALUES("1","2012-12-03");
INSERT INTO category_part2 VALUES("2","2012-12-03");
INSERT INTO category_part2 VALUES("3","2012-12-03");





CREATE TABLE `tag` (
  `tag_id` int(11) NOT NULL AUTO_INCREMENT,
  `description` varchar(120) DEFAULT NULL,
  `priority` int(11) DEFAULT NULL,
  PRIMARY KEY (`tag_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO tag VALUES("1","fghj","2");
INSERT INTO tag VALUES("2","gfhj","9");
INSERT INTO tag VALUES("3","fghjk","5");





CREATE TABLE `tag_user` (
  `tag_id` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO tag_user VALUES("3","1");
INSERT INTO tag_user VALUES("1","3");
INSERT INTO tag_user VALUES("2","2");





CREATE TABLE `user` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `income` float DEFAULT NULL,
  `age` int(11) DEFAULT NULL,
  `created_on` date DEFAULT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO user VALUES("1","1.06","21","2012-12-03");
INSERT INTO user VALUES("2","9.03","21","2012-12-03");
INSERT INTO user VALUES("3","10.8","21","2012-12-03");



--------------------------------------------------------------------------Sunday 13th of April 2014 08:40:30 PM