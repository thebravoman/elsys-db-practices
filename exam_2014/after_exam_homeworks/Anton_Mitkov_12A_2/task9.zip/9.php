
<!DOCTYPE html>
<html>
<head>
	<title>Anton Mitkov</title>
</head>
<body>
	Hello  <br/> &nbsp;&nbsp;&nbsp; Anton Mitkov 12 A, number in class 2 <br/>
	<br/><br/><br/>

<h3>Tips:</h3></br>
	sub_exam_backup1_1.sql - backup for the first part of the exam</br>
	sub_exam_backup1_2.sql - backup for the second part of the exam</br>

	If you refresh the page at the bottom of the file you'll see the changes and the time they are made.</br>
	It is possible when you refreshed the page to have an error with first answer because you change the database</br>
	and it affects on the result.</br></br>

<?php
	mysql_connect("localhost", "root","") or die(mysql_error());

/* Create table, ones I create table i shoud comment that line and uncoment the "mysql_selecet_db" line to connect */
		//mysql_query("CREATE DATABASE subd9") or die(mysql_error());

/*Select the database that was created*/
		mysql_select_db("subd9") or die(mysql_error());


/* That's how I create the tables*/
	 // 	mysql_query("CREATE TABLE Article (
		// 	  article_id INT AUTO_INCREMENT,
		// 	  name VARCHAR(220),
		// 	  published_on DATE,
		// 	  url VARCHAR(200),
		// 	  cat_id INT,
		// 	  PRIMARY KEY(article_id))") Or die(mysql_error());

		// mysql_query("CREATE TABLE Category (
		// 	  category_id INT AUTO_INCREMENT,
		// 	  	 created_by VARCHAR(120),
		// 	  	 date_created_on DATE,
		// 	  PRIMARY KEY(category_id))") Or die(mysql_error());

		// mysql_query("CREATE TABLE User (
		// 	  user_id INT AUTO_INCREMENT,
		// 	  	 income FLOAT,
		// 	  	 age INT,
		// 	  	 created_on DATE,
		// 	  PRIMARY KEY(user_id))") Or die(mysql_error());

		// mysql_query("CREATE TABLE Tag (
		// 	  tag_id INT AUTO_INCREMENT,
		// 	 	 description VARCHAR(120),
		// 	 	 priority INT,
		// 	  PRIMARY KEY(tag_id))") Or die(mysql_error());

		// mysql_query("CREATE TABLE cat_tag (
		// 	  cat_id INT,
		// 	  tag_id INT
		// 	  )") Or die(mysql_error());

		// mysql_query("CREATE TABLE tag_user (
		// 	  tag_id INT,
		// 	  user_id INT
		// 	  )") Or die(mysql_error());
		


/*INSERTIN SHITS*/
		// mysql_query("INSERT INTO Article( name, published_on, url, cat_id) VALUES ('KON','2012-12-03','sacsd',1)");
		// mysql_query("INSERT INTO Article( name, published_on, url, cat_id) VALUES ('SOPOL','2012-12-03','gvhbjn',2)");
		// mysql_query("INSERT INTO Article( name, published_on, url, cat_id) VALUES ('KRAVA','2012-12-03','qwerty',3)");

		// mysql_query("INSERT INTO Category( created_by, date_created_on) VALUES ('user1','2012-12-03')");
		// mysql_query("INSERT INTO Category( created_by, date_created_on) VALUES ('user2','2012-12-03')");
		// mysql_query("INSERT INTO Category( created_by, date_created_on) VALUES ('user3','2012-12-03')");

		// mysql_query("INSERT INTO USER(income, age, created_on) VALUES ('1.06',21,'2012-12-03')");
		// mysql_query("INSERT INTO USER(income, age, created_on) VALUES ('9.03',21,'2012-12-03')");
		// mysql_query("INSERT INTO USER(income, age, created_on) VALUES ('10.80',21,'2012-12-03')");

		// mysql_query("INSERT INTO tag(description, priority) VALUES ('fghj',2)");
		// mysql_query("INSERT INTO tag(description, priority) VALUES ('gfhj',9)");
		// mysql_query("INSERT INTO tag(description, priority) VALUES ('fghjk',5)");

		// mysql_query("INSERT INTO cat_tag( cat_id, tag_id) VALUES (1,1)");
		// mysql_query("INSERT INTO cat_tag( cat_id, tag_id) VALUES (2,2)");
		// mysql_query("INSERT INTO cat_tag( cat_id, tag_id) VALUES (3,3)");

		// mysql_query("INSERT INTO tag_user( user_id, tag_id) VALUES (1,3)");
		// mysql_query("INSERT INTO tag_user( user_id, tag_id) VALUES (3,1)");
		// mysql_query("INSERT INTO tag_user( user_id, tag_id) VALUES (2,2)");

	

/*Which are the Tag(s) for a given Article -> art cat_tag tag*/


		// $pena =  mysql_query("SELECT * FROM Article INNER JOIN cat_tag ON Article.cat_id = cat_tag.cat_id
		// 	 INNER JOIN tag ON Tag.tag_id = cat_tag.tag_id 
		// 	  WHERE Article.article_id = 2");

		//   ?> THE ANSWER OF THE FIRST QUESTION IS : <br/><?php
		// while($row = mysql_fetch_array($pena)){
		// 	echo $row["article_id"];		
		// 	echo $row["tag_id"];
		// 	echo $row["cat_id"];


		// 	?> <br/> <?php
		// }

/*Call the function that export the database*/
		backup_tables('localhost','root','subd9','sub_exam_backup2');	

/*Migration*/
		// mysql_query(" CREATE TABLE Category_part1 (
		// 	cat1_id INT AUTO_INCREMENT,
		// 	created_by DOUBLE,
		// 	PRIMARY KEY(cat1_id))") Or die(mysql_error());

		// mysql_query("INSERT INTO Category_part1 (created_by) SELECT created_by FROM Category");
		// mysql_query("ALTER TABLE Category DROP created_by");
		// mysql_query("ALTER TABLE Category RENAME TO Category_part2");

/*Secon of export the database*/
		backup_tables('localhost','root','subd9','sub_exam_backup2_1');

/*Which are the User(s) for a given Category -- > user tag_user cat_tag*/

		// 	$kon =  mysql_query("SELECT * FROM User INNER JOIN tag_user ON User.user_id = tag_user.user_id 
		// 	 INNER JOIN Cat_Tag ON Cat_Tag.tag_id = tag_user.tag_id 
		// 	 WHERE cat_tag.cat_id = 2");	 

		//   ?><br/><br/><br/> THE ANSWER OF THE SECOND QUESTION IS : <br/><?php
		// while($row2 = mysql_fetch_array($kon)){
		// 	echo $row2["cat_id"];		
		// 	echo $row2["tag_id"];
		// 	echo $row2["user_id"];


		// 	?> <br/> <?php
		// }

?>
</body>
</html>


<?php

	
/* backup the db OR just a table */
function backup_tables($host,$user,$name,$place,$tables = '*')
{
	
	$link = mysql_connect($host,$user,"");
	mysql_select_db($name,$link);
	
	//get all of the tables
	if($tables == '*')
	{
		$tables = array();
		$result = mysql_query('SHOW TABLES');
		//var_dump($result);
		while($row = mysql_fetch_row($result))
		{
			$tables[] = $row[0];
		}
	}
	else
	{
		$tables = is_array($tables) ? $tables : explode(',',$tables);
	}
	

	//cycle through
	foreach($tables as $table)
	{
		$result = mysql_query('SELECT * FROM '.$table);
		$num_fields = mysql_num_fields($result);
		
		$return = 'DROP TABLE '.$table.';';
		$row2 = mysql_fetch_row(mysql_query('SHOW CREATE TABLE '.$table));
		$return = "\n\n".$row2[1].";\n\n";
		
		for ($i = 0; $i < $num_fields; $i++) 
		{
			while($row = mysql_fetch_row($result))
			{
				$return.= 'INSERT INTO '.$table.' VALUES(';
				for($j=0; $j<$num_fields; $j++) 
				{
					$row[$j] = addslashes($row[$j]);
					$row[$j] = ereg_replace("\n","\\n",$row[$j]);
					if (isset($row[$j])) { $return.= '"'.$row[$j].'"' ; } else { $return.= '""'; }
					if ($j<($num_fields-1)) { $return.= ','; }
				}
				$return.= ");\n";
			}
		}
		$return.="\n\n\n";

	$handle = fopen($place.'.sql','a+');
	fwrite($handle,$return);

	}
	fwrite($handle,"--------------------------------------------------------------------------".date('l jS \of F Y h:i:s A'));
	fclose($handle);
}
?>