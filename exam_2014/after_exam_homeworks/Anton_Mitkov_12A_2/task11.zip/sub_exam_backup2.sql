

CREATE TABLE `article` (
  `article_id` int(11) NOT NULL AUTO_INCREMENT,
  `content` varchar(120) DEFAULT NULL,
  `price` varchar(20) DEFAULT NULL,
  `url` varchar(20) DEFAULT NULL,
  `cat_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`article_id`),
  UNIQUE KEY `cat_id` (`cat_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;






CREATE TABLE `category` (
  `category_id` int(11) NOT NULL AUTO_INCREMENT,
  `description` varchar(50) DEFAULT NULL,
  `date_created_on` date DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`category_id`),
  UNIQUE KEY `user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;






CREATE TABLE `tag` (
  `tag_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(40) DEFAULT NULL,
  `description` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`tag_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;






CREATE TABLE `user` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `created_on` date DEFAULT NULL,
  `password` varchar(100) DEFAULT NULL,
  `name` varchar(30) DEFAULT NULL,
  `tag_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;




--------------------------------------------------------------------------Monday 14th of April 2014 01:25:25 PM

CREATE TABLE `article` (
  `article_id` int(11) NOT NULL AUTO_INCREMENT,
  `content` varchar(120) DEFAULT NULL,
  `price` varchar(20) DEFAULT NULL,
  `url` varchar(20) DEFAULT NULL,
  `cat_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`article_id`),
  UNIQUE KEY `cat_id` (`cat_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO article VALUES("1","hjjhbgjhb","0.5","mnbvf","2");
INSERT INTO article VALUES("2","hjjhbgjhb","5.2","nbvc","3");
INSERT INTO article VALUES("3","hjjhbgjhb","7.1","jhgf","1");





CREATE TABLE `category` (
  `category_id` int(11) NOT NULL AUTO_INCREMENT,
  `description` varchar(50) DEFAULT NULL,
  `date_created_on` date DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`category_id`),
  UNIQUE KEY `user_id` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO category VALUES("1","fgbf","2012-12-03","3");
INSERT INTO category VALUES("2","fgbf","2012-12-03","2");
INSERT INTO category VALUES("3","fgbf","2012-12-03","1");





CREATE TABLE `tag` (
  `tag_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(40) DEFAULT NULL,
  `description` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`tag_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;






CREATE TABLE `user` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `created_on` date DEFAULT NULL,
  `password` varchar(100) DEFAULT NULL,
  `name` varchar(30) DEFAULT NULL,
  `tag_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;




--------------------------------------------------------------------------Monday 14th of April 2014 01:31:34 PM

CREATE TABLE `article` (
  `article_id` int(11) NOT NULL AUTO_INCREMENT,
  `content` varchar(120) DEFAULT NULL,
  `price` varchar(20) DEFAULT NULL,
  `url` varchar(20) DEFAULT NULL,
  `cat_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`article_id`),
  UNIQUE KEY `cat_id` (`cat_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO article VALUES("1","hjjhbgjhb","0.5","mnbvf","2");
INSERT INTO article VALUES("2","hjjhbgjhb","5.2","nbvc","3");
INSERT INTO article VALUES("3","hjjhbgjhb","7.1","jhgf","1");





CREATE TABLE `category` (
  `category_id` int(11) NOT NULL AUTO_INCREMENT,
  `description` varchar(50) DEFAULT NULL,
  `date_created_on` date DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`category_id`),
  UNIQUE KEY `user_id` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO category VALUES("1","fgbf","2012-12-03","3");
INSERT INTO category VALUES("2","fgbf","2012-12-03","2");
INSERT INTO category VALUES("3","fgbf","2012-12-03","1");





CREATE TABLE `tag` (
  `tag_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(40) DEFAULT NULL,
  `description` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`tag_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO tag VALUES("1","fghj","koko");
INSERT INTO tag VALUES("2","gfhj","bobo");
INSERT INTO tag VALUES("3","fghjk","soso");





CREATE TABLE `user` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `created_on` date DEFAULT NULL,
  `password` varchar(100) DEFAULT NULL,
  `name` varchar(30) DEFAULT NULL,
  `tag_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO user VALUES("1","2012-12-03","fcghjk","jkdshnck","1");
INSERT INTO user VALUES("2","2012-12-03","fcghjk","jkdshnck","3");
INSERT INTO user VALUES("3","2012-12-03","fcghjk","jkdshnck","2");



--------------------------------------------------------------------------Monday 14th of April 2014 01:32:14 PM

CREATE TABLE `article` (
  `article_id` int(11) NOT NULL AUTO_INCREMENT,
  `content` varchar(120) DEFAULT NULL,
  `price` varchar(20) DEFAULT NULL,
  `url` varchar(20) DEFAULT NULL,
  `cat_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`article_id`),
  UNIQUE KEY `cat_id` (`cat_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO article VALUES("1","hjjhbgjhb","0.5","mnbvf","2");
INSERT INTO article VALUES("2","hjjhbgjhb","5.2","nbvc","3");
INSERT INTO article VALUES("3","hjjhbgjhb","7.1","jhgf","1");





CREATE TABLE `category` (
  `category_id` int(11) NOT NULL AUTO_INCREMENT,
  `description` varchar(50) DEFAULT NULL,
  `date_created_on` date DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`category_id`),
  UNIQUE KEY `user_id` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO category VALUES("1","fgbf","2012-12-03","3");
INSERT INTO category VALUES("2","fgbf","2012-12-03","2");
INSERT INTO category VALUES("3","fgbf","2012-12-03","1");





CREATE TABLE `tag` (
  `tag_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(40) DEFAULT NULL,
  `description` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`tag_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO tag VALUES("1","fghj","koko");
INSERT INTO tag VALUES("2","gfhj","bobo");
INSERT INTO tag VALUES("3","fghjk","soso");





CREATE TABLE `user` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `created_on` date DEFAULT NULL,
  `password` varchar(100) DEFAULT NULL,
  `name` varchar(30) DEFAULT NULL,
  `tag_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO user VALUES("1","2012-12-03","fcghjk","jkdshnck","1");
INSERT INTO user VALUES("2","2012-12-03","fcghjk","jkdshnck","3");
INSERT INTO user VALUES("3","2012-12-03","fcghjk","jkdshnck","2");



--------------------------------------------------------------------------Monday 14th of April 2014 01:34:09 PM

CREATE TABLE `article` (
  `article_id` int(11) NOT NULL AUTO_INCREMENT,
  `content` varchar(120) DEFAULT NULL,
  `price` varchar(20) DEFAULT NULL,
  `url` varchar(20) DEFAULT NULL,
  `cat_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`article_id`),
  UNIQUE KEY `cat_id` (`cat_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO article VALUES("1","hjjhbgjhb","0.5","mnbvf","2");
INSERT INTO article VALUES("2","hjjhbgjhb","5.2","nbvc","3");
INSERT INTO article VALUES("3","hjjhbgjhb","7.1","jhgf","1");





CREATE TABLE `category` (
  `category_id` int(11) NOT NULL AUTO_INCREMENT,
  `description` varchar(50) DEFAULT NULL,
  `date_created_on` date DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`category_id`),
  UNIQUE KEY `user_id` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO category VALUES("1","fgbf","2012-12-03","3");
INSERT INTO category VALUES("2","fgbf","2012-12-03","2");
INSERT INTO category VALUES("3","fgbf","2012-12-03","1");





CREATE TABLE `tag` (
  `tag_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(40) DEFAULT NULL,
  `description` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`tag_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO tag VALUES("1","fghj","koko");
INSERT INTO tag VALUES("2","gfhj","bobo");
INSERT INTO tag VALUES("3","fghjk","soso");





CREATE TABLE `user` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `created_on` date DEFAULT NULL,
  `password` varchar(100) DEFAULT NULL,
  `name` varchar(30) DEFAULT NULL,
  `tag_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO user VALUES("1","2012-12-03","fcghjk","jkdshnck","1");
INSERT INTO user VALUES("2","2012-12-03","fcghjk","jkdshnck","3");
INSERT INTO user VALUES("3","2012-12-03","fcghjk","jkdshnck","2");



--------------------------------------------------------------------------Monday 14th of April 2014 01:35:55 PM

CREATE TABLE `article` (
  `article_id` int(11) NOT NULL AUTO_INCREMENT,
  `content` varchar(120) DEFAULT NULL,
  `price` varchar(20) DEFAULT NULL,
  `url` varchar(20) DEFAULT NULL,
  `cat_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`article_id`),
  UNIQUE KEY `cat_id` (`cat_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO article VALUES("1","hjjhbgjhb","0.5","mnbvf","2");
INSERT INTO article VALUES("2","hjjhbgjhb","5.2","nbvc","3");
INSERT INTO article VALUES("3","hjjhbgjhb","7.1","jhgf","1");





CREATE TABLE `category` (
  `category_id` int(11) NOT NULL AUTO_INCREMENT,
  `description` varchar(50) DEFAULT NULL,
  `date_created_on` date DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`category_id`),
  UNIQUE KEY `user_id` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO category VALUES("1","fgbf","2012-12-03","3");
INSERT INTO category VALUES("2","fgbf","2012-12-03","2");
INSERT INTO category VALUES("3","fgbf","2012-12-03","1");





CREATE TABLE `tag` (
  `tag_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(40) DEFAULT NULL,
  `description` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`tag_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO tag VALUES("1","fghj","koko");
INSERT INTO tag VALUES("2","gfhj","bobo");
INSERT INTO tag VALUES("3","fghjk","soso");





CREATE TABLE `user_part1` (
  `user1_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`user1_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO user_part1 VALUES("1","jkdshnck");
INSERT INTO user_part1 VALUES("2","jkdshnck");
INSERT INTO user_part1 VALUES("3","jkdshnck");





CREATE TABLE `user_part2` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `created_on` date DEFAULT NULL,
  `password` varchar(100) DEFAULT NULL,
  `tag_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO user_part2 VALUES("1","2012-12-03","fcghjk","1");
INSERT INTO user_part2 VALUES("2","2012-12-03","fcghjk","3");
INSERT INTO user_part2 VALUES("3","2012-12-03","fcghjk","2");



--------------------------------------------------------------------------Monday 14th of April 2014 01:37:47 PM