
<!DOCTYPE html>
<html>
<head>
	<title>Anton Mitkov</title>
</head>
<body>
	Hello  <br/> &nbsp;&nbsp;&nbsp; Anton Mitkov 12 A, number in class 2 <br/>
	<br/><br/><br/>

<h3>Tips:</h3></br>
	sub_exam_backup1_1.sql - backup for the first part of the exam</br>
	sub_exam_backup1_2.sql - backup for the second part of the exam</br>

	If you refresh the page at the bottom of the file you'll see the changes and the time they are made.</br>
	It is possible when you refreshed the page to have an error with first answer because you change the database</br>
	and it affects on the result.</br></br>

<?php
	mysql_connect("localhost", "root","") or die(mysql_error());

/* Create table, ones I create table i shoud comment that line and uncoment the "mysql_selecet_db" line to connect */
		//mysql_query("CREATE DATABASE subd11") or die(mysql_error());

/*Select the database that was created*/
		mysql_select_db("subd11") or die(mysql_error());


/* That's how I create the tables*/
	 // 	mysql_query("CREATE TABLE Article (
		// 	  article_id INT AUTO_INCREMENT,
		// 	  content VARCHAR(120),
		// 	  price VARCHAR(20),
		// 	  url VARCHAR(20),
		// 	  cat_id INT UNIQUE,
		// 	  PRIMARY KEY(article_id))") Or die(mysql_error());

		// mysql_query("CREATE TABLE Category (
		// 	  category_id INT AUTO_INCREMENT,
		// 	  description VARCHAR(50),
		// 	  date_created_on DATE,
		// 	  user_id INT UNIQUE,
		// 	  PRIMARY KEY(category_id))") Or die(mysql_error());

		// mysql_query("CREATE TABLE User (
		// 	  user_id INT AUTO_INCREMENT,
		// 	  created_on DATE,
		// 	  password VARCHAR(100),
		// 	  name VARCHAR(30),
		// 	  tag_id INT,
		// 	  PRIMARY KEY(user_id))") Or die(mysql_error());

		// mysql_query("CREATE TABLE Tag (
		// 	  tag_id INT AUTO_INCREMENT,
		// 	 	 name VARCHAR(40),
		// 	 	 description VARCHAR(30),
		// 	  PRIMARY KEY(tag_id))") Or die(mysql_error());

/*INSERTIN SHITS*/
		// mysql_query("INSERT INTO Article( content, price, url, cat_id) VALUES ('hjjhbgjhb','0.5','mnbvf',2)");
		// mysql_query("INSERT INTO Article( content, price, url, cat_id) VALUES ('hjjhbgjhb','5.2','nbvc',3)");
		// mysql_query("INSERT INTO Article( content, price, url, cat_id) VALUES ('hjjhbgjhb','7.1','jhgf',1)");

		// mysql_query("INSERT INTO Category( description, date_created_on, user_id) VALUES ('fgbf','2012-12-03',3)");
		// mysql_query("INSERT INTO Category( description, date_created_on, user_id) VALUES ('fgbf','2012-12-03',2)");
		// mysql_query("INSERT INTO Category( description, date_created_on, user_id) VALUES ('fgbf','2012-12-03',1)");

		// mysql_query("INSERT INTO USER(created_on, password, name, tag_id) VALUES ('2012-12-03','fcghjk','jkdshnck',1)");
		// mysql_query("INSERT INTO USER(created_on, password, name, tag_id) VALUES ('2012-12-03','fcghjk','jkdshnck',3)");
		// mysql_query("INSERT INTO USER(created_on, password, name, tag_id) VALUES ('2012-12-03','fcghjk','jkdshnck',2)");

		// mysql_query("INSERT INTO tag(name, description) VALUES ('fghj','koko')");
		// mysql_query("INSERT INTO tag(name, description) VALUES ('gfhj','bobo')");
		// mysql_query("INSERT INTO tag(name, description) VALUES ('fghjk','soso')");


/*Which are the Category(s) for a given Tag -> cat user tag*/


		// $pena =  mysql_query("SELECT * FROM Category INNER JOIN User ON Category.user_id = User.user_id
		// 	 INNER JOIN tag ON User.tag_id = tag.tag_id 
		// 	  WHERE Tag.tag_id = 2");

		//   ?> THE ANSWER OF THE FIRST QUESTION IS : <br/><?php
		// while($row = mysql_fetch_array($pena)){
		// 	echo $row["tag_id"];		
		// 	echo $row["user_id"];
		// 	echo $row["category_id"];


		// 	?> <br/> <?php
		// }

/*Call the function that export the database*/
		backup_tables('localhost','root','subd11','sub_exam_backup2');	

/*Migration*/
		// mysql_query(" CREATE TABLE User_part1 (
		// 	user1_id INT AUTO_INCREMENT,
		// 	name VARCHAR(100),
		// 	PRIMARY KEY(user1_id))") Or die(mysql_error());

		// mysql_query("INSERT INTO User_part1 (name) SELECT name FROM User");
		// mysql_query("ALTER TABLE User DROP name");
		// mysql_query("ALTER TABLE User RENAME TO User_part2");

/*Secon of export the database*/
		backup_tables('localhost','root','subd11','sub_exam_backup2_1');

/*Which are the Article(s) for a given User -->  art cat user_1*/

			$kon =  mysql_query("SELECT * FROM Article INNER JOIN Category ON Article.cat_id = Category.category_id 
			 INNER JOIN User_part2 ON User_part2.user_id = Category.user_id 
			 WHERE User_part2.user_id = 2");	 

		  ?><br/><br/><br/> THE ANSWER OF THE SECOND QUESTION IS : <br/><?php
		while($row2 = mysql_fetch_array($kon)){
			echo $row2["user_id"];		
			echo $row2["category_id"];
			echo $row2["article_id"];


			?> <br/> <?php
		}

?>
</body>
</html>


<?php

	
/* backup the db OR just a table */
function backup_tables($host,$user,$name,$place,$tables = '*')
{
	
	$link = mysql_connect($host,$user,"");
	mysql_select_db($name,$link);
	
	//get all of the tables
	if($tables == '*')
	{
		$tables = array();
		$result = mysql_query('SHOW TABLES');
		//var_dump($result);
		while($row = mysql_fetch_row($result))
		{
			$tables[] = $row[0];
		}
	}
	else
	{
		$tables = is_array($tables) ? $tables : explode(',',$tables);
	}
	

	//cycle through
	foreach($tables as $table)
	{
		$result = mysql_query('SELECT * FROM '.$table);
		$num_fields = mysql_num_fields($result);
		
		$return = 'DROP TABLE '.$table.';';
		$row2 = mysql_fetch_row(mysql_query('SHOW CREATE TABLE '.$table));
		$return = "\n\n".$row2[1].";\n\n";
		
		for ($i = 0; $i < $num_fields; $i++) 
		{
			while($row = mysql_fetch_row($result))
			{
				$return.= 'INSERT INTO '.$table.' VALUES(';
				for($j=0; $j<$num_fields; $j++) 
				{
					$row[$j] = addslashes($row[$j]);
					$row[$j] = ereg_replace("\n","\\n",$row[$j]);
					if (isset($row[$j])) { $return.= '"'.$row[$j].'"' ; } else { $return.= '""'; }
					if ($j<($num_fields-1)) { $return.= ','; }
				}
				$return.= ");\n";
			}
		}
		$return.="\n\n\n";

	$handle = fopen($place.'.sql','a+');
	fwrite($handle,$return);

	}
	fwrite($handle,"--------------------------------------------------------------------------".date('l jS \of F Y h:i:s A'));
	fclose($handle);
}
?>