
<!DOCTYPE html>
<html>
<head>
	<title>Anton Mitkov</title>
</head>
<body>
	Hello  <br/> &nbsp;&nbsp;&nbsp; Anton Mitkov 12 A, number in class 2 <br/>
	<br/><br/><br/>

<h3>Tips:</h3></br>
	sub_exam_backup1_1.sql - backup for the first part of the exam</br>
	sub_exam_backup1_2.sql - backup for the second part of the exam</br>

	If you refresh the page at the bottom of the file you'll see the changes and the time they are made.</br>
	It is possible when you refreshed the page to have an error with first answer because you change the database</br>
	and it affects on the result.</br></br>

<?php
	mysql_connect("localhost", "root","") or die(mysql_error());

/* Create table, ones I create table i shoud comment that line and uncoment the "mysql_selecet_db" line to connect */
		//mysql_query("CREATE DATABASE subd7") or die(mysql_error());

/*Select the database that was created*/
		mysql_select_db("subd7") or die(mysql_error());


/* That's how I create the tables*/
	 // 	mysql_query("CREATE TABLE Article (
		// 	  article_id INT AUTO_INCREMENT,
		// 	   name VARCHAR(20),
		// 	   created_on DATE,
		// 	   price VARCHAR(20),
		// 	   tag_id INT,
		// 	  PRIMARY KEY(article_id))") Or die(mysql_error());

		// mysql_query("CREATE TABLE Category (
		// 	  category_id INT AUTO_INCREMENT,
		// 	  date_created_on DATE,
		// 	  priority DOUBLE,
		// 	  user_id INT,
		// 	  PRIMARY KEY(category_id))") Or die(mysql_error());

		// mysql_query("CREATE TABLE User (
		// 	  user_id INT AUTO_INCREMENT,
		// 	  password VARCHAR(20),
		// 	  name VARCHAR(20),
		// 	  age INT,
		// 	  PRIMARY KEY(user_id))") Or die(mysql_error());

		// mysql_query("CREATE TABLE Tag (
		// 	  tag_id INT AUTO_INCREMENT,
		// 	  priority INT,
		// 	  name VARCHAR(20),
		// 	  PRIMARY KEY(tag_id))") Or die(mysql_error());

		// mysql_query("CREATE TABLE Cat_Tag (
		// 	  cat_id INT,
		// 	  tag_id INT
		// 	  )") Or die(mysql_error());
		


/*INSERTIN SHITS*/
		// mysql_query("INSERT INTO Article( name, created_on, price, tag_id) VALUES ('KON','2012-02-1','5',1)");
		// mysql_query("INSERT INTO Article( name, created_on, price, tag_id) VALUES ('SOPOL','2012-02-1','5.04',2)");
		// mysql_query("INSERT INTO Article( name, created_on, price, tag_id) VALUES ('KRAVA','2012-02-1','5.04',3)");

		// mysql_query("INSERT INTO Category( date_created_on, priority,user_id) VALUES ('2012-12-03','1.5',3)");
		// mysql_query("INSERT INTO Category( date_created_on, priority,user_id) VALUES ('2012-05-12','1.26',1)");
		// mysql_query("INSERT INTO Category( date_created_on, priority,user_id) VALUES ('2012-09-02','1.05',2)");

		// mysql_query("INSERT INTO USER(password, name, age) VALUES ('gfhjk','GOGO',21)");
		// mysql_query("INSERT INTO USER(password, name, age) VALUES ('grdthfyukj','PACO',152)");
		// mysql_query("INSERT INTO USER(password, name, age) VALUES ('rteyuio','NASKO',23)");

		// mysql_query("INSERT INTO tag( priority, name) VALUES (28,'kon')");
		// mysql_query("INSERT INTO tag( priority, name) VALUES (26,'sopol')");
		// mysql_query("INSERT INTO tag( priority, name) VALUES (92,'gevrek')");

		// mysql_query("INSERT INTO Cat_Tag( cat_id, tag_id) VALUES (1,2)");
		// mysql_query("INSERT INTO Cat_Tag( cat_id, tag_id) VALUES (1,3)");
		// mysql_query("INSERT INTO Cat_Tag( cat_id, tag_id) VALUES (2,1)");



/*Which are the Category(s) for a given Article -> art cat_tag cat*/


		// $pena =  mysql_query("SELECT * FROM Article INNER JOIN cat_tag ON Article.tag_id = Cat_Tag.tag_id
		// 	 INNER JOIN Category ON Category.category_id = Cat_Tag.cat_id 
		// 	  WHERE Article.article_id = 2");

		//   ?> THE ANSWER OF THE FIRST QUESTION IS : <br/><?php
		// while($row = mysql_fetch_array($pena)){
		// 	echo $row["article_id"];		
		// 	echo $row["tag_id"];
		// 	echo $row["category_id"];


		// 	?> <br/> <?php
		// }

/*Call the function that export the database*/
		backup_tables('localhost','root','subd7','sub_exam_backup2');	

/*Migration*/
		// mysql_query(" CREATE TABLE Tag_part1 (
		// 	tag1_id INT AUTO_INCREMENT,
		// 	name DOUBLE,
		// 	PRIMARY KEY(tag1_id))") Or die(mysql_error());

		// mysql_query("INSERT INTO Tag_part1 (name) SELECT name FROM Tag");
		// mysql_query("ALTER TABLE Tag DROP name");
		// mysql_query("ALTER TABLE Tag RENAME TO Tag_part2");

/*Secon of export the database*/
		backup_tables('localhost','root','subd7','sub_exam_backup2_1');

/*Which are the User(s) for a given Tag - >user cat cat_tag tag1*/

			$kon =  mysql_query("SELECT * FROM User INNER JOIN Category ON User.user_id = Category.user_id 
			 INNER JOIN Cat_Tag ON Cat_Tag.cat_id = Category.category_id INNER JOIN Tag_part2 ON Cat_Tag.tag_id = Tag_part2.tag_id 
			 WHERE Tag_part2.tag_id = 2");	 

		  ?><br/><br/><br/> THE ANSWER OF THE SECOND QUESTION IS : <br/><?php
		while($row2 = mysql_fetch_array($kon)){
			echo $row2["tag_id"];		
			echo $row2["category_id"];
			echo $row2["user_id"];


			?> <br/> <?php
		}

?>
</body>
</html>


<?php

	
/* backup the db OR just a table */
function backup_tables($host,$user,$name,$place,$tables = '*')
{
	
	$link = mysql_connect($host,$user,"");
	mysql_select_db($name,$link);
	
	//get all of the tables
	if($tables == '*')
	{
		$tables = array();
		$result = mysql_query('SHOW TABLES');
		//var_dump($result);
		while($row = mysql_fetch_row($result))
		{
			$tables[] = $row[0];
		}
	}
	else
	{
		$tables = is_array($tables) ? $tables : explode(',',$tables);
	}
	

	//cycle through
	foreach($tables as $table)
	{
		$result = mysql_query('SELECT * FROM '.$table);
		$num_fields = mysql_num_fields($result);
		
		$return = 'DROP TABLE '.$table.';';
		$row2 = mysql_fetch_row(mysql_query('SHOW CREATE TABLE '.$table));
		$return = "\n\n".$row2[1].";\n\n";
		
		for ($i = 0; $i < $num_fields; $i++) 
		{
			while($row = mysql_fetch_row($result))
			{
				$return.= 'INSERT INTO '.$table.' VALUES(';
				for($j=0; $j<$num_fields; $j++) 
				{
					$row[$j] = addslashes($row[$j]);
					$row[$j] = ereg_replace("\n","\\n",$row[$j]);
					if (isset($row[$j])) { $return.= '"'.$row[$j].'"' ; } else { $return.= '""'; }
					if ($j<($num_fields-1)) { $return.= ','; }
				}
				$return.= ");\n";
			}
		}
		$return.="\n\n\n";

	$handle = fopen($place.'.sql','a+');
	fwrite($handle,$return);

	}
	fwrite($handle,"--------------------------------------------------------------------------".date('l jS \of F Y h:i:s A'));
	fclose($handle);
}
?>