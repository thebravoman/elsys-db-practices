

CREATE TABLE `article` (
  `article_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(20) DEFAULT NULL,
  `created_on` date DEFAULT NULL,
  `price` varchar(20) DEFAULT NULL,
  `tag_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`article_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;






CREATE TABLE `cat_tag` (
  `cat_id` int(11) DEFAULT NULL,
  `tag_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;






CREATE TABLE `category` (
  `category_id` int(11) NOT NULL AUTO_INCREMENT,
  `date_created_on` date DEFAULT NULL,
  `priority` double DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`category_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;






CREATE TABLE `tag` (
  `tag_id` int(11) NOT NULL AUTO_INCREMENT,
  `priority` int(11) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`tag_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;






CREATE TABLE `user` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `password` varchar(20) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL,
  `age` int(11) DEFAULT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;




--------------------------------------------------------------------------Sunday 13th of April 2014 05:18:22 PM

CREATE TABLE `article` (
  `article_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(20) DEFAULT NULL,
  `created_on` date DEFAULT NULL,
  `price` varchar(20) DEFAULT NULL,
  `tag_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`article_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO article VALUES("1","KON","2012-02-01","5","1");
INSERT INTO article VALUES("2","SOPOL","2012-02-01","5.04","2");
INSERT INTO article VALUES("3","KRAVA","2012-02-01","5.04","3");





CREATE TABLE `cat_tag` (
  `cat_id` int(11) DEFAULT NULL,
  `tag_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO cat_tag VALUES("1","2");
INSERT INTO cat_tag VALUES("1","3");
INSERT INTO cat_tag VALUES("2","1");





CREATE TABLE `category` (
  `category_id` int(11) NOT NULL AUTO_INCREMENT,
  `date_created_on` date DEFAULT NULL,
  `priority` double DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`category_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO category VALUES("1","2012-12-03","1.5","3");
INSERT INTO category VALUES("2","2012-05-12","1.26","1");
INSERT INTO category VALUES("3","2012-09-02","1.05","2");





CREATE TABLE `tag` (
  `tag_id` int(11) NOT NULL AUTO_INCREMENT,
  `priority` int(11) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`tag_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO tag VALUES("1","28","kon");
INSERT INTO tag VALUES("2","26","sopol");
INSERT INTO tag VALUES("3","92","gevrek");





CREATE TABLE `user` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `password` varchar(20) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL,
  `age` int(11) DEFAULT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

INSERT INTO user VALUES("1","gfhjk","GOGO","21");
INSERT INTO user VALUES("2","grdthfyukj","PACO","152");



--------------------------------------------------------------------------Sunday 13th of April 2014 05:23:10 PM

CREATE TABLE `article` (
  `article_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(20) DEFAULT NULL,
  `created_on` date DEFAULT NULL,
  `price` varchar(20) DEFAULT NULL,
  `tag_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`article_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO article VALUES("1","KON","2012-02-01","5","1");
INSERT INTO article VALUES("2","SOPOL","2012-02-01","5.04","2");
INSERT INTO article VALUES("3","KRAVA","2012-02-01","5.04","3");





CREATE TABLE `cat_tag` (
  `cat_id` int(11) DEFAULT NULL,
  `tag_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO cat_tag VALUES("1","2");
INSERT INTO cat_tag VALUES("1","3");
INSERT INTO cat_tag VALUES("2","1");





CREATE TABLE `category` (
  `category_id` int(11) NOT NULL AUTO_INCREMENT,
  `date_created_on` date DEFAULT NULL,
  `priority` double DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`category_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO category VALUES("1","2012-12-03","1.5","3");
INSERT INTO category VALUES("2","2012-05-12","1.26","1");
INSERT INTO category VALUES("3","2012-09-02","1.05","2");





CREATE TABLE `tag` (
  `tag_id` int(11) NOT NULL AUTO_INCREMENT,
  `priority` int(11) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`tag_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO tag VALUES("1","28","kon");
INSERT INTO tag VALUES("2","26","sopol");
INSERT INTO tag VALUES("3","92","gevrek");





CREATE TABLE `user` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `password` varchar(20) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL,
  `age` int(11) DEFAULT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

INSERT INTO user VALUES("1","gfhjk","GOGO","21");
INSERT INTO user VALUES("2","grdthfyukj","PACO","152");



--------------------------------------------------------------------------Sunday 13th of April 2014 05:25:56 PM

CREATE TABLE `article` (
  `article_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(20) DEFAULT NULL,
  `created_on` date DEFAULT NULL,
  `price` varchar(20) DEFAULT NULL,
  `tag_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`article_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO article VALUES("1","KON","2012-02-01","5","1");
INSERT INTO article VALUES("2","SOPOL","2012-02-01","5.04","2");
INSERT INTO article VALUES("3","KRAVA","2012-02-01","5.04","3");





CREATE TABLE `cat_tag` (
  `cat_id` int(11) DEFAULT NULL,
  `tag_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO cat_tag VALUES("1","2");
INSERT INTO cat_tag VALUES("1","3");
INSERT INTO cat_tag VALUES("2","1");





CREATE TABLE `category` (
  `category_id` int(11) NOT NULL AUTO_INCREMENT,
  `date_created_on` date DEFAULT NULL,
  `priority` double DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`category_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO category VALUES("1","2012-12-03","1.5","3");
INSERT INTO category VALUES("2","2012-05-12","1.26","1");
INSERT INTO category VALUES("3","2012-09-02","1.05","2");





CREATE TABLE `tag_part1` (
  `tag1_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` double DEFAULT NULL,
  PRIMARY KEY (`tag1_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO tag_part1 VALUES("1","0");
INSERT INTO tag_part1 VALUES("2","0");
INSERT INTO tag_part1 VALUES("3","0");





CREATE TABLE `tag_part2` (
  `tag_id` int(11) NOT NULL AUTO_INCREMENT,
  `priority` int(11) DEFAULT NULL,
  PRIMARY KEY (`tag_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO tag_part2 VALUES("1","28");
INSERT INTO tag_part2 VALUES("2","26");
INSERT INTO tag_part2 VALUES("3","92");





CREATE TABLE `user` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `password` varchar(20) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL,
  `age` int(11) DEFAULT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

INSERT INTO user VALUES("1","gfhjk","GOGO","21");
INSERT INTO user VALUES("2","grdthfyukj","PACO","152");



--------------------------------------------------------------------------Sunday 13th of April 2014 05:27:15 PM

CREATE TABLE `article` (
  `article_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(20) DEFAULT NULL,
  `created_on` date DEFAULT NULL,
  `price` varchar(20) DEFAULT NULL,
  `tag_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`article_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO article VALUES("1","KON","2012-02-01","5","1");
INSERT INTO article VALUES("2","SOPOL","2012-02-01","5.04","2");
INSERT INTO article VALUES("3","KRAVA","2012-02-01","5.04","3");





CREATE TABLE `cat_tag` (
  `cat_id` int(11) DEFAULT NULL,
  `tag_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO cat_tag VALUES("1","2");
INSERT INTO cat_tag VALUES("1","3");
INSERT INTO cat_tag VALUES("2","1");





CREATE TABLE `category` (
  `category_id` int(11) NOT NULL AUTO_INCREMENT,
  `date_created_on` date DEFAULT NULL,
  `priority` double DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`category_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO category VALUES("1","2012-12-03","1.5","3");
INSERT INTO category VALUES("2","2012-05-12","1.26","1");
INSERT INTO category VALUES("3","2012-09-02","1.05","2");





CREATE TABLE `tag_part1` (
  `tag1_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` double DEFAULT NULL,
  PRIMARY KEY (`tag1_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO tag_part1 VALUES("1","0");
INSERT INTO tag_part1 VALUES("2","0");
INSERT INTO tag_part1 VALUES("3","0");





CREATE TABLE `tag_part2` (
  `tag_id` int(11) NOT NULL AUTO_INCREMENT,
  `priority` int(11) DEFAULT NULL,
  PRIMARY KEY (`tag_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO tag_part2 VALUES("1","28");
INSERT INTO tag_part2 VALUES("2","26");
INSERT INTO tag_part2 VALUES("3","92");





CREATE TABLE `user` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `password` varchar(20) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL,
  `age` int(11) DEFAULT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

INSERT INTO user VALUES("1","gfhjk","GOGO","21");
INSERT INTO user VALUES("2","grdthfyukj","PACO","152");



--------------------------------------------------------------------------Sunday 13th of April 2014 05:42:31 PM

CREATE TABLE `article` (
  `article_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(20) DEFAULT NULL,
  `created_on` date DEFAULT NULL,
  `price` varchar(20) DEFAULT NULL,
  `tag_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`article_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO article VALUES("1","KON","2012-02-01","5","1");
INSERT INTO article VALUES("2","SOPOL","2012-02-01","5.04","2");
INSERT INTO article VALUES("3","KRAVA","2012-02-01","5.04","3");





CREATE TABLE `cat_tag` (
  `cat_id` int(11) DEFAULT NULL,
  `tag_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO cat_tag VALUES("1","2");
INSERT INTO cat_tag VALUES("1","3");
INSERT INTO cat_tag VALUES("2","1");





CREATE TABLE `category` (
  `category_id` int(11) NOT NULL AUTO_INCREMENT,
  `date_created_on` date DEFAULT NULL,
  `priority` double DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`category_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO category VALUES("1","2012-12-03","1.5","3");
INSERT INTO category VALUES("2","2012-05-12","1.26","1");
INSERT INTO category VALUES("3","2012-09-02","1.05","2");





CREATE TABLE `tag_part1` (
  `tag1_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` double DEFAULT NULL,
  PRIMARY KEY (`tag1_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO tag_part1 VALUES("1","0");
INSERT INTO tag_part1 VALUES("2","0");
INSERT INTO tag_part1 VALUES("3","0");





CREATE TABLE `tag_part2` (
  `tag_id` int(11) NOT NULL AUTO_INCREMENT,
  `priority` int(11) DEFAULT NULL,
  PRIMARY KEY (`tag_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO tag_part2 VALUES("1","28");
INSERT INTO tag_part2 VALUES("2","26");
INSERT INTO tag_part2 VALUES("3","92");





CREATE TABLE `user` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `password` varchar(20) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL,
  `age` int(11) DEFAULT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

INSERT INTO user VALUES("1","gfhjk","GOGO","21");
INSERT INTO user VALUES("2","grdthfyukj","PACO","152");



--------------------------------------------------------------------------Sunday 13th of April 2014 06:41:44 PM

CREATE TABLE `article` (
  `article_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(20) DEFAULT NULL,
  `created_on` date DEFAULT NULL,
  `price` varchar(20) DEFAULT NULL,
  `tag_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`article_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO article VALUES("1","KON","2012-02-01","5","1");
INSERT INTO article VALUES("2","SOPOL","2012-02-01","5.04","2");
INSERT INTO article VALUES("3","KRAVA","2012-02-01","5.04","3");





CREATE TABLE `cat_tag` (
  `cat_id` int(11) DEFAULT NULL,
  `tag_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO cat_tag VALUES("1","2");
INSERT INTO cat_tag VALUES("1","3");
INSERT INTO cat_tag VALUES("2","1");





CREATE TABLE `category` (
  `category_id` int(11) NOT NULL AUTO_INCREMENT,
  `date_created_on` date DEFAULT NULL,
  `priority` double DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`category_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO category VALUES("1","2012-12-03","1.5","3");
INSERT INTO category VALUES("2","2012-05-12","1.26","1");
INSERT INTO category VALUES("3","2012-09-02","1.05","2");





CREATE TABLE `tag_part1` (
  `tag1_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` double DEFAULT NULL,
  PRIMARY KEY (`tag1_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO tag_part1 VALUES("1","0");
INSERT INTO tag_part1 VALUES("2","0");
INSERT INTO tag_part1 VALUES("3","0");





CREATE TABLE `tag_part2` (
  `tag_id` int(11) NOT NULL AUTO_INCREMENT,
  `priority` int(11) DEFAULT NULL,
  PRIMARY KEY (`tag_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO tag_part2 VALUES("1","28");
INSERT INTO tag_part2 VALUES("2","26");
INSERT INTO tag_part2 VALUES("3","92");





CREATE TABLE `user` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `password` varchar(20) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL,
  `age` int(11) DEFAULT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

INSERT INTO user VALUES("1","gfhjk","GOGO","21");
INSERT INTO user VALUES("2","grdthfyukj","PACO","152");



--------------------------------------------------------------------------Sunday 13th of April 2014 06:41:50 PM

CREATE TABLE `article` (
  `article_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(20) DEFAULT NULL,
  `created_on` date DEFAULT NULL,
  `price` varchar(20) DEFAULT NULL,
  `tag_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`article_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO article VALUES("1","KON","2012-02-01","5","1");
INSERT INTO article VALUES("2","SOPOL","2012-02-01","5.04","2");
INSERT INTO article VALUES("3","KRAVA","2012-02-01","5.04","3");





CREATE TABLE `cat_tag` (
  `cat_id` int(11) DEFAULT NULL,
  `tag_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO cat_tag VALUES("1","2");
INSERT INTO cat_tag VALUES("1","3");
INSERT INTO cat_tag VALUES("2","1");





CREATE TABLE `category` (
  `category_id` int(11) NOT NULL AUTO_INCREMENT,
  `date_created_on` date DEFAULT NULL,
  `priority` double DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`category_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO category VALUES("1","2012-12-03","1.5","3");
INSERT INTO category VALUES("2","2012-05-12","1.26","1");
INSERT INTO category VALUES("3","2012-09-02","1.05","2");





CREATE TABLE `tag_part1` (
  `tag1_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` double DEFAULT NULL,
  PRIMARY KEY (`tag1_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO tag_part1 VALUES("1","0");
INSERT INTO tag_part1 VALUES("2","0");
INSERT INTO tag_part1 VALUES("3","0");





CREATE TABLE `tag_part2` (
  `tag_id` int(11) NOT NULL AUTO_INCREMENT,
  `priority` int(11) DEFAULT NULL,
  PRIMARY KEY (`tag_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO tag_part2 VALUES("1","28");
INSERT INTO tag_part2 VALUES("2","26");
INSERT INTO tag_part2 VALUES("3","92");





CREATE TABLE `user` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `password` varchar(20) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL,
  `age` int(11) DEFAULT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

INSERT INTO user VALUES("1","gfhjk","GOGO","21");
INSERT INTO user VALUES("2","grdthfyukj","PACO","152");



--------------------------------------------------------------------------Sunday 13th of April 2014 06:43:00 PM

CREATE TABLE `article` (
  `article_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(20) DEFAULT NULL,
  `created_on` date DEFAULT NULL,
  `price` varchar(20) DEFAULT NULL,
  `tag_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`article_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO article VALUES("1","KON","2012-02-01","5","1");
INSERT INTO article VALUES("2","SOPOL","2012-02-01","5.04","2");
INSERT INTO article VALUES("3","KRAVA","2012-02-01","5.04","3");





CREATE TABLE `cat_tag` (
  `cat_id` int(11) DEFAULT NULL,
  `tag_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO cat_tag VALUES("1","2");
INSERT INTO cat_tag VALUES("1","3");
INSERT INTO cat_tag VALUES("2","1");





CREATE TABLE `category` (
  `category_id` int(11) NOT NULL AUTO_INCREMENT,
  `date_created_on` date DEFAULT NULL,
  `priority` double DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`category_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO category VALUES("1","2012-12-03","1.5","3");
INSERT INTO category VALUES("2","2012-05-12","1.26","1");
INSERT INTO category VALUES("3","2012-09-02","1.05","2");





CREATE TABLE `tag_part1` (
  `tag1_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` double DEFAULT NULL,
  PRIMARY KEY (`tag1_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO tag_part1 VALUES("1","0");
INSERT INTO tag_part1 VALUES("2","0");
INSERT INTO tag_part1 VALUES("3","0");





CREATE TABLE `tag_part2` (
  `tag_id` int(11) NOT NULL AUTO_INCREMENT,
  `priority` int(11) DEFAULT NULL,
  PRIMARY KEY (`tag_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO tag_part2 VALUES("1","28");
INSERT INTO tag_part2 VALUES("2","26");
INSERT INTO tag_part2 VALUES("3","92");





CREATE TABLE `user` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `password` varchar(20) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL,
  `age` int(11) DEFAULT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO user VALUES("1","gfhjk","GOGO","21");
INSERT INTO user VALUES("2","grdthfyukj","PACO","152");
INSERT INTO user VALUES("3","fghj","fghjkl","12");



--------------------------------------------------------------------------Sunday 13th of April 2014 06:44:38 PM