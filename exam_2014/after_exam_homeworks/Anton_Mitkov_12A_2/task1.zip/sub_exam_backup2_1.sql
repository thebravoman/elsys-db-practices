

CREATE TABLE `article_part1` (
  `art_part1_id` int(11) NOT NULL AUTO_INCREMENT,
  `created_on` date DEFAULT NULL,
  PRIMARY KEY (`art_part1_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO article_part1 VALUES("1","2012-02-01");
INSERT INTO article_part1 VALUES("2","2012-02-01");
INSERT INTO article_part1 VALUES("3","2012-02-01");





CREATE TABLE `article_part2` (
  `article_id` int(11) NOT NULL AUTO_INCREMENT,
  `price` float DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL,
  `tag_id` int(11) DEFAULT NULL,
  `cat_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`article_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO article_part2 VALUES("1","5.04","blala","1","1");
INSERT INTO article_part2 VALUES("2","5.04","blala","2","2");
INSERT INTO article_part2 VALUES("3","5.04","blala","3","3");





CREATE TABLE `category` (
  `category_id` int(11) NOT NULL AUTO_INCREMENT,
  `date_created_on` date DEFAULT NULL,
  `priority` double DEFAULT NULL,
  PRIMARY KEY (`category_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO category VALUES("1","2012-12-03","2");
INSERT INTO category VALUES("2","2012-05-12","2");
INSERT INTO category VALUES("3","2012-09-02","1");





CREATE TABLE `tag` (
  `tag_id` int(11) NOT NULL AUTO_INCREMENT,
  `description` varchar(200) DEFAULT NULL,
  `priority` int(11) DEFAULT NULL,
  PRIMARY KEY (`tag_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO tag VALUES("1","kon","2");
INSERT INTO tag VALUES("2","sopol","1");
INSERT INTO tag VALUES("3","gevrek","3");





CREATE TABLE `user` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `description` varchar(200) DEFAULT NULL,
  `income` float DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL,
  `cat_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;




--------------------------------------------------------------------------Sunday 13th of April 2014 06:56:00 PM