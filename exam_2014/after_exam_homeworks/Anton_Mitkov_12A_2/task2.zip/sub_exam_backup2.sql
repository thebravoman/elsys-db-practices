

CREATE TABLE `article` (
  `article_id` int(11) NOT NULL AUTO_INCREMENT,
  `price` varchar(20) DEFAULT NULL,
  `create_on` date DEFAULT NULL,
  `content` int(11) DEFAULT NULL,
  `tag_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`article_id`),
  UNIQUE KEY `tag_id` (`tag_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;






CREATE TABLE `cat_user` (
  `cat_id` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;






CREATE TABLE `category` (
  `category_id` int(11) NOT NULL AUTO_INCREMENT,
  `priority` double DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`category_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;






CREATE TABLE `tag` (
  `tag_id` int(11) NOT NULL AUTO_INCREMENT,
  `description` varchar(220) DEFAULT NULL,
  `second_priority` float DEFAULT NULL,
  `cat_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`tag_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;






CREATE TABLE `user` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `description` varchar(200) DEFAULT NULL,
  `created_on` date DEFAULT NULL,
  `password` varchar(90) DEFAULT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;




--------------------------------------------------------------------------Saturday 12th of April 2014 10:45:39 AM

CREATE TABLE `article` (
  `article_id` int(11) NOT NULL AUTO_INCREMENT,
  `price` varchar(20) DEFAULT NULL,
  `create_on` date DEFAULT NULL,
  `content` int(11) DEFAULT NULL,
  `tag_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`article_id`),
  UNIQUE KEY `tag_id` (`tag_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;






CREATE TABLE `cat_user` (
  `cat_id` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO cat_user VALUES("1","2");
INSERT INTO cat_user VALUES("1","1");
INSERT INTO cat_user VALUES("2","3");





CREATE TABLE `category` (
  `category_id` int(11) NOT NULL AUTO_INCREMENT,
  `priority` double DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`category_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO category VALUES("1","2012","Krimi");
INSERT INTO category VALUES("2","2012","Biznes");
INSERT INTO category VALUES("3","2012","Sport");





CREATE TABLE `tag` (
  `tag_id` int(11) NOT NULL AUTO_INCREMENT,
  `description` varchar(220) DEFAULT NULL,
  `second_priority` float DEFAULT NULL,
  `cat_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`tag_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO tag VALUES("1","kon","2.15","2");
INSERT INTO tag VALUES("2","sopol","1.89","1");
INSERT INTO tag VALUES("3","gevrek","6.45","3");





CREATE TABLE `user` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `description` varchar(200) DEFAULT NULL,
  `created_on` date DEFAULT NULL,
  `password` varchar(90) DEFAULT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;




--------------------------------------------------------------------------Saturday 12th of April 2014 10:55:03 AM

CREATE TABLE `article` (
  `article_id` int(11) NOT NULL AUTO_INCREMENT,
  `price` varchar(20) DEFAULT NULL,
  `create_on` date DEFAULT NULL,
  `content` int(11) DEFAULT NULL,
  `tag_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`article_id`),
  UNIQUE KEY `tag_id` (`tag_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;






CREATE TABLE `cat_user` (
  `cat_id` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO cat_user VALUES("1","2");
INSERT INTO cat_user VALUES("1","1");
INSERT INTO cat_user VALUES("2","3");





CREATE TABLE `category` (
  `category_id` int(11) NOT NULL AUTO_INCREMENT,
  `priority` double DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`category_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO category VALUES("1","2012","Krimi");
INSERT INTO category VALUES("2","2012","Biznes");
INSERT INTO category VALUES("3","2012","Sport");





CREATE TABLE `tag` (
  `tag_id` int(11) NOT NULL AUTO_INCREMENT,
  `description` varchar(220) DEFAULT NULL,
  `second_priority` float DEFAULT NULL,
  `cat_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`tag_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO tag VALUES("1","kon","2.15","2");
INSERT INTO tag VALUES("2","sopol","1.89","1");
INSERT INTO tag VALUES("3","gevrek","6.45","3");





CREATE TABLE `user` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `description` varchar(200) DEFAULT NULL,
  `created_on` date DEFAULT NULL,
  `password` varchar(90) DEFAULT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;




--------------------------------------------------------------------------Saturday 12th of April 2014 10:59:47 AM

CREATE TABLE `article` (
  `article_id` int(11) NOT NULL AUTO_INCREMENT,
  `price` varchar(20) DEFAULT NULL,
  `create_on` date DEFAULT NULL,
  `content` int(11) DEFAULT NULL,
  `tag_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`article_id`),
  UNIQUE KEY `tag_id` (`tag_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;






CREATE TABLE `cat_user` (
  `cat_id` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO cat_user VALUES("1","2");
INSERT INTO cat_user VALUES("1","1");
INSERT INTO cat_user VALUES("2","3");





CREATE TABLE `category` (
  `category_id` int(11) NOT NULL AUTO_INCREMENT,
  `priority` double DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`category_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO category VALUES("1","2012","Krimi");
INSERT INTO category VALUES("2","2012","Biznes");
INSERT INTO category VALUES("3","2012","Sport");





CREATE TABLE `tag` (
  `tag_id` int(11) NOT NULL AUTO_INCREMENT,
  `description` varchar(220) DEFAULT NULL,
  `second_priority` float DEFAULT NULL,
  `cat_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`tag_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO tag VALUES("1","kon","2.15","2");
INSERT INTO tag VALUES("2","sopol","1.89","1");
INSERT INTO tag VALUES("3","gevrek","6.45","3");





CREATE TABLE `user` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `description` varchar(200) DEFAULT NULL,
  `created_on` date DEFAULT NULL,
  `password` varchar(90) DEFAULT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;




--------------------------------------------------------------------------Saturday 12th of April 2014 11:01:52 AM

CREATE TABLE `article` (
  `article_id` int(11) NOT NULL AUTO_INCREMENT,
  `price` varchar(20) DEFAULT NULL,
  `create_on` date DEFAULT NULL,
  `content` int(11) DEFAULT NULL,
  `tag_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`article_id`),
  UNIQUE KEY `tag_id` (`tag_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;






CREATE TABLE `cat_user` (
  `cat_id` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO cat_user VALUES("1","2");
INSERT INTO cat_user VALUES("1","1");
INSERT INTO cat_user VALUES("2","3");





CREATE TABLE `category` (
  `category_id` int(11) NOT NULL AUTO_INCREMENT,
  `priority` double DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`category_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO category VALUES("1","2012","Krimi");
INSERT INTO category VALUES("2","2012","Biznes");
INSERT INTO category VALUES("3","2012","Sport");





CREATE TABLE `tag` (
  `tag_id` int(11) NOT NULL AUTO_INCREMENT,
  `description` varchar(220) DEFAULT NULL,
  `second_priority` float DEFAULT NULL,
  `cat_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`tag_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO tag VALUES("1","kon","2.15","2");
INSERT INTO tag VALUES("2","sopol","1.89","1");
INSERT INTO tag VALUES("3","gevrek","6.45","3");





CREATE TABLE `user` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `description` varchar(200) DEFAULT NULL,
  `created_on` date DEFAULT NULL,
  `password` varchar(90) DEFAULT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;




--------------------------------------------------------------------------Saturday 12th of April 2014 11:01:55 AM

CREATE TABLE `article` (
  `article_id` int(11) NOT NULL AUTO_INCREMENT,
  `price` varchar(20) DEFAULT NULL,
  `create_on` date DEFAULT NULL,
  `content` int(11) DEFAULT NULL,
  `tag_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`article_id`),
  UNIQUE KEY `tag_id` (`tag_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;






CREATE TABLE `cat_user` (
  `cat_id` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO cat_user VALUES("1","2");
INSERT INTO cat_user VALUES("1","1");
INSERT INTO cat_user VALUES("2","3");





CREATE TABLE `category` (
  `category_id` int(11) NOT NULL AUTO_INCREMENT,
  `priority` double DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`category_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO category VALUES("1","2012","Krimi");
INSERT INTO category VALUES("2","2012","Biznes");
INSERT INTO category VALUES("3","2012","Sport");





CREATE TABLE `tag` (
  `tag_id` int(11) NOT NULL AUTO_INCREMENT,
  `description` varchar(220) DEFAULT NULL,
  `second_priority` float DEFAULT NULL,
  `cat_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`tag_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO tag VALUES("1","kon","2.15","2");
INSERT INTO tag VALUES("2","sopol","1.89","1");
INSERT INTO tag VALUES("3","gevrek","6.45","3");





CREATE TABLE `user` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `description` varchar(200) DEFAULT NULL,
  `created_on` date DEFAULT NULL,
  `password` varchar(90) DEFAULT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;




--------------------------------------------------------------------------Saturday 12th of April 2014 11:05:48 AM

CREATE TABLE `article` (
  `article_id` int(11) NOT NULL AUTO_INCREMENT,
  `price` varchar(20) DEFAULT NULL,
  `create_on` date DEFAULT NULL,
  `content` int(11) DEFAULT NULL,
  `tag_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`article_id`),
  UNIQUE KEY `tag_id` (`tag_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;






CREATE TABLE `cat_user` (
  `cat_id` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO cat_user VALUES("1","2");
INSERT INTO cat_user VALUES("1","1");
INSERT INTO cat_user VALUES("2","3");





CREATE TABLE `category` (
  `category_id` int(11) NOT NULL AUTO_INCREMENT,
  `priority` double DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`category_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO category VALUES("1","2012","Krimi");
INSERT INTO category VALUES("2","2012","Biznes");
INSERT INTO category VALUES("3","2012","Sport");





CREATE TABLE `tag` (
  `tag_id` int(11) NOT NULL AUTO_INCREMENT,
  `description` varchar(220) DEFAULT NULL,
  `second_priority` float DEFAULT NULL,
  `cat_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`tag_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO tag VALUES("1","kon","2.15","2");
INSERT INTO tag VALUES("2","sopol","1.89","1");
INSERT INTO tag VALUES("3","gevrek","6.45","3");





CREATE TABLE `user` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `description` varchar(200) DEFAULT NULL,
  `created_on` date DEFAULT NULL,
  `password` varchar(90) DEFAULT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;




--------------------------------------------------------------------------Saturday 12th of April 2014 11:05:55 AM

CREATE TABLE `article` (
  `article_id` int(11) NOT NULL AUTO_INCREMENT,
  `price` varchar(20) DEFAULT NULL,
  `create_on` date DEFAULT NULL,
  `content` int(11) DEFAULT NULL,
  `tag_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`article_id`),
  UNIQUE KEY `tag_id` (`tag_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;






CREATE TABLE `cat_user` (
  `cat_id` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO cat_user VALUES("1","2");
INSERT INTO cat_user VALUES("1","1");
INSERT INTO cat_user VALUES("2","3");





CREATE TABLE `category` (
  `category_id` int(11) NOT NULL AUTO_INCREMENT,
  `priority` double DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`category_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO category VALUES("1","2012","Krimi");
INSERT INTO category VALUES("2","2012","Biznes");
INSERT INTO category VALUES("3","2012","Sport");





CREATE TABLE `tag` (
  `tag_id` int(11) NOT NULL AUTO_INCREMENT,
  `description` varchar(220) DEFAULT NULL,
  `second_priority` float DEFAULT NULL,
  `cat_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`tag_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO tag VALUES("1","kon","2.15","2");
INSERT INTO tag VALUES("2","sopol","1.89","1");
INSERT INTO tag VALUES("3","gevrek","6.45","3");





CREATE TABLE `user` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `description` varchar(200) DEFAULT NULL,
  `created_on` date DEFAULT NULL,
  `password` varchar(90) DEFAULT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;




--------------------------------------------------------------------------Saturday 12th of April 2014 11:10:37 AM

CREATE TABLE `article` (
  `article_id` int(11) NOT NULL AUTO_INCREMENT,
  `price` varchar(20) DEFAULT NULL,
  `create_on` date DEFAULT NULL,
  `content` int(11) DEFAULT NULL,
  `tag_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`article_id`),
  UNIQUE KEY `tag_id` (`tag_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;






CREATE TABLE `cat_user` (
  `cat_id` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO cat_user VALUES("1","2");
INSERT INTO cat_user VALUES("1","1");
INSERT INTO cat_user VALUES("2","3");





CREATE TABLE `category` (
  `category_id` int(11) NOT NULL AUTO_INCREMENT,
  `priority` double DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`category_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO category VALUES("1","2012","Krimi");
INSERT INTO category VALUES("2","2012","Biznes");
INSERT INTO category VALUES("3","2012","Sport");





CREATE TABLE `tag` (
  `tag_id` int(11) NOT NULL AUTO_INCREMENT,
  `description` varchar(220) DEFAULT NULL,
  `second_priority` float DEFAULT NULL,
  `cat_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`tag_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO tag VALUES("1","kon","2.15","2");
INSERT INTO tag VALUES("2","sopol","1.89","1");
INSERT INTO tag VALUES("3","gevrek","6.45","3");





CREATE TABLE `user` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `description` varchar(200) DEFAULT NULL,
  `created_on` date DEFAULT NULL,
  `password` varchar(90) DEFAULT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;




--------------------------------------------------------------------------Saturday 12th of April 2014 11:12:20 AM

CREATE TABLE `article` (
  `article_id` int(11) NOT NULL AUTO_INCREMENT,
  `price` varchar(20) DEFAULT NULL,
  `create_on` date DEFAULT NULL,
  `content` int(11) DEFAULT NULL,
  `tag_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`article_id`),
  UNIQUE KEY `tag_id` (`tag_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;






CREATE TABLE `cat_user` (
  `cat_id` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO cat_user VALUES("1","2");
INSERT INTO cat_user VALUES("1","1");
INSERT INTO cat_user VALUES("2","3");





CREATE TABLE `category` (
  `category_id` int(11) NOT NULL AUTO_INCREMENT,
  `priority` double DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`category_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO category VALUES("1","2012","Krimi");
INSERT INTO category VALUES("2","2012","Biznes");
INSERT INTO category VALUES("3","2012","Sport");





CREATE TABLE `tag` (
  `tag_id` int(11) NOT NULL AUTO_INCREMENT,
  `description` varchar(220) DEFAULT NULL,
  `second_priority` float DEFAULT NULL,
  `cat_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`tag_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO tag VALUES("1","kon","2.15","2");
INSERT INTO tag VALUES("2","sopol","1.89","1");
INSERT INTO tag VALUES("3","gevrek","6.45","3");





CREATE TABLE `user` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `description` varchar(200) DEFAULT NULL,
  `created_on` date DEFAULT NULL,
  `password` varchar(90) DEFAULT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;




--------------------------------------------------------------------------Saturday 12th of April 2014 11:12:24 AM

CREATE TABLE `article` (
  `article_id` int(11) NOT NULL AUTO_INCREMENT,
  `price` varchar(20) DEFAULT NULL,
  `create_on` date DEFAULT NULL,
  `content` int(11) DEFAULT NULL,
  `tag_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`article_id`),
  UNIQUE KEY `tag_id` (`tag_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;






CREATE TABLE `cat_user` (
  `cat_id` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO cat_user VALUES("1","2");
INSERT INTO cat_user VALUES("1","1");
INSERT INTO cat_user VALUES("2","3");





CREATE TABLE `category` (
  `category_id` int(11) NOT NULL AUTO_INCREMENT,
  `priority` double DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`category_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO category VALUES("1","2012","Krimi");
INSERT INTO category VALUES("2","2012","Biznes");
INSERT INTO category VALUES("3","2012","Sport");





CREATE TABLE `tag` (
  `tag_id` int(11) NOT NULL AUTO_INCREMENT,
  `description` varchar(220) DEFAULT NULL,
  `second_priority` float DEFAULT NULL,
  `cat_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`tag_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO tag VALUES("1","kon","2.15","2");
INSERT INTO tag VALUES("2","sopol","1.89","1");
INSERT INTO tag VALUES("3","gevrek","6.45","3");





CREATE TABLE `user` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `description` varchar(200) DEFAULT NULL,
  `created_on` date DEFAULT NULL,
  `password` varchar(90) DEFAULT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;




--------------------------------------------------------------------------Saturday 12th of April 2014 11:12:40 AM

CREATE TABLE `article` (
  `article_id` int(11) NOT NULL AUTO_INCREMENT,
  `price` varchar(20) DEFAULT NULL,
  `create_on` date DEFAULT NULL,
  `content` int(11) DEFAULT NULL,
  `tag_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`article_id`),
  UNIQUE KEY `tag_id` (`tag_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;






CREATE TABLE `cat_user` (
  `cat_id` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO cat_user VALUES("1","2");
INSERT INTO cat_user VALUES("1","1");
INSERT INTO cat_user VALUES("2","3");





CREATE TABLE `category` (
  `category_id` int(11) NOT NULL AUTO_INCREMENT,
  `priority` double DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`category_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO category VALUES("1","2012","Krimi");
INSERT INTO category VALUES("2","2012","Biznes");
INSERT INTO category VALUES("3","2012","Sport");





CREATE TABLE `tag` (
  `tag_id` int(11) NOT NULL AUTO_INCREMENT,
  `description` varchar(220) DEFAULT NULL,
  `second_priority` float DEFAULT NULL,
  `cat_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`tag_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO tag VALUES("1","kon","2.15","2");
INSERT INTO tag VALUES("2","sopol","1.89","1");
INSERT INTO tag VALUES("3","gevrek","6.45","3");





CREATE TABLE `user` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `description` varchar(200) DEFAULT NULL,
  `created_on` date DEFAULT NULL,
  `password` varchar(90) DEFAULT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;




--------------------------------------------------------------------------Saturday 12th of April 2014 11:51:21 AM

CREATE TABLE `article` (
  `article_id` int(11) NOT NULL AUTO_INCREMENT,
  `price` varchar(20) DEFAULT NULL,
  `create_on` date DEFAULT NULL,
  `content` int(11) DEFAULT NULL,
  `tag_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`article_id`),
  UNIQUE KEY `tag_id` (`tag_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;






CREATE TABLE `cat_user` (
  `cat_id` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO cat_user VALUES("1","2");
INSERT INTO cat_user VALUES("1","1");
INSERT INTO cat_user VALUES("2","3");





CREATE TABLE `category` (
  `category_id` int(11) NOT NULL AUTO_INCREMENT,
  `priority` double DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`category_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO category VALUES("1","2012","Krimi");
INSERT INTO category VALUES("2","2012","Biznes");
INSERT INTO category VALUES("3","2012","Sport");





CREATE TABLE `tag1` (
  `tag1_id` int(11) NOT NULL AUTO_INCREMENT,
  `description` date DEFAULT NULL,
  PRIMARY KEY (`tag1_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO tag1 VALUES("1","0000-00-00");
INSERT INTO tag1 VALUES("2","0000-00-00");
INSERT INTO tag1 VALUES("3","0000-00-00");





CREATE TABLE `tag2` (
  `tag_id` int(11) NOT NULL AUTO_INCREMENT,
  `second_priority` float DEFAULT NULL,
  `cat_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`tag_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO tag2 VALUES("1","2.15","2");
INSERT INTO tag2 VALUES("2","1.89","1");
INSERT INTO tag2 VALUES("3","6.45","3");





CREATE TABLE `user` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `description` varchar(200) DEFAULT NULL,
  `created_on` date DEFAULT NULL,
  `password` varchar(90) DEFAULT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;




--------------------------------------------------------------------------Saturday 12th of April 2014 12:14:01 PM

CREATE TABLE `article` (
  `article_id` int(11) NOT NULL AUTO_INCREMENT,
  `price` varchar(20) DEFAULT NULL,
  `create_on` date DEFAULT NULL,
  `content` int(11) DEFAULT NULL,
  `tag_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`article_id`),
  UNIQUE KEY `tag_id` (`tag_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;






CREATE TABLE `cat_user` (
  `cat_id` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO cat_user VALUES("1","2");
INSERT INTO cat_user VALUES("1","1");
INSERT INTO cat_user VALUES("2","3");





CREATE TABLE `category` (
  `category_id` int(11) NOT NULL AUTO_INCREMENT,
  `priority` double DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`category_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO category VALUES("1","2012","Krimi");
INSERT INTO category VALUES("2","2012","Biznes");
INSERT INTO category VALUES("3","2012","Sport");





CREATE TABLE `tag1` (
  `tag1_id` int(11) NOT NULL AUTO_INCREMENT,
  `description` date DEFAULT NULL,
  PRIMARY KEY (`tag1_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO tag1 VALUES("1","0000-00-00");
INSERT INTO tag1 VALUES("2","0000-00-00");
INSERT INTO tag1 VALUES("3","0000-00-00");





CREATE TABLE `tag2` (
  `tag_id` int(11) NOT NULL AUTO_INCREMENT,
  `second_priority` float DEFAULT NULL,
  `cat_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`tag_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO tag2 VALUES("1","2.15","2");
INSERT INTO tag2 VALUES("2","1.89","1");
INSERT INTO tag2 VALUES("3","6.45","3");





CREATE TABLE `user` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `description` varchar(200) DEFAULT NULL,
  `created_on` date DEFAULT NULL,
  `password` varchar(90) DEFAULT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;




--------------------------------------------------------------------------Saturday 12th of April 2014 12:27:19 PM

CREATE TABLE `article` (
  `article_id` int(11) NOT NULL AUTO_INCREMENT,
  `price` varchar(20) DEFAULT NULL,
  `create_on` date DEFAULT NULL,
  `content` int(11) DEFAULT NULL,
  `tag_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`article_id`),
  UNIQUE KEY `tag_id` (`tag_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;






CREATE TABLE `cat_user` (
  `cat_id` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO cat_user VALUES("1","2");
INSERT INTO cat_user VALUES("1","1");
INSERT INTO cat_user VALUES("2","3");





CREATE TABLE `category` (
  `category_id` int(11) NOT NULL AUTO_INCREMENT,
  `priority` double DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`category_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO category VALUES("1","2012","Krimi");
INSERT INTO category VALUES("2","2012","Biznes");
INSERT INTO category VALUES("3","2012","Sport");





CREATE TABLE `tag1` (
  `tag1_id` int(11) NOT NULL AUTO_INCREMENT,
  `description` date DEFAULT NULL,
  PRIMARY KEY (`tag1_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO tag1 VALUES("1","0000-00-00");
INSERT INTO tag1 VALUES("2","0000-00-00");
INSERT INTO tag1 VALUES("3","0000-00-00");





CREATE TABLE `tag2` (
  `tag_id` int(11) NOT NULL AUTO_INCREMENT,
  `second_priority` float DEFAULT NULL,
  `cat_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`tag_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO tag2 VALUES("1","2.15","2");
INSERT INTO tag2 VALUES("2","1.89","1");
INSERT INTO tag2 VALUES("3","6.45","3");





CREATE TABLE `user` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `description` varchar(200) DEFAULT NULL,
  `created_on` date DEFAULT NULL,
  `password` varchar(90) DEFAULT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;




--------------------------------------------------------------------------Saturday 12th of April 2014 12:33:19 PM

CREATE TABLE `article` (
  `article_id` int(11) NOT NULL AUTO_INCREMENT,
  `price` varchar(20) DEFAULT NULL,
  `create_on` date DEFAULT NULL,
  `content` int(11) DEFAULT NULL,
  `tag_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`article_id`),
  UNIQUE KEY `tag_id` (`tag_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;






CREATE TABLE `cat_user` (
  `cat_id` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO cat_user VALUES("1","2");
INSERT INTO cat_user VALUES("1","1");
INSERT INTO cat_user VALUES("2","3");





CREATE TABLE `category` (
  `category_id` int(11) NOT NULL AUTO_INCREMENT,
  `priority` double DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`category_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO category VALUES("1","2012","Krimi");
INSERT INTO category VALUES("2","2012","Biznes");
INSERT INTO category VALUES("3","2012","Sport");





CREATE TABLE `tag1` (
  `tag1_id` int(11) NOT NULL AUTO_INCREMENT,
  `description` date DEFAULT NULL,
  PRIMARY KEY (`tag1_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO tag1 VALUES("1","0000-00-00");
INSERT INTO tag1 VALUES("2","0000-00-00");
INSERT INTO tag1 VALUES("3","0000-00-00");





CREATE TABLE `tag2` (
  `tag_id` int(11) NOT NULL AUTO_INCREMENT,
  `second_priority` float DEFAULT NULL,
  `cat_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`tag_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO tag2 VALUES("1","2.15","2");
INSERT INTO tag2 VALUES("2","1.89","1");
INSERT INTO tag2 VALUES("3","6.45","3");





CREATE TABLE `user` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `description` varchar(200) DEFAULT NULL,
  `created_on` date DEFAULT NULL,
  `password` varchar(90) DEFAULT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

INSERT INTO user VALUES("1","gfhjk","2012-12-03","GOGO");
INSERT INTO user VALUES("2","grdthfyukj","2012-05-12","PACO");



--------------------------------------------------------------------------Saturday 12th of April 2014 12:33:58 PM

CREATE TABLE `article` (
  `article_id` int(11) NOT NULL AUTO_INCREMENT,
  `price` varchar(20) DEFAULT NULL,
  `create_on` date DEFAULT NULL,
  `content` int(11) DEFAULT NULL,
  `tag_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`article_id`),
  UNIQUE KEY `tag_id` (`tag_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;






CREATE TABLE `cat_user` (
  `cat_id` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO cat_user VALUES("1","2");
INSERT INTO cat_user VALUES("1","1");
INSERT INTO cat_user VALUES("2","3");





CREATE TABLE `category` (
  `category_id` int(11) NOT NULL AUTO_INCREMENT,
  `priority` double DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`category_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO category VALUES("1","2012","Krimi");
INSERT INTO category VALUES("2","2012","Biznes");
INSERT INTO category VALUES("3","2012","Sport");





CREATE TABLE `tag1` (
  `tag1_id` int(11) NOT NULL AUTO_INCREMENT,
  `description` date DEFAULT NULL,
  PRIMARY KEY (`tag1_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO tag1 VALUES("1","0000-00-00");
INSERT INTO tag1 VALUES("2","0000-00-00");
INSERT INTO tag1 VALUES("3","0000-00-00");





CREATE TABLE `tag2` (
  `tag_id` int(11) NOT NULL AUTO_INCREMENT,
  `second_priority` float DEFAULT NULL,
  `cat_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`tag_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO tag2 VALUES("1","2.15","2");
INSERT INTO tag2 VALUES("2","1.89","1");
INSERT INTO tag2 VALUES("3","6.45","3");





CREATE TABLE `user` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `description` varchar(200) DEFAULT NULL,
  `created_on` date DEFAULT NULL,
  `password` varchar(90) DEFAULT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

INSERT INTO user VALUES("1","gfhjk","2012-12-03","GOGO");
INSERT INTO user VALUES("2","grdthfyukj","2012-05-12","PACO");



--------------------------------------------------------------------------Saturday 12th of April 2014 12:34:30 PM

CREATE TABLE `article` (
  `article_id` int(11) NOT NULL AUTO_INCREMENT,
  `price` varchar(20) DEFAULT NULL,
  `create_on` date DEFAULT NULL,
  `content` int(11) DEFAULT NULL,
  `tag_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`article_id`),
  UNIQUE KEY `tag_id` (`tag_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;






CREATE TABLE `cat_user` (
  `cat_id` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO cat_user VALUES("1","2");
INSERT INTO cat_user VALUES("1","1");
INSERT INTO cat_user VALUES("2","3");





CREATE TABLE `category` (
  `category_id` int(11) NOT NULL AUTO_INCREMENT,
  `priority` double DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`category_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO category VALUES("1","2012","Krimi");
INSERT INTO category VALUES("2","2012","Biznes");
INSERT INTO category VALUES("3","2012","Sport");





CREATE TABLE `tag1` (
  `tag1_id` int(11) NOT NULL AUTO_INCREMENT,
  `description` date DEFAULT NULL,
  PRIMARY KEY (`tag1_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO tag1 VALUES("1","0000-00-00");
INSERT INTO tag1 VALUES("2","0000-00-00");
INSERT INTO tag1 VALUES("3","0000-00-00");





CREATE TABLE `tag2` (
  `tag_id` int(11) NOT NULL AUTO_INCREMENT,
  `second_priority` float DEFAULT NULL,
  `cat_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`tag_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO tag2 VALUES("1","2.15","2");
INSERT INTO tag2 VALUES("2","1.89","1");
INSERT INTO tag2 VALUES("3","6.45","3");





CREATE TABLE `user` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `description` varchar(200) DEFAULT NULL,
  `created_on` date DEFAULT NULL,
  `password` varchar(90) DEFAULT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

INSERT INTO user VALUES("1","gfhjk","2012-12-03","GOGO");
INSERT INTO user VALUES("2","grdthfyukj","2012-05-12","PACO");



--------------------------------------------------------------------------Saturday 12th of April 2014 12:37:06 PM

CREATE TABLE `article` (
  `article_id` int(11) NOT NULL AUTO_INCREMENT,
  `price` varchar(20) DEFAULT NULL,
  `create_on` date DEFAULT NULL,
  `content` int(11) DEFAULT NULL,
  `tag_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`article_id`),
  UNIQUE KEY `tag_id` (`tag_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;






CREATE TABLE `cat_user` (
  `cat_id` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO cat_user VALUES("1","2");
INSERT INTO cat_user VALUES("1","1");
INSERT INTO cat_user VALUES("2","3");





CREATE TABLE `category` (
  `category_id` int(11) NOT NULL AUTO_INCREMENT,
  `priority` double DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`category_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO category VALUES("1","2012","Krimi");
INSERT INTO category VALUES("2","2012","Biznes");
INSERT INTO category VALUES("3","2012","Sport");





CREATE TABLE `tag1` (
  `tag1_id` int(11) NOT NULL AUTO_INCREMENT,
  `description` date DEFAULT NULL,
  PRIMARY KEY (`tag1_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO tag1 VALUES("1","0000-00-00");
INSERT INTO tag1 VALUES("2","0000-00-00");
INSERT INTO tag1 VALUES("3","0000-00-00");





CREATE TABLE `tag2` (
  `tag_id` int(11) NOT NULL AUTO_INCREMENT,
  `second_priority` float DEFAULT NULL,
  `cat_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`tag_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO tag2 VALUES("1","2.15","2");
INSERT INTO tag2 VALUES("2","1.89","1");
INSERT INTO tag2 VALUES("3","6.45","3");





CREATE TABLE `user` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `description` varchar(200) DEFAULT NULL,
  `created_on` date DEFAULT NULL,
  `password` varchar(90) DEFAULT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

INSERT INTO user VALUES("1","gfhjk","2012-12-03","GOGO");
INSERT INTO user VALUES("2","grdthfyukj","2012-05-12","PACO");



--------------------------------------------------------------------------Saturday 12th of April 2014 12:38:51 PM