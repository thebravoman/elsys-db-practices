

CREATE TABLE `article` (
  `article_id` int(11) NOT NULL AUTO_INCREMENT,
  `published_on` date DEFAULT NULL,
  `price` varchar(20) DEFAULT NULL,
  `content` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`article_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;






CREATE TABLE `cat_tag` (
  `cat_id` int(11) DEFAULT NULL,
  `tag_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;






CREATE TABLE `cat_user` (
  `cat_id` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;






CREATE TABLE `category` (
  `category_id` int(11) NOT NULL AUTO_INCREMENT,
  `priority` double DEFAULT NULL,
  `description` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`category_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;






CREATE TABLE `tag` (
  `tag_id` int(11) NOT NULL AUTO_INCREMENT,
  `second_priority` float DEFAULT NULL,
  `description` varchar(220) DEFAULT NULL,
  PRIMARY KEY (`tag_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;






CREATE TABLE `user` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `description` varchar(200) DEFAULT NULL,
  `created_on` date DEFAULT NULL,
  `password` varchar(90) DEFAULT NULL,
  `art_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;




--------------------------------------------------------------------------Sunday 13th of April 2014 10:12:46 AM

CREATE TABLE `article` (
  `article_id` int(11) NOT NULL AUTO_INCREMENT,
  `published_on` date DEFAULT NULL,
  `price` varchar(20) DEFAULT NULL,
  `content` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`article_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO article VALUES("1","2012-02-01","5","dsfghjk");
INSERT INTO article VALUES("2","2012-02-01","5.04","asdfghj");
INSERT INTO article VALUES("3","2012-02-01","5.04","qwertyui");





CREATE TABLE `cat_tag` (
  `cat_id` int(11) DEFAULT NULL,
  `tag_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO cat_tag VALUES("1","2");
INSERT INTO cat_tag VALUES("1","3");
INSERT INTO cat_tag VALUES("2","1");





CREATE TABLE `cat_user` (
  `cat_id` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO cat_user VALUES("1","2");
INSERT INTO cat_user VALUES("1","1");
INSERT INTO cat_user VALUES("2","3");





CREATE TABLE `category` (
  `category_id` int(11) NOT NULL AUTO_INCREMENT,
  `priority` double DEFAULT NULL,
  `description` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`category_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO category VALUES("1","2012","Krimi");
INSERT INTO category VALUES("2","2012","Biznes");
INSERT INTO category VALUES("3","2012","Sport");





CREATE TABLE `tag` (
  `tag_id` int(11) NOT NULL AUTO_INCREMENT,
  `second_priority` float DEFAULT NULL,
  `description` varchar(220) DEFAULT NULL,
  PRIMARY KEY (`tag_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO tag VALUES("1","2.15","kon");
INSERT INTO tag VALUES("2","1.89","sopol");
INSERT INTO tag VALUES("3","6.45","gevrek");





CREATE TABLE `user` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `description` varchar(200) DEFAULT NULL,
  `created_on` date DEFAULT NULL,
  `password` varchar(90) DEFAULT NULL,
  `art_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

INSERT INTO user VALUES("1","gfhjk","2012-12-03","GOGO","1");
INSERT INTO user VALUES("2","grdthfyukj","2012-05-12","PACO","2");



--------------------------------------------------------------------------Sunday 13th of April 2014 10:17:50 AM

CREATE TABLE `article` (
  `article_id` int(11) NOT NULL AUTO_INCREMENT,
  `published_on` date DEFAULT NULL,
  `price` varchar(20) DEFAULT NULL,
  `content` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`article_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO article VALUES("1","2012-02-01","5","dsfghjk");
INSERT INTO article VALUES("2","2012-02-01","5.04","asdfghj");
INSERT INTO article VALUES("3","2012-02-01","5.04","qwertyui");





CREATE TABLE `cat_tag` (
  `cat_id` int(11) DEFAULT NULL,
  `tag_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO cat_tag VALUES("1","2");
INSERT INTO cat_tag VALUES("1","3");
INSERT INTO cat_tag VALUES("2","1");





CREATE TABLE `cat_user` (
  `cat_id` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO cat_user VALUES("1","2");
INSERT INTO cat_user VALUES("1","1");
INSERT INTO cat_user VALUES("2","3");





CREATE TABLE `category` (
  `category_id` int(11) NOT NULL AUTO_INCREMENT,
  `priority` double DEFAULT NULL,
  `description` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`category_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO category VALUES("1","2012","Krimi");
INSERT INTO category VALUES("2","2012","Biznes");
INSERT INTO category VALUES("3","2012","Sport");





CREATE TABLE `tag` (
  `tag_id` int(11) NOT NULL AUTO_INCREMENT,
  `second_priority` float DEFAULT NULL,
  `description` varchar(220) DEFAULT NULL,
  PRIMARY KEY (`tag_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO tag VALUES("1","2.15","kon");
INSERT INTO tag VALUES("2","1.89","sopol");
INSERT INTO tag VALUES("3","6.45","gevrek");





CREATE TABLE `user` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `description` varchar(200) DEFAULT NULL,
  `created_on` date DEFAULT NULL,
  `password` varchar(90) DEFAULT NULL,
  `art_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

INSERT INTO user VALUES("1","gfhjk","2012-12-03","GOGO","1");
INSERT INTO user VALUES("2","grdthfyukj","2012-05-12","PACO","2");



--------------------------------------------------------------------------Sunday 13th of April 2014 10:22:20 AM

CREATE TABLE `article` (
  `article_id` int(11) NOT NULL AUTO_INCREMENT,
  `published_on` date DEFAULT NULL,
  `price` varchar(20) DEFAULT NULL,
  `content` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`article_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO article VALUES("1","2012-02-01","5","dsfghjk");
INSERT INTO article VALUES("2","2012-02-01","5.04","asdfghj");
INSERT INTO article VALUES("3","2012-02-01","5.04","qwertyui");





CREATE TABLE `cat_tag` (
  `cat_id` int(11) DEFAULT NULL,
  `tag_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO cat_tag VALUES("1","2");
INSERT INTO cat_tag VALUES("1","3");
INSERT INTO cat_tag VALUES("2","1");





CREATE TABLE `cat_user` (
  `cat_id` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO cat_user VALUES("1","2");
INSERT INTO cat_user VALUES("1","1");
INSERT INTO cat_user VALUES("2","3");





CREATE TABLE `category` (
  `category_id` int(11) NOT NULL AUTO_INCREMENT,
  `priority` double DEFAULT NULL,
  `description` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`category_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO category VALUES("1","2012","Krimi");
INSERT INTO category VALUES("2","2012","Biznes");
INSERT INTO category VALUES("3","2012","Sport");





CREATE TABLE `tag` (
  `tag_id` int(11) NOT NULL AUTO_INCREMENT,
  `second_priority` float DEFAULT NULL,
  `description` varchar(220) DEFAULT NULL,
  PRIMARY KEY (`tag_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO tag VALUES("1","2.15","kon");
INSERT INTO tag VALUES("2","1.89","sopol");
INSERT INTO tag VALUES("3","6.45","gevrek");





CREATE TABLE `user` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `description` varchar(200) DEFAULT NULL,
  `created_on` date DEFAULT NULL,
  `password` varchar(90) DEFAULT NULL,
  `art_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

INSERT INTO user VALUES("1","gfhjk","2012-12-03","GOGO","1");
INSERT INTO user VALUES("2","grdthfyukj","2012-05-12","PACO","2");



--------------------------------------------------------------------------Sunday 13th of April 2014 10:22:52 AM

CREATE TABLE `article` (
  `article_id` int(11) NOT NULL AUTO_INCREMENT,
  `published_on` date DEFAULT NULL,
  `price` varchar(20) DEFAULT NULL,
  `content` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`article_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO article VALUES("1","2012-02-01","5","dsfghjk");
INSERT INTO article VALUES("2","2012-02-01","5.04","asdfghj");
INSERT INTO article VALUES("3","2012-02-01","5.04","qwertyui");





CREATE TABLE `cat_tag` (
  `cat_id` int(11) DEFAULT NULL,
  `tag_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO cat_tag VALUES("1","2");
INSERT INTO cat_tag VALUES("1","3");
INSERT INTO cat_tag VALUES("2","1");





CREATE TABLE `cat_user` (
  `cat_id` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO cat_user VALUES("1","2");
INSERT INTO cat_user VALUES("1","1");
INSERT INTO cat_user VALUES("2","3");





CREATE TABLE `category` (
  `category_id` int(11) NOT NULL AUTO_INCREMENT,
  `priority` double DEFAULT NULL,
  `description` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`category_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO category VALUES("1","2012","Krimi");
INSERT INTO category VALUES("2","2012","Biznes");
INSERT INTO category VALUES("3","2012","Sport");





CREATE TABLE `tag` (
  `tag_id` int(11) NOT NULL AUTO_INCREMENT,
  `second_priority` float DEFAULT NULL,
  `description` varchar(220) DEFAULT NULL,
  PRIMARY KEY (`tag_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO tag VALUES("1","2.15","kon");
INSERT INTO tag VALUES("2","1.89","sopol");
INSERT INTO tag VALUES("3","6.45","gevrek");





CREATE TABLE `user` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `description` varchar(200) DEFAULT NULL,
  `created_on` date DEFAULT NULL,
  `password` varchar(90) DEFAULT NULL,
  `art_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

INSERT INTO user VALUES("1","gfhjk","2012-12-03","GOGO","1");
INSERT INTO user VALUES("2","grdthfyukj","2012-05-12","PACO","2");



--------------------------------------------------------------------------Sunday 13th of April 2014 10:25:24 AM

CREATE TABLE `article` (
  `article_id` int(11) NOT NULL AUTO_INCREMENT,
  `published_on` date DEFAULT NULL,
  `price` varchar(20) DEFAULT NULL,
  `content` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`article_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO article VALUES("1","2012-02-01","5","dsfghjk");
INSERT INTO article VALUES("2","2012-02-01","5.04","asdfghj");
INSERT INTO article VALUES("3","2012-02-01","5.04","qwertyui");





CREATE TABLE `cat_tag` (
  `cat_id` int(11) DEFAULT NULL,
  `tag_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO cat_tag VALUES("1","2");
INSERT INTO cat_tag VALUES("1","3");
INSERT INTO cat_tag VALUES("2","1");





CREATE TABLE `cat_user` (
  `cat_id` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO cat_user VALUES("1","2");
INSERT INTO cat_user VALUES("1","1");
INSERT INTO cat_user VALUES("2","3");





CREATE TABLE `category` (
  `category_id` int(11) NOT NULL AUTO_INCREMENT,
  `priority` double DEFAULT NULL,
  `description` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`category_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO category VALUES("1","2012","Krimi");
INSERT INTO category VALUES("2","2012","Biznes");
INSERT INTO category VALUES("3","2012","Sport");





CREATE TABLE `tag` (
  `tag_id` int(11) NOT NULL AUTO_INCREMENT,
  `second_priority` float DEFAULT NULL,
  `description` varchar(220) DEFAULT NULL,
  PRIMARY KEY (`tag_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO tag VALUES("1","2.15","kon");
INSERT INTO tag VALUES("2","1.89","sopol");
INSERT INTO tag VALUES("3","6.45","gevrek");





CREATE TABLE `user` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `description` varchar(200) DEFAULT NULL,
  `created_on` date DEFAULT NULL,
  `password` varchar(90) DEFAULT NULL,
  `art_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

INSERT INTO user VALUES("1","gfhjk","2012-12-03","GOGO","1");
INSERT INTO user VALUES("2","grdthfyukj","2012-05-12","PACO","2");



--------------------------------------------------------------------------Sunday 13th of April 2014 10:25:45 AM

CREATE TABLE `article` (
  `article_id` int(11) NOT NULL AUTO_INCREMENT,
  `published_on` date DEFAULT NULL,
  `price` varchar(20) DEFAULT NULL,
  `content` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`article_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO article VALUES("1","2012-02-01","5","dsfghjk");
INSERT INTO article VALUES("2","2012-02-01","5.04","asdfghj");
INSERT INTO article VALUES("3","2012-02-01","5.04","qwertyui");





CREATE TABLE `cat_tag` (
  `cat_id` int(11) DEFAULT NULL,
  `tag_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO cat_tag VALUES("1","2");
INSERT INTO cat_tag VALUES("1","3");
INSERT INTO cat_tag VALUES("2","1");





CREATE TABLE `cat_user` (
  `cat_id` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO cat_user VALUES("1","2");
INSERT INTO cat_user VALUES("1","1");
INSERT INTO cat_user VALUES("2","3");





CREATE TABLE `category1` (
  `cat1_id1` int(11) NOT NULL AUTO_INCREMENT,
  `priority` double DEFAULT NULL,
  PRIMARY KEY (`cat1_id1`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO category1 VALUES("1","2012");
INSERT INTO category1 VALUES("2","2012");
INSERT INTO category1 VALUES("3","2012");





CREATE TABLE `category2` (
  `category_id` int(11) NOT NULL AUTO_INCREMENT,
  `description` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`category_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO category2 VALUES("1","Krimi");
INSERT INTO category2 VALUES("2","Biznes");
INSERT INTO category2 VALUES("3","Sport");





CREATE TABLE `tag` (
  `tag_id` int(11) NOT NULL AUTO_INCREMENT,
  `second_priority` float DEFAULT NULL,
  `description` varchar(220) DEFAULT NULL,
  PRIMARY KEY (`tag_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO tag VALUES("1","2.15","kon");
INSERT INTO tag VALUES("2","1.89","sopol");
INSERT INTO tag VALUES("3","6.45","gevrek");





CREATE TABLE `user` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `description` varchar(200) DEFAULT NULL,
  `created_on` date DEFAULT NULL,
  `password` varchar(90) DEFAULT NULL,
  `art_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

INSERT INTO user VALUES("1","gfhjk","2012-12-03","GOGO","1");
INSERT INTO user VALUES("2","grdthfyukj","2012-05-12","PACO","2");



--------------------------------------------------------------------------Sunday 13th of April 2014 10:32:45 AM

CREATE TABLE `article` (
  `article_id` int(11) NOT NULL AUTO_INCREMENT,
  `published_on` date DEFAULT NULL,
  `price` varchar(20) DEFAULT NULL,
  `content` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`article_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO article VALUES("1","2012-02-01","5","dsfghjk");
INSERT INTO article VALUES("2","2012-02-01","5.04","asdfghj");
INSERT INTO article VALUES("3","2012-02-01","5.04","qwertyui");





CREATE TABLE `cat_tag` (
  `cat_id` int(11) DEFAULT NULL,
  `tag_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO cat_tag VALUES("1","2");
INSERT INTO cat_tag VALUES("1","3");
INSERT INTO cat_tag VALUES("2","1");





CREATE TABLE `cat_user` (
  `cat_id` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO cat_user VALUES("1","2");
INSERT INTO cat_user VALUES("1","1");
INSERT INTO cat_user VALUES("2","3");





CREATE TABLE `category1` (
  `cat1_id1` int(11) NOT NULL AUTO_INCREMENT,
  `priority` double DEFAULT NULL,
  PRIMARY KEY (`cat1_id1`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO category1 VALUES("1","2012");
INSERT INTO category1 VALUES("2","2012");
INSERT INTO category1 VALUES("3","2012");





CREATE TABLE `category2` (
  `category_id` int(11) NOT NULL AUTO_INCREMENT,
  `description` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`category_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO category2 VALUES("1","Krimi");
INSERT INTO category2 VALUES("2","Biznes");
INSERT INTO category2 VALUES("3","Sport");





CREATE TABLE `tag` (
  `tag_id` int(11) NOT NULL AUTO_INCREMENT,
  `second_priority` float DEFAULT NULL,
  `description` varchar(220) DEFAULT NULL,
  PRIMARY KEY (`tag_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO tag VALUES("1","2.15","kon");
INSERT INTO tag VALUES("2","1.89","sopol");
INSERT INTO tag VALUES("3","6.45","gevrek");





CREATE TABLE `user` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `description` varchar(200) DEFAULT NULL,
  `created_on` date DEFAULT NULL,
  `password` varchar(90) DEFAULT NULL,
  `art_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

INSERT INTO user VALUES("1","gfhjk","2012-12-03","GOGO","1");
INSERT INTO user VALUES("2","grdthfyukj","2012-05-12","PACO","2");



--------------------------------------------------------------------------Sunday 13th of April 2014 10:33:17 AM

CREATE TABLE `article` (
  `article_id` int(11) NOT NULL AUTO_INCREMENT,
  `published_on` date DEFAULT NULL,
  `price` varchar(20) DEFAULT NULL,
  `content` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`article_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO article VALUES("1","2012-02-01","5","dsfghjk");
INSERT INTO article VALUES("2","2012-02-01","5.04","asdfghj");
INSERT INTO article VALUES("3","2012-02-01","5.04","qwertyui");





CREATE TABLE `cat_tag` (
  `cat_id` int(11) DEFAULT NULL,
  `tag_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO cat_tag VALUES("1","2");
INSERT INTO cat_tag VALUES("1","3");
INSERT INTO cat_tag VALUES("2","1");





CREATE TABLE `cat_user` (
  `cat_id` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO cat_user VALUES("1","2");
INSERT INTO cat_user VALUES("1","1");
INSERT INTO cat_user VALUES("2","3");





CREATE TABLE `category1` (
  `cat1_id1` int(11) NOT NULL AUTO_INCREMENT,
  `priority` double DEFAULT NULL,
  PRIMARY KEY (`cat1_id1`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO category1 VALUES("1","2012");
INSERT INTO category1 VALUES("2","2012");
INSERT INTO category1 VALUES("3","2012");





CREATE TABLE `category2` (
  `category_id` int(11) NOT NULL AUTO_INCREMENT,
  `description` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`category_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO category2 VALUES("1","Krimi");
INSERT INTO category2 VALUES("2","Biznes");
INSERT INTO category2 VALUES("3","Sport");





CREATE TABLE `tag` (
  `tag_id` int(11) NOT NULL AUTO_INCREMENT,
  `second_priority` float DEFAULT NULL,
  `description` varchar(220) DEFAULT NULL,
  PRIMARY KEY (`tag_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO tag VALUES("1","2.15","kon");
INSERT INTO tag VALUES("2","1.89","sopol");
INSERT INTO tag VALUES("3","6.45","gevrek");





CREATE TABLE `user` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `description` varchar(200) DEFAULT NULL,
  `created_on` date DEFAULT NULL,
  `password` varchar(90) DEFAULT NULL,
  `art_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

INSERT INTO user VALUES("1","gfhjk","2012-12-03","GOGO","1");
INSERT INTO user VALUES("2","grdthfyukj","2012-05-12","PACO","2");



--------------------------------------------------------------------------Sunday 13th of April 2014 10:34:03 AM

CREATE TABLE `article` (
  `article_id` int(11) NOT NULL AUTO_INCREMENT,
  `published_on` date DEFAULT NULL,
  `price` varchar(20) DEFAULT NULL,
  `content` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`article_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO article VALUES("1","2012-02-01","5","dsfghjk");
INSERT INTO article VALUES("2","2012-02-01","5.04","asdfghj");
INSERT INTO article VALUES("3","2012-02-01","5.04","qwertyui");





CREATE TABLE `cat_tag` (
  `cat_id` int(11) DEFAULT NULL,
  `tag_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO cat_tag VALUES("1","2");
INSERT INTO cat_tag VALUES("1","3");
INSERT INTO cat_tag VALUES("2","1");





CREATE TABLE `cat_user` (
  `cat_id` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO cat_user VALUES("1","2");
INSERT INTO cat_user VALUES("1","1");
INSERT INTO cat_user VALUES("2","3");





CREATE TABLE `category1` (
  `cat1_id1` int(11) NOT NULL AUTO_INCREMENT,
  `priority` double DEFAULT NULL,
  PRIMARY KEY (`cat1_id1`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO category1 VALUES("1","2012");
INSERT INTO category1 VALUES("2","2012");
INSERT INTO category1 VALUES("3","2012");





CREATE TABLE `category2` (
  `category_id` int(11) NOT NULL AUTO_INCREMENT,
  `description` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`category_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO category2 VALUES("1","Krimi");
INSERT INTO category2 VALUES("2","Biznes");
INSERT INTO category2 VALUES("3","Sport");





CREATE TABLE `tag` (
  `tag_id` int(11) NOT NULL AUTO_INCREMENT,
  `second_priority` float DEFAULT NULL,
  `description` varchar(220) DEFAULT NULL,
  PRIMARY KEY (`tag_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO tag VALUES("1","2.15","kon");
INSERT INTO tag VALUES("2","1.89","sopol");
INSERT INTO tag VALUES("3","6.45","gevrek");





CREATE TABLE `user` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `description` varchar(200) DEFAULT NULL,
  `created_on` date DEFAULT NULL,
  `password` varchar(90) DEFAULT NULL,
  `art_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

INSERT INTO user VALUES("1","gfhjk","2012-12-03","GOGO","1");
INSERT INTO user VALUES("2","grdthfyukj","2012-05-12","PACO","2");



--------------------------------------------------------------------------Sunday 13th of April 2014 10:34:11 AM

CREATE TABLE `article` (
  `article_id` int(11) NOT NULL AUTO_INCREMENT,
  `published_on` date DEFAULT NULL,
  `price` varchar(20) DEFAULT NULL,
  `content` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`article_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO article VALUES("1","2012-02-01","5","dsfghjk");
INSERT INTO article VALUES("2","2012-02-01","5.04","asdfghj");
INSERT INTO article VALUES("3","2012-02-01","5.04","qwertyui");





CREATE TABLE `cat_tag` (
  `cat_id` int(11) DEFAULT NULL,
  `tag_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO cat_tag VALUES("1","2");
INSERT INTO cat_tag VALUES("1","3");
INSERT INTO cat_tag VALUES("2","1");





CREATE TABLE `cat_user` (
  `cat_id` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO cat_user VALUES("1","2");
INSERT INTO cat_user VALUES("1","1");
INSERT INTO cat_user VALUES("2","3");





CREATE TABLE `category1` (
  `cat1_id1` int(11) NOT NULL AUTO_INCREMENT,
  `priority` double DEFAULT NULL,
  PRIMARY KEY (`cat1_id1`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO category1 VALUES("1","2012");
INSERT INTO category1 VALUES("2","2012");
INSERT INTO category1 VALUES("3","2012");





CREATE TABLE `category2` (
  `category_id` int(11) NOT NULL AUTO_INCREMENT,
  `description` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`category_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO category2 VALUES("1","Krimi");
INSERT INTO category2 VALUES("2","Biznes");
INSERT INTO category2 VALUES("3","Sport");





CREATE TABLE `tag` (
  `tag_id` int(11) NOT NULL AUTO_INCREMENT,
  `second_priority` float DEFAULT NULL,
  `description` varchar(220) DEFAULT NULL,
  PRIMARY KEY (`tag_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO tag VALUES("1","2.15","kon");
INSERT INTO tag VALUES("2","1.89","sopol");
INSERT INTO tag VALUES("3","6.45","gevrek");





CREATE TABLE `user` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `description` varchar(200) DEFAULT NULL,
  `created_on` date DEFAULT NULL,
  `password` varchar(90) DEFAULT NULL,
  `art_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

INSERT INTO user VALUES("1","gfhjk","2012-12-03","GOGO","1");
INSERT INTO user VALUES("2","grdthfyukj","2012-05-12","PACO","2");



--------------------------------------------------------------------------Sunday 13th of April 2014 10:50:14 AM

CREATE TABLE `article` (
  `article_id` int(11) NOT NULL AUTO_INCREMENT,
  `published_on` date DEFAULT NULL,
  `price` varchar(20) DEFAULT NULL,
  `content` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`article_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO article VALUES("1","2012-02-01","5","dsfghjk");
INSERT INTO article VALUES("2","2012-02-01","5.04","asdfghj");
INSERT INTO article VALUES("3","2012-02-01","5.04","qwertyui");





CREATE TABLE `cat_tag` (
  `cat_id` int(11) DEFAULT NULL,
  `tag_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO cat_tag VALUES("1","2");
INSERT INTO cat_tag VALUES("1","3");
INSERT INTO cat_tag VALUES("2","1");





CREATE TABLE `cat_user` (
  `cat_id` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO cat_user VALUES("1","2");
INSERT INTO cat_user VALUES("1","1");
INSERT INTO cat_user VALUES("2","3");





CREATE TABLE `category1` (
  `cat1_id1` int(11) NOT NULL AUTO_INCREMENT,
  `priority` double DEFAULT NULL,
  PRIMARY KEY (`cat1_id1`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO category1 VALUES("1","2012");
INSERT INTO category1 VALUES("2","2012");
INSERT INTO category1 VALUES("3","2012");





CREATE TABLE `category2` (
  `category_id` int(11) NOT NULL AUTO_INCREMENT,
  `description` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`category_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO category2 VALUES("1","Krimi");
INSERT INTO category2 VALUES("2","Biznes");
INSERT INTO category2 VALUES("3","Sport");





CREATE TABLE `tag` (
  `tag_id` int(11) NOT NULL AUTO_INCREMENT,
  `second_priority` float DEFAULT NULL,
  `description` varchar(220) DEFAULT NULL,
  PRIMARY KEY (`tag_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO tag VALUES("1","2.15","kon");
INSERT INTO tag VALUES("2","1.89","sopol");
INSERT INTO tag VALUES("3","6.45","gevrek");





CREATE TABLE `user` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `description` varchar(200) DEFAULT NULL,
  `created_on` date DEFAULT NULL,
  `password` varchar(90) DEFAULT NULL,
  `art_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

INSERT INTO user VALUES("1","gfhjk","2012-12-03","GOGO","1");
INSERT INTO user VALUES("2","grdthfyukj","2012-05-12","PACO","2");



--------------------------------------------------------------------------Sunday 13th of April 2014 11:02:41 AM

CREATE TABLE `article` (
  `article_id` int(11) NOT NULL AUTO_INCREMENT,
  `published_on` date DEFAULT NULL,
  `price` varchar(20) DEFAULT NULL,
  `content` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`article_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO article VALUES("1","2012-02-01","5","dsfghjk");
INSERT INTO article VALUES("2","2012-02-01","5.04","asdfghj");
INSERT INTO article VALUES("3","2012-02-01","5.04","qwertyui");





CREATE TABLE `cat_tag` (
  `cat_id` int(11) DEFAULT NULL,
  `tag_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO cat_tag VALUES("1","2");
INSERT INTO cat_tag VALUES("1","3");
INSERT INTO cat_tag VALUES("2","1");





CREATE TABLE `cat_user` (
  `cat_id` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO cat_user VALUES("1","2");
INSERT INTO cat_user VALUES("1","1");
INSERT INTO cat_user VALUES("2","3");





CREATE TABLE `category1` (
  `cat1_id1` int(11) NOT NULL AUTO_INCREMENT,
  `priority` double DEFAULT NULL,
  PRIMARY KEY (`cat1_id1`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO category1 VALUES("1","2012");
INSERT INTO category1 VALUES("2","2012");
INSERT INTO category1 VALUES("3","2012");





CREATE TABLE `category2` (
  `category_id` int(11) NOT NULL AUTO_INCREMENT,
  `description` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`category_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO category2 VALUES("1","Krimi");
INSERT INTO category2 VALUES("2","Biznes");
INSERT INTO category2 VALUES("3","Sport");





CREATE TABLE `tag` (
  `tag_id` int(11) NOT NULL AUTO_INCREMENT,
  `second_priority` float DEFAULT NULL,
  `description` varchar(220) DEFAULT NULL,
  PRIMARY KEY (`tag_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO tag VALUES("1","2.15","kon");
INSERT INTO tag VALUES("2","1.89","sopol");
INSERT INTO tag VALUES("3","6.45","gevrek");





CREATE TABLE `user` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `description` varchar(200) DEFAULT NULL,
  `created_on` date DEFAULT NULL,
  `password` varchar(90) DEFAULT NULL,
  `art_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

INSERT INTO user VALUES("1","gfhjk","2012-12-03","GOGO","1");
INSERT INTO user VALUES("2","grdthfyukj","2012-05-12","PACO","2");



--------------------------------------------------------------------------Sunday 13th of April 2014 11:03:09 AM