

CREATE TABLE `article` (
  `article_id` int(11) NOT NULL AUTO_INCREMENT,
  `created_on` date DEFAULT NULL,
  `content` varchar(200) DEFAULT NULL,
  `url` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`article_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO article VALUES("1","2012-02-01","blala","google.com");
INSERT INTO article VALUES("2","2012-02-01","blala","data.bg");
INSERT INTO article VALUES("3","2012-02-01","blala","facebook.com");





CREATE TABLE `category_part1` (
  `cat_part1_id` int(11) NOT NULL AUTO_INCREMENT,
  `priority` double DEFAULT NULL,
  PRIMARY KEY (`cat_part1_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO category_part1 VALUES("1","2");
INSERT INTO category_part1 VALUES("2","2");
INSERT INTO category_part1 VALUES("3","1");





CREATE TABLE `category_part2` (
  `category_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`category_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO category_part2 VALUES("1","ekshun");
INSERT INTO category_part2 VALUES("2","drama");
INSERT INTO category_part2 VALUES("3","komediq");





CREATE TABLE `tag` (
  `tag_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) DEFAULT NULL,
  `priority` int(11) DEFAULT NULL,
  `cat_id` int(11) DEFAULT NULL,
  `art_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`tag_id`),
  UNIQUE KEY `art_id` (`art_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO tag VALUES("1","kon","2","1","1");
INSERT INTO tag VALUES("2","sopol","1","2","2");
INSERT INTO tag VALUES("3","gevrek","3","3","3");





CREATE TABLE `user` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `income` float DEFAULT NULL,
  `password` varchar(200) DEFAULT NULL,
  `picture_url` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO user VALUES("1","100.5","123","imgur.com");
INSERT INTO user VALUES("2","200.2","234","imgshack.net");
INSERT INTO user VALUES("3","300.45","345","data.bg/image");





CREATE TABLE `user_category` (
  `user_id` int(11) DEFAULT NULL,
  `cat_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO user_category VALUES("1","2");
INSERT INTO user_category VALUES("2","3");
INSERT INTO user_category VALUES("1","3");



--------------------------------------------------------------------------Sunday 13th of April 2014 08:01:26 PM