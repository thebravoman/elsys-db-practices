<!DOCTYPE html>
<html>
<head>
	<title> Anton Mitkov</title>
</head>
<body>
	Hello  <br/> &nbsp;&nbsp;&nbsp; Stefan Petrov 12 A, 27 number<br/>
	<br/><br/><br/>

<h3>Tips:</h3></br>
	task3_backup1.sql - backup for the first part of the exam</br>
	task3_backup2.sql - backup for the second part of the exam</br>

	If you refresh the page at the bottom of the file you'll see the changes and the time they are made.</br>
	It is possible when you refreshed the page to have an error with first answer because you change the database</br>
	and it affects on the result.</br></br>

<?php
	mysql_connect("localhost", "root","") or die(mysql_error());

/* Create table, ones I create table i shoud comment that line and uncoment the "mysql_selecet_db" line to connect */
		 mysql_query("CREATE DATABASE subd3") or die(mysql_error());

/*Select the database that was created*/
		mysql_select_db("subd3") or die(mysql_error());


/* That's how I create the tables*/
	 	 mysql_query("CREATE TABLE Article (
			   article_id INT AUTO_INCREMENT,
			   created_on DATE,
			   content VARCHAR (200),
			   url VARCHAR (200),
			   PRIMARY KEY(article_id))") Or die(mysql_error());

		 mysql_query("CREATE TABLE Category (
		 	  category_id INT AUTO_INCREMENT,
		 	  name VARCHAR (200),
		 	  priority DOUBLE,
		 	  PRIMARY KEY(category_id))") Or die(mysql_error());

		 mysql_query("CREATE TABLE User (
		 	  user_id INT AUTO_INCREMENT,
		 	  income FLOAT,
		 	  password VARCHAR (200),
		 	  picture_url VARCHAR (200),
		 	  PRIMARY KEY(user_id))") Or die(mysql_error());

		 mysql_query("CREATE TABLE Tag (
		 	  tag_id INT AUTO_INCREMENT,
		 	  name VARCHAR (200),
		 	  priority INT,
		 	  cat_id INT,
		 	  art_id INT UNIQUE,
		 	  PRIMARY KEY(tag_id))") Or die(mysql_error());

		 mysql_query("CREATE TABLE User_Category (
		 	  user_id INT,
		 	  cat_id INT
		 	  )") Or die(mysql_error());


/*INSERTIN SHITS*/
		 mysql_query("INSERT INTO Article( created_on, content, url) VALUES ('2012-02-1', 'blala', 'google.com')");
		 mysql_query("INSERT INTO Article( created_on, content, url) VALUES ('2012-02-1', 'blala', 'data.bg')");
		 mysql_query("INSERT INTO Article( created_on, content, url) VALUES ('2012-02-1', 'blala', 'facebook.com')");

		 mysql_query("INSERT INTO Category( name, priority) VALUES ('ekshun', 2)");
		 mysql_query("INSERT INTO Category( name, priority) VALUES ('drama', 2)");
		 mysql_query("INSERT INTO Category( name, priority) VALUES ('komediq', 1)");

		 mysql_query("INSERT INTO USER( income, password, picture_url) VALUES ('100.50', '123', 'imgur.com')");
		 mysql_query("INSERT INTO USER( income, password, picture_url) VALUES ('200.20', '234', 'imgshack.net')");
		 mysql_query("INSERT INTO USER( income, password, picture_url) VALUES ('300.45', '345', 'data.bg/image')");

		 mysql_query("INSERT INTO tag( name, priority, cat_id, art_id) VALUES ('kon', 2, 1, 1)");
		 mysql_query("INSERT INTO tag( name, priority, cat_id, art_id) VALUES ('sopol', 1, 2, 2)");
		 mysql_query("INSERT INTO tag( name, priority, cat_id, art_id) VALUES ('gevrek', 3, 3, 3)");

		 mysql_query("INSERT INTO User_Category( user_id, cat_id) VALUES (1, 2)");
		 mysql_query("INSERT INTO User_Category( user_id, cat_id) VALUES (2, 3)");
		 mysql_query("INSERT INTO User_Category( user_id, cat_id) VALUES (1, 3)");

/*Which are the Tag(s) for a given User --> SELECT 1*/

		 $pena =  mysql_query("SELECT * FROM User INNER JOIN User_Category,Tag WHERE User.user_id = User_Category.user_id 
		 	 AND User_Category.cat_id = Tag.cat_id AND Tag.tag_id = 3");  // SELECT 1

		 ?> THE ANSWER OF THE FIRST QUESTION IS : <br/><?php
		 while($row = mysql_fetch_array($pena)){
		 	echo $row["tag_id"];

		 	?> <br/> <?php
		 }

// /*Call the function that export the database*/
		 backup_tables('localhost','root','subd3','sub_exam_backup3_1');	

/*Migration*/
		 mysql_query(" CREATE TABLE Category_part1 (
		 	cat_part1_id INT AUTO_INCREMENT,
		 	priority DOUBLE,
		 	PRIMARY KEY(cat_part1_id))") Or die(mysql_error());

		 mysql_query("INSERT INTO Category_part1 (priority) SELECT priority FROM Category");
		 mysql_query("ALTER TABLE Category DROP priority");
		 mysql_query("ALTER TABLE Category RENAME TO Category_part2");

// /*Second of export the database*/
 		backup_tables('localhost','root','subd3','sub_exam_backup3_2');

/*Which are the Article(s) for a given Category ---> SELECT 2*/

		 $pena =  mysql_query("SELECT * FROM Article INNER JOIN Category_part2, Tag WHERE Article.article_id = Tag.art_id AND 
		 	Tag.cat_id = Category_part2.category_id AND Category_part2.category_id = '2' ");  // SELECT 2

		 ?> THE ANSWER OF THE FIRST QUESTION IS : <br/><?php
		 while($row = mysql_fetch_array($pena)){
		 	echo $row["article_id"];

		 	?> <br/> <?php
		 }	 


?>
</body>
</html>


<?php

	
/* backup the db OR just a table */
function backup_tables($host,$user,$name,$place,$tables = '*')
{
	
	$link = mysql_connect($host,$user,"");
	mysql_select_db($name,$link);
	
	//get all of the tables
	if($tables == '*')
	{
		$tables = array();
		$result = mysql_query('SHOW TABLES');
		//var_dump($result);
		while($row = mysql_fetch_row($result))
		{
			$tables[] = $row[0];
		}
	}
	else
	{
		$tables = is_array($tables) ? $tables : explode(',',$tables);
	}
	

	//cycle through
	foreach($tables as $table)
	{
		$result = mysql_query('SELECT * FROM '.$table);
		$num_fields = mysql_num_fields($result);
		
		$return = 'DROP TABLE '.$table.';';
		$row2 = mysql_fetch_row(mysql_query('SHOW CREATE TABLE '.$table));
		$return = "\n\n".$row2[1].";\n\n";
		
		for ($i = 0; $i < $num_fields; $i++) 
		{
			while($row = mysql_fetch_row($result))
			{
				$return.= 'INSERT INTO '.$table.' VALUES(';
				for($j=0; $j<$num_fields; $j++) 
				{
					$row[$j] = addslashes($row[$j]);
					$row[$j] = ereg_replace("\n","\\n",$row[$j]);
					if (isset($row[$j])) { $return.= '"'.$row[$j].'"' ; } else { $return.= '""'; }
					if ($j<($num_fields-1)) { $return.= ','; }
				}
				$return.= ");\n";
			}
		}
		$return.="\n\n\n";

	$handle = fopen($place.'.sql','a+');
	fwrite($handle,$return);

	}
	fwrite($handle,"--------------------------------------------------------------------------".date('l jS \of F Y h:i:s A'));
	fclose($handle);
}
?>