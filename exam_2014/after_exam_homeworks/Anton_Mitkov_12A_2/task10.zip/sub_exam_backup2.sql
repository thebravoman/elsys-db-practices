

CREATE TABLE `article` (
  `article_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(220) DEFAULT NULL,
  `published_on` date DEFAULT NULL,
  `url` varchar(200) DEFAULT NULL,
  `cat_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`article_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO article VALUES("1","KON","2012-12-03","sacsd","1");
INSERT INTO article VALUES("2","SOPOL","2012-12-03","gvhbjn","2");
INSERT INTO article VALUES("3","KRAVA","2012-12-03","qwerty","3");





CREATE TABLE `cat_tag` (
  `cat_id` int(11) DEFAULT NULL,
  `tag_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO cat_tag VALUES("1","1");
INSERT INTO cat_tag VALUES("2","2");
INSERT INTO cat_tag VALUES("3","3");





CREATE TABLE `category_part1` (
  `cat1_id` int(11) NOT NULL AUTO_INCREMENT,
  `created_by` double DEFAULT NULL,
  PRIMARY KEY (`cat1_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO category_part1 VALUES("1","0");
INSERT INTO category_part1 VALUES("2","0");
INSERT INTO category_part1 VALUES("3","0");





CREATE TABLE `category_part2` (
  `category_id` int(11) NOT NULL AUTO_INCREMENT,
  `date_created_on` date DEFAULT NULL,
  PRIMARY KEY (`category_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO category_part2 VALUES("1","2012-12-03");
INSERT INTO category_part2 VALUES("2","2012-12-03");
INSERT INTO category_part2 VALUES("3","2012-12-03");





CREATE TABLE `tag` (
  `tag_id` int(11) NOT NULL AUTO_INCREMENT,
  `description` varchar(120) DEFAULT NULL,
  `priority` int(11) DEFAULT NULL,
  PRIMARY KEY (`tag_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO tag VALUES("1","fghj","2");
INSERT INTO tag VALUES("2","gfhj","9");
INSERT INTO tag VALUES("3","fghjk","5");





CREATE TABLE `tag_user` (
  `tag_id` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO tag_user VALUES("3","1");
INSERT INTO tag_user VALUES("1","3");
INSERT INTO tag_user VALUES("2","2");





CREATE TABLE `user` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `income` float DEFAULT NULL,
  `age` int(11) DEFAULT NULL,
  `created_on` date DEFAULT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO user VALUES("1","1.06","21","2012-12-03");
INSERT INTO user VALUES("2","9.03","21","2012-12-03");
INSERT INTO user VALUES("3","10.8","21","2012-12-03");



--------------------------------------------------------------------------Monday 14th of April 2014 12:12:50 PM

CREATE TABLE `article` (
  `article_id` int(11) NOT NULL AUTO_INCREMENT,
  `created_on` date DEFAULT NULL,
  `price` varchar(30) DEFAULT NULL,
  `published_on` date DEFAULT NULL,
  PRIMARY KEY (`article_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO article VALUES("1","2012-12-03","0.5","2012-12-03");
INSERT INTO article VALUES("2","2012-12-03","5.2","2012-12-03");
INSERT INTO article VALUES("3","2012-12-03","7.1","2012-12-03");





CREATE TABLE `category` (
  `category_id` int(11) NOT NULL AUTO_INCREMENT,
  `created_by` varchar(60) DEFAULT NULL,
  `name` varchar(100) DEFAULT NULL,
  `tag_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`category_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO category VALUES("1","2012-12-03","GOGO","3");
INSERT INTO category VALUES("2","2012-12-03","GOGO","2");
INSERT INTO category VALUES("3","2012-12-03","GOGO","1");





CREATE TABLE `tag` (
  `tag_id` int(11) NOT NULL AUTO_INCREMENT,
  `description` varchar(50) DEFAULT NULL,
  `second_priority` float DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`tag_id`),
  UNIQUE KEY `user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;






CREATE TABLE `user` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `created_on` date DEFAULT NULL,
  `picture_url` varchar(100) DEFAULT NULL,
  `description` varchar(100) DEFAULT NULL,
  `art_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO user VALUES("1","2012-12-03","fcghjk","jkdshnck","1");
INSERT INTO user VALUES("2","2012-12-03","fcghjk","jkdshnck","3");
INSERT INTO user VALUES("3","2012-12-03","fcghjk","jkdshnck","2");



--------------------------------------------------------------------------Monday 14th of April 2014 12:43:07 PM

CREATE TABLE `article` (
  `article_id` int(11) NOT NULL AUTO_INCREMENT,
  `created_on` date DEFAULT NULL,
  `price` varchar(30) DEFAULT NULL,
  `published_on` date DEFAULT NULL,
  PRIMARY KEY (`article_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO article VALUES("1","2012-12-03","0.5","2012-12-03");
INSERT INTO article VALUES("2","2012-12-03","5.2","2012-12-03");
INSERT INTO article VALUES("3","2012-12-03","7.1","2012-12-03");





CREATE TABLE `category` (
  `category_id` int(11) NOT NULL AUTO_INCREMENT,
  `created_by` varchar(60) DEFAULT NULL,
  `name` varchar(100) DEFAULT NULL,
  `tag_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`category_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO category VALUES("1","2012-12-03","GOGO","3");
INSERT INTO category VALUES("2","2012-12-03","GOGO","2");
INSERT INTO category VALUES("3","2012-12-03","GOGO","1");





CREATE TABLE `tag` (
  `tag_id` int(11) NOT NULL AUTO_INCREMENT,
  `description` varchar(50) DEFAULT NULL,
  `second_priority` float DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`tag_id`),
  UNIQUE KEY `user_id` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO tag VALUES("1","fghj","5.2","2");
INSERT INTO tag VALUES("2","gfhj","4.1","3");
INSERT INTO tag VALUES("3","fghjk","1.39","1");





CREATE TABLE `user` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `created_on` date DEFAULT NULL,
  `picture_url` varchar(100) DEFAULT NULL,
  `description` varchar(100) DEFAULT NULL,
  `art_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO user VALUES("1","2012-12-03","fcghjk","jkdshnck","1");
INSERT INTO user VALUES("2","2012-12-03","fcghjk","jkdshnck","3");
INSERT INTO user VALUES("3","2012-12-03","fcghjk","jkdshnck","2");



--------------------------------------------------------------------------Monday 14th of April 2014 12:43:48 PM

CREATE TABLE `article` (
  `article_id` int(11) NOT NULL AUTO_INCREMENT,
  `created_on` date DEFAULT NULL,
  `price` varchar(30) DEFAULT NULL,
  `published_on` date DEFAULT NULL,
  PRIMARY KEY (`article_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO article VALUES("1","2012-12-03","0.5","2012-12-03");
INSERT INTO article VALUES("2","2012-12-03","5.2","2012-12-03");
INSERT INTO article VALUES("3","2012-12-03","7.1","2012-12-03");





CREATE TABLE `category` (
  `category_id` int(11) NOT NULL AUTO_INCREMENT,
  `created_by` varchar(60) DEFAULT NULL,
  `name` varchar(100) DEFAULT NULL,
  `tag_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`category_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO category VALUES("1","2012-12-03","GOGO","3");
INSERT INTO category VALUES("2","2012-12-03","GOGO","2");
INSERT INTO category VALUES("3","2012-12-03","GOGO","1");





CREATE TABLE `tag` (
  `tag_id` int(11) NOT NULL AUTO_INCREMENT,
  `description` varchar(50) DEFAULT NULL,
  `second_priority` float DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`tag_id`),
  UNIQUE KEY `user_id` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO tag VALUES("1","fghj","5.2","2");
INSERT INTO tag VALUES("2","gfhj","4.1","3");
INSERT INTO tag VALUES("3","fghjk","1.39","1");





CREATE TABLE `user` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `created_on` date DEFAULT NULL,
  `picture_url` varchar(100) DEFAULT NULL,
  `description` varchar(100) DEFAULT NULL,
  `art_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO user VALUES("1","2012-12-03","fcghjk","jkdshnck","1");
INSERT INTO user VALUES("2","2012-12-03","fcghjk","jkdshnck","3");
INSERT INTO user VALUES("3","2012-12-03","fcghjk","jkdshnck","2");



--------------------------------------------------------------------------Monday 14th of April 2014 12:48:45 PM

CREATE TABLE `article` (
  `article_id` int(11) NOT NULL AUTO_INCREMENT,
  `created_on` date DEFAULT NULL,
  `price` varchar(30) DEFAULT NULL,
  `published_on` date DEFAULT NULL,
  PRIMARY KEY (`article_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO article VALUES("1","2012-12-03","0.5","2012-12-03");
INSERT INTO article VALUES("2","2012-12-03","5.2","2012-12-03");
INSERT INTO article VALUES("3","2012-12-03","7.1","2012-12-03");





CREATE TABLE `category` (
  `category_id` int(11) NOT NULL AUTO_INCREMENT,
  `created_by` varchar(60) DEFAULT NULL,
  `name` varchar(100) DEFAULT NULL,
  `tag_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`category_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO category VALUES("1","2012-12-03","GOGO","3");
INSERT INTO category VALUES("2","2012-12-03","GOGO","2");
INSERT INTO category VALUES("3","2012-12-03","GOGO","1");





CREATE TABLE `tag` (
  `tag_id` int(11) NOT NULL AUTO_INCREMENT,
  `description` varchar(50) DEFAULT NULL,
  `second_priority` float DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`tag_id`),
  UNIQUE KEY `user_id` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO tag VALUES("1","fghj","5.2","2");
INSERT INTO tag VALUES("2","gfhj","4.1","3");
INSERT INTO tag VALUES("3","fghjk","1.39","1");





CREATE TABLE `user` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `created_on` date DEFAULT NULL,
  `picture_url` varchar(100) DEFAULT NULL,
  `description` varchar(100) DEFAULT NULL,
  `art_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO user VALUES("1","2012-12-03","fcghjk","jkdshnck","1");
INSERT INTO user VALUES("2","2012-12-03","fcghjk","jkdshnck","3");
INSERT INTO user VALUES("3","2012-12-03","fcghjk","jkdshnck","2");



--------------------------------------------------------------------------Monday 14th of April 2014 12:49:00 PM

CREATE TABLE `article` (
  `article_id` int(11) NOT NULL AUTO_INCREMENT,
  `created_on` date DEFAULT NULL,
  `price` varchar(30) DEFAULT NULL,
  `published_on` date DEFAULT NULL,
  PRIMARY KEY (`article_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO article VALUES("1","2012-12-03","0.5","2012-12-03");
INSERT INTO article VALUES("2","2012-12-03","5.2","2012-12-03");
INSERT INTO article VALUES("3","2012-12-03","7.1","2012-12-03");





CREATE TABLE `category` (
  `category_id` int(11) NOT NULL AUTO_INCREMENT,
  `created_by` varchar(60) DEFAULT NULL,
  `name` varchar(100) DEFAULT NULL,
  `tag_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`category_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO category VALUES("1","2012-12-03","GOGO","3");
INSERT INTO category VALUES("2","2012-12-03","GOGO","2");
INSERT INTO category VALUES("3","2012-12-03","GOGO","1");





CREATE TABLE `tag` (
  `tag_id` int(11) NOT NULL AUTO_INCREMENT,
  `description` varchar(50) DEFAULT NULL,
  `second_priority` float DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`tag_id`),
  UNIQUE KEY `user_id` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO tag VALUES("1","fghj","5.2","2");
INSERT INTO tag VALUES("2","gfhj","4.1","3");
INSERT INTO tag VALUES("3","fghjk","1.39","1");





CREATE TABLE `user` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `created_on` date DEFAULT NULL,
  `picture_url` varchar(100) DEFAULT NULL,
  `description` varchar(100) DEFAULT NULL,
  `art_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO user VALUES("1","2012-12-03","fcghjk","jkdshnck","1");
INSERT INTO user VALUES("2","2012-12-03","fcghjk","jkdshnck","3");
INSERT INTO user VALUES("3","2012-12-03","fcghjk","jkdshnck","2");



--------------------------------------------------------------------------Monday 14th of April 2014 12:50:34 PM

CREATE TABLE `article` (
  `article_id` int(11) NOT NULL AUTO_INCREMENT,
  `created_on` date DEFAULT NULL,
  `price` varchar(30) DEFAULT NULL,
  `published_on` date DEFAULT NULL,
  PRIMARY KEY (`article_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO article VALUES("1","2012-12-03","0.5","2012-12-03");
INSERT INTO article VALUES("2","2012-12-03","5.2","2012-12-03");
INSERT INTO article VALUES("3","2012-12-03","7.1","2012-12-03");





CREATE TABLE `category` (
  `category_id` int(11) NOT NULL AUTO_INCREMENT,
  `created_by` varchar(60) DEFAULT NULL,
  `name` varchar(100) DEFAULT NULL,
  `tag_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`category_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO category VALUES("1","2012-12-03","GOGO","3");
INSERT INTO category VALUES("2","2012-12-03","GOGO","2");
INSERT INTO category VALUES("3","2012-12-03","GOGO","1");





CREATE TABLE `tag` (
  `tag_id` int(11) NOT NULL AUTO_INCREMENT,
  `description` varchar(50) DEFAULT NULL,
  `second_priority` float DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`tag_id`),
  UNIQUE KEY `user_id` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO tag VALUES("1","fghj","5.2","2");
INSERT INTO tag VALUES("2","gfhj","4.1","3");
INSERT INTO tag VALUES("3","fghjk","1.39","1");





CREATE TABLE `user_part1` (
  `user1_id` int(11) NOT NULL AUTO_INCREMENT,
  `description` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`user1_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;






CREATE TABLE `user_part2` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `created_on` date DEFAULT NULL,
  `picture_url` varchar(100) DEFAULT NULL,
  `description` varchar(100) DEFAULT NULL,
  `art_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO user_part2 VALUES("1","2012-12-03","fcghjk","jkdshnck","1");
INSERT INTO user_part2 VALUES("2","2012-12-03","fcghjk","jkdshnck","3");
INSERT INTO user_part2 VALUES("3","2012-12-03","fcghjk","jkdshnck","2");



--------------------------------------------------------------------------Monday 14th of April 2014 12:55:07 PM

CREATE TABLE `article` (
  `article_id` int(11) NOT NULL AUTO_INCREMENT,
  `created_on` date DEFAULT NULL,
  `price` varchar(30) DEFAULT NULL,
  `published_on` date DEFAULT NULL,
  PRIMARY KEY (`article_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO article VALUES("1","2012-12-03","0.5","2012-12-03");
INSERT INTO article VALUES("2","2012-12-03","5.2","2012-12-03");
INSERT INTO article VALUES("3","2012-12-03","7.1","2012-12-03");





CREATE TABLE `category` (
  `category_id` int(11) NOT NULL AUTO_INCREMENT,
  `created_by` varchar(60) DEFAULT NULL,
  `name` varchar(100) DEFAULT NULL,
  `tag_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`category_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO category VALUES("1","2012-12-03","GOGO","3");
INSERT INTO category VALUES("2","2012-12-03","GOGO","2");
INSERT INTO category VALUES("3","2012-12-03","GOGO","1");





CREATE TABLE `tag` (
  `tag_id` int(11) NOT NULL AUTO_INCREMENT,
  `description` varchar(50) DEFAULT NULL,
  `second_priority` float DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`tag_id`),
  UNIQUE KEY `user_id` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO tag VALUES("1","fghj","5.2","2");
INSERT INTO tag VALUES("2","gfhj","4.1","3");
INSERT INTO tag VALUES("3","fghjk","1.39","1");





CREATE TABLE `user_part1` (
  `user1_id` int(11) NOT NULL AUTO_INCREMENT,
  `description` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`user1_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;






CREATE TABLE `user_part2` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `created_on` date DEFAULT NULL,
  `picture_url` varchar(100) DEFAULT NULL,
  `description` varchar(100) DEFAULT NULL,
  `art_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO user_part2 VALUES("1","2012-12-03","fcghjk","jkdshnck","1");
INSERT INTO user_part2 VALUES("2","2012-12-03","fcghjk","jkdshnck","3");
INSERT INTO user_part2 VALUES("3","2012-12-03","fcghjk","jkdshnck","2");



--------------------------------------------------------------------------Monday 14th of April 2014 12:59:24 PM

CREATE TABLE `article` (
  `article_id` int(11) NOT NULL AUTO_INCREMENT,
  `created_on` date DEFAULT NULL,
  `price` varchar(30) DEFAULT NULL,
  `published_on` date DEFAULT NULL,
  PRIMARY KEY (`article_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO article VALUES("1","2012-12-03","0.5","2012-12-03");
INSERT INTO article VALUES("2","2012-12-03","5.2","2012-12-03");
INSERT INTO article VALUES("3","2012-12-03","7.1","2012-12-03");





CREATE TABLE `category` (
  `category_id` int(11) NOT NULL AUTO_INCREMENT,
  `created_by` varchar(60) DEFAULT NULL,
  `name` varchar(100) DEFAULT NULL,
  `tag_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`category_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO category VALUES("1","2012-12-03","GOGO","3");
INSERT INTO category VALUES("2","2012-12-03","GOGO","2");
INSERT INTO category VALUES("3","2012-12-03","GOGO","1");





CREATE TABLE `tag` (
  `tag_id` int(11) NOT NULL AUTO_INCREMENT,
  `description` varchar(50) DEFAULT NULL,
  `second_priority` float DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`tag_id`),
  UNIQUE KEY `user_id` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO tag VALUES("1","fghj","5.2","2");
INSERT INTO tag VALUES("2","gfhj","4.1","3");
INSERT INTO tag VALUES("3","fghjk","1.39","1");





CREATE TABLE `user_part1` (
  `user1_id` int(11) NOT NULL AUTO_INCREMENT,
  `description` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`user1_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;






CREATE TABLE `user_part2` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `created_on` date DEFAULT NULL,
  `picture_url` varchar(100) DEFAULT NULL,
  `description` varchar(100) DEFAULT NULL,
  `art_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO user_part2 VALUES("1","2012-12-03","fcghjk","jkdshnck","1");
INSERT INTO user_part2 VALUES("2","2012-12-03","fcghjk","jkdshnck","3");
INSERT INTO user_part2 VALUES("3","2012-12-03","fcghjk","jkdshnck","2");



--------------------------------------------------------------------------Monday 14th of April 2014 12:59:54 PM

CREATE TABLE `article` (
  `article_id` int(11) NOT NULL AUTO_INCREMENT,
  `created_on` date DEFAULT NULL,
  `price` varchar(30) DEFAULT NULL,
  `published_on` date DEFAULT NULL,
  PRIMARY KEY (`article_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO article VALUES("1","2012-12-03","0.5","2012-12-03");
INSERT INTO article VALUES("2","2012-12-03","5.2","2012-12-03");
INSERT INTO article VALUES("3","2012-12-03","7.1","2012-12-03");





CREATE TABLE `category` (
  `category_id` int(11) NOT NULL AUTO_INCREMENT,
  `created_by` varchar(60) DEFAULT NULL,
  `name` varchar(100) DEFAULT NULL,
  `tag_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`category_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO category VALUES("1","2012-12-03","GOGO","3");
INSERT INTO category VALUES("2","2012-12-03","GOGO","2");
INSERT INTO category VALUES("3","2012-12-03","GOGO","1");





CREATE TABLE `tag` (
  `tag_id` int(11) NOT NULL AUTO_INCREMENT,
  `description` varchar(50) DEFAULT NULL,
  `second_priority` float DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`tag_id`),
  UNIQUE KEY `user_id` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO tag VALUES("1","fghj","5.2","2");
INSERT INTO tag VALUES("2","gfhj","4.1","3");
INSERT INTO tag VALUES("3","fghjk","1.39","1");





CREATE TABLE `user_part1` (
  `user1_id` int(11) NOT NULL AUTO_INCREMENT,
  `description` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`user1_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO user_part1 VALUES("1","jkdshnck");
INSERT INTO user_part1 VALUES("2","jkdshnck");
INSERT INTO user_part1 VALUES("3","jkdshnck");





CREATE TABLE `user_part2` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `created_on` date DEFAULT NULL,
  `picture_url` varchar(100) DEFAULT NULL,
  `description` varchar(100) DEFAULT NULL,
  `art_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO user_part2 VALUES("1","2012-12-03","fcghjk","jkdshnck","1");
INSERT INTO user_part2 VALUES("2","2012-12-03","fcghjk","jkdshnck","3");
INSERT INTO user_part2 VALUES("3","2012-12-03","fcghjk","jkdshnck","2");



--------------------------------------------------------------------------Monday 14th of April 2014 01:00:19 PM