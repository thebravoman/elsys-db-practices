

CREATE TABLE `article` (
  `article_id` int(11) NOT NULL AUTO_INCREMENT,
  `price` varchar(20) DEFAULT NULL,
  `url` varchar(255) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`article_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;




--------------------------------------------------------------------------Saturday 12th of April 2014 12:58:53 PM

CREATE TABLE `article` (
  `article_id` int(11) NOT NULL AUTO_INCREMENT,
  `price` varchar(20) DEFAULT NULL,
  `url` varchar(255) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`article_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;






CREATE TABLE `category` (
  `category_id` int(11) NOT NULL AUTO_INCREMENT,
  `date_created_on` date DEFAULT NULL,
  `priority` double DEFAULT NULL,
  PRIMARY KEY (`category_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;






CREATE TABLE `tag` (
  `tag_id` int(11) NOT NULL AUTO_INCREMENT,
  `priority` varchar(220) DEFAULT NULL,
  `second_priority` float DEFAULT NULL,
  `cat_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`tag_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;






CREATE TABLE `user` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `password` varchar(90) DEFAULT NULL,
  `income` float DEFAULT NULL,
  `picture_url` varchar(200) DEFAULT NULL,
  `art_id` int(11) DEFAULT NULL,
  `tag_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;




--------------------------------------------------------------------------Saturday 12th of April 2014 12:59:22 PM

CREATE TABLE `article` (
  `article_id` int(11) NOT NULL AUTO_INCREMENT,
  `price` varchar(20) DEFAULT NULL,
  `url` varchar(255) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`article_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO article VALUES("1","5","erty.com","dsfghjk");
INSERT INTO article VALUES("2","5.04","erty.com","asdfghj");
INSERT INTO article VALUES("3","5.04","erty.com","qwertyui");





CREATE TABLE `category` (
  `category_id` int(11) NOT NULL AUTO_INCREMENT,
  `date_created_on` date DEFAULT NULL,
  `priority` double DEFAULT NULL,
  PRIMARY KEY (`category_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;






CREATE TABLE `tag` (
  `tag_id` int(11) NOT NULL AUTO_INCREMENT,
  `priority` varchar(220) DEFAULT NULL,
  `second_priority` float DEFAULT NULL,
  `cat_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`tag_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;






CREATE TABLE `user` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `password` varchar(90) DEFAULT NULL,
  `income` float DEFAULT NULL,
  `picture_url` varchar(200) DEFAULT NULL,
  `art_id` int(11) DEFAULT NULL,
  `tag_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;




--------------------------------------------------------------------------Saturday 12th of April 2014 01:00:26 PM

CREATE TABLE `article` (
  `article_id` int(11) NOT NULL AUTO_INCREMENT,
  `price` varchar(20) DEFAULT NULL,
  `url` varchar(255) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`article_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO article VALUES("1","5","erty.com","dsfghjk");
INSERT INTO article VALUES("2","5.04","erty.com","asdfghj");
INSERT INTO article VALUES("3","5.04","erty.com","qwertyui");





CREATE TABLE `category` (
  `category_id` int(11) NOT NULL AUTO_INCREMENT,
  `date_created_on` date DEFAULT NULL,
  `priority` double DEFAULT NULL,
  PRIMARY KEY (`category_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO category VALUES("1","2012-12-03","12.5");
INSERT INTO category VALUES("2","2012-05-12","25.9");
INSERT INTO category VALUES("3","2012-09-02","78.5");





CREATE TABLE `tag` (
  `tag_id` int(11) NOT NULL AUTO_INCREMENT,
  `priority` varchar(220) DEFAULT NULL,
  `second_priority` float DEFAULT NULL,
  `cat_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`tag_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;






CREATE TABLE `user` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `password` varchar(90) DEFAULT NULL,
  `income` float DEFAULT NULL,
  `picture_url` varchar(200) DEFAULT NULL,
  `art_id` int(11) DEFAULT NULL,
  `tag_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;




--------------------------------------------------------------------------Saturday 12th of April 2014 01:01:50 PM

CREATE TABLE `article` (
  `article_id` int(11) NOT NULL AUTO_INCREMENT,
  `price` varchar(20) DEFAULT NULL,
  `url` varchar(255) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`article_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO article VALUES("1","5","erty.com","dsfghjk");
INSERT INTO article VALUES("2","5.04","erty.com","asdfghj");
INSERT INTO article VALUES("3","5.04","erty.com","qwertyui");





CREATE TABLE `category` (
  `category_id` int(11) NOT NULL AUTO_INCREMENT,
  `date_created_on` date DEFAULT NULL,
  `priority` double DEFAULT NULL,
  PRIMARY KEY (`category_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO category VALUES("1","2012-12-03","12.5");
INSERT INTO category VALUES("2","2012-05-12","25.9");
INSERT INTO category VALUES("3","2012-09-02","78.5");





CREATE TABLE `tag` (
  `tag_id` int(11) NOT NULL AUTO_INCREMENT,
  `priority` varchar(220) DEFAULT NULL,
  `second_priority` float DEFAULT NULL,
  `cat_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`tag_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;






CREATE TABLE `user` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `password` varchar(90) DEFAULT NULL,
  `income` float DEFAULT NULL,
  `picture_url` varchar(200) DEFAULT NULL,
  `art_id` int(11) DEFAULT NULL,
  `tag_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

INSERT INTO user VALUES("1","sdfds","1.25","GOGO","1","2");
INSERT INTO user VALUES("2","sdfdsfyukj","1.58","PACO","2","3");



--------------------------------------------------------------------------Saturday 12th of April 2014 01:05:31 PM

CREATE TABLE `article` (
  `article_id` int(11) NOT NULL AUTO_INCREMENT,
  `price` varchar(20) DEFAULT NULL,
  `url` varchar(255) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`article_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO article VALUES("1","5","erty.com","dsfghjk");
INSERT INTO article VALUES("2","5.04","erty.com","asdfghj");
INSERT INTO article VALUES("3","5.04","erty.com","qwertyui");





CREATE TABLE `category` (
  `category_id` int(11) NOT NULL AUTO_INCREMENT,
  `date_created_on` date DEFAULT NULL,
  `priority` double DEFAULT NULL,
  PRIMARY KEY (`category_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO category VALUES("1","2012-12-03","12.5");
INSERT INTO category VALUES("2","2012-05-12","25.9");
INSERT INTO category VALUES("3","2012-09-02","78.5");





CREATE TABLE `tag` (
  `tag_id` int(11) NOT NULL AUTO_INCREMENT,
  `priority` varchar(220) DEFAULT NULL,
  `second_priority` float DEFAULT NULL,
  `cat_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`tag_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;






CREATE TABLE `user` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `password` varchar(90) DEFAULT NULL,
  `income` float DEFAULT NULL,
  `picture_url` varchar(200) DEFAULT NULL,
  `art_id` int(11) DEFAULT NULL,
  `tag_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO user VALUES("1","sdfds","1.25","GOGO","1","2");
INSERT INTO user VALUES("2","sdfdsfyukj","1.58","PACO","2","3");
INSERT INTO user VALUES("3","sdfdsio","1.29","NASKO","3","1");



--------------------------------------------------------------------------Saturday 12th of April 2014 01:05:58 PM

CREATE TABLE `article` (
  `article_id` int(11) NOT NULL AUTO_INCREMENT,
  `price` varchar(20) DEFAULT NULL,
  `url` varchar(255) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`article_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO article VALUES("1","5","erty.com","dsfghjk");
INSERT INTO article VALUES("2","5.04","erty.com","asdfghj");
INSERT INTO article VALUES("3","5.04","erty.com","qwertyui");





CREATE TABLE `category` (
  `category_id` int(11) NOT NULL AUTO_INCREMENT,
  `date_created_on` date DEFAULT NULL,
  `priority` double DEFAULT NULL,
  PRIMARY KEY (`category_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO category VALUES("1","2012-12-03","12.5");
INSERT INTO category VALUES("2","2012-05-12","25.9");
INSERT INTO category VALUES("3","2012-09-02","78.5");





CREATE TABLE `tag` (
  `tag_id` int(11) NOT NULL AUTO_INCREMENT,
  `priority` varchar(220) DEFAULT NULL,
  `second_priority` float DEFAULT NULL,
  `cat_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`tag_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO tag VALUES("1","kon","2.15","2");
INSERT INTO tag VALUES("2","sopol","1.89","1");
INSERT INTO tag VALUES("3","gevrek","6.45","3");





CREATE TABLE `user` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `password` varchar(90) DEFAULT NULL,
  `income` float DEFAULT NULL,
  `picture_url` varchar(200) DEFAULT NULL,
  `art_id` int(11) DEFAULT NULL,
  `tag_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO user VALUES("1","sdfds","1.25","GOGO","1","2");
INSERT INTO user VALUES("2","sdfdsfyukj","1.58","PACO","2","3");
INSERT INTO user VALUES("3","sdfdsio","1.29","NASKO","3","1");



--------------------------------------------------------------------------Saturday 12th of April 2014 01:07:44 PM

CREATE TABLE `article` (
  `article_id` int(11) NOT NULL AUTO_INCREMENT,
  `price` varchar(20) DEFAULT NULL,
  `url` varchar(255) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`article_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO article VALUES("1","5","erty.com","dsfghjk");
INSERT INTO article VALUES("2","5.04","erty.com","asdfghj");
INSERT INTO article VALUES("3","5.04","erty.com","qwertyui");





CREATE TABLE `category` (
  `category_id` int(11) NOT NULL AUTO_INCREMENT,
  `date_created_on` date DEFAULT NULL,
  `priority` double DEFAULT NULL,
  PRIMARY KEY (`category_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO category VALUES("1","2012-12-03","12.5");
INSERT INTO category VALUES("2","2012-05-12","25.9");
INSERT INTO category VALUES("3","2012-09-02","78.5");





CREATE TABLE `tag` (
  `tag_id` int(11) NOT NULL AUTO_INCREMENT,
  `priority` varchar(220) DEFAULT NULL,
  `second_priority` float DEFAULT NULL,
  `cat_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`tag_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO tag VALUES("1","kon","2.15","2");
INSERT INTO tag VALUES("2","sopol","1.89","1");
INSERT INTO tag VALUES("3","gevrek","6.45","3");





CREATE TABLE `user` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `password` varchar(90) DEFAULT NULL,
  `income` float DEFAULT NULL,
  `picture_url` varchar(200) DEFAULT NULL,
  `art_id` int(11) DEFAULT NULL,
  `tag_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO user VALUES("1","sdfds","1.25","GOGO","1","2");
INSERT INTO user VALUES("2","sdfdsfyukj","1.58","PACO","2","3");
INSERT INTO user VALUES("3","sdfdsio","1.29","NASKO","3","1");



--------------------------------------------------------------------------Saturday 12th of April 2014 01:11:58 PM

CREATE TABLE `article` (
  `article_id` int(11) NOT NULL AUTO_INCREMENT,
  `price` varchar(20) DEFAULT NULL,
  `url` varchar(255) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`article_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO article VALUES("1","5","erty.com","dsfghjk");
INSERT INTO article VALUES("2","5.04","erty.com","asdfghj");
INSERT INTO article VALUES("3","5.04","erty.com","qwertyui");





CREATE TABLE `category` (
  `category_id` int(11) NOT NULL AUTO_INCREMENT,
  `date_created_on` date DEFAULT NULL,
  `priority` double DEFAULT NULL,
  PRIMARY KEY (`category_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO category VALUES("1","2012-12-03","12.5");
INSERT INTO category VALUES("2","2012-05-12","25.9");
INSERT INTO category VALUES("3","2012-09-02","78.5");





CREATE TABLE `tag` (
  `tag_id` int(11) NOT NULL AUTO_INCREMENT,
  `priority` varchar(220) DEFAULT NULL,
  `second_priority` float DEFAULT NULL,
  `cat_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`tag_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO tag VALUES("1","kon","2.15","2");
INSERT INTO tag VALUES("2","sopol","1.89","1");
INSERT INTO tag VALUES("3","gevrek","6.45","3");





CREATE TABLE `user` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `password` varchar(90) DEFAULT NULL,
  `income` float DEFAULT NULL,
  `picture_url` varchar(200) DEFAULT NULL,
  `art_id` int(11) DEFAULT NULL,
  `tag_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO user VALUES("1","sdfds","1.25","GOGO","1","2");
INSERT INTO user VALUES("2","sdfdsfyukj","1.58","PACO","2","3");
INSERT INTO user VALUES("3","sdfdsio","1.29","NASKO","3","1");



--------------------------------------------------------------------------Saturday 12th of April 2014 01:13:47 PM

CREATE TABLE `article` (
  `article_id` int(11) NOT NULL AUTO_INCREMENT,
  `price` varchar(20) DEFAULT NULL,
  `url` varchar(255) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`article_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO article VALUES("1","5","erty.com","dsfghjk");
INSERT INTO article VALUES("2","5.04","erty.com","asdfghj");
INSERT INTO article VALUES("3","5.04","erty.com","qwertyui");





CREATE TABLE `category` (
  `category_id` int(11) NOT NULL AUTO_INCREMENT,
  `date_created_on` date DEFAULT NULL,
  `priority` double DEFAULT NULL,
  PRIMARY KEY (`category_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO category VALUES("1","2012-12-03","12.5");
INSERT INTO category VALUES("2","2012-05-12","25.9");
INSERT INTO category VALUES("3","2012-09-02","78.5");





CREATE TABLE `tag` (
  `tag_id` int(11) NOT NULL AUTO_INCREMENT,
  `priority` varchar(220) DEFAULT NULL,
  `second_priority` float DEFAULT NULL,
  `cat_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`tag_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO tag VALUES("1","kon","2.15","2");
INSERT INTO tag VALUES("2","sopol","1.89","1");
INSERT INTO tag VALUES("3","gevrek","6.45","3");





CREATE TABLE `user` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `password` varchar(90) DEFAULT NULL,
  `income` float DEFAULT NULL,
  `picture_url` varchar(200) DEFAULT NULL,
  `art_id` int(11) DEFAULT NULL,
  `tag_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO user VALUES("1","sdfds","1.25","GOGO","1","2");
INSERT INTO user VALUES("2","sdfdsfyukj","1.58","PACO","2","3");
INSERT INTO user VALUES("3","sdfdsio","1.29","NASKO","3","1");





CREATE TABLE `user1` (
  `user1_id` int(11) NOT NULL AUTO_INCREMENT,
  `password` date DEFAULT NULL,
  PRIMARY KEY (`user1_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;




--------------------------------------------------------------------------Saturday 12th of April 2014 01:18:44 PM

CREATE TABLE `article` (
  `article_id` int(11) NOT NULL AUTO_INCREMENT,
  `price` varchar(20) DEFAULT NULL,
  `url` varchar(255) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`article_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO article VALUES("1","5","erty.com","dsfghjk");
INSERT INTO article VALUES("2","5.04","erty.com","asdfghj");
INSERT INTO article VALUES("3","5.04","erty.com","qwertyui");





CREATE TABLE `category` (
  `category_id` int(11) NOT NULL AUTO_INCREMENT,
  `date_created_on` date DEFAULT NULL,
  `priority` double DEFAULT NULL,
  PRIMARY KEY (`category_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO category VALUES("1","2012-12-03","12.5");
INSERT INTO category VALUES("2","2012-05-12","25.9");
INSERT INTO category VALUES("3","2012-09-02","78.5");





CREATE TABLE `tag` (
  `tag_id` int(11) NOT NULL AUTO_INCREMENT,
  `priority` varchar(220) DEFAULT NULL,
  `second_priority` float DEFAULT NULL,
  `cat_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`tag_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO tag VALUES("1","kon","2.15","2");
INSERT INTO tag VALUES("2","sopol","1.89","1");
INSERT INTO tag VALUES("3","gevrek","6.45","3");





CREATE TABLE `user` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `password` varchar(90) DEFAULT NULL,
  `income` float DEFAULT NULL,
  `picture_url` varchar(200) DEFAULT NULL,
  `art_id` int(11) DEFAULT NULL,
  `tag_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO user VALUES("1","sdfds","1.25","GOGO","1","2");
INSERT INTO user VALUES("2","sdfdsfyukj","1.58","PACO","2","3");
INSERT INTO user VALUES("3","sdfdsio","1.29","NASKO","3","1");





CREATE TABLE `user1` (
  `user1_id` int(11) NOT NULL AUTO_INCREMENT,
  `password` date DEFAULT NULL,
  PRIMARY KEY (`user1_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;




--------------------------------------------------------------------------Saturday 12th of April 2014 01:19:06 PM

CREATE TABLE `article` (
  `article_id` int(11) NOT NULL AUTO_INCREMENT,
  `price` varchar(20) DEFAULT NULL,
  `url` varchar(255) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`article_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO article VALUES("1","5","erty.com","dsfghjk");
INSERT INTO article VALUES("2","5.04","erty.com","asdfghj");
INSERT INTO article VALUES("3","5.04","erty.com","qwertyui");





CREATE TABLE `category` (
  `category_id` int(11) NOT NULL AUTO_INCREMENT,
  `date_created_on` date DEFAULT NULL,
  `priority` double DEFAULT NULL,
  PRIMARY KEY (`category_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO category VALUES("1","2012-12-03","12.5");
INSERT INTO category VALUES("2","2012-05-12","25.9");
INSERT INTO category VALUES("3","2012-09-02","78.5");





CREATE TABLE `tag` (
  `tag_id` int(11) NOT NULL AUTO_INCREMENT,
  `priority` varchar(220) DEFAULT NULL,
  `second_priority` float DEFAULT NULL,
  `cat_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`tag_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO tag VALUES("1","kon","2.15","2");
INSERT INTO tag VALUES("2","sopol","1.89","1");
INSERT INTO tag VALUES("3","gevrek","6.45","3");





CREATE TABLE `user1` (
  `user1_id` int(11) NOT NULL AUTO_INCREMENT,
  `password` date DEFAULT NULL,
  PRIMARY KEY (`user1_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO user1 VALUES("1","0000-00-00");
INSERT INTO user1 VALUES("2","0000-00-00");
INSERT INTO user1 VALUES("3","0000-00-00");





CREATE TABLE `user2` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `income` float DEFAULT NULL,
  `picture_url` varchar(200) DEFAULT NULL,
  `art_id` int(11) DEFAULT NULL,
  `tag_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO user2 VALUES("1","1.25","GOGO","1","2");
INSERT INTO user2 VALUES("2","1.58","PACO","2","3");
INSERT INTO user2 VALUES("3","1.29","NASKO","3","1");



--------------------------------------------------------------------------Saturday 12th of April 2014 01:39:33 PM

CREATE TABLE `article` (
  `article_id` int(11) NOT NULL AUTO_INCREMENT,
  `price` varchar(20) DEFAULT NULL,
  `url` varchar(255) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`article_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO article VALUES("1","5","erty.com","dsfghjk");
INSERT INTO article VALUES("2","5.04","erty.com","asdfghj");
INSERT INTO article VALUES("3","5.04","erty.com","qwertyui");





CREATE TABLE `category` (
  `category_id` int(11) NOT NULL AUTO_INCREMENT,
  `date_created_on` date DEFAULT NULL,
  `priority` double DEFAULT NULL,
  PRIMARY KEY (`category_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO category VALUES("1","2012-12-03","12.5");
INSERT INTO category VALUES("2","2012-05-12","25.9");
INSERT INTO category VALUES("3","2012-09-02","78.5");





CREATE TABLE `tag` (
  `tag_id` int(11) NOT NULL AUTO_INCREMENT,
  `priority` varchar(220) DEFAULT NULL,
  `second_priority` float DEFAULT NULL,
  `cat_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`tag_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO tag VALUES("1","kon","2.15","2");
INSERT INTO tag VALUES("2","sopol","1.89","1");
INSERT INTO tag VALUES("3","gevrek","6.45","3");





CREATE TABLE `user1` (
  `user1_id` int(11) NOT NULL AUTO_INCREMENT,
  `password` date DEFAULT NULL,
  PRIMARY KEY (`user1_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO user1 VALUES("1","0000-00-00");
INSERT INTO user1 VALUES("2","0000-00-00");
INSERT INTO user1 VALUES("3","0000-00-00");





CREATE TABLE `user2` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `income` float DEFAULT NULL,
  `picture_url` varchar(200) DEFAULT NULL,
  `art_id` int(11) DEFAULT NULL,
  `tag_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO user2 VALUES("1","1.25","GOGO","1","2");
INSERT INTO user2 VALUES("2","1.58","PACO","2","3");
INSERT INTO user2 VALUES("3","1.29","NASKO","3","1");



--------------------------------------------------------------------------Saturday 12th of April 2014 01:43:24 PM

CREATE TABLE `article` (
  `article_id` int(11) NOT NULL AUTO_INCREMENT,
  `price` varchar(20) DEFAULT NULL,
  `url` varchar(255) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`article_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO article VALUES("1","5","erty.com","dsfghjk");
INSERT INTO article VALUES("2","5.04","erty.com","asdfghj");
INSERT INTO article VALUES("3","5.04","erty.com","qwertyui");





CREATE TABLE `category` (
  `category_id` int(11) NOT NULL AUTO_INCREMENT,
  `date_created_on` date DEFAULT NULL,
  `priority` double DEFAULT NULL,
  PRIMARY KEY (`category_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO category VALUES("1","2012-12-03","12.5");
INSERT INTO category VALUES("2","2012-05-12","25.9");
INSERT INTO category VALUES("3","2012-09-02","78.5");





CREATE TABLE `tag` (
  `tag_id` int(11) NOT NULL AUTO_INCREMENT,
  `priority` varchar(220) DEFAULT NULL,
  `second_priority` float DEFAULT NULL,
  `cat_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`tag_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO tag VALUES("1","kon","2.15","2");
INSERT INTO tag VALUES("2","sopol","1.89","1");
INSERT INTO tag VALUES("3","gevrek","6.45","3");





CREATE TABLE `user1` (
  `user1_id` int(11) NOT NULL AUTO_INCREMENT,
  `password` date DEFAULT NULL,
  PRIMARY KEY (`user1_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO user1 VALUES("1","0000-00-00");
INSERT INTO user1 VALUES("2","0000-00-00");
INSERT INTO user1 VALUES("3","0000-00-00");





CREATE TABLE `user2` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `income` float DEFAULT NULL,
  `picture_url` varchar(200) DEFAULT NULL,
  `art_id` int(11) DEFAULT NULL,
  `tag_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO user2 VALUES("1","1.25","GOGO","1","2");
INSERT INTO user2 VALUES("2","1.58","PACO","2","3");
INSERT INTO user2 VALUES("3","1.29","NASKO","3","1");



--------------------------------------------------------------------------Saturday 12th of April 2014 01:43:59 PM

CREATE TABLE `article` (
  `article_id` int(11) NOT NULL AUTO_INCREMENT,
  `price` varchar(20) DEFAULT NULL,
  `url` varchar(255) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`article_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO article VALUES("1","5","erty.com","dsfghjk");
INSERT INTO article VALUES("2","5.04","erty.com","asdfghj");
INSERT INTO article VALUES("3","5.04","erty.com","qwertyui");





CREATE TABLE `category` (
  `category_id` int(11) NOT NULL AUTO_INCREMENT,
  `date_created_on` date DEFAULT NULL,
  `priority` double DEFAULT NULL,
  PRIMARY KEY (`category_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO category VALUES("1","2012-12-03","12.5");
INSERT INTO category VALUES("2","2012-05-12","25.9");
INSERT INTO category VALUES("3","2012-09-02","78.5");





CREATE TABLE `tag` (
  `tag_id` int(11) NOT NULL AUTO_INCREMENT,
  `priority` varchar(220) DEFAULT NULL,
  `second_priority` float DEFAULT NULL,
  `cat_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`tag_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO tag VALUES("1","kon","2.15","2");
INSERT INTO tag VALUES("2","sopol","1.89","1");
INSERT INTO tag VALUES("3","gevrek","6.45","3");





CREATE TABLE `user1` (
  `user1_id` int(11) NOT NULL AUTO_INCREMENT,
  `password` date DEFAULT NULL,
  PRIMARY KEY (`user1_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO user1 VALUES("1","0000-00-00");
INSERT INTO user1 VALUES("2","0000-00-00");
INSERT INTO user1 VALUES("3","0000-00-00");





CREATE TABLE `user2` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `income` float DEFAULT NULL,
  `picture_url` varchar(200) DEFAULT NULL,
  `art_id` int(11) DEFAULT NULL,
  `tag_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO user2 VALUES("1","1.25","GOGO","1","2");
INSERT INTO user2 VALUES("2","1.58","PACO","2","3");
INSERT INTO user2 VALUES("3","1.29","NASKO","3","1");



--------------------------------------------------------------------------Saturday 12th of April 2014 01:44:44 PM

CREATE TABLE `article` (
  `article_id` int(11) NOT NULL AUTO_INCREMENT,
  `price` varchar(20) DEFAULT NULL,
  `url` varchar(255) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`article_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO article VALUES("1","5","erty.com","dsfghjk");
INSERT INTO article VALUES("2","5.04","erty.com","asdfghj");
INSERT INTO article VALUES("3","5.04","erty.com","qwertyui");





CREATE TABLE `category` (
  `category_id` int(11) NOT NULL AUTO_INCREMENT,
  `date_created_on` date DEFAULT NULL,
  `priority` double DEFAULT NULL,
  PRIMARY KEY (`category_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO category VALUES("1","2012-12-03","12.5");
INSERT INTO category VALUES("2","2012-05-12","25.9");
INSERT INTO category VALUES("3","2012-09-02","78.5");





CREATE TABLE `tag` (
  `tag_id` int(11) NOT NULL AUTO_INCREMENT,
  `priority` varchar(220) DEFAULT NULL,
  `second_priority` float DEFAULT NULL,
  `cat_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`tag_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO tag VALUES("1","kon","2.15","2");
INSERT INTO tag VALUES("2","sopol","1.89","1");
INSERT INTO tag VALUES("3","gevrek","6.45","3");





CREATE TABLE `user1` (
  `user1_id` int(11) NOT NULL AUTO_INCREMENT,
  `password` date DEFAULT NULL,
  PRIMARY KEY (`user1_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO user1 VALUES("1","0000-00-00");
INSERT INTO user1 VALUES("2","0000-00-00");
INSERT INTO user1 VALUES("3","0000-00-00");





CREATE TABLE `user2` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `income` float DEFAULT NULL,
  `picture_url` varchar(200) DEFAULT NULL,
  `art_id` int(11) DEFAULT NULL,
  `tag_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO user2 VALUES("1","1.25","GOGO","1","2");
INSERT INTO user2 VALUES("2","1.58","PACO","2","3");
INSERT INTO user2 VALUES("3","1.29","NASKO","3","1");



--------------------------------------------------------------------------Saturday 12th of April 2014 01:44:51 PM

CREATE TABLE `article` (
  `article_id` int(11) NOT NULL AUTO_INCREMENT,
  `price` varchar(20) DEFAULT NULL,
  `url` varchar(255) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`article_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO article VALUES("1","5","erty.com","dsfghjk");
INSERT INTO article VALUES("2","5.04","erty.com","asdfghj");
INSERT INTO article VALUES("3","5.04","erty.com","qwertyui");





CREATE TABLE `category` (
  `category_id` int(11) NOT NULL AUTO_INCREMENT,
  `date_created_on` date DEFAULT NULL,
  `priority` double DEFAULT NULL,
  PRIMARY KEY (`category_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO category VALUES("1","2012-12-03","12.5");
INSERT INTO category VALUES("2","2012-05-12","25.9");
INSERT INTO category VALUES("3","2012-09-02","78.5");





CREATE TABLE `tag` (
  `tag_id` int(11) NOT NULL AUTO_INCREMENT,
  `priority` varchar(220) DEFAULT NULL,
  `second_priority` float DEFAULT NULL,
  `cat_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`tag_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO tag VALUES("1","kon","2.15","2");
INSERT INTO tag VALUES("2","sopol","1.89","1");
INSERT INTO tag VALUES("3","gevrek","6.45","3");





CREATE TABLE `user1` (
  `user1_id` int(11) NOT NULL AUTO_INCREMENT,
  `password` date DEFAULT NULL,
  PRIMARY KEY (`user1_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO user1 VALUES("1","0000-00-00");
INSERT INTO user1 VALUES("2","0000-00-00");
INSERT INTO user1 VALUES("3","0000-00-00");





CREATE TABLE `user2` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `income` float DEFAULT NULL,
  `picture_url` varchar(200) DEFAULT NULL,
  `art_id` int(11) DEFAULT NULL,
  `tag_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO user2 VALUES("1","1.25","GOGO","1","2");
INSERT INTO user2 VALUES("2","1.58","PACO","2","3");
INSERT INTO user2 VALUES("3","1.29","NASKO","3","1");



--------------------------------------------------------------------------Saturday 12th of April 2014 01:45:24 PM

CREATE TABLE `article` (
  `article_id` int(11) NOT NULL AUTO_INCREMENT,
  `price` varchar(20) DEFAULT NULL,
  `url` varchar(255) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`article_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO article VALUES("1","5","erty.com","dsfghjk");
INSERT INTO article VALUES("2","5.04","erty.com","asdfghj");
INSERT INTO article VALUES("3","5.04","erty.com","qwertyui");





CREATE TABLE `category` (
  `category_id` int(11) NOT NULL AUTO_INCREMENT,
  `date_created_on` date DEFAULT NULL,
  `priority` double DEFAULT NULL,
  PRIMARY KEY (`category_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO category VALUES("1","2012-12-03","12.5");
INSERT INTO category VALUES("2","2012-05-12","25.9");
INSERT INTO category VALUES("3","2012-09-02","78.5");





CREATE TABLE `tag` (
  `tag_id` int(11) NOT NULL AUTO_INCREMENT,
  `priority` varchar(220) DEFAULT NULL,
  `second_priority` float DEFAULT NULL,
  `cat_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`tag_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO tag VALUES("1","kon","2.15","2");
INSERT INTO tag VALUES("2","sopol","1.89","1");
INSERT INTO tag VALUES("3","gevrek","6.45","3");





CREATE TABLE `user1` (
  `user1_id` int(11) NOT NULL AUTO_INCREMENT,
  `password` date DEFAULT NULL,
  PRIMARY KEY (`user1_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO user1 VALUES("1","0000-00-00");
INSERT INTO user1 VALUES("2","0000-00-00");
INSERT INTO user1 VALUES("3","0000-00-00");





CREATE TABLE `user2` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `income` float DEFAULT NULL,
  `picture_url` varchar(200) DEFAULT NULL,
  `art_id` int(11) DEFAULT NULL,
  `tag_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO user2 VALUES("1","1.25","GOGO","1","2");
INSERT INTO user2 VALUES("2","1.58","PACO","2","3");
INSERT INTO user2 VALUES("3","1.29","NASKO","3","1");



--------------------------------------------------------------------------Saturday 12th of April 2014 01:46:25 PM