#!/usr/bin/env python
import datetime 
import time

import MySQLdb

def close(connection):
    connection.close()

db = MySQLdb.connect(host = "localhost", user="root", passwd="plamen92", db="Task8")
cur = db.cursor()
#run the create only once!!!!
#cur.execute("CREATE TABLE User_part1(name VARCHAR(32));")
#cur.execute("CREATE TABLE User_part2(created_on DATE , password VARCHAR(32), U_id INT,T_id INT);")
#string2 = "%d" %(row[1])
# 4.Which are the Category(s) for a given Tag
#cur.execute("SELECT category_id FROM Article WHERE id = category_id;")
#for row in cur.fetchall():
#    print row[0]
#cur.execute("CREATE TABLE article_part1 (published_on DATE);")
#cur.execute("CREATE TABLE article_part2 (name varchar(32) , user_id int);")



cur.execute("SELECT created_on, password,U_id, T_id FROM User;")
start = datetime
for row in cur.fetchall():
	start = row[0];
	string2 = "%d" %(row[2])
	string3 = "%d" %(row[3])
	strk = start.strftime("%Y-%m-%d")
	print strk
	cur.execute("INSERT INTO User_part2 values('"+strk+"','"+row[1]+"',"+string2+","+string3+");")


#cur.execute("CREATE TABLE article_part2 (price DECIMAL(30) NOT NULL, article_id INT(30) NOT NULL PRIMARY KEY AUTO_INCREMENT UNIQUE, category_id INT(30) NOT NULL UNIQUE);")
#cur.execute("INSERT INTO article_part2 SELECT Article.price, Article.id, Article.category_id FROM Article;")

cur.execute("SELECT name FROM User;")
for row in cur.fetchall():
	
	cur.execute("INSERT INTO User_part1 values('"+row[0]+"');")


db.commit()
#cur.execute("SELECT * FROM article_part2;")
#for row in cur.fetchall():
#    print row[0], row[1], row[2]
close(db)
