﻿from sqlalchemy import *
from sqlalchemy.orm import sessionmaker


metadata = MetaData()


try:

    engine = create_engine('mysql://root:localhost:3306/exam');
    connection = engine.connect()
   # metadata.bind=engine
    Session = sessionmaker(bind=engine)

    # create a Session
    session = Session()
    metadata.reflect(bind=engine)
    article_table = metadata.tables['article']
    tag_table  = metadata.tables['tag']
    user_table = metadata.tables['user']
    category_table = metadata.tables['category']

    #input the table from task
    t = raw_input("Enter the name from the task\n")
    t=str(t).lower().lstrip().rstrip()


    new_table1 = t+"_part1"

    new_table2 = t+"_part2"

    input_1 = raw_input("Enter fields for part1 from create sql\n")

    input_1 = str(input_1)

    str1 = "create table if not exists "+new_table1+"(id int not null primary key auto_increment, %s )"
    str1 = str1 % input_1




    input_1 = raw_input("Enter fields for part2 create sql\n")

    input_1 = str(input_1)
    str2 = "create table if not exists "+new_table2+"(id int not null primary key auto_increment, %s )"
    str2 = str2 % input_1


    #alt1 = "alter table "+new_table1+" add column "+new_table2+"_id int auto_increment, add FOREIGN KEY ("+new_table2+"_id) REFERENCES "+new_table2+"(id)"
    #alt2 = "alter table "+new_table2+" add column "+new_table1+"_id int auto_increment, add FOREIGN KEY ("+new_table1+"_id) REFERENCES "+new_table1+"(id)"


    connection.execute(str1)
    connection.execute(str2)

    #connection.execute(alt1)
    #connection.execute(alt2)

    metadata.reflect(bind=engine)
    table1 = metadata.tables[new_table1]
    table2 = metadata.tables[new_table2]


    parent_table = metadata.tables[t]
    q= parent_table.select()
    res = connection.execute(q)
    for item in res:
        q = table1.insert().values(item)
        connection.execute(q)

        q= table2.insert().values(item)
        connection.execute(q)


    connection.close()
except Exception as e:
    print e