---First query
select User.name as username, Tag.name as tag_name from Tag, Category,Tag_Category, User where User.id = Category.user_id and Category.id = Tag_Category.category_id and Tag.id = Tag_Category.tag_id;

---Second query
select Category_part1.name as category_name, Article.name as article_name from Category_part2 join Category_part1 join User join Article where Article.user_id = User.id and User.id = Category_part2.user_id and Category_part2.id = Category_part1.table2_id;

