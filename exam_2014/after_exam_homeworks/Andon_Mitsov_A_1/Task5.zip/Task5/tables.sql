create table Article(id int not null primary key,published_on date,price decimal(30,2));
create table User(id int not null primary key,name varchar(32),created_on date, password varchar(32));
create table Category(id int not null primary key,date_created_on date, description varchar(256));
create table Tag(id int not null primary key,priority int, name varchar(32),user_id int not null);
create table Tag_Article(tag_id int not null, article_id int not null);
create table User_Category(user_id int not null, category_id int not null);

insert into Article values(1,"2014-2-20",1.4);
insert into Article values(2,"2013-1-1",2.5);
insert into Category values(1,"2014-1-1","Sci-fi-space shit");
insert into Category values(2,"2013-2-2","Comedy - funny guys talk stuf");
insert into User values(1,"Donny","2013-3-3","nananana");
insert into User values(2,"Brandon","2013-4-4","light");
insert into Tag values(1,2,"Tag1",1);
insert into Tag values(2,1,"Tag2",1);

insert into Tag_Article values(1,2);
insert into Tag_Article values(2,1);
insert into User_Category values(1,1);
insert into User_Category values(2,2);
