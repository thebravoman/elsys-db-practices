--First query
select User.name as username, Article.published_on from User, Article, Tag,Tag_Article where User.id = Tag.user_id and Tag.id = Tag_Article.tag_id and Article.id = Tag_Article.article_id;

--Second query
select Category.description as category, Tag_part2.name as tag_name from Tag_part2, Category, User, User_Category where User.id = User_Category.user_id and Category.id = User_Category.category_id and Tag_part2.user_id = User.id; 
