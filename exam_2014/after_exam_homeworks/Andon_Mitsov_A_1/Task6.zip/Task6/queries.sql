-----First query
select User.name as username, Tag.description as description from Tag, User, Category where Tag.Category_id = Category.id and Category.user_id = User.id;

-----Second query
select Article.published_on, Category_part1.description from Category_part1, Category_part2, User, Article where Category_part2.user_id = User.id and User.article_id = Article.id and Category_part1.table2_id = Category_part2.id;
