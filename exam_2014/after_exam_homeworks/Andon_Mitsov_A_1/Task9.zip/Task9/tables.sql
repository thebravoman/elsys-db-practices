create table Article(id int not null primary key,name varchar(32),price decimal(15,2));
create table User(id int not null primary key,name varchar(32), age int, created_on date, tag_id int not null ,category_id int not null);
create table Category(id int not null primary key, name varchar(32), description varchar(256),user_id int not null);
create table Tag(id int not null primary key, description varchar(256), name varchar(32));

insert into Article values(1,"Damn nigga!",1.4,1);
insert into Article values(2,"Random name",2.5,2);
insert into Category values(1,"Sci-fi","space shit",1);
insert into Category values(2,"Comedy","funny guys talk stuf",2);
insert into User values(1,"Donny",18,"2014-1-1",1,1);
insert into User values(2,"Brandon",20,"2014-1-1",2,2);
insert into Tag values(1,"game of thrones","Tag1");
insert into Tag values(2,"game of goats","Tag2");

