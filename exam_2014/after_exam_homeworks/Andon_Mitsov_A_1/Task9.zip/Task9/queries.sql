---First query
select distinct Article.name as article_name, User.name as username from Article,User, Category where User.category_id = Article.category_id;

---Second query
select distinct Tag.name as tag_name, Category_part1.name as category_name from Tag, Category_part1, Category_part2, User where User.tag_id = Tag.id and User.category_id=Category_part1.id;

