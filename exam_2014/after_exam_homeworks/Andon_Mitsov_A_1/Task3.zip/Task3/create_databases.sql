create table Article(id int not null primary key, price decimal(30,2),name varchar(30), user_id int not null);
create table User(id int not null primary key,created_on date, password varchar(32),name varchar(64));
create table Category(id int not null primary key,name varchar(30),created_on date,user_id int not null);
create table Tag(id int not null primary key,description varchar(256),priority int);
create table Tag_Category(user_id int, category_id int);
