--First query
select User.name, Tag.priority from User join Tag join Tag_Category join Category where User.id = Category.user_id and Category.id = Tag_Category.category_id and Tag.id = Tag_Category.user_id;

--Second query
select Category_part2.name, Article.name from User join Article join Category_part2 where Article.user_id = User.id and Category_part2.user_id =User.id;
