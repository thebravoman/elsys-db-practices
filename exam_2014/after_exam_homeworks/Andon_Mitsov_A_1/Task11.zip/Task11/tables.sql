create table Article(id int not null primary key,name varchar(32),price decimal(15,2));
create table User(id int not null primary key,age int, password varchar(32), created_on date);
create table Category(id int not null primary key, name varchar(32), date_created_on date, user_id int not null, article_id int not null);
create table Tag(id int not null primary key, name varchar(256), priority int);
create table User_Tag(User_id int, tag_id int);

insert into Article values(1,"Damn nigga!",10.20);
insert into Article values(2,"Krai",2.50);
insert into Category values(1,"Sci-fi","1999-1-1",1,1);
insert into Category values(2,"Comedy","1111-11-11",2,2);
insert into User values(1,12,"smthing","2014-1-1");
insert into User values(2,15,"Smthing2","2014-1-1");
insert into Tag values(1,"game of thrones",1);
insert into Tag values(2,"game of goats",2);
insert into User_Tag values(1,1);
insert into User_Tag values(2,2);

