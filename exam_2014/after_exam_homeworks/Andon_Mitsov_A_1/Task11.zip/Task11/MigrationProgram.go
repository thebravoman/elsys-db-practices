package main

import(
	"database/sql"
	"fmt"	
	"time"

)

import _ "github.com/go-sql-driver/mysql"


type Table1 struct {
	id int
	age int
	content_id int
}

type Table2 struct {
	id int
	password string
	date time.Time
}


func main(){
	database,err := sql.Open("mysql","root:@/Task11?parseTime=true")

	if err != nil{
		fmt.Printf("Database not created")
	}

	res, errx := database.Query("select COUNT(*) from User")
	

	if errx != nil{
		fmt.Println("Error:",errx.Error())
		return 
	}

	var count int
	res.Next()
	if err := res.Scan(&count); err !=nil{
		fmt.Println("Error:",err.Error())
		return 
	}


	articles := make([]Table1,count,count)
	contents := make([]Table2,count,count)
	
	stmtDel,errdel := database.Prepare("drop table User")
	
	if errdel != nil{
		fmt.Println("Error:",errdel.Error())
		return 
	}
	

	stmtCreateArticle := "create table User_part1 (id int not null auto_increment primary key,age int,table2_id int not null)"
	
	stmtCreateContent := "create table User_part2 (id int not null auto_increment primary key, password varchar(32),date_created_on date)"


	stmtInsertArticle := "insert into User_part1 values(?,?,?)"
	stmtInsertContent := "insert into User_part2 values(?,?,?)"

	rows, errq := database.Query("select * from User")
	if errq != nil{
		fmt.Println("Error:",errq.Error())
		return 
	}

	for i:= 0; rows.Next(); i++ {
			if err := rows.Scan(&articles[i].id,&articles[i].age, &contents[i].password,&contents[i].date); err != nil{
				fmt.Println("Error:",err.Error())
				return 
			}
			
			articles[i].content_id = i + 1

				
			contents[i].id = i + 1

	}	

	if _,err := database.Exec(stmtCreateArticle); err != nil{
		fmt.Println("Error:",err.Error())
		return 
	}

	if _,err := database.Exec(stmtCreateContent); err != nil{
		fmt.Println("Error:",err.Error())
		return 
	}

	
	for _,article_title := range articles{
		if _, err := database.Exec(stmtInsertArticle,article_title.id,article_title.age,article_title.content_id); err != nil{
			fmt.Println("Error:",err.Error())
			return 
		}
	}

	for _,article_content := range contents{
		if _, err := database.Exec(stmtInsertContent,article_content.id, article_content.password, article_content.date); err != nil{
			fmt.Println("Error:",err.Error())
			return 
		}
	}	

	if _,err := stmtDel.Exec(); err != nil{
			fmt.Println("Error:",err.Error())
			return 
	}

}
