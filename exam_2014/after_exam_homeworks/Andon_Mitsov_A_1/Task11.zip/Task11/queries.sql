---First query
select Category.name as category, Tag.name as tag from Tag, Category, User_Tag, User where Tag.id = User_Tag.tag_id and User.id = User_Tag.user_id and Category.user_id = User.id;

---Second query
select Article.name as article, User_part1.age as user from User_part1, Article, Category where Category.article_id = Article.id and User_part1.id = Category.user_id;

