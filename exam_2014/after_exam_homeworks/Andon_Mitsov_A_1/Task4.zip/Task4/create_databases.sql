create table Article(id int not null primary key,name varchar(32),price decimal(30,2), category_id int not null);
create table User(id int not null primary key,name varchar(32), password varchar(32),created_on date);
create table Category(id int not null primary key,date_created_on date, name varchar(30), user_id int not null);
create table Tag(id int not null primary key,priority int, name varchar(32));
create table Tag_Article(tag_id int not null, article_id int not null);

insert into Article values(1,"Rano e",1.4,1);
insert into Article values(2,"Spi mi se",2.5,2);
insert into Category values(1,"2014-1-1","Sci-fi",1);
insert into Category values(2,"2013-2-2","Comedy",2);
insert into User values(1,"Donny","nananana","2013-3-3");
insert into User values(2,"Brandon", "light","2013-4-4");
insert into Tag values(1,2,"Tag1");
insert into Tag values(2,1,"Tag2");
insert into Tag_Article values(1,2);
insert into Tag_Article values(2,1);
