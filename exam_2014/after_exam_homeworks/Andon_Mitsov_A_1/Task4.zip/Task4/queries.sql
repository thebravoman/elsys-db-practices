--First query
select Article.name as article_name, User.name as username from Article, Category, User where Article.category_id = Category.id and Category.user_id = User.id;

--Second query
select  Category_part2.name as category_name, Tag.name as tag_name from Tag, Article, Category_part1, Category_part2, Tag_Article where Tag.id = Tag_Article.tag_id and Article.id = Tag_Article. article_id and Article.category_id = Category_part1.id and Category_part1.descr_id = Category_part2.id;
