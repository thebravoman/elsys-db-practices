----First query
 select User.name as username, Article.name as article_name from User, Article, Tag, Article_Tag where User.id = Tag.user_id and Tag.id = Article_Tag.tag_id and Article.id = Article_Tag.article_id;

----Second query
select Tag_part1.description as tag, Category.name as category from Tag_part1, Tag_part2, Category, User where Tag_part1.table2_id = Tag_part2.id and Tag_part2.user_id = User.id and Category.user_id = User.id;


