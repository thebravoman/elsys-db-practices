--First query

select Tag.priority, Tag.description, User.age from Tag join Category join User where Category.id = Tag.category_id and Category.user_id = User.id;


--Second query
select Article.name, Category_part1.name from Article join User join User_Article join Category_part1 join Category_part2 where Article.id = User_Article.article_id and User.id = User_Article.user_id and Category_part2.user_id = User.id and Category_part2.id = Category_part1.descr_id;


