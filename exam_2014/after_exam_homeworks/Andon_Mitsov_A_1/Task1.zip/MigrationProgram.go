package main

import(
	"database/sql"
	"fmt"
)

import _ "github.com/go-sql-driver/mysql"


type Table1 struct {
	id int
	title string
	content_id int
}

type Table2 struct {
	id int
	content string
	author int
}


func main(){
	database,err := sql.Open("mysql","root:@/exam")

	if err != nil{
		fmt.Printf("Database not created")
	}

	res, errx := database.Query("select COUNT(*) from Category")
	if errx != nil{
		fmt.Println("Error:",err.Error())
		return 
	}

	var count int
	res.Next()
	if err := res.Scan(&count); err !=nil{
		fmt.Println("Error:",err.Error())
		return 
	}


	articles := make([]Table1,count,count)
	contents := make([]Table2,count,count)

	stmtDel,errdel := database.Prepare("drop table Category")
	
	if errdel != nil{
		fmt.Println("Error:",errdel.Error())
		return 
	}
	

	stmtCreateArticle := "create table Category_part1 (id int not null auto_increment primary key,name varchar(50),descr_id int not null)"
	stmtCreateContent := "create table Category_part2 (id int not null auto_increment primary key,description varchar(256), user_id int not null)"


	stmtInsertArticle := "insert into Category_part1 values(?,?,?)"
	stmtInsertContent := "insert into Category_part2 values(?,?,?)"

	rows, errq := database.Query("select * from Category")
	if errq != nil{
		fmt.Println("Error:",errq.Error())
		return 
	}

	for i:= 0; rows.Next(); i++ {
			if err := rows.Scan(&articles[i].id,&articles[i].title,&contents[i].content,&contents[i].author); err != nil{
				fmt.Println("Error:",err.Error())
				return 
			}
			
			articles[i].content_id = i + 1

				
			contents[i].id = i + 1

	}	

	if _,err := database.Exec(stmtCreateArticle); err != nil{
		fmt.Println("Error:",err.Error())
		return 
	}

	if _,err := database.Exec(stmtCreateContent); err != nil{
		fmt.Println("Error:",err.Error())
		return 
	}

	
	for _,article_title := range articles{
		if _, err := database.Exec(stmtInsertArticle,article_title.id,article_title.title,article_title.content_id); err != nil{
			fmt.Println("Error:",err.Error())
			return 
		}
	}

	for _,article_content := range contents{
		if _, err := database.Exec(stmtInsertContent,article_content.id,article_content.content,article_content.author); err != nil{
			fmt.Println("Error:",err.Error())
			return 
		}
	}	

	if _,err := stmtDel.Exec(); err != nil{
			fmt.Println("Error:",err.Error())
			return 
	}

}
