--First query
select Tag.name as tag_name, User.name as username from Tag, User, Category where Tag.category_id = Category.id and Category.user_id = User.id;

--Second query
select Article.published_on, Category_part2.name as category_name from Article, Tag, Category_part1, Category_part2 where Article.id = Tag.article_id and Tag.category_id = Category_part1.id and Category_part1.table2_id = Category_part2.id;

