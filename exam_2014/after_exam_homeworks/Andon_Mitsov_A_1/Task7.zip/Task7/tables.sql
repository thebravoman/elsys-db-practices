create table Article(id int not null primary key,published_on date,price decimal(30,2));
create table User(id int not null primary key,name varchar(32), password varchar(32), age int,article_id int);
create table Category(id int not null primary key, description varchar(256), name varchar(32),user_id int not null);
create table Tag(id int not null primary key,priority int, name varchar(32),category_id int not null, article_id int not null);


insert into Article values(1,"2014-2-20",1.4);
insert into Article values(2,"2013-1-1",2.5);
insert into Category values(1,"space shit","Sci-fi",1);
insert into Category values(2,"funny guys talk stuf","Comedy",2);
insert into User values(1,"Donny","nananana",18,1);
insert into User values(2,"Brandon","light",20,2);
insert into Tag values(1,2,"Tag1",1,1);
insert into Tag values(2,1,"Tag2",2,1);

