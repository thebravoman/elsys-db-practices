
--First query
select Article.name, User.age from Article, User, Category, User_Category where Article.category_id = Category.id and Category.id = User_Category.category_id and User.id = User_Category.user_id;

--Second query
select Tag.description, Category_part1.name from Tag, Category_part1, Article_Tag, Article where Tag.id = Article_Tag.tag_id and Article.id = Article_Tag.article_id and Article.category_id = Category_part1.id;
