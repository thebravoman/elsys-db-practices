import MySQLdb as mdb

con = mdb.connect('localhost', 'root', '951753', 'Task4')

cur = con.cursor()
cur.execute("create table Article_part1(id INT, published_on DATE);");
cur.execute("insert into Article_part1 (id, published_on) select id, published_on from Article;");
cur.execute("alter table Article rename Article_part2;");
cur.execute("alter table Article_part2 drop column published_on;");

rows = cur.fetchall()







