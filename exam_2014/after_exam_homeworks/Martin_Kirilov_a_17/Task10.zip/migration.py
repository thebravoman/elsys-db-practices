import MySQLdb as mdb

con = mdb.connect('localhost', 'root', '951753', 'Task10')

cur = con.cursor()
cur.execute("create table User_part1(id INT, picture_url TEXT);");
cur.execute("insert into User_part1 (id, picture_url) select id, picture_url from User;");
cur.execute("alter table User rename User_part2;");
cur.execute("alter table User_part2 drop column picture_url;");

rows = cur.fetchall()



