import MySQLdb as mdb

con = mdb.connect('localhost', 'root', '951753', 'Task13')

cur = con.cursor()
cur.execute("create table Category_part1(id INT, created_by TEXT);");
cur.execute("insert into Category_part1 (id, created_by) select id, created_by from Category;");
cur.execute("alter table Category rename Category_part2;");
cur.execute("alter table Category_part2 drop column created_by;");

rows = cur.fetchall()











