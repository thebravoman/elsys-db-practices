import MySQLdb as mdb

con = mdb.connect('localhost', 'root', '951753', 'Task11')

cur = con.cursor()
cur.execute("create table Article_part1(id INT, price DECIMAL);");
cur.execute("insert into Article_part1 (id, price) select id, price from Article;");
cur.execute("alter table Article rename Article_part2;");
cur.execute("alter table Article_part2 drop column price;");

rows = cur.fetchall()




