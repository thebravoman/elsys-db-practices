import MySQLdb as mdb

con = mdb.connect('localhost', 'root', '951753', 'Task9')

cur = con.cursor()
cur.execute("create table User_part1(id INT, age INT);");
cur.execute("insert into User_part1 (id, age) select id, age from User;");
cur.execute("alter table User rename User_part2;");
cur.execute("alter table User_part2 drop column age;");

rows = cur.fetchall()



