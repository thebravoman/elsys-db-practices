import MySQLdb as mdb

con = mdb.connect('localhost', 'root', '951753', 'Task1')

cur = con.cursor()
cur.execute("create table Category_part1(id INT, name VARCHAR(255));");
cur.execute("insert into Category_part1 (id,name) select id, name from Category;");
cur.execute("alter table Category rename Category_part2;");
cur.execute("alter table Category_part2 drop column name;");

rows = cur.fetchall()


