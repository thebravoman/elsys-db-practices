import MySQLdb as mdb

con = mdb.connect('localhost', 'root', '951753', 'Task3')

cur = con.cursor()
cur.execute("create table Tag_part1(id INT, name VARCHAR(255));");
cur.execute("insert into Tag_part1 (id, name) select id, name from Tag;");
cur.execute("alter table Tag rename Tag_part2;");
cur.execute("alter table Tag_part2 drop column name;");

rows = cur.fetchall()

