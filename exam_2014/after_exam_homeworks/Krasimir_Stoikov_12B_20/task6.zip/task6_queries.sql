CREATE DATABASE `llama6` DEFAULT CHARSET UTF8;
USE llama6;
CREATE TABLE `article` (
        `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
	`name` VARCHAR(42),
	`content` LONG VARCHAR,
	`published_on` DATE,
	PRIMARY KEY (`id`)
);
CREATE TABLE `category` (
        `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
	`date_created_on` DATE,
	`created_by` VARCHAR(42),
	PRIMARY KEY (`id`)
);
CREATE TABLE `user` (
        `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
	`picture_url` VARCHAR(42),
	`description` LONG VARCHAR,
	`password` VARCHAR(42),
	PRIMARY KEY (`id`)
);
CREATE TABLE `tag` (
        `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
	`priority` INT,
	`description` VARCHAR(42),
	PRIMARY KEY (`id`)
);
ALTER TABLE `article` ADD FOREIGN KEY (id) REFERENCES user(id);
ALTER TABLE `category` ADD COLUMN user_id INT UNSIGNED NOT NULL;
ALTER TABLE `tag` ADD FOREIGN KEY (id) REFERENCES article(id);

INSERT INTO user (`id`,`picture_url`,`description`,`password`) VALUES
	('1','url','llamaurl','llama'),
	('2','url','llamaurl','llama');
INSERT INTO article (`id`,`name`,`content`,`published_on`) VALUES
	('1','llama1','llama','2014-04-04'),
	('2','llama2','llama','2014-04-04');
INSERT INTO category (`id`,`date_created_on`,`created_by`, `user_id`) VALUES
	('1','2014-04-04','llama', '1'),
	('2','2014-04-04','llama', '1');
INSERT INTO tag (`id`,`priority`,`description`) VALUES
	('1','1','llama1'),
	('2','2','llama2');

SELECT user.id FROM user WHERE user.id =
(SELECT article.id FROM article, tag WHERE article.id = tag.id AND tag.id = 1);
	
CREATE TABLE Article_part1 (`id` INT UNSIGNED NOT NULL AUTO_INCREMENT, `published_on` DATE, PRIMARY KEY (`id`));
CREATE TABLE Article_part2 (`id` INT UNSIGNED NOT NULL AUTO_INCREMENT, `name` VARCHAR(42), `content` LONG VARCHAR, PRIMARY KEY (`id`));
INSERT INTO Article_part1 (`published_on`) SELECT `published_on` FROM Article;
INSERT INTO Article_part2 (`name`, `content`) SELECT `name`, `content` FROM Article;

SET foreign_key_checks = 0;

DROP TABLE Article;

SET foreign_key_checks = 1;

SELECT category.id FROM category WHERE category.user_id IN 
(SELECT user.id FROM user, article_part1 WHERE user.id = article_part1.id AND article_part1.id = 1);