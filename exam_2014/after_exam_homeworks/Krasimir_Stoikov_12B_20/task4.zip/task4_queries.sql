CREATE DATABASE `llama4` DEFAULT CHARSET UTF8;
USE llama4;
CREATE TABLE `article` (
        `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
	`content` LONG VARCHAR,
	`created_on` DATE,
	`published_on` DATE,
	PRIMARY KEY (`id`)
);
CREATE TABLE `category` (
        `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
	`created_by` VARCHAR(42),
	`date_created_on` DATE,
	PRIMARY KEY (`id`)
);
CREATE TABLE `user` (
        `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
	`password` VARCHAR(42),
	`income` FLOAT,
	`name` VARCHAR(42),
	PRIMARY KEY (`id`)
);
CREATE TABLE `tag` (
        `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
	`second_priority` FLOAT,
	`priority` INT,
	PRIMARY KEY (`id`)
);
CREATE TABLE `tag_article` (
            `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
            `article_id` INT UNSIGNED NOT NULL,
            `tag_id` INT UNSIGNED NOT NULL,
            PRIMARY KEY(`id`)
         );

ALTER TABLE `user` ADD FOREIGN KEY (id) REFERENCES article(id);
ALTER TABLE `tag` ADD COLUMN category_id INT UNSIGNED NOT NULL;

INSERT INTO article (`id`,`content`,`created_on`,`published_on`) VALUES
	('1','nah','2012-12-12','2012-12-12'),
	('2','nah','2012-12-12','2012-12-12');
INSERT INTO category (`id`,`created_by`,`date_created_on`) VALUES
	('1','none','2012-12-12'),
	('2','none','2012-12-12');
INSERT INTO user (`id`,`password`,`income`,`name`) VALUES
	('1','nah','1','none'),
	('2','nah','1','none');
INSERT INTO tag (`id`,`second_priority`,`priority`, `category_id`) VALUES
	('1','2','1', '1'),
	('2','2','1', '2');
INSERT INTO tag_article (`id`,`article_id`,`tag_id`) VALUES
	('1','2','1'),
	('2','1','2');	

SELECT tag_article.tag_id FROM tag_article WHERE tag_article.article_id IN 
(SELECT article.id FROM article JOIN user WHERE article.id = user.id AND user.id = 1);

CREATE TABLE Article_part1 (`id` INT UNSIGNED NOT NULL AUTO_INCREMENT, `content` LONG, PRIMARY KEY (`id`));
CREATE TABLE Article_part2 (`id` INT UNSIGNED NOT NULL AUTO_INCREMENT, `created_on` DATE, `published_on` DATE, PRIMARY KEY (`id`));
INSERT INTO Article_part1 (`content`) SELECT `content` FROM Article;
INSERT INTO Article_part2 (`created_on`, `published_on`) SELECT `created_on`, `published_on` FROM Article;

SET foreign_key_checks = 0;

DROP TABLE Article;

SET foreign_key_checks = 1;

SELECT DISTINCT tag.category_id FROM tag WHERE tag.id IN 
(SELECT tag_id FROM tag_article WHERE tag_article.article_id = 1);