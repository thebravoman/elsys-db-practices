CREATE DATABASE `llama2` DEFAULT CHARSET UTF8;
USE llama2;
CREATE TABLE `article` (
        `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
	`name` VARCHAR(42),
	`created_on` DATE,
	`price` DECIMAL,
	PRIMARY KEY (`id`)
);
CREATE TABLE `category` (
        `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
	`date_created_on` DATE,
	`created_by` VARCHAR(42),
	PRIMARY KEY (`id`)
);
CREATE TABLE `user` (
        `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
	`age` INTEGER,
	`password` VARCHAR(42),
	`created_on` DATE,
	PRIMARY KEY (`id`)
);
CREATE TABLE `tag` (
        `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
	`second_priority` FLOAT,
	`priority` INT,
	PRIMARY KEY (`id`)
);

ALTER TABLE `article` ADD FOREIGN KEY (id) REFERENCES tag(id);
ALTER TABLE `user` ADD COLUMN category_id INT UNSIGNED NOT NULL;
ALTER TABLE `tag` ADD FOREIGN KEY (id) REFERENCES category(id);

INSERT INTO category (`id`,`date_created_on`,`created_by`) VALUES
	('14','2014-04-04','darkpeople'),
	('1','2014-04-04','darkpeople');
INSERT INTO tag (`id`,`second_priority`,`priority`) VALUES
	('14','14.14','14'),
	('1','3.3','3');
INSERT INTO article (`id`,`name`,`created_on`,`price`) VALUES
	('14','llamazel','2014-04-04','444'),
	('1','lloridin','2014-04-04','444');
INSERT INTO user (`id`,`age`,`password`,`created_on`, `category_id`) VALUES
	('14','4000','14','2014-04-04', '14'),
	('2','22','22','2012-02-02', '14');
	
SELECT category.id FROM category JOIN tag JOIN article WHERE article.id = 14 AND tag.id = article.id AND tag.id = category.id;

CREATE TABLE Tag_part1 (`id` INT UNSIGNED NOT NULL AUTO_INCREMENT, `second_priority` FLOAT, PRIMARY KEY (`id`));
CREATE TABLE Tag_part2 (`id` INT UNSIGNED NOT NULL AUTO_INCREMENT, `priority` INT, PRIMARY KEY (`id`));
INSERT INTO Tag_part1 (`id`, `second_priority`) SELECT `id`, `second_priority` FROM Tag;
INSERT INTO Tag_part2 (`id`, `priority`) SELECT `id`, `priority` FROM Tag;

SET foreign_key_checks = 0;

DROP TABLE Tag;

SET foreign_key_checks = 1;

SELECT DISTINCT user.id FROM user JOIN category JOIN tag_part1 WHERE tag_part1.id = 14 AND tag_part1.id = category.id AND category.id = user.category_id;