CREATE DATABASE `llama3` DEFAULT CHARSET UTF8;
USE llama3;
CREATE TABLE `article` (
        `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
	`name` VARCHAR(42),
	`created_on` DATE,
	`content` LONG VARCHAR,
	PRIMARY KEY (`id`)
);
CREATE TABLE `category` (
        `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
	`date_created_on` DATE,
	`name` VARCHAR(42),
	PRIMARY KEY (`id`)
);
CREATE TABLE `user` (
        `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
	`password` VARCHAR(42),
	`age` INTEGER,
	`name` VARCHAR(42),
	PRIMARY KEY (`id`)
);
CREATE TABLE `tag` (
        `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
	`priority` INT,
	`second_priority` FLOAT,
	PRIMARY KEY (`id`)
);
CREATE TABLE `tag_article` (
            `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
            `article_id` INT UNSIGNED NOT NULL,
            `tag_id` INT UNSIGNED NOT NULL,
            PRIMARY KEY(`id`)
         );
CREATE TABLE `article_category` (
            `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
            `category_id` INT UNSIGNED NOT NULL,
            `article_id` INT UNSIGNED NOT NULL,
            PRIMARY KEY(`id`)
         );

CREATE TABLE `user_tag` (
            `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
            `tag_id` INT UNSIGNED NOT NULL,
            `user_id` INT UNSIGNED NOT NULL,
            PRIMARY KEY(`id`)
         );
INSERT INTO article (`id`,`name`,`created_on`,`content`) VALUES
	('6','llamorc','2000-02-02','donotmesswithllamas'),
	('2','llamgogh','2000-02-02','saidyou');
INSERT INTO category (`id`,`date_created_on`,`name`) VALUES
	('4','1999-09-09','onlyfortrolls'),
	('5','1999-09-09','elf');
INSERT INTO user (`id`,`password`,`age`,`name`) VALUES
	('7','777','77','llamragon'),
	('8','888','88','llamrahl');
INSERT INTO tag (`id`,`priority`,`second_priority`) VALUES
	('9','0','0'),
	('11','0','0');
	
INSERT INTO tag_article (`id`,`article_id`,`tag_id`) VALUES
	('1','6','9'),
	('2','7','9');
INSERT INTO article_category (`id`,`category_id`,`article_id`) VALUES
	('1','6','9'),
	('2','7','9');
INSERT INTO user_tag (`id`,`tag_id`,`user_id`) VALUES
	('1','6','9'),
	('2','7','9');
	
SELECT tag.id FROM tag, tag_article WHERE tag_article.article_id =
 (SELECT article.id FROM article, article_category WHERE article_category.category_id = 1);

CREATE TABLE Article_part1 (`id` INT UNSIGNED NOT NULL AUTO_INCREMENT, `content` LONG VARCHAR, PRIMARY KEY (`id`));
CREATE TABLE Article_part2 (`id` INT UNSIGNED NOT NULL AUTO_INCREMENT, `name` VARCHAR(42), `created_on` DATE, PRIMARY KEY (`id`));
INSERT INTO Article_part1 (`id`, `content`) SELECT `id`, `content` FROM Article;
INSERT INTO Article_part2 (`id`, `name`, `created_on`) SELECT `id`, `name`, `created_on` FROM Article;

DROP TABLE Article;

SELECT user_id FROM user_tag WHERE tag_id = 
 (SELECT tag_article.tag_id FROM tag_article WHERE tag_article.article_id = 1)