CREATE DATABASE `llama5` DEFAULT CHARSET UTF8;
USE llama5;
CREATE TABLE `article` (
        `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
	`url` VARCHAR(42),
	`content` LONG VARCHAR,
	`created_on` DATE,
	PRIMARY KEY (`id`)
);
CREATE TABLE `category` (
        `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
	`created_by` VARCHAR(42),
	`date_created_on` DATE,
	PRIMARY KEY (`id`)
);
CREATE TABLE `user` (
        `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
	`created_on` DATE,
	`picture_url` VARCHAR(42),
	`description` LONG VARCHAR,
	PRIMARY KEY (`id`)
);
CREATE TABLE `tag` (
        `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
	`priority` INT,
	`second_priority` FLOAT,
	PRIMARY KEY (`id`)
);
ALTER TABLE `article` ADD FOREIGN KEY (id) REFERENCES user(id);
ALTER TABLE `category` ADD FOREIGN KEY (id) REFERENCES tag(id);
ALTER TABLE `user` ADD COLUMN category_id INT UNSIGNED NOT NULL;

INSERT INTO user (`id`,`created_on`,`picture_url`,`description`, `category_id`) VALUES
	('1','2012-12-12','what','what', '1'),
	('2','2012-12-12','what','what', '1');
INSERT INTO tag (`id`,`priority`,`second_priority`) VALUES
	('1','1','2'),
	('2','1','2');
INSERT INTO article (`id`,`url`,`content`,`created_on`) VALUES
	('1','llama','llamas','2012-12-12'),
	('2','llama','llamas','2012-12-12');
INSERT INTO category (`id`,`created_by`,`date_created_on`) VALUES
	('1','','2012-12-12'),
	('2','','2012-12-12');
	
SELECT DISTINCT user.category_id FROM user WHERE user.id IN
(SELECT user.id FROM user JOIN article WHERE user.id = article.id AND article.id = 1);

CREATE TABLE User_part1 (`id` INT UNSIGNED NOT NULL AUTO_INCREMENT, `picture_url` LONG VARCHAR, PRIMARY KEY (`id`));
CREATE TABLE User_part2 (`id` INT UNSIGNED NOT NULL AUTO_INCREMENT, `created_on` DATE, `description` LONG VARCHAR, `category_id` INT UNSIGNED NOT NULL, PRIMARY KEY (`id`));
INSERT INTO User_part1 (`id`, `picture_url`) SELECT `id`, `picture_url` FROM User;
INSERT INTO User_part2 (`id`, `created_on`, `description`, `category_id`) SELECT `id`, `created_on`, `description`, `category_id` FROM User;

SET foreign_key_checks = 0;

DROP TABLE User;

SET foreign_key_checks = 1;

SELECT tag.id FROM tag JOIN category WHERE category.id = tag.id AND category.id IN
(SELECT DISTINCT category_id FROM user_part2 WHERE user_part2.id = 1);