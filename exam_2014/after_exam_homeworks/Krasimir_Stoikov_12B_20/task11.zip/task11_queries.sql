CREATE DATABASE `llama11` DEFAULT CHARSET UTF8;
USE llama11;
CREATE TABLE `article` (
        `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
	`url` VARCHAR(42),
	`price` DECIMAL,
	`published_on` DATE,
	PRIMARY KEY (`id`)
);
CREATE TABLE `category` (
        `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
	`priority` DOUBLE,
	`created_by` VARCHAR(42),
	PRIMARY KEY (`id`)
);
CREATE TABLE `user` (
        `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
	`description` LONG VARCHAR,
	`income` FLOAT,
	`created_on` DATE,
	PRIMARY KEY (`id`)
);
CREATE TABLE `tag` (
        `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
	`priority` INT,
	`second_priority` FLOAT,
	PRIMARY KEY (`id`)
);
ALTER TABLE `article` ADD COLUMN category_id INT UNSIGNED NOT NULL;
ALTER TABLE `tag` ADD COLUMN category_id INT UNSIGNED NOT NULL;
ALTER TABLE `user` ADD COLUMN article_id INT UNSIGNED NOT NULL;

INSERT INTO article (`id`,`url`,`price`,`published_on`,`category_id`) VALUES
	('1','u1','10','2014-04-14','1'),
	('2','u2','20','2014-04-14','1');
INSERT INTO category (`id`,`priority`,`created_by`) VALUES
	('1','1','c1'),
	('2','2','c2');
INSERT INTO user (`id`,`description`,`income`,`created_on`,`article_id`) VALUES
	('1','d1','100','2014-04-14','1'),
	('2','d2','200','2014-04-04','1');
INSERT INTO tag (`id`,`priority`,`second_priority`,`category_id`) VALUES
	('1','1','2','1'),
	('2','2','4','1');

SELECT DISTINCT article.category_id FROM article WHERE article.id =
(SELECT DISTINCT user.article_id FROM user WHERE user.id = 1);

CREATE TABLE Article_part1 (`id` INT UNSIGNED NOT NULL AUTO_INCREMENT, `published_on` DATE, PRIMARY KEY (`id`));
CREATE TABLE Article_part2 (`id` INT UNSIGNED NOT NULL AUTO_INCREMENT, `url` VARCHAR(42), `price` DECIMAL, `category_id` INT, PRIMARY KEY (`id`));
INSERT INTO Article_part1 (`published_on`) SELECT `published_on` FROM Article;
INSERT INTO Article_part2 (`url`, `price`, `category_id`) SELECT `url`, `price`, `category_id` FROM Article;

DROP TABLE Article;

SELECT DISTINCT tag.id FROM tag WHERE tag.category_id IN
(SELECT DISTINCT article_part2.category_id FROM article_part2, article_part1 WHERE
 article_part2.id = article_part1.id AND article_part1.id = 1);