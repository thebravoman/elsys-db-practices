CREATE DATABASE `llama9` DEFAULT CHARSET UTF8;
USE llama9;
CREATE TABLE `article` (
        `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
	`price` DECIMAL,
	`url` VARCHAR(42),
	`created_on` DATE,
	PRIMARY KEY (`id`)
);
CREATE TABLE `category` (
        `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
	`description` VARCHAR(42),
	`name` VARCHAR(42),
	PRIMARY KEY (`id`)
);
CREATE TABLE `user` (
        `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
	`age` INTEGER,
	`name` VARCHAR(42),
	`password` VARCHAR(42),
	PRIMARY KEY (`id`)
);
CREATE TABLE `tag` (
        `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
	`priority` INT,
	`name` VARCHAR(42),
	PRIMARY KEY (`id`)
);
CREATE TABLE `user_article` (
            `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
            `article_id` INT UNSIGNED NOT NULL,
            `user_id` INT UNSIGNED NOT NULL,
            PRIMARY KEY(`id`)
         );
ALTER TABLE `category` ADD COLUMN tag_id INT UNSIGNED NOT NULL;
ALTER TABLE `tag` ADD COLUMN article_id INT UNSIGNED NOT NULL;

INSERT INTO article (`id`,`price`,`url`,`created_on`) VALUES
	('1','10','u1','2014-04-04'),
	('2','20','u2','2014-04-04');
INSERT INTO category (`id`,`description`,`name`, `tag_id`) VALUES
	('1','d1','n1','1'),
	('2','d2','n2','1');
INSERT INTO user (`id`,`age`,`name`,`password`) VALUES
	('1','111','n1','p1'),
	('2','222','n2','p2');
INSERT INTO tag (`id`,`priority`,`name`, `article_id`) VALUES
	('1','1','t1','1'),
	('2','2','t2','1');
	
INSERT INTO `user_article` (`id`, `article_id`, `user_id`) VALUES
	('1', '1', '1'),
	('2', '1', '2');

SELECT tag.article_id FROM tag WHERE tag.id = 
(SELECT category.tag_id FROM category WHERE category.id = 1);


CREATE TABLE Tag_part1 (`id` INT UNSIGNED NOT NULL AUTO_INCREMENT, `name` VARCHAR(42), PRIMARY KEY (`id`));
CREATE TABLE Tag_part2 (`id` INT UNSIGNED NOT NULL AUTO_INCREMENT, `priority` INT, `article_id` INT, PRIMARY KEY (`id`));
INSERT INTO Tag_part1 (`name`) SELECT `name` FROM Tag;
INSERT INTO Tag_part2 (`priority`, `article_id`) SELECT `priority`, `article_id` FROM Tag;

DROP TABLE Tag;

SELECT user_article.user_id FROM user_article WHERE user_article.article_id =
(SELECT tag_part2.article_id FROM tag_part2 WHERE tag_part2.id = 1);