CREATE DATABASE `llama8` DEFAULT CHARSET UTF8;
USE llama8;
CREATE TABLE `article` (
        `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
	`published_on` DATE,
	`url` VARCHAR(42),
	`price` DECIMAL,
	PRIMARY KEY (`id`)
);
CREATE TABLE `category` (
        `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
	`created_by` VARCHAR(42),
	`description` VARCHAR(42),
	PRIMARY KEY (`id`)
);
CREATE TABLE `user` (
        `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
	`picture_url` VARCHAR(42),
	`name` VARCHAR(42),
	`description` LONG VARCHAR,
	PRIMARY KEY (`id`)
);
CREATE TABLE `tag` (
        `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
	`priority` INT,
	`name` VARCHAR(42),
	PRIMARY KEY (`id`)
);
ALTER TABLE `tag` ADD COLUMN article_id INT UNSIGNED NOT NULL;
CREATE TABLE `article_category` (
            `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
            `category_id` INT UNSIGNED NOT NULL,
            `article_id` INT UNSIGNED NOT NULL,
            PRIMARY KEY(`id`)
         );
CREATE TABLE `category_user` (
            `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
            `user_id` INT UNSIGNED NOT NULL,
            `category_id` INT UNSIGNED NOT NULL,
            PRIMARY KEY(`id`)
         );

INSERT INTO article (`id`,`published_on`,`url`,`price`) VALUES
	('1','2014-04-14','U1','1'),
	('2','2014-04-14','U2','2');
INSERT INTO category (`id`,`created_by`,`description`) VALUES
	('1','C1','D1'),
	('2','C2','D2');
INSERT INTO user (`id`,`picture_url`,`name`,`description`) VALUES
	('1','U1','U1','D1'),
	('2','U2','U2','D2');
INSERT INTO tag (`id`,`priority`,`name`, `article_id`) VALUES
	('1','1','T1', '1'),
	('2','2','T2', '1');
	
INSERT INTO `article_category` (`id`, `category_id`, `article_id`) VALUES
	('1', '1', '1'),
	('2', '1', '2');
INSERT INTO `category_user` (`id`, `user_id`, `category_id`) VALUES
	('1', '1', '1'),
	('2', '1', '2');

SELECT DISTINCT article_category.article_id FROM article_category WHERE article_category.category_id IN
(SELECT DISTINCT category_user.category_id FROM category_user, user WHERE user.id = 1 AND category_user.user_id = user.id);

CREATE TABLE Category_part1 (`id` INT UNSIGNED NOT NULL AUTO_INCREMENT, `description` VARCHAR(42), PRIMARY KEY (`id`));
CREATE TABLE Category_part2 (`id` INT UNSIGNED NOT NULL AUTO_INCREMENT, `created_by` VARCHAR(42), PRIMARY KEY (`id`));
INSERT INTO Category_part1 (`description`) SELECT `description` FROM Category;
INSERT INTO Category_part2 (`created_by`) SELECT `created_by` FROM Category;

DROP TABLE Category;

SELECT DISTINCT tag.id FROM tag WHERE tag.article_id IN
(SELECT DISTINCT article_category.article_id FROM article_category, category_part1
 WHERE article_category.category_id = category_part1.id AND category_part1.id = 1);