CREATE DATABASE `llama10` DEFAULT CHARSET UTF8;
USE llama10;
CREATE TABLE `article` (
        `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
	`url` VARCHAR(42),
	`created_on` DATE,
	`price` DECIMAL,
	PRIMARY KEY (`id`)
);
CREATE TABLE `category` (
        `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
	`created_by` VARCHAR(42),
	`description` VARCHAR(42),
	PRIMARY KEY (`id`)
);
CREATE TABLE `user` (
        `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
	`age` INTEGER,
	`name` VARCHAR(42),
	`created_on` DATE,
	PRIMARY KEY (`id`)
);
CREATE TABLE `tag` (
        `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
	`name` VARCHAR(42),
	`priority` INT,
	PRIMARY KEY (`id`)
);

ALTER TABLE `article` ADD COLUMN category_id INT UNSIGNED NOT NULL;
ALTER TABLE `tag` ADD COLUMN user_id INT UNSIGNED NOT NULL;
CREATE TABLE `category_tag` (
            `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
            `tag_id` INT UNSIGNED NOT NULL,
            `category_id` INT UNSIGNED NOT NULL,
            PRIMARY KEY(`id`)
         );
INSERT INTO article (`id`,`url`,`created_on`,`price`,`category_id`) VALUES
	('1','u1','2012-02-02','100','1'),
	('2','u2','2012-02-02','200','1');
INSERT INTO category (`id`,`created_by`,`description`) VALUES
	('1','c1','d1'),
	('2','c2','d2');
INSERT INTO user (`id`,`age`,`name`,`created_on`) VALUES
	('1','10','n1','2014-04-14'),
	('2','20','n2','2014-04-14');
INSERT INTO tag (`id`,`name`,`priority`,`user_id`) VALUES
	('1','n1','1','1'),
	('2','n2','2','1');
	
INSERT INTO `category_tag` (`id`, `tag_id`, `category_id`) VALUES
	('1', '1', '1'),
	('2', '1', '2');

SELECT category_tag.category_id FROM category_tag WHERE category_tag.tag_id IN
(SELECT DISTINCT tag.id FROM tag, user WHERE user.id = 1 AND user.id = tag.user_id);

CREATE TABLE Tag_part1 (`id` INT UNSIGNED NOT NULL AUTO_INCREMENT, `name` VARCHAR(42), PRIMARY KEY (`id`));
CREATE TABLE Tag_part2 (`id` INT UNSIGNED NOT NULL AUTO_INCREMENT, `priority` INT, `user_id` INT, PRIMARY KEY (`id`));
INSERT INTO Tag_part1 (`name`) SELECT `name` FROM Tag;
INSERT INTO Tag_part2 (`priority`, `user_id`) SELECT `priority`, `user_id` FROM Tag;

DROP TABLE Tag;

SELECT DISTINCT article.id FROM article WHERE article.category_id IN
(SELECT category_tag.category_id FROM category_tag, tag_part1 WHERE tag_part1.id = 1 AND category_tag.tag_id = tag_part1.id);