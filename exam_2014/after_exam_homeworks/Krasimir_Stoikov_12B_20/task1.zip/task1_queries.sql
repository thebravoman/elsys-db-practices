CREATE DATABASE `llama1` DEFAULT CHARSET UTF8;
USE llama1;
CREATE TABLE `article` (
        `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
	`url` VARCHAR(42),
	`created_on` DATE,
	`name` VARCHAR(42),
	PRIMARY KEY (`id`)
);
CREATE TABLE `category` (
        `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
	`description` VARCHAR(42),
	`created_by` VARCHAR(42),
	PRIMARY KEY (`id`)
);
CREATE TABLE `user` (
        `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
	`income` FLOAT,
	`created_on` DATE,
	`picture_url` VARCHAR(42),
	PRIMARY KEY (`id`)
);
CREATE TABLE `tag` (
        `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
	`priority` INT,
	`description` VARCHAR(42),
	PRIMARY KEY (`id`)
);

ALTER TABLE `article` ADD FOREIGN KEY (id) REFERENCES user(id);
ALTER TABLE `category` ADD FOREIGN KEY (id) REFERENCES tag(id);
ALTER TABLE `tag` ADD FOREIGN KEY (id) REFERENCES article(id);

INSERT INTO user (`id`,`income`,`created_on`,`picture_url`) VALUES
	('6','10.0','2013-03-13','nah'),
	('7','10.0','2013-03-13','nah');
INSERT INTO article (`id`,`url`,`created_on`,`name`) VALUES
	('6','llama','2013-03-13','llama'),
	('7','llama','2013-03-13','llama');
INSERT INTO tag (`id`,`priority`,`description`) VALUES
	('6','11','llama'),
	('7','22','llama');
INSERT INTO category (`id`,`description`,`created_by`) VALUES
	('6','llama','badllama'),
	('7','llama','badllama');

SELECT article.id FROM tag JOIN article JOIN category WHERE category.id = 6 AND category.id = tag.id AND tag.id = article.id;

CREATE TABLE Tag_part1 (`id` INT UNSIGNED NOT NULL AUTO_INCREMENT, `priority` INT, PRIMARY KEY (`id`));
CREATE TABLE Tag_part2 (`id` INT UNSIGNED NOT NULL AUTO_INCREMENT, `description` VARCHAR(42), PRIMARY KEY (`id`));
INSERT INTO Tag_part1 (`id`, `priority`) SELECT `id`, `priority` FROM Tag;
INSERT INTO Tag_part2 (`id`, `description`) SELECT `id`, `description` FROM Tag;

SET foreign_key_checks = 0;

DROP TABLE Tag;

SET foreign_key_checks = 1; 

SELECT user.id FROM user JOIN article JOIN tag_part1 WHERE tag_part1.id = 6 AND user.id = article.id AND tag_part1.id = article.id;