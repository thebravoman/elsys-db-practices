CREATE DATABASE `llama1` DEFAULT CHARSET UTF8;
USE llama1;
CREATE TABLE `article` (
        `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
	`url` VARCHAR(42),
	`created_on` DATE,
	`name` VARCHAR(42),
	PRIMARY KEY (`id`)
);
CREATE TABLE `category` (
        `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
	`description` VARCHAR(42),
	`created_by` VARCHAR(42),
	PRIMARY KEY (`id`)
);
CREATE TABLE `user` (
        `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
	`income` FLOAT,
	`created_on` DATE,
	`picture_url` VARCHAR(42),
	PRIMARY KEY (`id`)
);
CREATE TABLE `tag` (
        `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
	`priority` INT,
	`description` VARCHAR(42),
	PRIMARY KEY (`id`)
);

ALTER TABLE `article` ADD FOREIGN KEY (id) REFERENCES user(id);
ALTER TABLE `category` ADD FOREIGN KEY (id) REFERENCES tag(id);
ALTER TABLE `tag` ADD FOREIGN KEY (id) REFERENCES article(id);

INSERT INTO user (`id`,`income`,`created_on`,`picture_url`) VALUES
	('6','10.0','2013-03-13','nah'),
	('7','10.0','2013-03-13','nah');
INSERT INTO article (`id`,`url`,`created_on`,`name`) VALUES
	('6','llama','2013-03-13','llama'),
	('7','llama','2013-03-13','llama');
INSERT INTO tag (`id`,`priority`,`description`) VALUES
	('6','1','llama'),
	('7','2','llama');
INSERT INTO category (`id`,`description`,`created_by`) VALUES
	('6','llama','badllama'),
	('7','llama','badllama');

CREATE TABLE Tag_part1 (`id` INT UNSIGNED NOT NULL AUTO_INCREMENT, `priority` INT, PRIMARY KEY (`id`));
CREATE TABLE Tag_part2 (`id` INT UNSIGNED NOT NULL AUTO_INCREMENT, `description` VARCHAR(42), PRIMARY KEY (`id`));
INSERT INTO Tag_part1 (`priority`) SELECT `priority` FROM Tag;
INSERT INTO Tag_part2 (`description`) SELECT `description` FROM Tag;

SET foreign_key_checks = 0;

DROP TABLE Tag;

SET foreign_key_checks = 1; */