CREATE DATABASE `llama7` DEFAULT CHARSET UTF8;
USE llama7;
CREATE TABLE `article` (
        `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
	`price` DECIMAL,
	`name` VARCHAR(42),
	`content` LONG VARCHAR,
	PRIMARY KEY (`id`)
);
CREATE TABLE `category` (
        `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
	`description` VARCHAR(42),
	`date_created_on` DATE,
	PRIMARY KEY (`id`)
);
CREATE TABLE `user` (
        `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
	`picture_url` VARCHAR(42),
	`description` LONG VARCHAR,
	`name` VARCHAR(42),
	PRIMARY KEY (`id`)
);
CREATE TABLE `tag` (
        `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
	`priority` INT,
	`name` VARCHAR(42),
	PRIMARY KEY (`id`)
);
ALTER TABLE `article` ADD COLUMN user_id INT UNSIGNED NOT NULL;
ALTER TABLE `tag` ADD COLUMN user_id INT UNSIGNED NOT NULL;
ALTER TABLE `tag` ADD FOREIGN KEY (id) REFERENCES category(id);

INSERT INTO article (`id`,`price`,`name`,`content`,`user_id`) VALUES
	('1','1','a1','llama1','1'),
	('2','2','a2','llama2','1');
INSERT INTO category (`id`,`description`,`date_created_on`) VALUES
	('1','1d','2014-04-04'),
	('2','2d','2014-04-14');
INSERT INTO user (`id`,`picture_url`,`description`,`name`) VALUES
	('1','1u','1d','user1'),
	('2','2u','2d','user2');
INSERT INTO tag (`id`,`priority`,`name`,`user_id`) VALUES
	('1','1','tag1','1'),
	('2','2','tag2','1');

SELECT tag.user_id FROM tag WHERE tag.user_id = 
(SELECT article.user_id FROM article WHERE article.id = 1);

CREATE TABLE User_part1 (`id` INT UNSIGNED NOT NULL AUTO_INCREMENT, `name` VARCHAR(42), PRIMARY KEY (`id`));
CREATE TABLE User_part2 (`id` INT UNSIGNED NOT NULL AUTO_INCREMENT, `picture_url` VARCHAR(42), `description` LONG VARCHAR, PRIMARY KEY (`id`));
INSERT INTO User_part1 (`name`) SELECT `name` FROM User;
INSERT INTO User_part2 (`picture_url`, `description`) SELECT `picture_url`, `description` FROM User;

SET foreign_key_checks = 0;

DROP TABLE User;

SET foreign_key_checks = 1;

SELECT category.id FROM category, tag WHERE category.id = tag.id AND tag.id IN
(SELECT DISTINCT tag.id FROM tag, user_part1 WHERE tag.user_id = user_part1.id AND user_part1.id = 1);