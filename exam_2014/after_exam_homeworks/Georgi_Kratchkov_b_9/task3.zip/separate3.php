Separate Tag on two tables
Tag_part1 containing description
Tag_part2 containing all the other fields
As a result SQL queries+code in other programming language must be create

CREATE TABLE Tag(id int,name varchar(50), description varchar(50), category_id int, user_id int)

<?php
$table_name = "Tag";
$db = new mysqli("localhost", "root", "", "task3");

$db->query(sprintf("create table %s_part1(id int, description varchar(50))", $table_name));
$db->query(sprintf("create table %s_part2(id int, name varchar(50), category_id int, user_id int)", $table_name));

$result = $db->query("select * from " . $table_name);

while($row = $result->fetch_assoc()) {
	$db->query(sprintf("insert into %s_part1 values(%d, '%s')", $table_name, $row["id"], $row["description"]));
	$db->query(sprintf("insert into %s_part2 values(%d, '%s', %d, %d)", $table_name, $row["id"], $row["name"],$row["category_id"], $row["user_id"]));
}

$db->query("drop table " . $table_name);
$db->close();