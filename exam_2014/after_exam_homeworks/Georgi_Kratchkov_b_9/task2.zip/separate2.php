Separate Tag on two tables
Tag_part1 containing priority
Tag_part2 containing all the other fields
As a result SQL queries+code in other programming language must be create

CREATE TABLE Tag(id int,name varchar(50), priority int, category_id int)

<?php
$table_name = "Tag";
$db = new mysqli("localhost", "root", "", "task2");

$db->query(sprintf("create table %s_part1(id int,name varchar(50))", $table_name));
$db->query(sprintf("create table %s_part2(id int,age int,income float,article_id int, unique(article_id))", $table_name));

$result = $db->query("select * from " . $table_name);

while($row = $result->fetch_assoc()) {
	$db->query(sprintf("insert into %s_part1 values(%d, %d)", $table_name, $row["id"], $row["priority"]));
	$db->query(sprintf("insert into %s_part2 values(%d, '%s', %d)", $table_name, $row["id"], $row["name"],$row["category_id"]));
}

$db->query("drop table " . $table_name);
$db->close();