Separate Category on two tables
Category_part1 containing created_by
Category_part2 containing all the other fields
As a result SQL queries+code in other programming language must be create

CREATE TABLE Category(id int, created_by varchar(50), priority double, tag_id int, unique(tag_id))

<?php
$table_name = "Category";
$db = new mysqli("localhost", "root", "", "task10");

$db->query(sprintf("create table %s_part1(id int, created_by varchar(50))", $table_name));
$db->query(sprintf("create table %s_part2(id int, priority double, tag_id int, unique(tag_id))", $table_name));

$result = $db->query("select * from " . $table_name);

while($row = $result->fetch_assoc()) {
	$db->query(sprintf("insert into %s_part1 values(%d, '%s')", $table_name, $row["id"], $row["created_by"]));
	$db->query(sprintf("insert into %s_part2 values(%d, %d, %d)", $table_name, $row["id"], $row["priority"], $row["tag_id"]));
}

$db->query("drop table " . $table_name);
$db->close();