-- phpMyAdmin SQL Dump
-- version 4.1.6
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Apr 14, 2014 at 02:47 AM
-- Server version: 5.6.16
-- PHP Version: 5.5.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `task8`
--

-- --------------------------------------------------------

--
-- Table structure for table `article_part1`
--

CREATE TABLE IF NOT EXISTS `article_part1` (
  `id` int(11) DEFAULT NULL,
  `published_on` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `article_part1`
--

INSERT INTO `article_part1` (`id`, `published_on`) VALUES
(1, '2006-02-02'),
(2, '2004-02-02');

-- --------------------------------------------------------

--
-- Table structure for table `article_part2`
--

CREATE TABLE IF NOT EXISTS `article_part2` (
  `id` int(11) DEFAULT NULL,
  `price` float DEFAULT NULL,
  `url` varchar(50) DEFAULT NULL,
  `category_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `article_part2`
--

INSERT INTO `article_part2` (`id`, `price`, `url`, `category_id`) VALUES
(1, 100.2, 'url.com', 1),
(2, 10.2, 'url.com', 2);

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

CREATE TABLE IF NOT EXISTS `category` (
  `id` int(11) DEFAULT NULL,
  `date_created_on` date DEFAULT NULL,
  `name` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`id`, `date_created_on`, `name`) VALUES
(1, '2006-02-02', 'name'),
(2, '2006-02-04', 'name2');

-- --------------------------------------------------------

--
-- Table structure for table `tag`
--

CREATE TABLE IF NOT EXISTS `tag` (
  `id` int(11) DEFAULT NULL,
  `description` varchar(50) DEFAULT NULL,
  `name` varchar(50) DEFAULT NULL,
  `category_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tag`
--

INSERT INTO `tag` (`id`, `description`, `name`, `category_id`) VALUES
(1, 'description', 'name', 1),
(2, 'description2', 'name2', 2);

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE IF NOT EXISTS `user` (
  `id` int(11) DEFAULT NULL,
  `created_on` date DEFAULT NULL,
  `income` float DEFAULT NULL,
  `age` int(11) DEFAULT NULL,
  `article_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `created_on`, `income`, `age`, `article_id`) VALUES
(1, '2006-02-02', 10.1, 100, 1),
(2, '2006-02-03', 10.21, 10, 2);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
