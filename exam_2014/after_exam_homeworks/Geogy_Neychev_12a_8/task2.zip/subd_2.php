<html>
<title> zadacha 2 </title>

<body>

	Georgi Neychev - 12a

<?php
mysql_connect("localhost","root","");

//mysql_query("CREATE DATABASE subd_2") or die(mysql_error());

mysql_select_db("subd_2") or die(mysql_error());

// mysql_query("CREATE TABLE Article (
// 	 	  article_id INT AUTO_INCREMENT,
// 	 	  price VARCHAR(20), 
// 	 	  url VARCHAR(32),
// 	 	  content VARCHAR(32),
// 	 	  PRIMARY KEY(article_id))") Or die(mysql_error());

// mysql_query("CREATE TABLE Category (
// 	      cat_id INT AUTO_INCREMENT,
// 		  created_by VARCHAR(43),
// 		  description VARCHAR(34),
// 		  art_id INT,
// 		  PRIMARY KEY(cat_id))") Or die(mysql_error());
		  
// mysql_query("CREATE TABLE User (
// 		  user_id INT AUTO_INCREMENT,
// 		  income VARCHAR(43),
// 		  created_on DATE,
// 		  password VARCHAR(12),
// 	 	  PRIMARY KEY(user_id))") Or die(mysql_error());
		  
// mysql_query("CREATE TABLE Tag (
// 		  tag_id INT AUTO_INCREMENT, 
// 		  second_priority VARCHAR(31),
// 		  description VARCHAR(32),
// 		  PRIMARY KEY(tag_id))") Or die(mysql_error());
		  		  
// mysql_query("CREATE TABLE Tag_art (
// 		  tag_id INT, 
// 		  art_id INT 
// 		  )") Or die(mysql_error());

	// mysql_query("INSERT INTO Article( price, url, content) VALUES ('dfsdsd','dfsfds','ksjdakjdas')");
	// mysql_query("INSERT INTO Article( price, url, content) VALUES ('fsdsgsf','gsfgsf','jkfdkj')");	

	// mysql_query("INSERT INTO Category( created_by, description) VALUES ('dasdas','sport')");	
	// mysql_query("INSERT INTO Category( created_by, description) VALUES ('faaf','kdakjdk')");

	// mysql_query("INSERT INTO User( income, created_on, password) VALUES ('cddssdc','2013-03-12','googo')");	
	// mysql_query("INSERT INTO User( income, created_on, password) VALUES ('descassac','2013-03-12','kdajakjdk')");
	
	// mysql_query("INSERT INTO Tag( description, second_priority) VALUES ('aadafdadfd','dcdc')");
	// mysql_query("INSERT INTO Tag( description, second_priority) VALUES ('adsfdsffsd','dsdfds')");
	
	// mysql_query("INSERT INTO Tag_art( tag_id, art_id) VALUES (1,1)");
	// mysql_query("INSERT INTO Tag_art( tag_id, art_id) VALUES (1,2)");

backup_tables('localhost','root','subd_1','sub_exam2_1');

backup_tables('localhost','root','subd_1','sub_exam2_2');


function backup_tables($host,$user,$name,$place,$tables = '*')
{
	
	$link = mysql_connect($host,$user,"");
	mysql_select_db($name,$link);
	
	//get all of the tables
	if($tables == '*')
	{
		$tables = array();
		$result = mysql_query('SHOW TABLES');
		//var_dump($result);
		while($row = mysql_fetch_row($result))
		{
			$tables[] = $row[0];
		}
	}
	else
	{
		$tables = is_array($tables) ? $tables : explode(',',$tables);
	}
	
	//cycle through
	foreach($tables as $table)
	{
		$result = mysql_query('SELECT * FROM '.$table);
		$num_fields = mysql_num_fields($result);
		
		$return = 'DROP TABLE '.$table.';';
		$row2 = mysql_fetch_row(mysql_query('SHOW CREATE TABLE '.$table));
		$return = "\n\n".$row2[1].";\n\n";
		
	$handle = fopen($place.'.sql','a+');
	fwrite($handle,$return);

	}
	fwrite($handle,"***************************************************************");
	fclose($handle);
}


?>
</body>

</html>