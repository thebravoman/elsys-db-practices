-- ============================

-- This file was created using Derby's dblook utility.
-- Timestamp: 2014-04-04 10:39:47.986
-- Source database is: dbDaniela
-- Connection URL is: jdbc:derby:dbDaniela
-- appendLogs: false

-- ----------------------------------------------
-- DDL Statements for tables
-- ----------------------------------------------

CREATE TABLE "APP"."ARTICLE" ("ID" INTEGER NOT NULL GENERATED ALWAYS AS IDENTITY (START WITH 1, INCREMENT BY 1), "CREATED_BY" VARCHAR(150), "PRIORITY" DOUBLE);

CREATE TABLE "APP"."ARTICLE_TAG" ("ID" INTEGER NOT NULL GENERATED ALWAYS AS IDENTITY (START WITH 1, INCREMENT BY 1), "ARTICLE_ID" INTEGER, "TAG_ID" INTEGER);

CREATE TABLE "APP"."TAG" ("ID" INTEGER NOT NULL GENERATED ALWAYS AS IDENTITY (START WITH 1, INCREMENT BY 1), "NAME" VARCHAR(70), "SECOND_PRIORITY" DOUBLE);

CREATE TABLE "APP"."USERS" ("ID" INTEGER NOT NULL GENERATED ALWAYS AS IDENTITY (START WITH 1, INCREMENT BY 1), "NAME" VARCHAR(70), "PICTURE_URL" VARCHAR(150), "CREATED_ON" DATE, "TAG_ID" INTEGER);

CREATE TABLE "APP"."CATEGORY" ("ID" INTEGER NOT NULL GENERATED ALWAYS AS IDENTITY (START WITH 1, INCREMENT BY 1), "NAME" VARCHAR(70), "USER_ID" INTEGER);

INSERT INTO Users(name,picture_url,created_on,tag_id) VALUES ('User1','Url1','2014-10-10',1);
INSERT INTO Users(name,picture_url,created_on,tag_id) VALUES ('User2','Url2','2014-11-11',1);

INSERT INTO Tag (name,second_priority) VALUES ('Tag1',2);
INSERT INTO Tag (name,second_priority) VALUES ('Tag2',1);

INSERT INTO Article (created_by,priority) VALUES ('User1',2.20);
INSERT INTO Article (created_by,priority) VALUES ('User1',3.30);

INSERT INTO Category (name,user_id) VALUES ('Category1',1);
INSERT INTO Category (name,user_id) VALUES ('Category2',2);

INSERT INTO Article_Tag (article_id,tag_id) VALUES (1,1);
INSERT INTO Article_Tag (article_id,tag_id) VALUES (2,2);
