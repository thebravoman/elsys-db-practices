eparate Tag on two tables
Tag_part1 containing description
Tag_part2 containing all the other fields
create table Tag(id int, second_priority float, description varchar(30))


<?php
$table_name = "Tag";

$db = new mysqli("localhost", "root", "", "examantondedikov");

$db->query(sprintf("create table %s_part1(id int, description varchar(30))", $table_name));
$db->query(sprintf("create table %s_part2(id int, second_priority float)", $table_name));

$result = $db->query("select * from " . $table_name);

while($row = $result->fetch_assoc()) {
	$db->query(sprintf("insert into %s_part1 values(%d, '%s')", $table_name, $row["id"], $row["description"]));
	$db->query(sprintf("insert into %s_part2 values(%d, %f)", $table_name, $row["id"], $row["second_priority"] ));
}

$db->query("drop table " . $table_name);
$db->close();