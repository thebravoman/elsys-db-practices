CREATE DATABASE `exam` DEFAULT CHARSET UTF8;
USE exam;
CREATE TABLE `article` (
        id INT UNSIGNED NOT NULL AUTO_INCREMENT,
	name VARCHAR (48),
	PRIMARY KEY (id)
);
CREATE TABLE `category` (
        id INT UNSIGNED NOT NULL AUTO_INCREMENT,
	name VARCHAR (48),
	PRIMARY KEY (id)
);
CREATE TABLE `user` (
        id INT UNSIGNED NOT NULL AUTO_INCREMENT,
	picture_url STRING,
	PRIMARY KEY (id)
);
CREATE TABLE `tag` (
        id INT UNSIGNED NOT NULL AUTO_INCREMENT,
	second_priority FLOAT,
	PRIMARY KEY (id)
);
ALTER TABLE user ADD COLUMN article_id INT UNSIGNED NOT NULL;

ALTER TABLE user ADD COLUMN tag_id INT UNSIGNED NOT NULL;
ALTER TABLE tag ADD COLUMN category_id INT UNSIGNED NOT NULL;

INSERT INTO article (`id`,`name`) VALUES
	(1,'Neshto'),
	(2,'Neshto2');
INSERT INTO category (`id`,`name`) VALUES
	(1,'cat'),
	(2,'catg');
INSERT INTO user (`id`,`picture_url`) VALUES
	(1,'65156'),
	(2,'46553');
INSERT INTO tag (`id`,`second_priority`) VALUES
	(1,2),
	(2,2);

