<?php
$table_name = "category";
$db = new mysqli("localhost", "root", "", "subd");

$db->query(sprintf("create table %s_part1(id int, description varchar(200))", $table_name));
$db->query(sprintf("create table %s_part2(id int, created_by text)", $table_name));

$result = $db->query("select * from " . $table_name);

while($row = $result->fetch_assoc()) {
	$db->query(sprintf("insert into %s_part1 values(%d, '%s')", $table_name, $row["id"], $row["description"]));
	$db->query(sprintf("insert into %s_part2 values(%d, '%s')", $table_name, $row["id"], $row["created_by"]));
}

$db->query("drop table " . $table_name);
$db->close();
