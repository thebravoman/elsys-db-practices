<?php
/* xampp->phpmyadmin->libraries->config.default.php    $cfg['AllowUserDropDatabase'] = false; */

$database = 'subd2';

$flag = false;

$db = new mysqli("localhost", "root", "", "$database");
$counter = 0;

$handle = fopen("zadacha.txt", "r");
if ($handle) {
    while (($line = fgets($handle)) !== false) {
		$counter++;
		if ($db->query(sprintf($line))) {
			echo "$counter is okey<br/>";
			$flag = true;
		} else { 
			echo "There is an error on line number $counter<br/>";
			echo "$line<br/>";
			echo "Clearing the database !!!!<br/>";
			$db->query(sprintf('DROP DATABASE '. $database));
			$db->query(sprintf('CREATE DATABASE '. $database));
			$flag = false;
			break;
		}
		}
} else {
    echo "Error opening the file<br/>";
}
if($flag) {
	echo "Everything works fine !!!!<br/>";
}
$db->close();
