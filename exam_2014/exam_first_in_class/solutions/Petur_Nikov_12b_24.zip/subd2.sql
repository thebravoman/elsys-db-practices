-- phpMyAdmin SQL Dump
-- version 4.1.6
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time:  4 апр 2014 в 09:35
-- Версия на сървъра: 5.6.16
-- PHP Version: 5.5.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `subd2`
--

-- --------------------------------------------------------

--
-- Структура на таблица `Article`
--

CREATE TABLE IF NOT EXISTS `Article` (
  `id` int(11) DEFAULT NULL,
  `published_on` date DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL,
  `url` text
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Схема на данните от таблица `Article`
--

INSERT INTO `Article` (`id`, `published_on`, `name`, `url`) VALUES
(1, '2006-02-02', 'art1', 'arturl'),
(2, '2010-05-05', 'art2', 'arturl2');

-- --------------------------------------------------------

--
-- Структура на таблица `Article_Category`
--

CREATE TABLE IF NOT EXISTS `Article_Category` (
  `id_article` int(11) DEFAULT NULL,
  `id_category` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Схема на данните от таблица `Article_Category`
--

INSERT INTO `Article_Category` (`id_article`, `id_category`) VALUES
(1, 1),
(2, 2);

-- --------------------------------------------------------

--
-- Структура на таблица `Category`
--

CREATE TABLE IF NOT EXISTS `Category` (
  `id` int(11) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL,
  `created_by` text,
  `tag_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Схема на данните от таблица `Category`
--

INSERT INTO `Category` (`id`, `name`, `created_by`, `tag_id`) VALUES
(1, 'cat1', 'pesho', 1),
(2, 'cat2', 'gosho', 2);

-- --------------------------------------------------------

--
-- Структура на таблица `Tag`
--

CREATE TABLE IF NOT EXISTS `Tag` (
  `id` int(11) DEFAULT NULL,
  `name` varchar(30) DEFAULT NULL,
  `priority` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Схема на данните от таблица `Tag`
--

INSERT INTO `Tag` (`id`, `name`, `priority`) VALUES
(1, 'tag1', 1),
(2, 'tag2', 2);

-- --------------------------------------------------------

--
-- Структура на таблица `User`
--

CREATE TABLE IF NOT EXISTS `User` (
  `id` int(11) DEFAULT NULL,
  `age` int(11) DEFAULT NULL,
  `name` varchar(30) DEFAULT NULL,
  `created_on` date DEFAULT NULL,
  `article_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Схема на данните от таблица `User`
--

INSERT INTO `User` (`id`, `age`, `name`, `created_on`, `article_id`) VALUES
(1, 20, 'Pesho', '2002-02-02', 1),
(2, 22, 'Gosho', '2001-01-01', 2);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
