#!/usr/bin/env python

import MySQLdb
import sys

sys.dont_write_bytecode = True # don't cluster source folder
# create an export

# write your own migration
db = MySQLdb.connect(unix_socket='/home/ico/Programs/mysql/socket', user="root", passwd="mono", db="exam_database")
db.autocommit(False)
cur = db.cursor()

try:
    cur.execute("CREATE TABLE IF NOT EXISTS Tag_part1 (second_priority FLOAT(15, 5) NOT NULL);")
    cur.execute("INSERT INTO Tag_part1 SELECT Tag.second_priority FROM Tag;")
except MySQLdb.Error,e:
    db.rollback()
    print e
    cur.close()
    db.close()
    
try:
    cur.execute("CREATE TABLE IF NOT EXISTS Tag_part2 (name VARCHAR(30) NOT NULL, tag_id INT NOT NULL PRIMARY KEY UNIQUE, many_article_id INT NOT NULL);");
    cur.execute("INSERT INTO Tag_part2 SELECT Tag.name, Tag.tag_id, Tag.many_article_id FROM Tag;")
except MySQLdb.Error,e:
    db.rollback()
    print e
    cur.close()
    db.close()
db.commit()
db.close()
# done !
