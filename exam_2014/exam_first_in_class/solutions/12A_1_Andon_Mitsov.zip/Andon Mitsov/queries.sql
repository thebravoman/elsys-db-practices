select  User.name, Category.id from User,Category,Tag, Category_Tag where
 User.id = Tag.User_id and Category_Tag.Category_id = Category.id and Tag.id = Category_Tag.Tag_id;

 select distinct Article.name, Tag_part2.id from Article,Tag_part2 where Tag_part2.User_id = Article.User_id ;

