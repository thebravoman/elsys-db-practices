# Use like:
# ruby exam_helper.rb "Table1 c1:t1 c2:t2; Table2 c1:t1 c2:t2"

tables, connections = ARGV[0], ARGV[1]

File.open("./exam.sql", "w") do |file|
  tables.split(/;/).each do |table|
    table_name, *columns = table.split
    columns.map! { |c| c.gsub ":", " " }
    file.write "CREATE TABLE #{table_name} (#{columns.join ", "});\n"
  end

 # connections.split(/;/).each do |conn|
 #   table1, type, table2 = conn.split
 #   case type
 #   when "m-m":
 #     file.write "CREATE TABLE #{table1 + "_" + table2} (#{table1.downcase+"_id"} INT, #{table2.downcase+"_id"} INT);\n"
 #   when "1-1" 
 #   end
 # end
end
