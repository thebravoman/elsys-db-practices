CREATE DATABASE `exam` DEFAULT CHARSET UTF8;
USE exam;
CREATE TABLE `article` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `content` LONGTEXT,
  `price` DECIMAL,
  `created_on` DATE,
	PRIMARY KEY (`id`)
);
CREATE TABLE `category` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
	`date_created_on` DATE,
  `priority` DOUBLE,
	PRIMARY KEY (`id`)
);
CREATE TABLE `user` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
	`income` FLOAT,
  `password` VARCHAR(100),
  `picture_url` TEXT,
	PRIMARY KEY (`id`)
);
CREATE TABLE `tag` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
	`description` VARCHAR(100),
  `name` VARCHAR(100),
	PRIMARY KEY (`id`)
);
ALTER TABLE `article` ADD COLUMN user_id INT UNSIGNED NOT NULL;
ALTER TABLE `category` ADD COLUMN article_id INT UNSIGNED NOT NULL;

ALTER TABLE `tag` ADD FOREIGN KEY (id) REFERENCES category(id);
INSERT INTO article (`id`,`content`, `price`, `created_on`) VALUES
	(1,"llama", 1.1, "2013-10-1"),
	(2,"llama2", 1.2, "2013-10-2");
INSERT INTO category (`id`,`date_created_on`, `priority`) VALUES
	(1,"2013-10-1", 1),
	(2,"2013-10-2", 2);
INSERT INTO user (`id`,`income`, `password`, `picture_url`) VALUES
	(1, 100, "mypass", "httpurl"),
	(2, 100, "mypass2", "httpurl2");
INSERT INTO tag (`id`,`description`, `name`) VALUES
	(1, "descr","name1"),
	(2, "descr2","name2");

SELECT article.id FROM tag JOIN article JOIN category WHERE tag.id = 1 AND category.id = tag.id AND category.article_id = article.id;

CREATE TABLE Category_part1 (`id` INT UNSIGNED NOT NULL AUTO_INCREMENT, `priority` DOUBLE, PRIMARY KEY (`id`));
CREATE TABLE Category_part2 (`id` INT UNSIGNED NOT NULL AUTO_INCREMENT, `date_created_on` DATE, `article_id` INT UNSIGNED NOT NULL, PRIMARY KEY (`id`));
INSERT INTO Category_part1 (`priority`) SELECT priority FROM Category;
INSERT INTO Category_part2 (`priority`) SELECT date_created_on, article_id FROM Category;
DROP TABLE Category;
