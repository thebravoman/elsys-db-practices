CREATE DATABASE `dobromir_ivanov` DEFAULT CHARSET UTF8;
USE dobromir_ivanov;
CREATE TABLE `article` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `content` LONGTEXT,
  `price` FLOAT,
  `created_on` TIMESTAMP,
  PRIMARY KEY (`id`)
);
CREATE TABLE `category` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `priority` FLOAT,
  `name` VARCHAR(64),
  PRIMARY KEY (`id`)
);
CREATE TABLE `user` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `income` FLOAT,
  `password` VARCHAR(64),
  `created_on` TIMESTAMP,
  PRIMARY KEY (`id`)
);
CREATE TABLE `tag` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `second_priority` FLOAT,
  `description` VARCHAR(64),
  PRIMARY KEY (`id`)
);

ALTER TABLE `tag` ADD COLUMN article_id INT UNSIGNED NOT NULL;
ALTER TABLE `user` ADD FOREIGN KEY (id) REFERENCES category(id);
ALTER TABLE `tag` ADD FOREIGN KEY (id) REFERENCES user(id);

INSERT INTO article (`id`,`content`, `price`, `created_on`) VALUES
  ('1','sadfsadf', 1.64, CURRENT_TIMESTAMP()),
  ('2','sadfsdf', 1.45, CURRENT_TIMESTAMP());
INSERT INTO category (`id`,`priority`, `name`) VALUES
  ('1',1.64, 'asdfsdf'),
  ('2',1.55, 'asdgfsdfagfg');
INSERT INTO user (`id`,`income`, `password`, `created_on`) VALUES
  ('1', 1.55, 'sdfasdfg', CURRENT_TIMESTAMP()),
  ('2', 1.54, 'fdgfdg', CURRENT_TIMESTAMP());
INSERT INTO tag (`id`,`second_priority`, `description`, `article_id`) VALUES
  ('1', 1.54, 'asdfsadf', 1),
  ('2', 1.22, 'asfdsaf', 2);

select * from `user`.`id` join `tag`, `article` where `user`.`id` = `tag`.`id` and `tag`.`article_id` = `article`.`id` and `article`.`id` = 1;

CREATE TABLE `tag_part1` (
  `id` int(10) unsigned NOT NULL,
  `second_priority` float DEFAULT NULL,
  `article_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE `tag_part2` (
  `id` int(10) unsigned NOT NULL,
  `description` varchar(64) DEFAULT NULL,
  `article_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


select `second_priority`, `aricle_id` from `tag` into `tag_part1`;
select `description`, `aricle_id` from `tag` into `tag_part1`;

drop table `tag`;
