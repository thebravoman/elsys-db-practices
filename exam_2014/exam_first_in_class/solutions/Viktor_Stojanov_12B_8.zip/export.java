import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.ResultSetMetaData;

public class DbExport {

	private static String dbURL = "jdbc:derby:/home/student/jk-derby/bin/real";
	// jdbc Connection
	private static Connection conn = null;
	private static Statement stmt = null;
	private static BufferedWriter writer;

	public static void main(String[] args) throws IOException {
		createConnection();
		writer = new BufferedWriter(new FileWriter(
				"/home/student/Desktop/export2.csv"));
		// insertRestaurants(5, "LaVals", "Berkeley");
		selectNew("article");
		selectNew("category");
		selectNew("users");
		selectNew("tag");
		selectNew("CATEGORY_part1");
		selectNew("CATEGORY_part2");
		writer.close();
		// shutdown();
	}

	private static void createConnection() {
		try {
			Class.forName("org.apache.derby.jdbc.ClientDriver").newInstance();
			// Get a connection
			conn = DriverManager.getConnection(dbURL);
		} catch (Exception except) {
			except.printStackTrace();
		}
	}

	private static void selectNew(String tableName) throws IOException {
		try {
			stmt = conn.createStatement();
			ResultSet results = stmt.executeQuery("select * from " + tableName);
			ResultSetMetaData rsmd = results.getMetaData();
			int numberCols = rsmd.getColumnCount();
			writer.write("\n");
			writer.write(tableName);
			writer.write("\n");
			for (int i = 1; i <= numberCols; i++) {
				// print Column Names
				writer.write(rsmd.getColumnLabel(i) + "\t\t");
			}

			writer.write("\n-------------------------------------------------");

			while (results.next()) {
				int id = results.getInt(1);
				String first = results.getString(2);
				String second = results.getString(3);
				if (numberCols == 3) {
					writer.write("\n" + id + "\t\t" + first + "\t\t" + second);
				} else if(numberCols == 4){
					String last = results.getString(4);
					writer.write("\n" + id + "\t\t" + first + "\t\t" + second
							+ "\t\t" + last);
				} else if(numberCols == 5){
					String last = results.getString(4);
					String lastReal = results.getString(5);
					writer.write("\n" + id + "\t\t" + first + "\t\t" + second
							+ "\t\t" + last + "\t\t" + lastReal);
				}
			}
			results.close();
			stmt.close();
			System.out.println("Done");
		} catch (SQLException sqlExcept) {
			sqlExcept.printStackTrace();
		}
	}

	private static void shutdown() {
		try {
			if (stmt != null) {
				stmt.close();
			}
			if (conn != null) {
				DriverManager.getConnection(dbURL + ";shutdown=true");
				conn.close();
			}
		} catch (SQLException sqlExcept) {

		}

	}
}

