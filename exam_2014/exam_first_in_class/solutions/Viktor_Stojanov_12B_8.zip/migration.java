import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.ResultSetMetaData;
import java.util.Date;

import org.apache.derby.client.am.PreparedStatement;

public class Migration {

	private static String dbURL = "jdbc:derby:/home/student/jk-derby/bin/real";
	// jdbc Connection
	private static Connection conn = null;
	private static Statement stmt = null;

	public static void main(String[] args) throws SQLException {
		createConnection();
		// insertRestaurants(5, "LaVals", "Berkeley");
		selectNew("category");
		// shutdown();
	}

	private static void createConnection() {
		try {
			Class.forName("org.apache.derby.jdbc.ClientDriver").newInstance();
			// Get a connection
			conn = DriverManager.getConnection(dbURL);
		} catch (Exception except) {
			except.printStackTrace();
		}
	}

	private static void selectNew(String tableName) throws SQLException {

		stmt = conn.createStatement();
		//String createString1 = "CREATE TABLE CATEGORY_part1 (ID INT, PRIORITY INT, USER_ID INT, UNIQUE(USER_ID))";
		//String createString2 = "CREATE TABLE CATEGORY_part2 (CAT_ID INT, DATE_CREATED_ON DATE, USER_ID INT, UNIQUE(USER_ID))";
		//stmt.executeUpdate(createString1);
		//stmt.executeUpdate(createString2);
		ResultSet results = stmt.executeQuery("select * from " + tableName);
		ResultSetMetaData rsmd = results.getMetaData();
		int numberCols = rsmd.getColumnCount();
		int[] id = new int[5];
		Date[] date = new Date[5];
		int[] price = new int[5];
		int[] tagId = new int[5];
		int i = 0;
		while (results.next()) {
			id[i] = results.getInt(1);
			date[i] = results.getDate(2);
			price[i] = results.getInt(3);
			tagId[i] = results.getInt(4);
			i++;
		}
		for (int j = 0; j < i; j++) {
			stmt.execute("insert into CATEGORY_part2 values (" + id[j] + ",'"
					+ date[j] + "'," + tagId[j] + ")");
			stmt.execute("insert into CATEGORY_part1 values (" + id[j] + ","
					+ price[j] + "," + tagId[j] + ")");
		}
		results.close();
		stmt.close();
		System.out.println("Done");
	}

	private static void shutdown() {
		try {
			if (stmt != null) {
				stmt.close();
			}
			if (conn != null) {
				DriverManager.getConnection(dbURL + ";shutdown=true");
				conn.close();
			}
		} catch (SQLException sqlExcept) {

		}

	}
}
