package migrate.com;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.ResultSet;
import java.util.ArrayList;


public class Migrate {

	 public static void main(String args[]){
		String table = "tag";
		String new_table1 = "tag_part1";
		String new_table2 = "tag_part2";
		ArrayList<MigrateHelper> list = new ArrayList<MigrateHelper>();
		Statement stmt = null;
		ResultSet rs = null;
		Connection conn = null;
		 
		 try {
			    conn = DriverManager.getConnection("jdbc:mysql://localhost/exam?" + "user=root&password=");
			  
			} catch (SQLException ex) {
			    // handle any errors
			    System.out.println("SQLException: " + ex.getMessage());
			    System.out.println("SQLState: " + ex.getSQLState());
			    System.out.println("VendorError: " + ex.getErrorCode());
			}
		 
		 
		 try {
			 stmt = conn.createStatement();
		     rs = stmt.executeQuery("SELECT * FROM " + table);
		     while(rs.next()){
		     		String name = rs.getString(2);
					String price = rs.getString(3);
					int id = rs.getInt(1);
					list.add(new MigrateHelper(id,name,price));
		     }
		     stmt = conn.createStatement();
		     stmt.execute("CREATE TABLE " + new_table1  + " (id int,second_priority FLOAT) ");
		     stmt = conn.createStatement();
		     stmt.execute("CREATE TABLE "+ new_table2 + " (id int,description varchar(20))");
		     stmt = conn.createStatement();
		     stmt.execute("DROP TABLE " + table );	
		     
		     stmt = conn.createStatement();
				for(MigrateHelper mh:list){ 
					
						 stmt = conn.createStatement();
						stmt.execute("INSERT INTO " + new_table1 + " values(\""+ mh.getId() + "\",\""+ mh.getField_1() +  "\");" ); 
						 stmt = conn.createStatement();
						stmt.execute("INSERT INTO " + new_table2 + " values(\""+ mh.getId()  + "\",\""+ mh.getField_2() + "\");" );
						
						

					}

		 }
		 catch (SQLException ex){
		     // handle any errors
		     System.out.println("SQLException: " + ex.getMessage());
		     System.out.println("SQLState: " + ex.getSQLState());
		     System.out.println("VendorError: " + ex.getErrorCode());
		 }
		 
//		 try{
//			 stmt = conn.createStatement();
//		     rs = stmt.executeQuery("SELECT * FROM " + new_table1);
//		     while(rs.next()){
//		     		String name = rs.getString(2);
//					//String price = rs.getString(3);
//					int id = rs.getInt(1);
//					list.add(new MigrateHelper(id,name));
//		     }
//		  
//		     
//		     stmt = conn.createStatement();
//		     stmt.execute("ALTER TABLE " + new_table2 + " ADD name varchar(20)"); 
//		     
//		     for(int i = 1; i <= list.size(); i++){
//		    	 
//		    	 stmt = conn.createStatement();
//			     stmt.execute("UPDATE " + new_table2 + " SET name = '" +  list.get(i-1).getField_1() + "' WHERE "+ new_table2+".id" + " = " + i); 
//			     //stmt = conn.createStatement();
//			    // stmt.execute("ALTER TABLE " + new_table2 + " RENAME TO "+ table); 
//	     		stmt = conn.createStatement();
//	    		 stmt.execute("DROP TABLE " + new_table2); 
//		    	 
//		     }
//				
//		 }
//		 catch(SQLException ex){
//		     // handle any errors
//		     System.out.println("SQLException: " + ex.getMessage());
//		     System.out.println("SQLState: " + ex.getSQLState());
//		     System.out.println("VendorError: " + ex.getErrorCode());
//		 }
	
	
	 }
	
	
}
