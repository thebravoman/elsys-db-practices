CREATE DATABASE `exam` DEFAULT CHARSET UTF8;
USE exam;
CREATE TABLE `article` (
        `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
	`published_on` DATE,
	`name` VARCHAR(42),
	`price` DECIMAL,
	PRIMARY KEY (`id`)
);
CREATE TABLE `category` (
        `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
	`priority` DOUBLE,
	`description` VARCHAR(42),
	PRIMARY KEY (`id`)
);
CREATE TABLE `user` (
        `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
	`created_on` DATE,
	`password` varchar(42),
	`description` VARCHAR(42),
	PRIMARY KEY (`id`)
);
CREATE TABLE `tag` (
        `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
	`name` VARCHAR(42),
	`description` varchar(42),
	PRIMARY KEY (`id`)
);
ALTER TABLE `article` ADD FOREIGN KEY (id) REFERENCES category(id);
ALTER TABLE `category` ADD COLUMN user_id INT UNSIGNED NOT NULL;

ALTER TABLE `tag` ADD FOREIGN KEY (id) REFERENCES article(id);
INSERT INTO article (`id`,`published_on`, `name`, `price`) VALUES
	('0','moridin', `10.0`),
	('1','dafuq', `20.0`);
