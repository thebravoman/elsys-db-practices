 select * from category,tag,article_39
     where category.id = category.tag_id
	 and article.id = tag.article_39_id;