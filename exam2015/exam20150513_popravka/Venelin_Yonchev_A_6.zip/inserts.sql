INSERT INTO article_39 (`visible`, `url`, `price`) VALUES
        (true, 'text', '10.2'),
        (true, 'text', '10.2');
INSERT INTO category (`created_by`, `description`,`tag_id`) VALUES
        ('text', 'long text',1),
        ('text', 'long text',2);
INSERT INTO user (`description`, `name`, `age`,`category_id`) VALUES
        ('long text', 'varchar', '42',1),
        ('long text', 'varchar', '42',2);
INSERT INTO tag (`description`, `hash`,`article_39_id`) VALUES
        ('aaaa', 'asdf',1),
        ('bbbb', 'fdsa',2);
		

		