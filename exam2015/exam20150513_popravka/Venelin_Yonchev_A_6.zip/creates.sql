CREATE TABLE IF NOT EXISTS `article_39` (
        `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
        `visible` BOOLEAN,
        `url` TEXT,
        `price` DECIMAL(10,2),
        PRIMARY KEY (`id`)
);
CREATE TABLE IF NOT EXISTS `category` (
        `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
        `created_by` TEXT,
        `description` LONGTEXT,
        PRIMARY KEY (`id`)
);
CREATE TABLE IF NOT EXISTS `user` (
        `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
        `description` LONGTEXT,
        `name` VARCHAR(255),
        `age` INTEGER,
        PRIMARY KEY (`id`)
);
CREATE TABLE IF NOT EXISTS `tag` (
        `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
        `description` VARCHAR(255),
        `hash` VARCHAR(6),
        PRIMARY KEY (`id`)
);
ALTER TABLE `tag` ADD COLUMN article_39_id INT UNSIGNED NOT NULL;
ALTER TABLE `user` ADD COLUMN category_id INT UNSIGNED NOT NULL;

ALTER TABLE `category` ADD COLUMN tag_id INT UNSIGNED NOT NULL;