create table Tag_part1(id int unsigned primary key auto_increment, description VARCHAR(255));
create table Tag_part2(id int unsigned primary key auto_increment, hash VARCHAR(6));
insert into Tag_part1(id, description) select id, description from tag;
insert into Tag_part2(id, hash) select id, hash from tag;

drop table tag;