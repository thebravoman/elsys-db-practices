INSERT INTO Article_0 ( Article_0_ID, created_on, name, password) VALUES( null, "2012-09-11", 'John', 'YebfxhObljehMx');
INSERT INTO Article_0 ( Article_0_ID, created_on, name, password) VALUES( null, "2006-04-10", 'John', 'GvijuwRtgqyeDn');
INSERT INTO Article_0 ( Article_0_ID, created_on, name, password) VALUES( null, "2013-09-19", 'Manuel', 'ZofhirZtwvovGz');

INSERT INTO Category ( Category_ID, created_by, priority) VALUES( null, 'she', '683');
INSERT INTO Category ( Category_ID, created_by, priority) VALUES( null, 'me', '674');
INSERT INTO Category ( Category_ID, created_by, priority) VALUES( null, 'she', '521');

INSERT INTO User ( Category_ID, User_ID, created_on, description, picture_url) VALUES(2,  null, "2013-12-12", 'gladen sum', 'http:\\homepage.bg\a.gif');
INSERT INTO User ( Category_ID, User_ID, created_on, description, picture_url) VALUES(2,  null, "2002-03-02", 'az sum sashko', 'http:\\homepage.bg\a.gif');
INSERT INTO User ( Category_ID, User_ID, created_on, description, picture_url) VALUES(1,  null, "2002-09-28", 'gladen sum', 'http:\\mnogoqko.com\pic1222.jpg');

INSERT INTO Tag ( Article_0_ID, Tag_ID, User_ID, description, hash) VALUES(3,  null,1,  "dsfds", "fdgfd");
INSERT INTO Tag ( Article_0_ID, Tag_ID, User_ID, description, hash) VALUES(1,  null,3,  "vfxv", "dsfs");
INSERT INTO Tag ( Article_0_ID, Tag_ID, User_ID, description, hash) VALUES(1,  null,2,  "ffdsg" , "fdfsd");


