connect 'jdbc:derby:exam45';
select b.id from article_4_category a inner join user1 b on a.category_id = b.category_id where article_4_id = 5;

