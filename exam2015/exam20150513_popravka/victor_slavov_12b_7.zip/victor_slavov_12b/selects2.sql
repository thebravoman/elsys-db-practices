connect 'jdbc:derby:exam45';
select user1.tag_id from user1 where category_id = 4;

