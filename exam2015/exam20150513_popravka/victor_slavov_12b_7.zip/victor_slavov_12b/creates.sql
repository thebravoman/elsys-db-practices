connect 'jdbc:derby:exam45;create=true';
create table Article_4 (id int primary key, name varchar(15), password varchar(15), visible boolean);
create table Category (id int primary key, date_created_on date, priority float);
create table User1 (id int primary key, income float, gender varchar(6), created_on date);
create table Tag (id int primary key, priority int, hash varchar(16));
create table article_4_category (article_4_id int, category_id int, primary key (article_4_id, category_id));
alter table User1 add column category_id int;
alter table User1 add column tag_id int;

