connect 'jdbc:derby:exam45';
create table category_part1(id int primary key, date_created_on date);
insert into category_part1 select id, date_created_on from category;
create table category_part2(category_id int primary key, priority float);
insert into category_part2 select id, priority from category;
drop table category;

