insert into Article_6(article_id, published_on,content,visible,categ_id) values (1, '2014/10/10', 'asdf', true, 1),(2,'2014/10/10','asdf',true,2),(3,'2014/10/10','asdf',false,3);
insert into Category(categ_id,created_by,description) values (1,'asdf','asdf'),(2,'asdf','asdf'),(3,'asdf','asdf');
insert into User(user_id,description,income,name,p_id) values (1,'asdf',5.0,'asdf',1),(2,'asdf',6.0,'asdf',2),(3,'asdf',8.0,'asdf',3);
insert into Tag(tag_id, description, hash,p_id) values (1,'asdf','asdf',1),(2,'asdf','asdf',2),(3,'asdf','asdf',3);
insert into Category_User(categ_id,user_id) values (1,1),(2,2),(3,3);

