-- MySQL dump 10.13  Distrib 5.5.41, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: exam
-- ------------------------------------------------------
-- Server version	5.5.41-0ubuntu0.12.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `Article_6`
--

DROP TABLE IF EXISTS `Article_6`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Article_6` (
  `article_id` int(11) NOT NULL,
  `published_on` date DEFAULT NULL,
  `content` text,
  `visible` tinyint(1) DEFAULT NULL,
  `categ_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`article_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Article_6`
--

LOCK TABLES `Article_6` WRITE;
/*!40000 ALTER TABLE `Article_6` DISABLE KEYS */;
INSERT INTO `Article_6` VALUES (1,'2014-10-10','asdf',1,1),(2,'2014-10-10','asdf',1,2),(3,'2014-10-10','asdf',0,3);
/*!40000 ALTER TABLE `Article_6` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Category_User`
--

DROP TABLE IF EXISTS `Category_User`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Category_User` (
  `categ_id` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Category_User`
--

LOCK TABLES `Category_User` WRITE;
/*!40000 ALTER TABLE `Category_User` DISABLE KEYS */;
INSERT INTO `Category_User` VALUES (1,1),(2,2),(3,3);
/*!40000 ALTER TABLE `Category_User` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Category_part1`
--

DROP TABLE IF EXISTS `Category_part1`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Category_part1` (
  `categ_id` int(11) NOT NULL,
  `description` text,
  PRIMARY KEY (`categ_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Category_part1`
--

LOCK TABLES `Category_part1` WRITE;
/*!40000 ALTER TABLE `Category_part1` DISABLE KEYS */;
INSERT INTO `Category_part1` VALUES (1,'asdf'),(2,'asdf'),(3,'asdf');
/*!40000 ALTER TABLE `Category_part1` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Category_part2`
--

DROP TABLE IF EXISTS `Category_part2`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Category_part2` (
  `categ_id` int(11) NOT NULL,
  `created_by` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`categ_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Category_part2`
--

LOCK TABLES `Category_part2` WRITE;
/*!40000 ALTER TABLE `Category_part2` DISABLE KEYS */;
INSERT INTO `Category_part2` VALUES (1,'asdf'),(2,'asdf'),(3,'asdf');
/*!40000 ALTER TABLE `Category_part2` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Tag`
--

DROP TABLE IF EXISTS `Tag`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Tag` (
  `tag_id` int(11) NOT NULL,
  `description` varchar(30) DEFAULT NULL,
  `hash` varchar(16) DEFAULT NULL,
  `p_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`tag_id`),
  UNIQUE KEY `p_id` (`p_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Tag`
--

LOCK TABLES `Tag` WRITE;
/*!40000 ALTER TABLE `Tag` DISABLE KEYS */;
INSERT INTO `Tag` VALUES (1,'asdf','asdf',1),(2,'asdf','asdf',2),(3,'asdf','asdf',3);
/*!40000 ALTER TABLE `Tag` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `User`
--

DROP TABLE IF EXISTS `User`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `User` (
  `user_id` int(11) NOT NULL,
  `description` text,
  `income` float DEFAULT NULL,
  `name` varchar(30) DEFAULT NULL,
  `p_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`user_id`),
  UNIQUE KEY `p_id` (`p_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `User`
--

LOCK TABLES `User` WRITE;
/*!40000 ALTER TABLE `User` DISABLE KEYS */;
INSERT INTO `User` VALUES (1,'asdf',5,'asdf',1),(2,'asdf',6,'asdf',2),(3,'asdf',8,'asdf',3);
/*!40000 ALTER TABLE `User` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2015-05-13  8:29:30
