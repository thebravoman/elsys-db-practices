create table Category_part1(categ_id int primary key,description text);
insert into Category_part1(categ_id,description) select categ_id,description from Category;
create table Category_part2(categ_id int primary key,created_by varchar(30));
insert into Category_part2(categ_id,created_by) select categ_id,created_by from Category;
drop table Category;
