create table Article_19(
	url VARCHAR(25),
	created_on DATE,
	password VARCHAR(25)
);

create table Category(
	description LONGTEXT,
	priority DOUBLE
);

create table Tag(
	twitter VARCHAR(25),
	password VARCHAR(25)
	gender VARCHAR(6)
);

create table TagToUserCon(
	tagId INT,
	userId INT
);

create rable UserToCatCon(
	userId INT,
	catId INT
);
