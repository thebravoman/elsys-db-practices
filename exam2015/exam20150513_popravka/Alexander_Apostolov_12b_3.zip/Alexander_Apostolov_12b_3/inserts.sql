insert into article_1 (id, visible, created_on, password) 
values (1, 0, '2012/02/02', 'sdhasdh'), (2, 1, '2015/05/08', 'sdasdg');

insert into category (id, name, description, user_id) 
values (1, 'pesho', 'dasfasfasgas', 1), (2, 'ivcho', 'asdasgfasg', 2);

insert into user (id, description, picture_url, income, tag_id) 
values (1, 'dasfasfasgas', 'asdjashfjash', 1.1, 2), (2, 'asgasg', 'asdasgfasg', 22.55, 1);

insert into tag (id, priority, second_priority) 
values (1, 55, 12.5), (2, 412, 74.35);

insert into tag_to_category (id, tag_id, category_id) 
values (1, 2, 1), (2, 1, 2);


