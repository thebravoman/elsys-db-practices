select category.* from category
inner join tag_to_category on category.id = tag_to_category.category_id
inner join tag on tag_to_category.tag_id = tag.id
where tag.id = 1;

