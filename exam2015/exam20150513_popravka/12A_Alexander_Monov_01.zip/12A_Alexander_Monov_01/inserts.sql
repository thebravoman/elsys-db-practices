insert into Article_34 (url, published_on, created_on) values ("jwfij", CURRENT_DATE(), CURRENT_DATE()), ("jwfij", CURRENT_DATE(), CURRENT_DATE());
insert into Category (date_created_on, name) values (CURRENT_DATE(), "regeg"), (CURRENT_DATE(), "fdsfdsf");
insert into User (picture_url, description, password) values ("fwggg", "wefwwf", "dsfwf"), ("fwggg", "wefwwf", "dsfwf");
insert into Tag (hash, name) values ("4wfwfw", "ddow"), ("4wfwfw", "ddow");

