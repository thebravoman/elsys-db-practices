create database monov default charset utf8;
use monov;
create table Article_34 (id integer not null primary key auto_increment, url varchar(255), published_on date, created_on date);
create table Category (id integer not null primary key auto_increment,date_created_on date, name varchar(20));
create table User (id integer not null primary key auto_increment, picture_url varchar(255), description text, password varchar(20));
create table Tag (id integer not null primary key auto_increment, hash varchar(16), name varchar(20));

alter table Tag add column article_34_id integer;
alter table Tag add foreign key (article_34_id) references Article_34(id);

alter table Category add column article_34_id integer;
alter table Category add foreign key (article_34_id) references Article_34(id);

alter table Article_34 add column category_id integer;
alter table Article_34 add foreign key (category_id) references Category(id);

alter table Tag add column user_id integer;
alter table Tag add foreign key (user_id) references User(id);

alter table User add column tag_id integer;
alter table User add foreign key (tag_id) references Tag(id);


