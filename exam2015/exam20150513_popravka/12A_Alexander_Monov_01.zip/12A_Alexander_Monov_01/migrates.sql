create table Article_34_part1 (id integer not null primary key auto_increment,published_on date);
create table Article_34_part2 (id integer not null primary key auto_increment, url varchar(255), created_on date);
insert into Article_34_part1(published_on) select published_on from Article_34;

insert into Article_34_part2(url, created_on) select url, created_on from Article_34;

