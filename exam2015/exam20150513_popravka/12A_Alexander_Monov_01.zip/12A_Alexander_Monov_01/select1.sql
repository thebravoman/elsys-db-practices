select *
from Tag t
	inner join Article_34 a
	on a.tag_id = t.id
		inner join Category c
		on c.id = a.category_id

