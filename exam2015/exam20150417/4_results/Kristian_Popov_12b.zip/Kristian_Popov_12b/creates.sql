CREATE TABLE Article_22(Article_22_ID int primary key not null auto_increment, price decimal(10,2), visible int, published_on date);
CREATE TABLE Category(Category_ID int primary key not null auto_increment, priority double, name varchar(255));
CREATE TABLE User(User_ID int primary key not null auto_increment, picture_url varchar(255), twitter varchar(255), income float);
CREATE TABLE Tag(Tag_ID int primary key not null auto_increment, name varchar(255), description varchar(255));

ALTER TABLE Category ADD Article_22_ID INT;
ALTER TABLE Category ADD FOREIGN KEY(Article_22_ID) REFERENCES Article_22(Article_22_ID);
CREATE TABLE Category_Tag(Category_ID INT, FOREIGN KEY(Category_ID) REFERENCES Category(Category_ID), Tag_ID INT, FOREIGN KEY(Tag_ID) REFERENCES Tag(Tag_ID));
ALTER TABLE User ADD Tag_ID INT;
ALTER TABLE User ADD FOREIGN KEY(Tag_ID) REFERENCES Tag(Tag_ID);