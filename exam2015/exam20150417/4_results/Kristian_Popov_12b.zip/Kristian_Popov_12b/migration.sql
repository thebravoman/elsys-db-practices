CREATE TABLE Category_part1(name varchar(255));
CREATE TABLE Category_part2(priority double);

INSERT INTO Category_part1 SELECT name FROM Category;
INSERT INTO Category_part2 SELECT priority FROM Category;