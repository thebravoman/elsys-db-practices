create table tag_part1(
	id int,
	PRIMARY KEY (id),
	hash VARCHAR(16)
);


create table tag_part2(
	id int,
	PRIMARY KEY (id),
	description VARCHAR(45),
);

insert into tag_part1(id,hash) select idtag,hash from tag
insert into tag_part2(id,description) select idtag,description from tag