CREATE TABLE `pesho`.`article_3` (
  `idarticle_3` INT NOT NULL,
  `content` VARCHAR(45) NOT NULL,
  `created_on` DATE NOT NULL,
  `url` VARCHAR(45) NOT NULL,
  PRIMARY KEY (`idarticle_3`));
  
  CREATE TABLE `pesho`.`category` (
  `idcategory` INT NOT NULL,
  `created_by` VARCHAR(45) NOT NULL,
  `name` VARCHAR(45) NOT NULL,
  PRIMARY KEY (`idcategory`));

  
  CREATE TABLE `pesho`.`user` (
  `iduser` INT NOT NULL,
  `picture_url` VARCHAR(45) NOT NULL,
  `name` VARCHAR(45) NOT NULL,
  `twitter` VARCHAR(45) NOT NULL,
  PRIMARY KEY (`iduser`));

  
  CREATE TABLE `pesho`.`tag` (
  `idtag` INT NOT NULL,
  `description` VARCHAR(45) NOT NULL,
  `hash` VARCHAR(16) NOT NULL,
  PRIMARY KEY (`idtag`));

  
  CREATE TABLE IF NOT EXISTS `pesho`.`user` (
  `iduser` INT(11) NOT NULL,
  `picture_url` VARCHAR(45) NOT NULL,
  `name` VARCHAR(45) NOT NULL,
  `twitter` VARCHAR(45) NOT NULL,
  `tag_idtag` INT(11) NOT NULL,
  PRIMARY KEY (`iduser`),
  INDEX `fk_user_tag1_idx` (`tag_idtag` ASC),
  CONSTRAINT `fk_user_tag1`
    FOREIGN KEY (`tag_idtag`)
    REFERENCES `pesho`.`tag` (`idtag`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8