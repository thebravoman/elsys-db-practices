INSERT INTO `pesho`.`article_3` (`idarticle_3`, `content`, `created_on`, `url`) VALUES ('1', 'asdf', '2015-04-17', 'ww.com');
INSERT INTO `pesho`.`article_3` (`idarticle_3`, `content`, `created_on`, `url`) VALUES ('2', 'asd', '2015-04-17', 'www.net');

INSERT INTO `pesho`.`category` (`idcategory`, `created_by`, `name`) VALUES ('1', 'pesho', 'fiki');
INSERT INTO `pesho`.`category` (`idcategory`, `created_by`, `name`) VALUES ('2', 'niki', 'bobi');

INSERT INTO `pesho`.`tag` (`idtag`, `description`, `hash`) VALUES ('1', 'potatos', '8');
INSERT INTO `pesho`.`tag` (`idtag`, `description`, `hash`) VALUES ('2', 'tomatos', '4');

INSERT INTO `pesho`.`user` (`iduser`, `picture_url`, `name`, `twitter`) VALUES ('1', 'alabala.cm', 'ivan', 'pussyslayer69');
INSERT INTO `pesho`.`user` (`iduser`, `picture_url`, `name`, `twitter`) VALUES ('2', 'balaala.bob', 'dragan', 'cuntdestroyer99');
