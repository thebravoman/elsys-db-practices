create database nedelcho_delchev;
use nedelcho_delchev;

CREATE TABLE `nedelcho_delchev`.`article_26` (
  `article_id` INT NOT NULL AUTO_INCREMENT,
  `created_on` DATE NOT NULL,
  `published_on` DATE NOT NULL,
  `password` VARCHAR(45) NOT NULL,
  PRIMARY KEY (`article_id`));

  CREATE TABLE `nedelcho_delchev`.`category` (
  `category_id` INT NOT NULL AUTO_INCREMENT,
  `priority` DOUBLE NOT NULL,
  `created_by` VARCHAR(45) NOT NULL,
  `article_id` INT NOT NULL,
  PRIMARY KEY (`category_id`));

  CREATE TABLE `nedelcho_delchev`.`user` (
  `user_id` INT NOT NULL AUTO_INCREMENT,
  `income` FLOAT NOT NULL,
  `age` INT NOT NULL,
  `description` LONGTEXT NOT NULL,
  PRIMARY KEY (`user_id`));

  CREATE TABLE `nedelcho_delchev`.`tag` (
  `tag_id` INT NOT NULL AUTO_INCREMENT,
  `hash` VARCHAR(16) NOT NULL,
  `description` VARCHAR(45) NOT NULL,
  PRIMARY KEY (`tag_id`));

  CREATE TABLE `nedelcho_delchev`.`tag_article` (
  `tag_article_id` INT NOT NULL AUTO_INCREMENT,
  `tag_id` INT NOT NULL,
  `article_id` INT NOT NULL,
  PRIMARY KEY (`tag_article_id`));

  CREATE TABLE `nedelcho_delchev`.`category_user` (
  `category_user_id` INT NOT NULL AUTO_INCREMENT,
  `category_id` INT NOT NULL,
  `user_id` INT NOT NULL,
  PRIMARY KEY (`category_user_id`));
