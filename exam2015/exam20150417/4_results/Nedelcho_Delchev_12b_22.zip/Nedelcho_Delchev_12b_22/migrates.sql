CREATE TABLE `nedelcho_delchev`.`article_26_part1` (
  `article_26_part1_id` INT NOT NULL AUTO_INCREMENT,
  `created_on` DATE NOT NULL,
  PRIMARY KEY (`article_26_part1_id`));

CREATE TABLE `nedelcho_delchev`.`article_26_part2` (
  `article_26_part2_id` INT NOT NULL AUTO_INCREMENT,
  `published_on` DATE NOT NULL,
  `password` VARCHAR(45) NOT NULL,
  PRIMARY KEY (`article_26_part2_id`));

INSERT INTO `nedelcho_delchev`.`article_26_part1` (`created_on`) VALUES ('23.03.2015');
INSERT INTO `nedelcho_delchev`.`article_26_part1` (`created_on`) VALUES ('10.10.2010');

INSERT INTO `nedelcho_delchev`.`article_26_part2` (`published_on`, `password`) VALUES ('23.04.2010', 'haha');
INSERT INTO `nedelcho_delchev`.`article_26_part2` (`published_on`, `password`) VALUES ('10.12.2012', 'kot takoa');