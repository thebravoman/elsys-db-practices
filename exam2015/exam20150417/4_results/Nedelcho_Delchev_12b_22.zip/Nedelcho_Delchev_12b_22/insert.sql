INSERT INTO `nedelcho_delchev`.`article_26` (`created_on`, `published_on`, `password`) VALUES ('12.12.2012', '13.12.2013', 'huehue');
INSERT INTO `nedelcho_delchev`.`article_26` (`created_on`, `published_on`, `password`) VALUES ('10.10.2010', '11.10.210', 'nimao');

INSERT INTO `nedelcho_delchev`.`category` (`priority`, `created_by`, `article_id`) VALUES ('5', 'Pesho', '1');
INSERT INTO `nedelcho_delchev`.`category` (`priority`, `created_by`, `article_id`) VALUES ('6', 'Strahil', '2');

INSERT INTO `nedelcho_delchev`.`tag` (`hash`, `description`) VALUES ('hahahuehuehue1234', 'mnogo qko brat');
INSERT INTO `nedelcho_delchev`.`tag` (`hash`, `description`) VALUES ('123456789abcdqwe', 'kot takoa');

INSERT INTO `nedelcho_delchev`.`category_user` (`category_id`, `user_id`) VALUES ('1', '2');
INSERT INTO `nedelcho_delchev`.`category_user` (`category_id`, `user_id`) VALUES ('2', '1');

INSERT INTO `nedelcho_delchev`.`user` (`income`, `age`, `description`) VALUES ('200,20', '30', 'mnogo qk pich');
INSERT INTO `nedelcho_delchev`.`user` (`income`, `age`, `description`) VALUES ('200,30', '43', 'nimoa prosto');

INSERT INTO `nedelcho_delchev`.`tag_article` (`tag_id`, `article_id`) VALUES ('1', '2');
INSERT INTO `nedelcho_delchev`.`tag_article` (`tag_id`, `article_id`) VALUES ('2', '1');
