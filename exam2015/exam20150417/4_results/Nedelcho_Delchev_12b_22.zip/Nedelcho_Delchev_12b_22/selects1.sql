select category.category_id from tag join tag_article on tag.tag_id = tag_article_id
join article_26 on tag_article.article_id = article_26.article_id
join category on category.category_id = article_26.article_id
where tag.description = "kot takoa";