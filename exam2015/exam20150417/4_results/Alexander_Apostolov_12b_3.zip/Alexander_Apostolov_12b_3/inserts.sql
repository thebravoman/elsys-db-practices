INSERT INTO `subd_exam2`.`article_1` (`id`, `password`, `visible`, `content`) VALUES ('1', 'pass1', 1, 'hahahhaha');
INSERT INTO `subd_exam2`.`article_1` (`id`, `password`, `visible`, `content`) VALUES ('2', 'passpasspa', 0, 'gsdgsdgsdg');

INSERT INTO `subd_exam2`.`category` (`priority`, `created_by`, `article_id`) VALUES ('243.5', 'pesho', '2');
INSERT INTO `subd_exam2`.`category` (`priority`, `created_by`, `article_id`) VALUES ('44.0', 'nasko', '1');

INSERT INTO `subd_exam2`.`tag` (`second_priority`, `name`) VALUES ('2.4', 'nasd');
INSERT INTO `subd_exam2`.`tag` (`second_priority`, `name`) VALUES ('22', 'koko');

INSERT INTO `subd_exam2`.`user` (`gender`, `picture_url`, `description`, `category_id`) VALUES ('male', '/home/ne_mi_puka', 'descript', '1');
INSERT INTO `subd_exam2`.`user` (`gender`, `picture_url`, `description`, `category_id`) VALUES ('female', '/usr/local/...', 'daskdja', '2');

INSERT INTO `subd_exam2`.`user_tag_rel` (`user_id`, `tag_id`) VALUES ('1', '2');
INSERT INTO `subd_exam2`.`user_tag_rel` (`user_id`, `tag_id`) VALUES ('2', '2');
INSERT INTO `subd_exam2`.`user_tag_rel` (`user_id`, `tag_id`) VALUES ('2', '1');


