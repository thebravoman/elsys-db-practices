CREATE SCHEMA `subd_exam2` ;

CREATE TABLE `subd_exam2`.`article_1` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `password` VARCHAR(45) NULL,
  `visible` BIT(2) NULL,
  `content` TEXT NULL,
  PRIMARY KEY (`id`));


CREATE TABLE `subd_exam2`.`category` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `priority` DOUBLE NULL,
  `created_by` VARCHAR(45) NULL,
  PRIMARY KEY (`id`));


CREATE TABLE `subd_exam2`.`user` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `gender` VARCHAR(6) NULL,
  `picture_url` VARCHAR(45) NULL,
  `description` TEXT NULL,
  PRIMARY KEY (`id`));


CREATE TABLE `subd_exam2`.`tag` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `second_priority` FLOAT NULL,
  `name` VARCHAR(45) NULL,
  PRIMARY KEY (`id`));


ALTER TABLE `subd_exam2`.`category` 
ADD COLUMN `article_id` INT NULL AFTER `created_by`,
ADD INDEX `article_id_idx` (`article_id` ASC);
ALTER TABLE `subd_exam2`.`category` 
ADD CONSTRAINT `article_id`
  FOREIGN KEY (`article_id`)
  REFERENCES `subd_exam2`.`article_1` (`id`)
  ON DELETE NO ACTION
  ON UPDATE NO ACTION;


ALTER TABLE `subd_exam2`.`user` 
ADD COLUMN `category_id` INT NULL AFTER `description`,
ADD INDEX `category_id_idx` (`category_id` ASC);
ALTER TABLE `subd_exam2`.`user` 
ADD CONSTRAINT `category_id`
  FOREIGN KEY (`category_id`)
  REFERENCES `subd_exam2`.`category` (`id`)
  ON DELETE NO ACTION
  ON UPDATE NO ACTION;


CREATE TABLE `subd_exam2`.`user_tag_rel` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `user_id` INT NULL,
  `tag_id` INT NULL,
  PRIMARY KEY (`id`),
  INDEX `user_id_idx` (`tag_id` ASC),
  CONSTRAINT `user_id`
    FOREIGN KEY (`tag_id`)
    REFERENCES `subd_exam2`.`user` (`id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `tag_id`
    FOREIGN KEY (`tag_id`)
    REFERENCES `subd_exam2`.`tag` (`id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION);


