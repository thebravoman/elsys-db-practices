create table Tag_part1(
	id int primary key identity,
	hash varchar(16)
)

create table Tag_part2(
	id int primary key identity, 
	name varchar(150)
)

insert into Tag_part1(hash) (select hash from Tag)

insert into Tag_part2(name) (select name from Tag)

drop table Tag