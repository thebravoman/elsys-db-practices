insert into Article_2(password, published_on, name)
values 
	('password1', '2012-3-4', 'article1'),
	('password2', '2012-5-6', 'article2'),
	('password3', '2012-10-10', 'article3')

insert into Category(created_by, priority)
values 
	('sample_creator1', 10.3),
	('sample_creator2', 413.5),
	('sample_creator3', 141.3)

insert into [User](description, age, password, TagId, Article_2Id)
values
	('user1', 11, 'password1', 3, 1),
	('user2', 31, 'password2', 2, 2),
	('user3', 112, 'password3', 1, 3)

insert into Tag(name, hash)
values 
	('tag1', 'taghash1'),
	('tag2', 'taghash2'),
	('tag3', 'taghash3')

insert into Category_Tag(TagId, CategoryId)
values 
	(1, 2),
	(3, 1),
	(2, 3)