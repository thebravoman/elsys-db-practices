select a.name
from Article_2 a
	join [User] u on u.Article_2Id = a.id
	join Tag_part2 t2 on t2.id = u.TagId
where t2.name = 'tag1'