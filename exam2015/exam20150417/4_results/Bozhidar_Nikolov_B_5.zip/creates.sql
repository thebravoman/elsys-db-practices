create database SUBDExam
go

use SUBDExam
go

create table Article_2(
	id int primary key identity,
	password varchar(150),
	published_on date,
	name varchar(150)
)

create table Category(
	id int primary key identity,
	created_by varchar(150),
	priority decimal(10, 2)
)

create table [User](
	id int primary key identity,
	description varchar(max),
	age int,
	password varchar(150)
)

create table Tag(
	id int primary key identity,
	name varchar(150),
	hash varchar(16)
)

create table Category_Tag(
	CategoryId int,
	TagId int
)

alter table [User] add TagId int

alter table [User] add Article_2Id int