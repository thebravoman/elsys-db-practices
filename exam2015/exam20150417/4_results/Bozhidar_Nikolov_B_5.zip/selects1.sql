select u.description
from 
	[User] u 
	join Tag t on u.TagId = t.id
	join Category_Tag ct on ct.TagId = t.id
	join Category c on c.id = ct.CategoryId
where c.created_by = 'sample_creator1'
