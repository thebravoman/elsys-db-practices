INSERT INTO `subd`.`article_8` (`created_on`, `name`, `url`) VALUES ('21.12.2012', 'ivan', 'az.com');
INSERT INTO `subd`.`article_8` (`created_on`, `name`, `url`) VALUES ('19.02.2017', 'gosho', 'ti.com');

INSERT INTO `subd`.`category` (`description`, `priority`) VALUES ('good', '4');
INSERT INTO `subd`.`category` (`description`, `priority`) VALUES ('bad', '3');

INSERT INTO `subd`.`tag` (`second_priority`, `hash`) VALUES ('3', 'ok');
INSERT INTO `subd`.`tag` (`second_priority`, `hash`) VALUES ('34', 'alright');

INSERT INTO `subd`.`user` (`picture_url`, `gender`, `password`) VALUES ('snimka.com/df', 'male', '123ok');
INSERT INTO `subd`.`user` (`picture_url`, `gender`, `password`) VALUES ('snima.com/33', 'female', 'ok123');
