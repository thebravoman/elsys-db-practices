CREATE TABLE `subd`.`category_part1` (
  `id` INT NOT NULL,
  `description` VARCHAR(45) NULL,
  PRIMARY KEY (`id`));

CREATE TABLE `subd`.`category_part2` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `priority` DOUBLE NULL,
  PRIMARY KEY (`id`));

insert into category_part1(id, description) select id, description from category;

insert into category_part2(id, priority) select id, priority from category;