SELECT tag.*
FROM tag
LEFT JOIN Category ON Category.User_id = User.id
LEFT JOIN User ON User.Category_id = Category.id
WHERE User.id = 1;
