CREATE TABLE `subd`.`article_8` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `created_on` DATE NULL,
  `name` VARCHAR(45) NULL,
  `url` VARCHAR(45) NULL,
  PRIMARY KEY (`id`));

CREATE TABLE `subd`.`category` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `description` VARCHAR(45) NULL,
  `priority` DOUBLE NULL,
  PRIMARY KEY (`id`));

CREATE TABLE `subd`.`user` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `picture_url` VARCHAR(45) NULL,
  `gender` VARCHAR(6) NULL,
  `password` VARCHAR(45) NULL,
  PRIMARY KEY (`id`));

CREATE TABLE `subd`.`tag` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `second_priority` FLOAT NULL,
  `hash` VARCHAR(16) NULL,
  PRIMARY KEY (`id`));

ALTER TABLE `subd`.`user` 
ADD COLUMN `category_id` INT NULL AFTER `password`;

ALTER TABLE `subd`.`tag` 
ADD COLUMN `category_id` INT NULL AFTER `hash`;

ALTER TABLE `subd`.`article_8` 
ADD COLUMN `tag_id` INT NULL AFTER `url`;
