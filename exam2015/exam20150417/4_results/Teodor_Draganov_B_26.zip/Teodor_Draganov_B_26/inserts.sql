#inserts.sql
INSERT INTO `exam`.`article_13` (`id`, `content`, `price`, `published_on`) VALUES ('1', 'rand', '10.20', '12.12.2012');
INSERT INTO `exam`.`article_13` (`id`, `content`, `price`, `published_on`) VALUES ('2', 'rndm', '20.10', '13.12.2013');

INSERT INTO `exam`.`category` (`id`, `created_by`, `created_on`) VALUES ('1', 'Tosho', '1.1.2010');
INSERT INTO `exam`.`category` (`id`, `created_by`, `created_on`) VALUES ('2', 'Gosho', '2.2.2011');

INSERT INTO `exam`.`tag` (`id`, `description`, `priority`, `article_13_id`) VALUES ('1', 'Describe', '1', '1');
INSERT INTO `exam`.`tag` (`id`, `description`, `priority`, `article_13_id`) VALUES ('2', 'Descript', '2', '2');

INSERT INTO `exam`.`user` (`id`, `created_on`, `age`, `income`) VALUES ('1', '21.3.2008', '7', '50.50');
INSERT INTO `exam`.`user` (`id`, `created_on`, `age`, `income`) VALUES ('2', '24.6.2009', '5', '100.50');
