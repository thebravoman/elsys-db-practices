#selects1.sql
select Tag.*
from Tag
left join User on User.Category_id = Tag.id
left join Category on Category.User_id = User.id
where Category.id = 1;
