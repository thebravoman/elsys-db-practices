CREATE TABLE `exam`.`article_13` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `content` LONGTEXT NULL,
  `price` DECIMAL(10,2) NULL,
  `published_on` DATETIME NULL,
  PRIMARY KEY (`id`));

CREATE TABLE `exam`.`category` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `created_by` VARCHAR(45) NULL,
  `created_on` DATETIME NULL,
  PRIMARY KEY (`id`));

CREATE TABLE `exam`.`user` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `created_on` DATE NULL,
  `age` INT NULL,
  `income` FLOAT NULL,
  PRIMARY KEY (`id`));

CREATE TABLE `exam`.`tag` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `description` VARCHAR(45) NULL,
  `priority` INT NULL,
  PRIMARY KEY (`id`));

#creates.sql
ALTER TABLE `exam`.`tag` 
ADD COLUMN `article_13_id` INT NULL AFTER `priority`,
ADD INDEX `article_13_id_idx` (`article_13_id` ASC);
ALTER TABLE `exam`.`tag` 
ADD CONSTRAINT `article_13_id`
  FOREIGN KEY (`article_13_id`)
  REFERENCES `exam`.`article_13` (`id`)
  ON DELETE NO ACTION
  ON UPDATE NO ACTION;

CREATE TABLE `exam`.`category_user_many2many` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `category_id` INT NULL,
  `user_id` INT NULL,
  PRIMARY KEY (`id`),
  INDEX `user_id_idx` (`category_id` ASC, `user_id` ASC),
  CONSTRAINT `category_id`
    FOREIGN KEY (`category_id` , `user_id`)
    REFERENCES `exam`.`category` (`id` , `id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `user_id`
    FOREIGN KEY (`category_id` , `user_id`)
    REFERENCES `exam`.`user` (`id` , `id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION);

CREATE TABLE `exam`.`user_tag_many2many` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `user_id` INT NULL,
  `tag_id` INT NULL,
  PRIMARY KEY (`id`),
  INDEX `tag_id_idx` (`user_id` ASC),
  INDEX `user_id_idx` (`user_id` ASC, `tag_id` ASC),
  CONSTRAINT `user_id`
    FOREIGN KEY (`user_id` , `tag_id`)
    REFERENCES `exam`.`user` (`id` , `id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `tag_id`
    FOREIGN KEY (`user_id`)
    REFERENCES `exam`.`tag` (`description`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION);

#migrations.sql
CREATE TABLE `exam`.`user_part1` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `age` INT NULL,
  PRIMARY KEY (`id`));

CREATE TABLE `exam`.`user_part2` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `created_on` DATE NULL,
  `income` FLOAT NULL,
  PRIMARY KEY (`id`));

DROP TABLE `exam`.`user`;

#inserts.sql
INSERT INTO `exam`.`article_13` (`id`, `content`, `price`, `published_on`) VALUES ('1', 'rand', '10.20', '12.12.2012');
INSERT INTO `exam`.`article_13` (`id`, `content`, `price`, `published_on`) VALUES ('2', 'rndm', '20.10', '13.12.2013');

INSERT INTO `exam`.`category` (`id`, `created_by`, `created_on`) VALUES ('1', 'Tosho', '1.1.2010');
INSERT INTO `exam`.`category` (`id`, `created_by`, `created_on`) VALUES ('2', 'Gosho', '2.2.2011');

INSERT INTO `exam`.`tag` (`id`, `description`, `priority`, `article_13_id`) VALUES ('1', 'Describe', '1', '1');
INSERT INTO `exam`.`tag` (`id`, `description`, `priority`, `article_13_id`) VALUES ('2', 'Descript', '2', '2');

INSERT INTO `exam`.`user` (`id`, `created_on`, `age`, `income`) VALUES ('1', '21.3.2008', '7', '50.50');
INSERT INTO `exam`.`user` (`id`, `created_on`, `age`, `income`) VALUES ('2', '24.6.2009', '5', '100.50');

#selects1.sql
select Tag.*
from Tag
left join User on User.Category_id = Tag.id
left join Category on Category.User_id = User.id
where Category.id = 1;

#selects2.sql
select Article_13.*
from Article_13
left join Tag on Tag.Article_13_id = Article_13.id
left join User on User.Tag_id = Tag.id
where User.id = 1;