#selects2.sql
select Article_13.*
from Article_13
left join Tag on Tag.Article_13_id = Article_13.id
left join User on User.Tag_id = Tag.id
where User.id = 1;