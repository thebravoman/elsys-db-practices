#migrations.sql
CREATE TABLE `exam`.`user_part1` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `age` INT NULL,
  PRIMARY KEY (`id`));

CREATE TABLE `exam`.`user_part2` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `created_on` DATE NULL,
  `income` FLOAT NULL,
  PRIMARY KEY (`id`));

DROP TABLE `exam`.`user`;