#creates.sql
ALTER TABLE `exam`.`tag` 
ADD COLUMN `article_13_id` INT NULL AFTER `priority`,
ADD INDEX `article_13_id_idx` (`article_13_id` ASC);
ALTER TABLE `exam`.`tag` 
ADD CONSTRAINT `article_13_id`
  FOREIGN KEY (`article_13_id`)
  REFERENCES `exam`.`article_13` (`id`)
  ON DELETE NO ACTION
  ON UPDATE NO ACTION;

CREATE TABLE `exam`.`category_user_many2many` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `category_id` INT NULL,
  `user_id` INT NULL,
  PRIMARY KEY (`id`),
  INDEX `user_id_idx` (`category_id` ASC, `user_id` ASC),
  CONSTRAINT `category_id`
    FOREIGN KEY (`category_id` , `user_id`)
    REFERENCES `exam`.`category` (`id` , `id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `user_id`
    FOREIGN KEY (`category_id` , `user_id`)
    REFERENCES `exam`.`user` (`id` , `id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION);

CREATE TABLE `exam`.`user_tag_many2many` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `user_id` INT NULL,
  `tag_id` INT NULL,
  PRIMARY KEY (`id`),
  INDEX `tag_id_idx` (`user_id` ASC),
  INDEX `user_id_idx` (`user_id` ASC, `tag_id` ASC),
  CONSTRAINT `user_id`
    FOREIGN KEY (`user_id` , `tag_id`)
    REFERENCES `exam`.`user` (`id` , `id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `tag_id`
    FOREIGN KEY (`user_id`)
    REFERENCES `exam`.`tag` (`description`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION);
