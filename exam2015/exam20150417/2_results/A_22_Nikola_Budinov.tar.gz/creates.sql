create table Article_32(
id INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
password varchar(256),
content varchar(256),
published_on DATE
);

create table Category(
id INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
name varchar(256),
priority DOUBLE(5,2)
);

create table User(
id INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
income FLOAT,
name varchar(256),
password varchar(256)
);

create table Tag(
id INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
second_priority FLOAT,
description varchar(256)
);

alter table Article_32 add user_id INT;

alter table User add category_id INT;

create table Category_Tag( 
id INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
category_id INT,
tag_id INT
);


