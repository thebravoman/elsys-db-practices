create table  User_part1 (
id INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
password varchar(256)
);


create table    User_part2 (
id INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
income FLOAT,
name varchar(256),
category_id INT
);

insert into User_part1(password)  select password  from   User ;


insert into User_part2(income, name, category_id) select income, name, category_id from User;  


