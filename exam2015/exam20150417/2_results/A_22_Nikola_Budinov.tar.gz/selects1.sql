 select * from Category JOIN User ON Category.id = User.category_id JOIN Article_32 ON User.id = Article_32.user_id;

