

INSERT INTO Article_32 (id, password, content, published_on, user_id)  VALUES
( 1 , "apss" , "asd", "dateae", 1 ),
( 2 ,  "apss" , "asd", "date2", 2   );

INSERT INTO Category (id, name, priority)  VALUES
( 1 , "name1" , 1.2 ),
( 2 , "name2" , 1.5 );

INSERT INTO User (id, income, name, password, category_id)  VALUES
( 1 , 5 , "heu", "pass", 1 ),
( 2 ,  5 , "hesau", "padsss", 2 );
INSERT INTO Tag (id, second_priority, description)  VALUES
( 1 , 1.2, "ASD" ),
( 2 , 1.2, "ASD"  );

insert into Category_Tag(id, category_id, tag_id) VALUES
(1, 1,1),
(2,2,2);

