
select * from Tag JOIN Category_Tag ON Tag.id = Category_Tag.tag_id left join Category ON Category.id = Category_Tag.category_id left join User_part2 ON User_part2.category_id = Category.id;


