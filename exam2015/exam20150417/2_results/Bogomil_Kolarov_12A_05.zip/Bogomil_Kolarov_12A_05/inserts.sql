INSERT INTO Article_38 (`content`, `url`, `password`, `Tag_id`, `User_id`) VALUES
	('long text', 'text', 'text', 1, 2),
	('long text', 'text', 'text', 2, 1);
INSERT INTO Category (`description`, `name`, `Tag_id`) VALUES
	('long text', 'varchar', 1),
	('long text', 'varchar', 2);
INSERT INTO User (`name`, `gender`, `password`, `Article_38_id`) VALUES
	('varchar', 'varchar', 'varchar', 1),
	('varchar', 'varchar', 'varchar', 2);
INSERT INTO Tag (`name`, `second_priority`) VALUES
	('varchar', 5.9),
	('varchar', 10.0);

