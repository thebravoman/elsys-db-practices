
create table Article_38_part1(
	id int(11) auto_increment primary key,
	`url` TEXT
);

insert into Article_38_part1(url) 
select url
from Article_38;

create table Article_38_part2(
	id int(11) auto_increment primary key,
	`content` LONGTEXT,
	`password` TEXT,
	Tag_id int(11),
	User_id int(11)
);

insert into Article_38_part2(id, content, password, Tag_id, User_id)
select id, content, password, Tag_id, User_id
from Article_38


