select * 
FROM Tag t
	inner join Article_38 a
	on a.Tag_id = t.id
		inner join User u
		on u.id = a.User_id

