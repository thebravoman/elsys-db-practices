select * 
FROM Category c
	inner join Tag t
	on c.Tag_id = t.id
		inner join Article_38_part2 a
		on a.Tag_id = t.id
