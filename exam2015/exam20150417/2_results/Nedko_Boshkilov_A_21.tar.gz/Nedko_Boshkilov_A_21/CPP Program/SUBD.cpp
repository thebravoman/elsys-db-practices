#include <iostream>
#include <fstream>

using namespace std;

int Menu()
{
	int a;
	cout << "1.Create\n" << "2.Insert\n" << "3.Export\n" << "4.Connect\n" << "5.Migrate\n" << "0.Exit\n";
	cin >> a;
	return a;
}

void Create()
{
	ofstream file;
	file.open("creates_part1.sql");

	file << "create database sandvich;\n";
	file << "use sandvich;\n";

	int tablecount;
	cout << "Number of Tables: ";
	cin >> tablecount;

	for (int i = 0; i < tablecount; i++)
	{
		string tablename;
		cout << "Table name: ";
		cin >> tablename;

		file << "create table " << tablename << "(id integer unsigned not null AUTO_INCREMENT, ";

		int fieldcount;
		cout << "Field Count: ";
		cin >> fieldcount;

		for (int j = 0; j < fieldcount; j++)
		{
			string name, type;
			cout << "Column Name: ";
			cin >> name;
			cout << "Column Type: ";
			cin >> type;

			file << name << " " << type << " not null, ";
		}

		file << "PRIMARY KEY(id));\n";
	}

	file.close();
}

void Insert()
{
	ofstream file;
	file.open("inserts.sql");

	int tablecount;
	cout << "Number of tables: ";
	cin >> tablecount;

	int inputcount;
	cout << "Number of inputs: ";
	cin >> inputcount;

	for (int j = 0; j < tablecount; j++)
	{
		string table;
		cout << "Table: ";
		cin >> table;

		for (int i = 1; i <= inputcount; i++)
		{
			string values;
			cout << "Values: ";
			cin >> values;

			file << "insert into " << table << " values(" << i <<"," << values << ");\n";
		}
	}
	
	file.close();
}

void Export()
{
	int count;
	cout << "Export number: ";
	cin >> count;

	cout << "mysqldump -u root -p --databases sandvich >export" << count << ".sql\n";
}

void Connect()
{
	ofstream file;
	file.open("creates_part2.sql");

	int connectioncount;
	cout << "Number of Connections: ";
	cin >> connectioncount;

	for (int i = 0; i < connectioncount; i++)
	{
		int type;
		cout << "1.One to One\n" << "2.One to Many\n" << "3.Many to Many\n";
		cin >> type;
		
		switch (type)
		{
		case 1:
		{
			string table1, table2;
			cout << "Tables: ";
			cin >> table1 >> table2;

			file << "alter table " << table1 << " add foreign key(id) references " << table2 << " (id);\n";
			break;
		}

		case 2:
		{
			string one, many;
			cout << "One: ";
			cin >> one;
			cout << "Many: ";
			cin >> many;

			file << "alter table " << many << " add column " << one << "_id int unsigned not null;\n";
			break;
		}

		case 3:
		{
			string table1, table2;
			cout << "Tables: ";
			cin >> table1 >> table2;

			file << "create table " << table1 << "_" << table2 << "(id integer unsigned not null AUTO_INCREMENT, " << table1 << "_id integer unsigned not null, " << table2 << "_id integer unsigned not null, PRIMARY KEY(id));\n";
			break;
		}
		}
	}

	file.close();
}

void Migrate()
{
	ofstream file;
	file.open("migrates.sql");

	string tablename;
	cout << "Table: ";
	cin >> tablename;

	int columns1, columns2;
	cout << "Column Count 1,2: ";
	cin >> columns1 >> columns2;

	string columnnames1, columnnames2;
	columnnames1 = "";
	columnnames2 = "";

	file << "create table " << tablename << "_part1(id integer unsigned not null AUTO_INCREMENT, ";

	for (int i = 0; i < columns1; i++)
	{
		string name, type;
		cout << "Column Name: ";
		cin >> name;
		cout << "Column Type: ";
		cin >> type;

		columnnames1 = columnnames1 + " " + name + ",";

		file << name << " " << type << " not null, ";
	}

	file << "PRIMARY KEY(id));\n";

	file << "create table " << tablename << "_part2(id integer unsigned not null AUTO_INCREMENT, ";

	for (int i = 0; i < columns2; i++)
	{
		string name, type;
		cout << "Column Name: ";
		cin >> name;
		cout << "Column Type: ";
		cin >> type;

		columnnames2 = columnnames2 + " " + name + ",";

		file << name << " " << type << " not null, ";
	}

	file << "PRIMARY KEY(id));\n";

	columnnames1.resize(columnnames1.size() - 1);
	columnnames2.resize(columnnames2.size() - 1);

	file << "insert into " << tablename << "_part1 values (id," << columnnames1 << ") select id," << columnnames1 << " from " << tablename << ";\n";
	file << "insert into " << tablename << "_part2 values (id," << columnnames2 << ") select id," << columnnames2 << " from " << tablename << ";\n";
	file << "drop table " << tablename << ";\n";

	file.close();
}

int main()
{
	int menu;
	while (1)
	{
		menu = Menu();
		switch (menu)
		{
		case 1: Create(); break;
		case 2: Insert(); break;
		case 3: Export(); break;
		case 4: Connect(); break;
		case 5: Migrate(); break;
		case 0: break; break;
		}
	}
	return 0;
}