select * from Tag, User, Article_31_User as x where x.User_id = User.id and Tag.id = User.id and Tag.id = 1;
