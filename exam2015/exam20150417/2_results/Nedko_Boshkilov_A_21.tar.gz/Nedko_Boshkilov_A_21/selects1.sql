select * from User,Category_Article_31 as x,Article_31_User as y where x.Article_31_id = y.Article_31_id and x.Category_id = 1;
