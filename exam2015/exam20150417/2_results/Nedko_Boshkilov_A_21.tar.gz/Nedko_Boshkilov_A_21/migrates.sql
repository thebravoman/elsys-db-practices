create table Article_31_part1(id integer unsigned not null AUTO_INCREMENT, visible bit(1) not null, PRIMARY KEY(id));
create table Article_31_part2(id integer unsigned not null AUTO_INCREMENT, created_on date not null, price decimal(10,2) not null, PRIMARY KEY(id));
insert into Article_31_part1 (id, visible) select id, visible from Article_31;
insert into Article_31_part2 (id, created_on, price) select id, created_on, price from Article_31;
drop table Article_31;
