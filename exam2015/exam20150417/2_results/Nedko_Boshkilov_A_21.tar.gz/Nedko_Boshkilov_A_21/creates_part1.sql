create database sandvich;
use sandvich;
create table Article_31(id integer unsigned not null AUTO_INCREMENT, visible bit(1) not null, created_on date not null, price decimal(10,2) not null, PRIMARY KEY(id));
create table Category(id integer unsigned not null AUTO_INCREMENT, description varchar(255) not null, created_by varchar(127) not null, PRIMARY KEY(id));
create table User(id integer unsigned not null AUTO_INCREMENT, gender varchar(6) not null, picture_url varchar(255) not null, age integer not null, PRIMARY KEY(id));
create table Tag(id integer unsigned not null AUTO_INCREMENT, second_priority float not null, name varchar(255) not null, PRIMARY KEY(id));
