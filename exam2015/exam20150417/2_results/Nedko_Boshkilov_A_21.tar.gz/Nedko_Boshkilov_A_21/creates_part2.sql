create table Category_Article_31(id integer unsigned not null AUTO_INCREMENT, Category_id integer unsigned not null, Article_31_id integer unsigned not null, PRIMARY KEY(id));
create table Article_31_User(id integer unsigned not null AUTO_INCREMENT, Article_31_id integer unsigned not null, User_id integer unsigned not null, PRIMARY KEY(id));
alter table User add foreign key(id) references Tag (id);
