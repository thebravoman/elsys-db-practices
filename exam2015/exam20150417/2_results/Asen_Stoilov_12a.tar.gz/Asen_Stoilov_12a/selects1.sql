Use my_db;

select * from Category
join Tag_Category, Tag, Article_37
where Tag.id = Tag_Category.Tag_id and Category.id = Tag_Category.Category_id
and Article_37.Tag_id = Tag.id;
