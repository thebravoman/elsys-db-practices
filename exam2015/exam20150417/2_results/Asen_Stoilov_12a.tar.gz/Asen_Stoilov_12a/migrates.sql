Use my_db;

CREATE TABLE `Tag2`(
	`id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
	`second_priority` float,
	`Article_37_id` INT,
	PRIMARY KEY (`id`)
);

insert into Tag2(`second_priority`,`Article_37_id`) select second_priority,Article_37_id
from Tag;
CREATE TABLE `Tag1`(
	`id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
	`description` varchar(15),	
	PRIMARY KEY (`id`)
);

insert into Tag1(`description`) select description
from Tag;
