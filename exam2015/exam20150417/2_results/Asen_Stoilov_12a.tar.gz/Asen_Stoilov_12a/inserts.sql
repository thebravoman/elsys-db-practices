Use my_db;

INSERT INTO Article_37 (`content`, `price`, `name`, `Tag_id`) VALUES
 (22.2, 22.2, 22.2, 10),
 (22.2, 22.2, 22.2, 10);
INSERT INTO Category (`description`, `date_created_on`) VALUES
 (22.2, CURRENT_DATE()),
 (22.2, CURRENT_DATE());
INSERT INTO User (`name`, `income`, `created_on`) VALUES
 (22.2, 22.2, CURRENT_DATE()),
 (22.2, 22.2, CURRENT_DATE());
INSERT INTO Tag (`second_priority`, `description`, `Article_37_id`) VALUES
 (22.2, 22.2, 10),
 (22.2, 22.2, 10);
INSERT INTO Category_User (`User_id`, `Category_id`) VALUES
 (1, 2),
 (2, 1);
INSERT INTO Tag_Category (`Category_id`, `Tag_id`) VALUES
 (1, 2),
 (2, 1);

