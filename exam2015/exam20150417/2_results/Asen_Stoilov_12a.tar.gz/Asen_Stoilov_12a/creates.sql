CREATE DATABASE my_db;
Use my_db;
CREATE TABLE `Article_37`(
	`id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
	`content` longtext,
	`price` float,
	`name` varchar(15),
	PRIMARY KEY (`id`)
);
CREATE TABLE `Category`(
	`id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
	`description` longtext,
	`date_created_on` date,
	PRIMARY KEY (`id`)
);
CREATE TABLE `User`(
	`id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
	`name` varchar(15),
	`income` float,
	`created_on` date,
	PRIMARY KEY (`id`)
);
CREATE TABLE `Tag`(
	`id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
	`second_priority` float,
	`description` varchar(15),
	PRIMARY KEY (`id`)
);
alter table Article_37 add column Tag_id  int unsigned not null;
alter table Tag add column Article_37_id  int unsigned not null;
CREATE TABLE `Category_User`(
	`id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
	`User_id` INT,
	`Category_id` INT,
	PRIMARY KEY (`id`)
);
CREATE TABLE `Tag_Category`(
	`id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
	`Category_id` INT,
	`Tag_id` INT,
	PRIMARY KEY (`id`)
);
