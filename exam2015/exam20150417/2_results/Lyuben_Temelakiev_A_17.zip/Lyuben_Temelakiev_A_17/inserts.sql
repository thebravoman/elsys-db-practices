INSERT INTO article_49 (published_on,url,created_on) VALUES
  (current_date(),"asdasd",current_date()),
  (current_date(),"ddd",current_date());
  
INSERT INTO Category (description,priority) VALUES
  ("adsasd",1.11),
  ("adsasd",2.22);
  
INSERT INTO User (gender,age,description) VALUES
  ("adsasd",12,"asldj"),
    ("adsasd",15,"ddddd");


INSERT INTO tag (second_priority,priority) VALUES
  (12.3,1),
  (13.2,4);
  
insert into tag_user(tag_id,user_id) values
(1,2),
(3,4);
  