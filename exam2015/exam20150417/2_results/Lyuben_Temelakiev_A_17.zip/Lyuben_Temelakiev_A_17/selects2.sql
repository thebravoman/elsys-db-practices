select * from article_49
join user, category
where user.id = category.id
and category.id = article_49.id;