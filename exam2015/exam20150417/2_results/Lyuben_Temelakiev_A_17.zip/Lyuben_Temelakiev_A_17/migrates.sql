create table user_part1(id int(6) primary key auto_increment not null,
description longtext
);

create table user_part2(id int(6) primary key auto_increment not null,
gender varchar(6),
age int
);

insert into user_part1(description) select description from user;
insert into user_part2(gender,age) select gender,age from user;
