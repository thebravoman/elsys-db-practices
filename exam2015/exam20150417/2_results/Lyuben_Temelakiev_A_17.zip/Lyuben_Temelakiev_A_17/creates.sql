create table Article_49 (
id int(6) primary key auto_increment not null,
published_on date,
url varchar(12),
created_on date
);

create table Category(
id int(6) primary key auto_increment not null,
description longtext,
priority double
);

create table User(
id int(6) primary key auto_increment not null,
gender varchar(6),
age int,
description longtext
);

create table Tag(
id int(6) primary key auto_increment not null,
second_priority float,
priority int
);

create table tag_user(
id int(6) primary key auto_increment not null,
tag_id int,
user_id int
);



alter table user add foreign key user(id) references category(id);
alter table category add foreign key category(id) references article_49(id);


