select * from category
join tag, tag_user, user
where tag_user.user_id = user.id
and tag_user.tag_id = tag.id
and user.id = category.id;