create table Article_34(id int(6) primary key auto_increment not null,
 price double,
 published_on date,
 visible boolean);
 
create table Category(id int(6) primary key auto_increment not null,
date_created_on date,
created_by longtext);
 
create table User(id int(6) primary key auto_increment not null,
twitter varchar(30),	 
password varchar(30),
description longtext);
 
create table Tag(id int(6) primary key auto_increment not null,
name varchar(30),	 
priority int(10));

alter table Category add foreign key (user_id) references User(id);
 
 
Select * from Tag
join category, user
where category.user_id = user.id
and Tag.user_id = user.id;