Select * from Article_34
join Tag, user
where User.tag_id = tag.id
and Tag.user_id = Article_34.id;