CREATE DATABASE 'Monov' DEFAULT CHARSET UTF8;
USE Monov;

create table Article_34(id int(6) primary key auto_increment not null,
 price double,
 published_on date,
 visible boolean);
 
create table Category(id int(6) primary key auto_increment not null,
date_created_on date,
created_by longtext);
 
create table User(id int(6) primary key auto_increment not null,
twitter varchar(30),	 
password varchar(30),	 
description longtext);
 
create table Tag(id int(6) primary key auto_increment not null,
name varchar(30),	 
priority int(10));

alter table Category add foreign key (user_id) references User(id);
 
 
alter table User add column tag_id int;
alter table User add foreign key (tag_id) references Tag(id);
 
alter table Tag add column article_34_id int;
alter table Tag add foreign key (article_34_id) references Article_34(id);
