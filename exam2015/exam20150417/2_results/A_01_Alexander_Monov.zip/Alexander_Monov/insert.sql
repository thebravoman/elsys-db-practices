INSERT INTO article_34 (price, published_on, visible) VALUES
  (14.55,CURRENT_DATE(), true),
  (14.56,CURRENT_DATE(), false);
 
 
INSERT INTO Category (date_created_on, created_by, user_id) VALUES
  (CURRENT_DATE(), "laslals", 1),
  (CURRENT_DATE(), "laslals", 1);  
 
INSERT INTO User (twitter, password, description, tag_id) VALUES
  ("aaa", "aaa", "aaa", 1),
  ("aaa", "aaa", "aaa", 2);    
 
INSERT INTO Tag(name, priority, article_34_id) VALUES
  ("aaa", 4, 2),
  ("aaa", 5, 3);
