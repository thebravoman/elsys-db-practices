create table User_part1 (id int(6) primary key auto_increment not null,
twitter varchar(30));
 
create table User_part2(id int(6) primary key auto_increment not null,
password varchar(30),	 
description longtext);
 
insert into User_part1(twitter) select twitter from User;
 
insert into User_part2(password, description) select password, description from User;
