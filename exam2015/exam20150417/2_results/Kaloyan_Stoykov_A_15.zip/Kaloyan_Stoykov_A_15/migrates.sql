CREATE TABLE IF NOT EXISTS `article_47_part1` (
        `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
	`content` LONGTEXT,
	PRIMARY KEY (`id`)
);

CREATE TABLE IF NOT EXISTS `article_47_part2` (
        `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
	`url` TEXT,
	`price` DECIMAL(10,2),
	`user_id` INT UNSIGNED NOT NULL,
	PRIMARY KEY (`id`)
);

INSERT into article_47_part1(content) select content from article_47;
INSERT into article_47_part2(url,price,user_id) select url,price,user_id from article_47;

drop table article_47;