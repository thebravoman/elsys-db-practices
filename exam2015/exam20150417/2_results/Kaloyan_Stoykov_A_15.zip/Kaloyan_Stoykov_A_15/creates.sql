CREATE TABLE IF NOT EXISTS `article_47` (
        `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
	`url` TEXT,
	`price` DECIMAL(10,2),
	`content` LONGTEXT,
	PRIMARY KEY (`id`)
);
CREATE TABLE IF NOT EXISTS `category` (
        `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
	`date_created_on` DATE,
	`name` VARCHAR(255),
	PRIMARY KEY (`id`)
);
CREATE TABLE IF NOT EXISTS `user` (
        `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
	`age` INTEGER,
	`description` LONGTEXT,
	`picture_url` TEXT,
	PRIMARY KEY (`id`)
);
CREATE TABLE IF NOT EXISTS `tag` (
        `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
	`description` VARCHAR(255),
	`second_priority` FLOAT,
	PRIMARY KEY (`id`)
);
ALTER TABLE `article_47` ADD COLUMN user_id INT UNSIGNED NOT NULL;
ALTER TABLE `category` ADD COLUMN article_47_id INT UNSIGNED NOT NULL;
CREATE TABLE IF NOT EXISTS `user_tag` (
            `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
            `user_id` INT UNSIGNED NOT NULL,
            `tag_id` INT UNSIGNED NOT NULL,
            PRIMARY KEY(`id`)
);