INSERT INTO article_47 (`id`,`url`, `price`, `content`, `user_id`) VALUES
	(1,'text', '10.2', 'long text',1),
	(2,'text', '10.2', 'long text',2);
INSERT INTO category (`id`,`date_created_on`, `name`,`article_47_id`) VALUES
	(1,'2012.12.12', 'varchar',1),
	(2,'2012.12.12', 'varchar',2);
INSERT INTO user (`id`,`age`, `description`, `picture_url`) VALUES
	(1,'41', 'long text', 'text'),
	(2,'42', 'long text', 'text');
INSERT INTO tag (`id`,`description`, `second_priority`) VALUES
	(1,'varchar',''),
	(2,'varchar', '');
INSERT INTO user_tag (`id`,`user_id`, `tag_id`) VALUES
	(1,1, 1),
	(2,1, 2);