select user.id from user
left join article_47 on article_47.user_id = user.id
left join category on category.article_47_id = article_47.id
where article_47.id = 1;