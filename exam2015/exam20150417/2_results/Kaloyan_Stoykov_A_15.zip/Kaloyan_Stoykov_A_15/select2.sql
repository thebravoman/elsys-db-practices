select tag.id from tag
left join user_tag on user_tag.tag_id = tag.id
left join user on user_tag.user_id = user.id
left join article_47_part2 on article_47_part2.user_id = user.id
where article_47_part2.id = 1;