CREATE TABLE article_54(id int auto_increment primary key, content longtext, published_on date, password varchar(255));
CREATE TABLE category(id int auto_increment primary key, date_created_on date, name varchar(255));
CREATE TABLE user(id int auto_increment primary key, gender varchar(6), description longtext, twitter varchar(255));
CREATE TABLE tag(id int auto_increment primary key, description varchar(255), name varchar(255));
ALTER TABLE category ADD COLUMN tag_id INT;
CREATE TABLE article_54_user(id int auto_increment primary key, article_54_id int, user_id int);
