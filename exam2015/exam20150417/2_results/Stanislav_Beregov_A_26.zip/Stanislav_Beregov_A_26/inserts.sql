INSERT INTO article_54 (content, published_on, password) values ('content0', '2015-04-1', 'password2'), ('content3', '2015-04-4', 'password5');
INSERT INTO category (date_created_on, name, tag_id) values ('2015-04-6', 'name7', 8), ('2015-04-9', 'name0', 1);
INSERT INTO user (gender, description, twitter) values ('gender2', 'description3', 'twitter4'), ('gender5', 'description6', 'twitter7');
INSERT INTO tag (description, name) values ('description8', 'name9'), ('description0', 'name1');
INSERT INTO article_54_user (article_54_id, user_id) values (2, 3), (4, 5);
