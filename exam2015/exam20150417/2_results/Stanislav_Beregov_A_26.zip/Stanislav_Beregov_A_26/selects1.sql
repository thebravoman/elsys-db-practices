SELECT * FROM article_54 JOIN tag ON article_54.id = tag.id JOIN category ON tag.id = category.tag_id WHERE category.id = 1;
