CREATE TABLE tag_part1(id int auto_increment primary key, name varchar(255));
CREATE TABLE tag_part2(id int auto_increment primary key, description varchar(255));
