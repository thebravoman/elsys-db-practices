SELECT * FROM user JOIN article_54_user ON user.id = article_54_user.user_id JOIN article_54 ON article_54_user.article_54_id = article_54.id JOIN tag ON article_54.id = tag.id WHERE tag.id = 1;
