create table User_part1(id int unsigned primary key auto_increment, created_on date);
te table User_part2(id int unsigned primary key auto_increment, twitter varchar(255), password varchar(255), article_44_id int unsigned);
insert into User_part1(id, created_on) select id, created_on from user;
insert into User_part2(id, twitter, password, article_44_id) select id, twitter, password, article_44_id from user;
