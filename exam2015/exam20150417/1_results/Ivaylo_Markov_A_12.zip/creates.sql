
CREATE DATABASE IF NOT EXISTS`exam` DEFAULT CHARSET UTF8;
USE exam;
CREATE TABLE IF NOT EXISTS `article_44` (
        `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
	`url` TEXT,
	`name` VARCHAR(255),
	`visible` BOOLEAN,
	PRIMARY KEY (`id`)
);
CREATE TABLE IF NOT EXISTS `category` (
        `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
	`priority` DOUBLE,
	`created_by` TEXT,
	PRIMARY KEY (`id`)
);
CREATE TABLE IF NOT EXISTS `user` (
        `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
	`twitter` VARCHAR(255),
	`password` VARCHAR(255),
	`created_on` DATE,
	PRIMARY KEY (`id`)
);
CREATE TABLE IF NOT EXISTS `tag` (
        `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
	`name` VARCHAR(255),
	`priority` INT,
	PRIMARY KEY (`id`)
);
CREATE TABLE IF NOT EXISTS `category_article_44` (
            `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
            `article_44_id` INT UNSIGNED NOT NULL,
            `category_id` INT UNSIGNED NOT NULL,
            PRIMARY KEY(`id`)
         );

ALTER TABLE `user` ADD COLUMN article_44_id INT UNSIGNED NOT NULL;
ALTER TABLE `tag` ADD COLUMN user_id INT UNSIGNED NOT NULL;
