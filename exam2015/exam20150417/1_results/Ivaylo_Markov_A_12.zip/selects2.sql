select * from category
     LEFT JOIN category_article_44
     ON category_article_44.category_id = category.id
     LEFT JOIN user
     ON category_article_44.article_44_id = user.article_44_id;
