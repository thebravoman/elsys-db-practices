select * from tag
     LEFT JOIN user
     ON tag.user_id = user.id
     LEFT JOIN article_44
     ON user.article_44_id = article_44.id;
