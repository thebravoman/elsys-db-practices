
INSERT INTO article_44 (`url`, `name`, `visible`) VALUES
	('text', 'varchar', 'true'),
	('text', 'varchar', 'true');
INSERT INTO category (`priority`, `created_by`) VALUES
	('42.2', 'text'),
	('42.2', 'text');
INSERT INTO user (`twitter`, `password`, `created_on`) VALUES
	('varchar', 'varchar', '2012.12.12'),
	('varchar', 'varchar', '2012.12.12');
INSERT INTO tag (`name`, `priority`) VALUES
	('varchar', '42'),
	('varchar', '42');
