DROP DATABASE my_db;
CREATE DATABASE my_db;
Use my_db;
CREATE TABLE `Article_35`(
	`id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
	`created_on` datetime,
	`content` varchar(255),
	`name` varchar(255),
	PRIMARY KEY (`id`)
);
CREATE TABLE `Category`(
	`id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
	`priority` double(2,2),
	`name` varchar(255),
	PRIMARY KEY (`id`)
);
CREATE TABLE `User`(
	`id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
	`income` float(5.2),
	`created_on` datetime,
	`picture_url` varchar(255),
	PRIMARY KEY (`id`)
);
CREATE TABLE `Tag`(
	`id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
	`description` varchar(255),
	`name` varchar(255),
	PRIMARY KEY (`id`)
);
alter table Article_35 add column Tag_id  int unsigned not null;
alter table Article_35 add column Category_id  int unsigned not null;
alter table Category add column Article_35_id  int unsigned not null;
alter table User add column Category_id  int unsigned not null;