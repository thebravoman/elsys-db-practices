CREATE TABLE `Article_351`(
	`id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
	`created_on` datetime,
	`content` varchar(255),
	PRIMARY KEY (`id`)
);

insert into Article_351(`created_on`,`content`) select created_on,content
from Article_35;
CREATE TABLE `Article_352`(
	`id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
	`name` varchar(255),
	`Tag_id` INT,
	`Category_id` INT,
	PRIMARY KEY (`id`)
);

insert into Article_352(`name`,`Tag_id`,`Category_id`) select name,Tag_id,Category_id
from Article_35;