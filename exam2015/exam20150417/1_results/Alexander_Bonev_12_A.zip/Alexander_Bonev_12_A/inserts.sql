INSERT INTO Article_35 (`created_on`, `content`, `name`) VALUES
 ('9999-12-31 23:59:59', "sadsad", "pesho");

INSERT INTO Category (`priority`, `name`) VALUES
 (2.2, "saddsa"),
 (2.2, "saddsa");

INSERT INTO User (`income`, `created_on`, `picture_url`) VALUES
 (22.2, '9999-12-31 23:59:59',"sdsadsadsa"),
 (22.2, '9999-12-31 23:49:59',"sdsadsad22sa");

INSERT INTO Tag (`description`, `name`) VALUES
 ("sadsa", "saddsa"),
 ("saddsa", "saddsads");