CREATE DATABASE `milko2` DEFAULT CHARSET UTF8;
USE milko2;
CREATE TABLE `article_51` (
        `id` INT(10) UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
	`name` VARCHAR(255),
	`url` TEXT ,
	`published_on` DATE 
);
CREATE TABLE `category` (
        `id` INT(10) UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
	`name` VARCHAR(255),
	`priority` DOUBLE(5,2) 
);
CREATE TABLE `user` (
        `id` INT(10) UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
	`picture_url` TEXT,
	`twitter` VARCHAR(255), 
	`description` LONGTEXT
);
CREATE TABLE `tag` (
        `id` INT(10) UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
	`description` VARCHAR(255),
	`hash` VARCHAR(16)
);

CREATE TABLE `user_article_51` (
        `id` INT(10) UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
	`user_id` FLOAT,
	`article_51_id` INT(100)
);

CREATE TABLE `category_article_51` (
        `id` INT(10) UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
	`category_id` FLOAT,
	`article_51_id` INT(100)
);

CREATE TABLE `category_tag` (
        `id` INT(10) UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
	`category_id` FLOAT,
	`tag_id` INT(100)
);
