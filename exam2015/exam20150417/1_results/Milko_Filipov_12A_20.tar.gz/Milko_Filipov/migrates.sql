create table article_51_part1(id INT(10) UNSIGNED AUTO_INCREMENT PRIMARY KEY, published_on DATE);
insert into article_51_part1(published_on) select published_on from article_51;
create table article_51_part2(id INT(10) UNSIGNED AUTO_INCREMENT PRIMARY KEY, user VARCHAR(16),url  TEXT);
insert into article_51_part2(user,url) select user,url from article_51;
drop table article_51;
