INSERT INTO article_51 (`id`,`name`,`url`,`published_on`) VALUES
	('1','asd','asdas.com','2015-01-05'),
	('2','fasd','fasda.com','2015-01-06');
INSERT INTO category (`id`,`name`,`priority`) VALUES
	('1','asfasd','4.13'),
	('2','fasd','5.61');
INSERT INTO user (`id`,`picture_url`,`twitter`,`description`) VALUES
	('1','fasd','fasdas','fasd'),
	('2','safasds','asdasf','fasdas');
INSERT INTO tag (`id`,`description`,`hash`) VALUES
	('1','asfas','fasds'),
	('2','fasdas','fasd');
INSERT INTO category_article_51 (`id`,`category_id`,`article_51_id`) VALUES
	('1','1','2'),
	('2','2','1');
INSERT INTO user_article_51 (`id`,`user_id`,`article_51_id`) VALUES
	('1','1','2'),
	('2','2','1');
INSERT INTO category_tag (`id`,`category_id`,`tag_id`) VALUES
	('1','1','1'),
	('2','2','1');
