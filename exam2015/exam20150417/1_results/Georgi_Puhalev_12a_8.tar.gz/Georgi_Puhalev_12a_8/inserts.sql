INSERT INTO article_40 VALUES ('', 'akjosdhdu', '2015-05-03', 'adhuis', '1');
INSERT INTO article_40 VALUES ('', 'apodjoa', '2015-06-04', 'ajdo9hfd', '2');
INSERT INTO category VALUES	('', 'iuagdu', 'asdf', '1');
INSERT INTO category VALUES	('', 'pishfa0o', 'asdf2', '2');
INSERT INTO user VALUES	('', 'long text', 'varchar', 'varchar', '1');
INSERT INTO user VALUES	('', 'long text', 'varchar', 'varchar', '2');
INSERT INTO tag VALUES ('', '12.2', 'varchar');
INSERT INTO tag VALUES ('', '12.4', 'varchar');