create table user_part1(id INT(10) UNSIGNED AUTO_INCREMENT PRIMARY KEY, name VARCHAR(255));
insert into user_part1(name) select name from user;
create table user_part2(id INT(10) UNSIGNED AUTO_INCREMENT PRIMARY KEY, `description` LONGTEXT, name VARCHAR(255), password VARCHAR(255), tag_id INT UNSIGNED NOT NULL);
insert into user_part2(description, name, password, tag_id) select description, name, password, tag_id from user;
drop table user;