


insert into Category(description, name)
values ("hello world", "fafaegg");

insert into Category(description, name)
values ("hello world 123", "fadfgegg");


insert into Article_33(published_on, content, name)
values ("0-0-0", "abc", "ABC");

insert into Article_33(published_on, content, name)
values ("0-0-0", "dfgf", "AGF");

insert into Tag (prority, second_priority)
values (1, 2);

insert into Tag (prority, second_priority)
values (10, 22);

insert into User (picture_Url, income, password, category_id, tag_id)
values ("pic url", 245, "pass", 1, 2);

insert into User (picture_Url, income, password, category_id, tag_id)
values ("pic url2", 1245, "pass2", 2, 1);