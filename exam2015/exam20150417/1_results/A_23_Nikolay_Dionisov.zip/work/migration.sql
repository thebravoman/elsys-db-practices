

Create table Category_part1(
	id int not null primary key auto_increment,
	name varchar(255)
	);
Create table Category_part2(
	id int not null primary key auto_increment,
	description longtext
	);
insert into Category_part1(name) select name from Category;
insert into Category_part2(description) select description from Category;

drop table Category;