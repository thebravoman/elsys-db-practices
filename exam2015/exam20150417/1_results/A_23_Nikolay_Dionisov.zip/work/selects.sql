

select * from User, Article_33 where User.category_id = Article_33.id;