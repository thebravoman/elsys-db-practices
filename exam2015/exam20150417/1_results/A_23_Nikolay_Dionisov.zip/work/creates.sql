


Create table Category(
	id int not null primary key auto_increment,
	description longtext,
	name varchar(255)
	);
Create table Article_33(
	id int not null primary key auto_increment,
	published_on date,
	content longtext,
	name varchar(255),
	FOREIGN KEY(id) REFERENCES Category(id)
);

Create table Tag(
	id int not null primary key auto_increment,
	prority int,
	second_priority float
);

Create table User(
	id int not null primary key auto_increment,
	picture_url varchar(255),
	income float,
	password varchar(255),
	category_id int not null,
	tag_id int not null,
	FOREIGN KEY(category_id) REFERENCES Category(id),
	FOREIGN KEY(tag_id) REFERENCES Tag(id) 
);