create table category_part1(id int(6) primary key auto_increment not null,
date_created_on date
);
create table category_part2(id int(6) primary key auto_increment not null,
name varchar(100)
);

insert into category_part1(date_created_on) select date_created_on from category;
insert into category_part2(name) select name from category;
drop table category;