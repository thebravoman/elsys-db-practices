create table Article_50(
id int(6) primary key auto_increment not null,
visible boolean,
price double,
created_on date
);

create table Category(
id int(6) primary key auto_increment not null,
date_created_on date,
name varchar(100)
);

create table User(
id int(6) primary key auto_increment not null,
age int,
gender varchar(6),
price_url text
);

create table Tag(
id int(6) primary key auto_increment not null,
hash varchar(16),
second_priority float
);

alter table article_50 add column category_id int;

create table category_user (
id int(6) primary key auto_increment not null,
category_id int,
user_id int
);



