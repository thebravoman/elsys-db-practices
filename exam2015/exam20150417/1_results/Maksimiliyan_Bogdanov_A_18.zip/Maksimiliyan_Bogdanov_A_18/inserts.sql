
INSERT INTO Category (date_created_on,name) VALUES
  (current_date(),"aaa"),
  (current_date(),"bbb");
  
  
INSERT INTO article_50 (visible,price,created_on,category_id) VALUES
  (true,12,current_date(),1),
  (false,13.2,current_date(),2);
  
INSERT INTO tag (hash,second_priority) VALUES
  ("asddd",12),
  ("ddddd",15);  
  
INSERT INTO User (id,age,gender,price_url) VALUES
  (1,15,"male",15),
  (2,16,"female",11);
  
INSERT INTO category_user (category_id,user_id) VALUES
  (1,1),
  (2,2);