select * from tag,category_part2,user,category_user
where tag.id = user.id
and user.id = category_user.user_id
and category_user.category_id = category_part2.id;