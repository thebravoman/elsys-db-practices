SELECT User.id, User.gender, User.picture_url
FROM Tag
LEFT JOIN Category
INNER JOIN User
ON Category.user_id = User.id
ON Tag.category_id = Category.id
WHERE Tag.id = 1;