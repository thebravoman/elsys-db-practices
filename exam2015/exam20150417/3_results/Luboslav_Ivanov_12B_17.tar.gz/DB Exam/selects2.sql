Articles_23 for given Category


SELECT Article_23.url, Article_23.password, Article_23.published_on
FROM Article_23
LEFT JOIN User_Article_23
LEFT JOIN User
INNER JOIN Category
ON Category.user_id = User.id
ON User_Article_23.User_id = User.id
ON Article_23.id = User_Article_23.Article_23_id
WHERE Category.id = 1;