
INSERT INTO Article_23( published_on, url, password) 
values( "2015-5-4", "valueName2", "dsadadasd" ),
	  ( "2015-10-2", "valueName2", "ddsdsds" );

INSERT INTO User( picture_url, gender, description) 
values( "dsdsdsd", 124, "dsdsdsd" ),
	  ( "valueName1", 654, "valueName3" );

INSERT INTO Category( created_by, date_created_on, user_id) 
values( "dsdsdvalueName1", "2014-6-4", 1 ),
	  ( "dasdasdasdf", "2014-2-3", 2 );

INSERT INTO Tag( description, second_priority, category_id) 
values( "dddsdsdsd", 2.3, 1 ),
	  ( "valueName", 1.3, 2 );
