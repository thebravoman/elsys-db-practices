CREATE TABLE Article_23(
	id int primary key auto_increment,
	url varchar(255),
	published_on date,
	password varchar(255)
);

CREATE TABLE Category(
	id int primary key auto_increment,
	created_by varchar(255),
	date_created_on date
);

CREATE TABLE User(
	id int primary key auto_increment,
	picture_url varchar(255),
	description longtext,
	gender varchar(6)
);

CREATE TABLE Tag(
	id int primary key auto_increment,
	description varchar(255),
	second_priority float
);



ALTER TABLE Tag 
ADD COLUMN category_id INT NOT NULL UNIQUE, 
ADD FOREIGN KEY (category_id) 
REFERENCES Category(id);


ALTER TABLE Category 
ADD COLUMN user_id INT NOT NULL, 
ADD FOREIGN KEY (user_id) 
REFERENCES User(id);

CREATE TABLE User_Article_23(
	id int primary key auto_increment,
	User_id int NOT NULL,
	Article_23_id int NOT NULL,
	FOREIGN KEY (User_id) REFERENCES User(id),
	FOREIGN KEY (Article_23_id) REFERENCES Article_23(id)
);
