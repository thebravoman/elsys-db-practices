
CREATE TABLE Category_part1(
	id int primary key auto_increment,
	created_by varchar(255)
);

CREATE TABLE Category_part2(
	id int primary key auto_increment,
	date_created_on date,
	user_id int
);

INSERT INTO Category_part1(created_by)
SELECT created_by 
FROM Category;


INSERT INTO Category_part2(date_created_on, user_id)
SELECT date_created_on, user_id 
FROM Category;

