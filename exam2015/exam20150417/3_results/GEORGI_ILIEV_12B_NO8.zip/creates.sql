CREATE TABLE Article_17(
		id INT NOT NULL PRIMARY KEY AUTO_INCREMENT,
		name varchar(30),
		url text,
		content text
	);

CREATE TABLE Category(
		id INT NOT NULL PRIMARY KEY AUTO_INCREMENT,
		name varchar(30),
		date_created_on date
	);

CREATE TABLE User(
		id INT NOT NULL PRIMARY KEY AUTO_INCREMENT,
		name varchar(30),
		twitter varchar(100),
		gender varchar(6)
   	);

CREATE TABLE Tag(
		id INT NOT NULL PRIMARY KEY AUTO_INCREMENT,
		name varchar(30),
		description varchar(200)
   	);




ALTER TABLE User 
ADD COLUMN category_id INT NOT NULL , 
ADD CONSTRAINT fk_cat_user FOREIGN KEY (category_id) 
REFERENCES Category(id); 

ALTER TABLE Tag 
ADD COLUMN Article_id INT NOT NULL , 
ADD CONSTRAINT fk_tag_article FOREIGN KEY (Article_id) 
REFERENCES Article_17(id); 


ALTER TABLE Article_17 
ADD COLUMN user_id INT NOT NULL , 
ADD CONSTRAINT fk_article_user FOREIGN KEY (user_id) 
REFERENCES User(id); 