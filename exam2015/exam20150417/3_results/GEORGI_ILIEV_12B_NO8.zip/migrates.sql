create table User_part1 (
id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
gender varchar(6)
);

insert into User_part1 (id, gender) select id, gender from User;
alter table User rename User_part2;
alter table User_part2 drop column gender;