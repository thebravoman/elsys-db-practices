SELECT Article_17.* FROM Article_17
JOIN  User on article_17.user_id=user.id
join Category on Category.id=User.category_id
Where Category.id=1 ;