INSERT INTO `exam`.`user` (`id`, `name`, `twitter`, `gender`, `category_id`) VALUES ('1', 'name1', 'twitter1', 'male', '1');
INSERT INTO `exam`.`user` (`id`, `name`, `twitter`, `gender`, `category_id`) VALUES ('2', 'name2', 'twitter2', 'female', '2');
INSERT INTO `exam`.`user` (`id`, `name`, `twitter`, `gender`, `category_id`) VALUES ('3', 'name3', 'twitter3', 'male', '3');

INSERT INTO `exam`.`article_17` (`id`, `name`, `url`, `content`, `user_id`) VALUES ('1', 'name1', 'url1', 'content1', '1');
INSERT INTO `exam`.`article_17` (`id`, `name`, `url`, `content`, `user_id`) VALUES ('2', 'name2', 'url2', 'content2', '2');
INSERT INTO `exam`.`article_17` (`id`, `name`, `url`, `content`, `user_id`) VALUES ('3', 'name3', 'url3', 'content3', '3');


INSERT INTO `exam`.`tag` (`id`, `name`, `description`, `Article_id`) VALUES ('1', 'name2', 'desc1', '2');
INSERT INTO `exam`.`tag` (`id`, `name`, `description`, `Article_id`) VALUES ('2', 'name3', 'desc2', '1');
INSERT INTO `exam`.`tag` (`id`, `name`, `description`, `Article_id`) VALUES ('3', 'name1', 'desc3', '3');

INSERT INTO `exam`.`tag` (`id`, `name`, `description`, `Article_id`) VALUES ('1', 'name2', 'desc1', '1');
INSERT INTO `exam`.`tag` (`id`, `name`, `description`, `Article_id`) VALUES ('2', 'name3', 'desc2', '2');
INSERT INTO `exam`.`tag` (`id`, `name`, `description`, `Article_id`) VALUES ('3', 'name1', 'desc3', '1');