SELECT Tag.* FROM Tag
JOIN article_17 on tag.Article_id=Article_17.id
join User_part2 on User_part2.category_id=Article_17.user_id
Where User_part2.id=1 ;