CREATE TABLE Article_17(
		id INT NOT NULL PRIMARY KEY AUTO_INCREMENT,
		name varchar(30),
		url text,
		content text
	);

CREATE TABLE Category(
		id INT NOT NULL PRIMARY KEY AUTO_INCREMENT,
		name varchar(30),
		date_created_on date
	);

CREATE TABLE User(
		id INT NOT NULL PRIMARY KEY AUTO_INCREMENT,
		name varchar(30),
		twitter varchar(100),
		gender varchar(6)
   	);

CREATE TABLE Tag(
		id INT NOT NULL PRIMARY KEY AUTO_INCREMENT,
		name varchar(30),
		description varchar(200)
   	);



___

ALTER TABLE User 
ADD COLUMN category_id INT NOT NULL , 
ADD CONSTRAINT fk_cat_user FOREIGN KEY (category_id) 
REFERENCES Category(id); 

ALTER TABLE Tag 
ADD COLUMN Article_id INT NOT NULL , 
ADD CONSTRAINT fk_tag_article FOREIGN KEY (Article_id) 
REFERENCES Article_17(id); 


ALTER TABLE Article_17 
ADD COLUMN user_id INT NOT NULL , 
ADD CONSTRAINT fk_article_user FOREIGN KEY (user_id) 
REFERENCES User(id); 





_____

INSERT INTO `exam`.`user` (`id`, `name`, `twitter`, `gender`, `category_id`) VALUES ('1', 'name1', 'twitter1', 'male', '1');
INSERT INTO `exam`.`user` (`id`, `name`, `twitter`, `gender`, `category_id`) VALUES ('2', 'name2', 'twitter2', 'female', '2');
INSERT INTO `exam`.`user` (`id`, `name`, `twitter`, `gender`, `category_id`) VALUES ('3', 'name3', 'twitter3', 'male', '3');

INSERT INTO `exam`.`article_17` (`id`, `name`, `url`, `content`, `user_id`) VALUES ('1', 'name1', 'url1', 'content1', '1');
INSERT INTO `exam`.`article_17` (`id`, `name`, `url`, `content`, `user_id`) VALUES ('2', 'name2', 'url2', 'content2', '2');
INSERT INTO `exam`.`article_17` (`id`, `name`, `url`, `content`, `user_id`) VALUES ('3', 'name3', 'url3', 'content3', '3');


INSERT INTO `exam`.`tag` (`id`, `name`, `description`, `Article_id`) VALUES ('1', 'name2', 'desc1', '2');
INSERT INTO `exam`.`tag` (`id`, `name`, `description`, `Article_id`) VALUES ('2', 'name3', 'desc2', '1');
INSERT INTO `exam`.`tag` (`id`, `name`, `description`, `Article_id`) VALUES ('3', 'name1', 'desc3', '3');

INSERT INTO `exam`.`tag` (`id`, `name`, `description`, `Article_id`) VALUES ('1', 'name2', 'desc1', '1');
INSERT INTO `exam`.`tag` (`id`, `name`, `description`, `Article_id`) VALUES ('2', 'name3', 'desc2', '2');
INSERT INTO `exam`.`tag` (`id`, `name`, `description`, `Article_id`) VALUES ('3', 'name1', 'desc3', '1');


_____



SELECT Article_17.* FROM Article_17
JOIN  User on article_17.user_id=user.id
join Category on Category.id=User.category_id
Where Category.id=1 ;


_____


create table User_part1 (
id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
gender varchar(6)
);

insert into User_part1 (id, gender) select id, gender from User;
alter table User rename User_part2;
alter table User_part2 drop column gender;


_____


SELECT Tag.* FROM Tag
JOIN article_17 on tag.Article_id=Article_17.id
join User_part2 on User_part2.category_id=Article_17.user_id
Where User_part2.id=1 ;