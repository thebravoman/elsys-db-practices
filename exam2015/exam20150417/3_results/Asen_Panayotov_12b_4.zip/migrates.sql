
		create table User_part_1 (
	id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
	description text
	);

		create table User_part_2 (
	id INT NOT NULL AUTO_INCREMENT PRIMARY KEY ,
	picture_url text,
	income float
	);

		ALTER TABLE User_part_2
	ADD COLUMN user_id INT(20) NOT NULL , 
	ADD CONSTRAINT fk_user_part_1_user_part_2 FOREIGN KEY (user_id) 
	REFERENCES User(id); 

	insert into User_part_1(id,description) select id,description  from User;
	insert into User_part_2(id,picture_url,income) select id,picture_url,income  from User;