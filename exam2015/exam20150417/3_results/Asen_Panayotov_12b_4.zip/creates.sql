CREATE TABLE Article_16(
		id INT NOT NULL PRIMARY KEY AUTO_INCREMENT,
		price float,
		content text,
		visible boolean
   	);

CREATE TABLE Category(
		id INT NOT NULL PRIMARY KEY AUTO_INCREMENT,
		created_by text,
		date_created_on date
	);


CREATE TABLE User(
		id INT NOT NULL PRIMARY KEY AUTO_INCREMENT,
		pricture_url text,
		income float,
		description text
	);


CREATE TABLE Tag(
	id INT NOT NULL PRIMARY KEY AUTO_INCREMENT,
	hash varchar(100),
	priority int
	);


ALTER TABLE Category
	ADD COLUMN User_id INT(20) NOT NULL , 
	ADD CONSTRAINT fk_cat_user FOREIGN KEY (User_id) 
	REFERENCES User(id); 


CREATE TABLE IF NOT EXISTS `exam2`.`category_has_article_16` (
  `category_id` INT(11) NOT NULL,
  `article_16_id` INT(11) NOT NULL,
  PRIMARY KEY (`category_id`, `article_16_id`),
  INDEX `fk_category_has_article_16_article_161_idx` (`article_16_id` ASC),
  INDEX `fk_category_has_article_16_category1_idx` (`category_id` ASC),
  CONSTRAINT `fk_category_has_article_16_category1`
    FOREIGN KEY (`category_id`)
    REFERENCES `exam2`.`category` (`id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_category_has_article_16_article_161`
    FOREIGN KEY (`article_16_id`)
    REFERENCES `exam2`.`article_16` (`id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8;