
	INSERT INTO Article_16 (price,content,visible)
	VALUES (10.2,'alah',1),(4.2,'alah',2);

	INSERT INTO Category (created_by,date_created_on,User_id)
	VALUES ('mega qko','2013-03-03',3),('mega','2012-01-05',4);

	INSERT INTO User (pricture_url,income,description,Tag_id)
	VALUES ('mega qko',1,'shalqlal',1),('qkata rauta',2,'brymbrum',2);

	INSERT INTO Tag (hash,priority)
	VALUES ('Ivan',1),('Asen',2);