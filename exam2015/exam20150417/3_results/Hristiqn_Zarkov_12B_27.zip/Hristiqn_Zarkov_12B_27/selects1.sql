use test;
Select Tag.id From Tag 
Inner Join Category on Category.id = Tag.category_id 
Inner Join User On User.id = Category.user_id 
Where User.id=2