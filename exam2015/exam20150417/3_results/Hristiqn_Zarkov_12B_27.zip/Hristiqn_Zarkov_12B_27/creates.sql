use test;

Create Table User(
	id int not null primary key auto_increment,
    name varchar(50),
    gender varchar(6),
    twitter varchar(50)
);

Create Table Category(
	id int not null primary key auto_increment,
	priority int,
    description text,
    user_id int,
    Foreign Key (user_id) REFERENCES User(id)
);

Create Table Tag(
	id int not null primary key auto_increment,
    hash varchar(16),
    priority int,
    category_id int,
    Foreign Key (category_id)  REFERENCES Category(id)
);

create Table Article_27(
	id int not null primary key auto_increment,
	content text,
    published_on date,
    name varchar(50)
);

Create Table Article_27AndTags(
	Article_27_id int not null,
    tag_id int not null,
    Foreign Key (Article_27_id) references Article_27(id),
    Foreign Key (tag_id) references Tag(id)
);