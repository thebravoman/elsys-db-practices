use test;
Select Article_27.id From Article_27
Inner Join Article_27AndTags On Article_27AndTags.Article_27_id = Article_27.id 
Inner Join Tag ON Tag.id = Article_27AndTags.tag_id
Inner Join Category_part2 On Category_part2.id = Tag.category_id
Where Category_part2.id = 1