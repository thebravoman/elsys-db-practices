use test;

Create Table Category_part1(
	id int not null primary key auto_increment,
	priority int
);

Create Table Category_part2(
	id int not null primary key auto_increment,
    description text,
    user_id int,
    Foreign Key (user_id) REFERENCES User(id)
);

Insert Into Category_part1 Select id,priority From Category;
Insert Into Category_part2 Select id,description,user_id From Category