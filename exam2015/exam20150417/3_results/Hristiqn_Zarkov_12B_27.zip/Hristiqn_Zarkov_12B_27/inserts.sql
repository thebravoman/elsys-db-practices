use test;
INSERT INTO `test`.`Article_27` (`content`, `published_on`, `name`) VALUES ('grw', '2007-11-4', 'grgrwe');
INSERT INTO `test`.`Article_27` (`content`, `published_on`, `name`) VALUES ('reger', '2007-11-4', 'fgret');

INSERT INTO `test`.`User` (`name`, `gender`, `twitter`) VALUES ('htrhyr', 'wfewr', 'etrhjty');
INSERT INTO `test`.`User` (`name`, `gender`, `twitter`) VALUES ('tjykgj', 'rehgtr', 'qweghgf');

INSERT INTO `test`.`Category` (`priority`, `description`, `user_id`) VALUES ('2', 'getre', '2');
INSERT INTO `test`.`Category` (`priority`, `description`, `user_id`) VALUES ('1', 'erfgegr', '1');

INSERT INTO `test`.`Tag` (`hash`, `priority`, `category_id`) VALUES ('frew', '2', '2');
INSERT INTO `test`.`Tag` (`hash`, `priority`, `category_id`) VALUES ('grw', '3', '1');

INSERT INTO `test`.`Article_27AndTags` (`Article_27_id`, `tag_id`) VALUES ('1', '2');
INSERT INTO `test`.`Article_27AndTags` (`Article_27_id`, `tag_id`) VALUES ('2', '2');
INSERT INTO `test`.`Article_27AndTags` (`Article_27_id`, `tag_id`) VALUES ('2', '1');
INSERT INTO `test`.`Article_27AndTags` (`Article_27_id`, `tag_id`) VALUES ('1', '1');
