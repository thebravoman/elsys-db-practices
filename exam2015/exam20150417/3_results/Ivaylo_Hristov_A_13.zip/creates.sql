create table User (
	id integer not null primary key auto_increment,
	twitter varchar(255),
	description text,
	income float(10, 2)
);

create table Category (
	id integer not null primary key auto_increment,
	name varchar(255),
	priority double,
	user_id integer unique,
	foreign key (user_id) references User(id)
);

create table Tag (
	id integer not null primary key auto_increment,
	hash varchar(16),
	second_priority float
);

create table Article_45 (
	id integer not null primary key auto_increment,
	price decimal(10, 2),
	published_on date,
	content text,
	tag_id integer unique,
	foreign key (tag_id) references Tag(id),
	user_id integer,
	foreign key (user_id) references User(id)
);