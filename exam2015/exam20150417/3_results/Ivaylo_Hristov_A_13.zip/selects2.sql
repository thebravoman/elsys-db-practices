select *
from Article_45_part1 a1
	inner join on Article_45_part2 a2
	on a1.id = a2.id
		inner join User u
		on a2.user_id = u.id
			inner join Category c
			on c.user_id = u.id