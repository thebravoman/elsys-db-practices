create table Article_45_part1 (
	id integer not null primary key auto_increment,
	price decimal(10, 2)
);

create table Article_45_part2 (
	id integer not null primary key auto_increment,
	published_on date,
	content text,
	tag_id integer unique,
	foreign key (tag_id) references Tag(id),
	user_id integer,
	foreign key (user_id) references User(id)
);

insert into Article_45_part1(price)
select price from Article_45;

insert into Article_45_part2(published_on, content, tag_id, user_id)
select published_on, content, tag_id, user_id from Article_45;

drop table Article_45;