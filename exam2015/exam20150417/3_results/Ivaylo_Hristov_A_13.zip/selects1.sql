select *
from Tag t
	inner join Article_45 a
	on a.tag_id = t.id
		inner join User u
		on u.id = a.user_id