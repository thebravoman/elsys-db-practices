insert into User (twitter)
values ("coolstory");
insert into User (twitter)
values ("nice");

insert into Category (name, user_id)
values ("first", 1);
insert into Category (name, user_id)
values ("second", 2);

insert into Tag (hash)
values ("zzzz1");
insert into Tag (hash)
values ("yyyy1");

insert into Article_45 (price, tag_id, user_id)
values (10.22, 1, 1);
insert into Article_45 (price, tag_id, user_id)
values (1337.42, 2, 1);