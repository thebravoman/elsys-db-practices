create table Article_11 (
	id int, 
	created_on date,  
	price currency,
	content long string
);

create table Category(
	id int,
	date_created_on date,
	priority double
);

create table User (
	id int,
	twitter varchar(30),
	income float,
	gender varchar(6)
);

create table Tag (
	id int,
	second_priority float,
	name varchar(30)
);
create table category_tag(
	id int,
	category_id int,
	tag_id int
);
create table tag_article_11(
	id int,
	tag_id int,
	article_11_id int
);
	
