create table Tag_part1(
	id int,
	second_priority float
);
create table Tag_part2(
	id int,
	name varchar(30)
);

insert into Tag_part1 (second_prority) select second_priority from Tag;
insert into Tag_part2 (name) select name from Tag;
