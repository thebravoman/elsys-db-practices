insert into Article_11 (id, created_on, price, content) values (1,"02-02-2015", 250, "pesho_trqbva_da_zavurshi"), (2,"03-04-2014", 350, "pesho_range");
insert into Category(id, date_created_on, priority) values(2,"04-02-2015", 4), (3,"02-05-2013", 6);
insert into User(id, twitter, income, gender) values(2, "pesho_twit", 650, "male"), (3, "boko_twit", 750, "female");
insert into Tag(id, second_priority, name) values(6, 5.50, "roshav"), (5, 6.50, "shashav");
insert into category_tag(id, category_id, tag_id) values(6, 3, 4), (5, 7, 5);
insert into tag_article_11(id, tag_id, article_11_id) values(7, 2, 1), (1, 4, 3);

