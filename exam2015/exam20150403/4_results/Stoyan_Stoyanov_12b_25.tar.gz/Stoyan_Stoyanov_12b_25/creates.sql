create table Article_12 (
    id serial primary key,
    name varchar(50),
    content text,
    url text
);

create table Category (
    id serial primary key,
    description text,
    name varchar(50)
);

create table users (
    id serial primary key,
    twitter varchar(50),
    name varchar(50),
    age int,
    article_id int
);

create table Tag (
    id serial primary key,
    description varchar(50),
    priority int,
    category_id int,
    user_id int
);
