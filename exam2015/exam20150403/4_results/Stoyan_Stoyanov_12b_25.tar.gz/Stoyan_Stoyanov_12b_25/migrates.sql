create table Tag_part1 (
    id serial primary key,
    description varchar(50)
);

create table Tag_part2 (
    id serial primary key,
    priority int,
    category_id int,
    user_id int
);

insert into Tag_part1 (description) select description from Tag;
insert into Tag_part2 (priority, category_id, user_id) select priority, category_id, user_id from Tag;
