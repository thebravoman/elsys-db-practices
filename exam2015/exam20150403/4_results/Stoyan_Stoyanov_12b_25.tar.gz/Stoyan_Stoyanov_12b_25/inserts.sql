insert into Article_12 (name, content, url) values ('haha', 'sudurjanie', 'asda'), ('sadsaas', 'sads', 'sadsa');
insert into Category (description, name) values ('martin', 'sadsa'), ('tosho', 'adsad');
insert into users (twitter, name, age, article_id) values ('sadassa', 'asdsaas', 15, 1), ('sadsa', 'asdas', 18, 2);
insert into Tag (description, priority, category_id, user_id) values ('asdsa', 3, 1, 2), ('dsad', 5, 2, 1);

