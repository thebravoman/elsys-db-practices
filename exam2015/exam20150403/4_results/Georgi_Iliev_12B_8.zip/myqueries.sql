CREATE TABLE Article_17(
		id INT NOT NULL PRIMARY KEY AUTO_INCREMENT,
		url text,
		content text,
		password varchar(30)
	);

CREATE TABLE Category(
		id INT NOT NULL PRIMARY KEY AUTO_INCREMENT,
		name varchar(30),
		priority double
	);

CREATE TABLE User(
		id INT NOT NULL PRIMARY KEY AUTO_INCREMENT,
		picture_url text ,
		age int,
		income float
);

CREATE TABLE Tag(
		id INT NOT NULL PRIMARY KEY AUTO_INCREMENT,
		name varchar(30),
		priority int
   	);



CREATE TABLE Category_User(
		id INT NOT NULL PRIMARY KEY AUTO_INCREMENT
		
);


ALTER TABLE Category_User 
ADD COLUMN category_id INT NOT NULL , 
ADD CONSTRAINT fk_cat_user_cat_id FOREIGN KEY (category_id) 
REFERENCES Category(id); 

ALTER TABLE Category_User
ADD COLUMN user_Id INT NOT NULL , 
ADD CONSTRAINT fk_cat_user_user_id FOREIGN KEY (user_Id) 
REFERENCES User(id);


ALTER TABLE Category 
ADD COLUMN tag_id INT NOT NULL , 
ADD CONSTRAINT fk_cat_tag FOREIGN KEY (tag_id) 
REFERENCES Tag(id);



CREATE TABLE Category_Article_17(
		id INT NOT NULL PRIMARY KEY AUTO_INCREMENT
   	);


ALTER TABLE Category_Article_17 
ADD COLUMN category_id INT NOT NULL , 
ADD CONSTRAINT fk_cat_art_cat_id FOREIGN KEY (category_id) 
REFERENCES Category(id); 

ALTER TABLE Category_Article_17 
ADD COLUMN article_17_id INT NOT NULL , 
ADD CONSTRAINT fk_cat_art_article_id FOREIGN KEY (article_17_id) 
REFERENCES Article_17(id); 



INSERT INTO Article_17 (url,content,password)
VALUES ("http://lubo.elsys-bg.org/databases/",'content1','17823781'),("http://lubo.elsys-bg.org/",'content3','1712323781'),("http://google.com",'content4','asdgadjhs');

INSERT INTO Tag (name,priority)
VALUES ('name1',12),('name2',11),('name4',240);

INSERT INTO Category(name,priority,tag_id)
VALUES ('name1',420.12,2),('name3',120.134,1),('name4',230.123,3);

INSERT INTO User(picture_url,age,income)
VALUES ('http://www.joomlaworks.net/images/demos/galleries/abstract/7.jpg',18,130.123),('http://www.joomlaworks.net/images/demos/galleries/abstract/8.jpg',23,13.12),('http://www.joomlaworks.net/images/demos/galleries/abstract/1.jpg',11,420.123);

INSERT INTO Category_Article_17(category_id,article_17_id)
VALUES (3,1),(2,1),(2,3);

INSERT INTO Category_User (category_id,user_Id)
VALUES (2,3),(1,1),(3,3);

create table Category_part1 (
id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
name varchar(30)
);

create table Category_part2 (
id INT NOT NULL AUTO_INCREMENT PRIMARY KEY ,
priority double

);

ALTER TABLE Category_part2 
ADD COLUMN tag_id INT NOT NULL , 
ADD CONSTRAINT fk_cat2_tag FOREIGN KEY (tag_id) 
REFERENCES Tag(id);


insert into Category_part1(id,name) select id,name from Category;

insert into Category_part2(id,priority,tag_id) select id,priority,tag_id from Category;