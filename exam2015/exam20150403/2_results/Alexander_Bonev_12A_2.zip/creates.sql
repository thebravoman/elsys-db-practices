create taBLE Article_35 (id int(12) primary key not null auto_increment,
url varchar(100),
password varchar(12),
published_on date);

create taBLE Category (id int(12) primary key not null auto_increment,
created_by varchar(20),
date_created_on date);

create taBLE User (id int(12) primary key not null auto_increment,
age int(99), 
twitter varchar(50),
gender varchar(6));

create taBLE Tag(id int(12) primary key not null auto_increment,
description varchar(100), 
hash varchar(16));


alter table Article_35 add column category_id int;
alter table Article_35 add foreign key (category_id) references category(id);

alter table Category add column tag_id int;
alter table Category add foreign key (tag_id) references tag(id);

alter table Tag add column user_id int;
alter table Tag add foreign key (user_id) references user(id);
