insert into article_35 (url,password) values
("http://google.com","sadasdd"),
("http://abv.bg","sdsddd");

insert into category (created_by,date_created_on) values
("Ivancho",'2003-12-31 01:02:03'),
("Dragancho","2003-12-31 01:02:05");

insert into user (age,twitter) values
(22,"twitter/sdd"),
(33,"twitter/ffa");

insert into tag (description,hash) values
("saddsadsa","sadasdd"),
("saddsadsa","sdsddd");
