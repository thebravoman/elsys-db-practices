insert into Article_34(id, visible, url, content) values 
(1, true, "ewjiewjf", "djsdiofsdof"),
(2, false, "ewjiewjf", "djsdiofsdof");

insert into Category(id, description, name) values 
(1, "ewjiewjf", "John"),
(2, "ewjiewjf", "Smith");

insert into User(id, gender, description, twitter) values 
(1, "male", "ewjiewjf", "djsdiofsdof"),
(2, "female", "ewjiewjf", "djsdiofsdof");

insert into Tag(id, description, second_priority) values 
(1, "ewjiewjf", 2.1),
(2, "ewjiewjf", 2.2);
