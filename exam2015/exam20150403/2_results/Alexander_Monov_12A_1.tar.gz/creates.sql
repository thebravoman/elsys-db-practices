CREATE DATABASE alexander_monov DEFAULT CHARSET UTF8;
use alexander_monov;

create table Article_34(id int(11) primary key auto_increment not null,
visible boolean,
url varchar(20),
content longtext
);


create table Category(id int(11) primary key auto_increment not null,
description longtext,
name varchar(12)
);

create table User(id int(11) primary key auto_increment not null,
gender varchar(6),
description longtext,
twitter varchar(10)
);

create table Tag(id int(11) primary key auto_increment not null,
description longtext,
second_priority float
);


alter table Category add column tag_id int;
alter table Category add foreign key (tag_id) references tag(id);
alter table Tag add column category_id int;
alter table Tag add foreign key (category_id) references category(id);

alter table Tag add column user_id int;
alter table Tag add foreign key (user_id) references user(id);

alter table User add column article34_id int;
alter table User add foreign key (article34_id) references article34(id);

