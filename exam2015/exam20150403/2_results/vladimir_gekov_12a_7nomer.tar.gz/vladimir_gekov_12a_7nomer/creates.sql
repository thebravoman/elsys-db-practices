SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='TRADITIONAL';

CREATE SCHEMA IF NOT EXISTS `mydb` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci ;
USE `mydb` ;

-- -----------------------------------------------------
-- Table `mydb`.`Tag`
-- -----------------------------------------------------
CREATE  TABLE IF NOT EXISTS `mydb`.`Tag` (
  `idTag` INT NOT NULL ,
  `priority` INT(11) NULL ,
  `name` VARCHAR(45) NULL ,
  PRIMARY KEY (`idTag`) )
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `mydb`.`Article_29`
-- -----------------------------------------------------
CREATE  TABLE IF NOT EXISTS `mydb`.`Article_29` (
  `idArticle_29` INT NOT NULL ,
  `visible` TINYINT(1) NULL ,
  `created_on` DATE NULL ,
  `published_on` DATE NULL ,
  `Tag_idTag` INT NOT NULL ,
  PRIMARY KEY (`idArticle_29`, `Tag_idTag`) ,
  INDEX `fk_Article_29_Tag1` (`Tag_idTag` ASC) ,
  CONSTRAINT `fk_Article_29_Tag1`
    FOREIGN KEY (`Tag_idTag` )
    REFERENCES `mydb`.`Tag` (`idTag` )
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `mydb`.`User`
-- -----------------------------------------------------
CREATE  TABLE IF NOT EXISTS `mydb`.`User` (
  `idUser` INT NOT NULL ,
  `gender` VARCHAR(6) NULL ,
  `income` FLOAT NULL ,
  `name` VARCHAR(45) NULL ,
  `Article_29_idArticle_29` INT NOT NULL ,
  PRIMARY KEY (`idUser`, `Article_29_idArticle_29`) ,
  INDEX `fk_User_Article_291` (`Article_29_idArticle_29` ASC) ,
  CONSTRAINT `fk_User_Article_291`
    FOREIGN KEY (`Article_29_idArticle_29` )
    REFERENCES `mydb`.`Article_29` (`idArticle_29` )
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `mydb`.`Category`
-- -----------------------------------------------------
CREATE  TABLE IF NOT EXISTS `mydb`.`Category` (
  `idCategory` INT NOT NULL ,
  `created_by` LONGTEXT NULL ,
  `priority` DOUBLE NULL ,
  `User_idUser` INT NOT NULL ,
  PRIMARY KEY (`idCategory`, `User_idUser`) ,
  INDEX `fk_Category_User` (`User_idUser` ASC) ,
  CONSTRAINT `fk_Category_User`
    FOREIGN KEY (`User_idUser` )
    REFERENCES `mydb`.`User` (`idUser` )
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;



SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;
