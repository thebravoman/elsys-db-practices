create table user_part1(
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT primary key,
  name varchar
);
create table user_part2(
	`id` INT UNSIGNED NOT NULL AUTO_INCREMENT primary key,
    content longtext,
    gender varchar,
    income float
);

insert into user_part1(name) select name from user;
insert into user_part2(gender,income) select gender,income from article;
