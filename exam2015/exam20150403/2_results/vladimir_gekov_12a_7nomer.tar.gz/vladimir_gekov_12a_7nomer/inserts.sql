INSERT INTO Article_29 (`visible`, `created_on`, `published_on`) VALUES
  (true, "04/05/2014", "05/05/2014"),
  (false, "04/05/2014", "05/05/2014");
  
INSERT INTO Category (`created_by`, `priority`) VALUES
  ("vladi", "41"),
  ("spas", "10");
  
INSERT INTO User (`gender`, `income`, `name`) VALUES
  ("asdf", "123", "vladi"),
  ("asdasd", "1313", "vladi");
  
INSERT INTO Tag (`priority`, `name`) VALUES
  (10, "spas"),
  (15, "asen");
