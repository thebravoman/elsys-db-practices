INSERT INTO article_44 (`id`) VALUES
	(0, "12.12.2012", 30.1, "topkek"),
	(1, "13.12.2013", 32.2, "kektop");
INSERT INTO category (`id`) VALUES
	(0, 30.2, "12.12.2032"),
	(1, 21.2, "10.12.3043");
INSERT INTO user (`id`) VALUES
	(0, "lel", "male", "lz1irq"),
	(1, "ddz", "female", "hng");
INSERT INTO tag (`id`) VALUES
	(0, 0.32, 221),
	(1, 7899);
