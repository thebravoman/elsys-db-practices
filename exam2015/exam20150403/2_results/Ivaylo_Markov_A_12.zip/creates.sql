CREATE DATABASE IF NOT EXISTS`exam` DEFAULT CHARSET UTF8;
USE exam;
CREATE TABLE IF NOT EXISTS `article_44` (
        `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
        `published_on` DATE,
        `price` DECIMAL(10,2),
        `password` VARCHAR(255),
	PRIMARY KEY (`id`)
);
CREATE TABLE IF NOT EXISTS `category` (
        `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
        `priority` DOUBLE,
        `date_created_on` DATE,
	PRIMARY KEY (`id`)
);
CREATE TABLE IF NOT EXISTS `user` (
        `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
        `name` VARCHAR(255),
        `gender` VARCHAR(6),
        `twitter` VARCHAR(255),
	PRIMARY KEY (`id`)
);
CREATE TABLE IF NOT EXISTS `tag` (
        `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
        `second_priority` FLOAT,
        `priority` INT,
	PRIMARY KEY (`id`)
);
ALTER TABLE `article_44` ADD FOREIGN KEY (id) REFERENCES user(id);

ALTER TABLE `tag` ADD COLUMN user_id INT UNSIGNED NOT NULL;
CREATE TABLE IF NOT EXISTS `category_tag` (
            `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
            `tag_id` INT UNSIGNED NOT NULL,
            `category_id` INT UNSIGNED NOT NULL,
            PRIMARY KEY(`id`)
         );
