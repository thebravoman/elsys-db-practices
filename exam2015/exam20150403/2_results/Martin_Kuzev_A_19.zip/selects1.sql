insert into article_30(published_on)
values(now());
insert into article_30(password)
values("asdf");
insert into article_30(url)
values("assddf");

insert into Category(date_created_on)
values(now());
insert into Category(description)
values("asdsddsf");

insert into user(name)
values("penata");
insert into user(password)
values("penata");
insert into user(age)
values(12);
insert into user(category_id)
values(1);

insert into Tag(description)
values("penata");
insert into Tag(priority)
values(5);
insert into Tag(article_id)
values(1);
insert into Tag(user_id)
values(1);