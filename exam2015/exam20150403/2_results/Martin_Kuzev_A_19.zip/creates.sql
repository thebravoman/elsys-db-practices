create table Article_30 (
    id integer not null primary key auto_increment,
    published_on date,
    password varchar(255),
    url varchar(255)
);
create table Category (
    id integer not null primary key auto_increment,
    date_created_on date,
    description text
);

create table User (
    id integer not null primary key auto_increment,
    name varchar(255),
    age integer,
    password varchar(255),
    category_id integer,
    foreign key (category_id) references Category(id)
);

create table Tag (
    id integer not null primary key auto_increment,
    priority int,
    description varchar(255),
    article_id integer unique,
    foreign key (article_id) references Article_30(id),
    user_id integer,
    foreign key (user_id) references User(id)
);
