USE izpit1_nikolay;

select Tag.description from Tag, Article_33, Category, Category_tags
where Category.article_id = Article_33.id and
		Category_tags.tag_id = Tag.id and
		Category_tags.cat_id = Category.id and
		Article_33.url = "abc";