USE izpit1_nikolay;

INSERT INTO Article_33(url, content, visible) VALUES("abc", "ABC", True), ("sec", "SEC", False);
INSERT INTO Category(description, created_by) VALUES("abc", "gosho"), ("sec", "pesho");
INSERT INTO User(picture_url, description, password) VALUES("abc", "gosho", "123"), ("sec", "pesho", "234");
INSERT INTO Tag(description, hash) VALUES("abc", "123"), ("desc", "hash");
