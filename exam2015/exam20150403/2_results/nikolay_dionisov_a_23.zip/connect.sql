USE izpit1_nikolay;

alter table Category add column article_id int not null;
create table Category_tags(id int not null auto_increment primary key,
	cat_id int not null,
	tag_id int not null);
alter table User add column tag_id int not null;

