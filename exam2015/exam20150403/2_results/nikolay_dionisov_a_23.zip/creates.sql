CREATE DATABASE `izpit1_nikolay` DEFAULT CHARSET UTF8;
USE izpit1_nikolay;

CREATE TABLE Article_33 (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `url` varchar(128),
  `content` longtext,
  `visible` boolean,
  PRIMARY KEY (`id`)
);
CREATE TABLE Category (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `description` longtext,
  `created_by` VARCHAR(64),
  PRIMARY KEY (`id`)
);

CREATE TABLE User (
	id INT UNSIGNED NOT NULL AUTO_INCREMENT,
	picture_url VARCHAR(128),
	description longtext,
	password varchar(128),
	PRIMARY KEY (`id`)
);

CREATE TABLE Tag (
	id INT UNSIGNED NOT NULL AUTO_INCREMENT,
	description varchar(128),
	hash varchar(16),
	PRIMARY KEY (`id`)
);

