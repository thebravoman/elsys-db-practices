INSERT INTO User (password,twitter,description) VALUES
  ("pass","twitt","asasa"),
  ("pass","twitt","asasa");
  
INSERT INTO article_49 (price,url,visible,category_id) VALUES
  (14,"asasa",true,1),
  (14,"asasa",true,2);
  
INSERT INTO tag (name,priority,category_id) VALUES
  ("asas",5,1),
  ("asas",5,2);
INSERT INTO Category (description, date_created_on,article_id) VALUES
  ("asasa",current_date(),1),
  ("asasa",current_date(),2); 