-- MySQL dump 10.13  Distrib 5.6.17, for Win32 (x86)
--
-- Host: localhost    Database: lubo
-- ------------------------------------------------------
-- Server version	5.6.23-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `article_49`
--

DROP TABLE IF EXISTS `article_49`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `article_49` (
  `id` int(6) NOT NULL AUTO_INCREMENT,
  `price` double DEFAULT NULL,
  `url` text,
  `visible` tinyint(1) DEFAULT NULL,
  `category_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `category_id` (`category_id`),
  CONSTRAINT `article_49_ibfk_1` FOREIGN KEY (`category_id`) REFERENCES `category` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=29 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `article_49`
--

LOCK TABLES `article_49` WRITE;
/*!40000 ALTER TABLE `article_49` DISABLE KEYS */;
INSERT INTO `article_49` VALUES (1,14.55,'asasa',1,NULL),(2,14.55,'asasa',1,NULL),(3,14,'asasa',1,1),(4,14,'asasa',1,2),(5,14,'asasa',1,1),(6,14,'asasa',1,2),(7,14,'asasa',1,1),(8,14,'asasa',1,2),(9,14,'asasa',1,1),(10,14,'asasa',1,2),(11,14,'asasa',1,1),(12,14,'asasa',1,2),(13,14,'asasa',1,1),(14,14,'asasa',1,2),(15,14,'asasa',1,1),(16,14,'asasa',1,2),(17,14,'asasa',1,1),(18,14,'asasa',1,2),(19,14,'asasa',1,1),(20,14,'asasa',1,2),(21,14,'asasa',1,1),(22,14,'asasa',1,2),(23,14,'asasa',1,1),(24,14,'asasa',1,2),(25,14,'asasa',1,1),(26,14,'asasa',1,2),(27,14,'asasa',1,1),(28,14,'asasa',1,2);
/*!40000 ALTER TABLE `article_49` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `article_49_part1`
--

DROP TABLE IF EXISTS `article_49_part1`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `article_49_part1` (
  `id` int(6) NOT NULL AUTO_INCREMENT,
  `visible` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=32 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `article_49_part1`
--

LOCK TABLES `article_49_part1` WRITE;
/*!40000 ALTER TABLE `article_49_part1` DISABLE KEYS */;
INSERT INTO `article_49_part1` VALUES (1,1),(2,1),(3,1),(4,1),(5,1),(6,1),(7,1),(8,1),(9,1),(10,1),(11,1),(12,1),(13,1),(14,1),(15,1),(16,1),(17,1),(18,1),(19,1),(20,1),(21,1),(22,1),(23,1),(24,1),(25,1),(26,1),(27,1),(28,1);
/*!40000 ALTER TABLE `article_49_part1` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `article_49_part2`
--

DROP TABLE IF EXISTS `article_49_part2`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `article_49_part2` (
  `id` int(6) NOT NULL AUTO_INCREMENT,
  `price` double DEFAULT NULL,
  `url` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=32 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `article_49_part2`
--

LOCK TABLES `article_49_part2` WRITE;
/*!40000 ALTER TABLE `article_49_part2` DISABLE KEYS */;
INSERT INTO `article_49_part2` VALUES (1,14.55,'asasa'),(2,14.55,'asasa'),(3,14,'asasa'),(4,14,'asasa'),(5,14,'asasa'),(6,14,'asasa'),(7,14,'asasa'),(8,14,'asasa'),(9,14,'asasa'),(10,14,'asasa'),(11,14,'asasa'),(12,14,'asasa'),(13,14,'asasa'),(14,14,'asasa'),(15,14,'asasa'),(16,14,'asasa'),(17,14,'asasa'),(18,14,'asasa'),(19,14,'asasa'),(20,14,'asasa'),(21,14,'asasa'),(22,14,'asasa'),(23,14,'asasa'),(24,14,'asasa'),(25,14,'asasa'),(26,14,'asasa'),(27,14,'asasa'),(28,14,'asasa');
/*!40000 ALTER TABLE `article_49_part2` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `category`
--

DROP TABLE IF EXISTS `category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `category` (
  `id` int(6) NOT NULL AUTO_INCREMENT,
  `description` longtext,
  `date_created_on` date DEFAULT NULL,
  `article_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `article_id` (`article_id`),
  CONSTRAINT `category_ibfk_1` FOREIGN KEY (`article_id`) REFERENCES `article_49` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `category`
--

LOCK TABLES `category` WRITE;
/*!40000 ALTER TABLE `category` DISABLE KEYS */;
INSERT INTO `category` VALUES (1,'asasa','2015-04-03',NULL),(2,'asasa','2015-04-03',NULL),(3,'asasa','2015-04-03',NULL),(4,'asasa','2015-04-03',NULL),(5,'asasa','2015-04-03',NULL),(6,'asasa','2015-04-03',NULL),(7,'asasa','2015-04-03',NULL),(8,'asasa','2015-04-03',NULL),(9,'asasa','2015-04-03',NULL),(10,'asasa','2015-04-03',NULL),(11,NULL,NULL,1),(12,NULL,NULL,2),(13,NULL,NULL,1),(14,NULL,NULL,2),(15,'asasa','2015-04-03',1),(16,'asasa','2015-04-03',2),(17,'asasa','2015-04-03',1),(18,'asasa','2015-04-03',2),(19,'asasa','2015-04-03',1),(20,'asasa','2015-04-03',2),(21,'asasa','2015-04-03',1),(22,'asasa','2015-04-03',2),(23,'asasa','2015-04-03',1),(24,'asasa','2015-04-03',2),(25,'asasa','2015-04-03',1),(26,'asasa','2015-04-03',2);
/*!40000 ALTER TABLE `category` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tag`
--

DROP TABLE IF EXISTS `tag`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tag` (
  `id` int(6) NOT NULL AUTO_INCREMENT,
  `name` varchar(12) DEFAULT NULL,
  `priority` int(11) DEFAULT NULL,
  `category_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `category_id` (`category_id`),
  CONSTRAINT `tag_ibfk_1` FOREIGN KEY (`category_id`) REFERENCES `category` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=29 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tag`
--

LOCK TABLES `tag` WRITE;
/*!40000 ALTER TABLE `tag` DISABLE KEYS */;
INSERT INTO `tag` VALUES (1,'asas',5,NULL),(2,'asas',5,NULL),(3,'asas',5,1),(4,'asas',5,2),(5,'asas',5,1),(6,'asas',5,2),(7,'asas',5,1),(8,'asas',5,2),(9,'asas',5,1),(10,'asas',5,2),(11,'asas',5,1),(12,'asas',5,2),(13,'asas',5,1),(14,'asas',5,2),(15,'asas',5,1),(16,'asas',5,2),(17,'asas',5,1),(18,'asas',5,2),(19,'asas',5,1),(20,'asas',5,2),(21,'asas',5,1),(22,'asas',5,2),(23,'asas',5,1),(24,'asas',5,2),(25,'asas',5,1),(26,'asas',5,2),(27,'asas',5,1),(28,'asas',5,2);
/*!40000 ALTER TABLE `tag` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user` (
  `id` int(6) NOT NULL AUTO_INCREMENT,
  `password` varchar(12) DEFAULT NULL,
  `twitter` varchar(12) DEFAULT NULL,
  `description` longtext,
  `article_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `article_id` (`article_id`),
  CONSTRAINT `user_ibfk_1` FOREIGN KEY (`article_id`) REFERENCES `article_49` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user`
--

LOCK TABLES `user` WRITE;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` VALUES (1,'pass','twitt','asasa',NULL),(2,'pass','twitt','asasa',NULL),(3,'pass','twitt','asasa',NULL),(4,'pass','twitt','asasa',NULL),(5,'pass','twitt','asasa',NULL),(6,'pass','twitt','asasa',NULL),(7,'pass','twitt','asasa',NULL),(8,'pass','twitt','asasa',NULL),(9,'pass','twitt','asasa',NULL),(10,'pass','twitt','asasa',NULL),(11,'pass','twitt','asasa',NULL),(12,'pass','twitt','asasa',NULL),(13,'pass','twitt','asasa',NULL),(14,'pass','twitt','asasa',NULL),(15,'pass','twitt','asasa',NULL),(16,'pass','twitt','asasa',NULL),(17,'pass','twitt','asasa',NULL),(18,'pass','twitt','asasa',NULL),(19,'pass','twitt','asasa',NULL),(20,'pass','twitt','asasa',NULL),(21,'pass','twitt','asasa',NULL),(22,'pass','twitt','asasa',NULL),(23,'pass','twitt','asasa',NULL),(24,'pass','twitt','asasa',NULL),(25,'pass','twitt','asasa',NULL),(26,'pass','twitt','asasa',NULL);
/*!40000 ALTER TABLE `user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'lubo'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2015-04-03  9:14:54
