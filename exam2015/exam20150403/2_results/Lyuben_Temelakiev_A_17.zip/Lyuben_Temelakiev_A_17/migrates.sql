create table Article_49_part1 (id int(6) primary key auto_increment not null,
visible bool);
create table Article_49_part2 (id int(6) primary key auto_increment not null,
price double,
url text);
insert into Article_49_part1(visible) select visible from article_49;
insert into Article_49_part2(price,url) select price,url from article_49;