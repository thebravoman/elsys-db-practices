
select * from tag
join article_49, category
where category.id = tag.category_id
and article_49.category_id = category.id;
  