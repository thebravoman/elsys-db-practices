create table Article_49(
id int(6) primary key auto_increment not null,
price double,
url text,
visible boolean
);

create table Category(
id int(6) primary key auto_increment not null,
description longtext,
date_created_on date
);

create table User(
id int(6) primary key auto_increment not null,
password varchar(12),
twitter varchar(12),
description longtext
);

create table Tag(
id int(6) primary key auto_increment not null,
name varchar(12),
priority int
);

alter table user add column article_id int;
alter table user add foreign key (article_id) references article_49(id);

alter table article_49 add column category_id int;
alter table article_49 add foreign key (category_id) references category(id);
alter table category add column article_id int;
alter table category add foreign key (article_id) references article_49(id);

alter table tag add column category_id int;
alter table tag add foreign key (category_id) references category(id);
