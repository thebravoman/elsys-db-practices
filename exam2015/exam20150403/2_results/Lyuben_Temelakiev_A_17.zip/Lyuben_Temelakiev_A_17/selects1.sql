select * from category
join user, article_49
where article_49.category_id = category.id
and user.article_id = article_49.id;
