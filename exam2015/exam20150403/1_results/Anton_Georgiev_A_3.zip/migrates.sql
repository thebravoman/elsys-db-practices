create table Article_36_part1(id int(11) auto_increment primary key, url text);
create table Article_36_part2 (id int(11) auto_increment primary key, price decimal(15, 2), name varchar(255));
insert into Article_36_part1 (url) select url from Article_36;
insert into Article_36_part2 (price, name) select price, name from Article_36;
