Create table Article_36(id int(11) auto_increment primary key, price decimal(15, 2), name varchar(255), url text);
Create table Category(id int(11) auto_increment primary key, name varchar(255),	 priority double);
Create table User(id int(11) auto_increment primary key, description text, picture_url text, income float);
Create table Tag(id int(11) auto_increment primary key, priority int, hash varchar(16));

alter table Article_36 add column User_id int(11);
alter table Article_36 add column Category_id int(11);
alter table Category add column Tag_id int(11);
