insert into Article_36(price, name, url) values(12.2, 'haha', 'http://example.com');
insert into Article_36(price, name, url) values(13.4, 'hihi', 'http://google.com');
insert into Category(name, priority) values('hoho', 1);
insert into Category(name, priority) values('hoha', 2);
insert into User(description, picture_url, income) values('beo', 'http://aa.com', 56.1);
insert into User(description, picture_url, income) values('beho', 'http://bb.com', 51.5);
insert into Tag(priority, hash) values(2, 'hash1');
insert into Tag(priority, hash) values(1, 'hash2');
