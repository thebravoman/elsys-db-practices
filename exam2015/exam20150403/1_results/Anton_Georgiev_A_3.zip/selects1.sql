select * from Category where (select Category_id from Article_36 where User_id = 1) = id;
