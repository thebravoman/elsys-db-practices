CREATE DATABASE milko_filipov DEFAULT CHARSET UTF8;
USE milko_filipov;

create table Article_51(

	id int,
	visible boolean,
	published_on date,
	created_on date,
	
	primary_key(id)
)

create table Category(id int, priority double, created_by text, primary_key(id));

create table User(id int, picture_url varchar(40), created_on date , income float, primary_key(id));

create table Tag(id int, name varchar(40), description varchar(40), primary_key(id));

ALTER TABLE Article_51 ADD COLUMN tag_id int;

create table Article_User(article_id int, user_id int);

ALTER TABLE User ADD COLUMN category_id int;

insert into Article_51(id , visible , published_on, created_on ) values (1, true, "2012-02-04", "2012-02-01");
insert into Article_51(id , visible , published_on, created_on ) values (1, true, "2012-02-05", "2012-02-03");

insert into Categpry(id , priority , created_by ) values (1, 2.5, "sad");
insert into Category(id , priority , created_by ) values (2, 2.3, "sasd");

insert into User(id , picture_url , created_on ) values (1, "asdas", "2012-02-03");
insert into User(id , picture_url , created_on ) values (2, "asdsas", "2011-02-03");

insert into Tag(id , name , description ) values (1, "asddas", "sad");
insert into Tag(id , name , description ) values (2, "asdas", "saad");

Select User.id from User inner join Article_User on user.id = Article_User.user_id and Article_51.id = Article_User.article_id and Article_51.tag_id = Tag.id;

create table Article_51_part1( id int,  visible boolean, tag_id int, primary_key(id));

create table Article_51_part2( id int,  published_on date, created_on date tag_id int, primary_key(id));

insert into Article_51_part1( id, visible, tag_id) select id, visible, tag_id from Article_51;

insert into Article_51_part1( id, published_on, created_on, tag_id) select id, visible, published_on, created_on tag_id from Article_51;

drop table Article_51;






