select * from user
join category,category_tag,tag
where user.id = tag.user_id
and tag.id = category_tag.tag_id
and category_tag.category_id = category.id;