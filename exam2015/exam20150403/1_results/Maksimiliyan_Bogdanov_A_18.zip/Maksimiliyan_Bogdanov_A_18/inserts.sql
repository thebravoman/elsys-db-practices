INSERT INTO article_50 (created_on,content,password) VALUES
  (current_date(),"asdasd","asdasdd"),
  (current_date(),"ddd","wwww");
  
INSERT INTO Category (name,description) VALUES
  ("adsasd","ojasd"),
  ("adsasd","ojasd");
  
INSERT INTO User (created_on,age,gender) VALUES
  (current_date(),12,"asldj"),
    (current_date(),15,"ddddd");
  
INSERT INTO tag (priority,name) VALUES
  (12,"kjl"),
  (13,"ahusd");
  
INSERT INTO article_50 (created_on,content,password,user_id) VALUES
  (current_date(),"asdasd","asdasdd",1),
  (current_date(),"ddd","wwww",2);
  
INSERT INTO User (created_on,age,gender,tag_id,article_id) VALUES
  (current_date(),12,"asldj",3,3),
    (current_date(),15,"ddddd",1,3);
    
INSERT INTO tag (priority,name,user_id) VALUES
  (12,"kjl",1),
  (13,"ahusd",4);
  
insert into category_tag(category_id,tag_id) values
(1,2),
(3,4);
  