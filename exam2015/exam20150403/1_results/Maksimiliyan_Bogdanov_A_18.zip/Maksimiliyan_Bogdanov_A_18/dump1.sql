-- MySQL dump 10.13  Distrib 5.6.17, for Win32 (x86)
--
-- Host: localhost    Database: max
-- ------------------------------------------------------
-- Server version	5.6.23-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `article_50`
--

DROP TABLE IF EXISTS `article_50`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `article_50` (
  `id` int(6) NOT NULL AUTO_INCREMENT,
  `created_on` date DEFAULT NULL,
  `content` longtext,
  `password` varchar(12) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `article_50_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `article_50`
--

LOCK TABLES `article_50` WRITE;
/*!40000 ALTER TABLE `article_50` DISABLE KEYS */;
INSERT INTO `article_50` VALUES (1,'2015-04-03','asdasd','asdasdd',NULL),(2,'2015-04-03','ddd','wwww',NULL),(3,'2015-04-03','asdasd','asdasdd',NULL),(4,'2015-04-03','ddd','wwww',NULL),(5,'2015-04-03','asdasd','asdasdd',NULL),(6,'2015-04-03','ddd','wwww',NULL),(7,'2015-04-03','asdasd','asdasdd',NULL),(8,'2015-04-03','ddd','wwww',NULL),(9,'2015-04-03','asdasd','asdasdd',NULL),(10,'2015-04-03','ddd','wwww',NULL),(11,'2015-04-03','asdasd','asdasdd',NULL),(12,'2015-04-03','ddd','wwww',NULL),(13,'2015-04-03','asdasd','asdasdd',1),(14,'2015-04-03','ddd','wwww',2),(15,'2015-04-03','asdasd','asdasdd',1),(16,'2015-04-03','ddd','wwww',2),(17,'2015-04-03','asdasd','asdasdd',1),(18,'2015-04-03','ddd','wwww',2),(19,'2015-04-03','asdasd','asdasdd',1),(20,'2015-04-03','ddd','wwww',2);
/*!40000 ALTER TABLE `article_50` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `category`
--

DROP TABLE IF EXISTS `category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `category` (
  `id` int(6) NOT NULL AUTO_INCREMENT,
  `name` varchar(12) DEFAULT NULL,
  `description` longtext,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `category`
--

LOCK TABLES `category` WRITE;
/*!40000 ALTER TABLE `category` DISABLE KEYS */;
INSERT INTO `category` VALUES (1,'adsasd','ojasd'),(2,'adsasd','ojasd'),(3,'adsasd','ojasd'),(4,'adsasd','ojasd'),(5,'adsasd','ojasd'),(6,'adsasd','ojasd'),(7,'adsasd','ojasd'),(8,'adsasd','ojasd'),(9,'adsasd','ojasd'),(10,'adsasd','ojasd'),(11,'adsasd','ojasd'),(12,'adsasd','ojasd'),(13,'adsasd','ojasd'),(14,'adsasd','ojasd'),(15,'adsasd','ojasd'),(16,'adsasd','ojasd'),(17,'adsasd','ojasd'),(18,'adsasd','ojasd'),(19,'adsasd','ojasd'),(20,'adsasd','ojasd'),(21,'adsasd','ojasd'),(22,'adsasd','ojasd'),(23,'adsasd','ojasd'),(24,'adsasd','ojasd');
/*!40000 ALTER TABLE `category` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `category_tag`
--

DROP TABLE IF EXISTS `category_tag`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `category_tag` (
  `id` int(6) NOT NULL AUTO_INCREMENT,
  `category_id` int(11) DEFAULT NULL,
  `tag_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `category_id` (`category_id`),
  KEY `tag_id` (`tag_id`),
  CONSTRAINT `category_tag_ibfk_1` FOREIGN KEY (`category_id`) REFERENCES `category` (`id`),
  CONSTRAINT `category_tag_ibfk_2` FOREIGN KEY (`tag_id`) REFERENCES `tag` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `category_tag`
--

LOCK TABLES `category_tag` WRITE;
/*!40000 ALTER TABLE `category_tag` DISABLE KEYS */;
INSERT INTO `category_tag` VALUES (1,1,2),(2,3,4),(3,1,2),(4,3,4),(5,1,2),(6,3,4),(7,1,2),(8,3,4);
/*!40000 ALTER TABLE `category_tag` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tag`
--

DROP TABLE IF EXISTS `tag`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tag` (
  `id` int(6) NOT NULL AUTO_INCREMENT,
  `priority` int(11) DEFAULT NULL,
  `name` varchar(12) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `tag_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=29 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tag`
--

LOCK TABLES `tag` WRITE;
/*!40000 ALTER TABLE `tag` DISABLE KEYS */;
INSERT INTO `tag` VALUES (1,12,'kjl',NULL),(2,13,'ahusd',NULL),(3,12,'kjl',NULL),(4,13,'ahusd',NULL),(5,12,'kjl',NULL),(6,13,'ahusd',NULL),(7,12,'kjl',NULL),(8,13,'ahusd',NULL),(9,12,'kjl',NULL),(10,13,'ahusd',NULL),(11,12,'kjl',1),(12,13,'ahusd',2),(13,12,'kjl',1),(14,13,'ahusd',2),(15,12,'kjl',1),(16,13,'ahusd',2),(17,12,'kjl',1),(18,13,'ahusd',2),(19,12,'kjl',1),(20,13,'ahusd',2),(21,12,'kjl',3),(22,13,'ahusd',3),(23,12,'kjl',3),(24,13,'ahusd',3),(25,12,'kjl',3),(26,13,'ahusd',4),(27,12,'kjl',3),(28,13,'ahusd',4);
/*!40000 ALTER TABLE `tag` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tag_part1`
--

DROP TABLE IF EXISTS `tag_part1`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tag_part1` (
  `id` int(6) NOT NULL AUTO_INCREMENT,
  `priority` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=32 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tag_part1`
--

LOCK TABLES `tag_part1` WRITE;
/*!40000 ALTER TABLE `tag_part1` DISABLE KEYS */;
INSERT INTO `tag_part1` VALUES (1,12),(2,13),(3,12),(4,13),(5,12),(6,13),(7,12),(8,13),(9,12),(10,13),(11,12),(12,13),(13,12),(14,13),(15,12),(16,13),(17,12),(18,13),(19,12),(20,13),(21,12),(22,13),(23,12),(24,13),(25,12),(26,13),(27,12),(28,13);
/*!40000 ALTER TABLE `tag_part1` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tag_part2`
--

DROP TABLE IF EXISTS `tag_part2`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tag_part2` (
  `id` int(6) NOT NULL AUTO_INCREMENT,
  `name` varchar(12) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=32 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tag_part2`
--

LOCK TABLES `tag_part2` WRITE;
/*!40000 ALTER TABLE `tag_part2` DISABLE KEYS */;
INSERT INTO `tag_part2` VALUES (1,'kjl',NULL),(2,'ahusd',NULL),(3,'kjl',NULL),(4,'ahusd',NULL),(5,'kjl',NULL),(6,'ahusd',NULL),(7,'kjl',NULL),(8,'ahusd',NULL),(9,'kjl',NULL),(10,'ahusd',NULL),(11,'kjl',1),(12,'ahusd',2),(13,'kjl',1),(14,'ahusd',2),(15,'kjl',1),(16,'ahusd',2),(17,'kjl',1),(18,'ahusd',2),(19,'kjl',1),(20,'ahusd',2),(21,'kjl',3),(22,'ahusd',3),(23,'kjl',3),(24,'ahusd',3),(25,'kjl',3),(26,'ahusd',4),(27,'kjl',3),(28,'ahusd',4);
/*!40000 ALTER TABLE `tag_part2` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user` (
  `id` int(6) NOT NULL AUTO_INCREMENT,
  `created_on` date DEFAULT NULL,
  `age` int(11) DEFAULT NULL,
  `gender` varchar(12) DEFAULT NULL,
  `tag_id` int(11) DEFAULT NULL,
  `article_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `tag_id` (`tag_id`),
  KEY `article_id` (`article_id`),
  CONSTRAINT `user_ibfk_1` FOREIGN KEY (`tag_id`) REFERENCES `tag` (`id`),
  CONSTRAINT `user_ibfk_2` FOREIGN KEY (`article_id`) REFERENCES `article_50` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=33 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user`
--

LOCK TABLES `user` WRITE;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` VALUES (1,'2015-04-03',12,'asldj',NULL,NULL),(2,'2015-04-03',12,'asldj',NULL,NULL),(3,'2015-04-03',12,'asldj',NULL,NULL),(4,'2015-04-03',12,'asldj',NULL,NULL),(5,'2015-04-03',12,'asldj',NULL,NULL),(6,'2015-04-03',12,'asldj',NULL,NULL),(7,'2015-04-03',12,'asldj',NULL,NULL),(8,'2015-04-03',12,'asldj',NULL,NULL),(9,'2015-04-03',12,'asldj',NULL,NULL),(10,'2015-04-03',15,'ddddd',NULL,NULL),(11,'2015-04-03',12,'asldj',1,2),(12,'2015-04-03',15,'ddddd',2,3),(13,'2015-04-03',12,'asldj',1,2),(14,'2015-04-03',15,'ddddd',2,3),(15,'2015-04-03',12,'asldj',1,2),(16,'2015-04-03',15,'ddddd',2,3),(17,'2015-04-03',12,'asldj',1,2),(18,'2015-04-03',15,'ddddd',2,3),(19,'2015-04-03',12,'asldj',1,2),(20,'2015-04-03',15,'ddddd',2,3),(21,'2015-04-03',12,'asldj',3,4),(22,'2015-04-03',15,'ddddd',2,2),(23,'2015-04-03',12,'asldj',3,4),(24,'2015-04-03',15,'ddddd',2,2),(25,'2015-04-03',12,'asldj',4,4),(26,'2015-04-03',15,'ddddd',1,2),(27,'2015-04-03',12,'asldj',4,4),(28,'2015-04-03',15,'ddddd',1,2),(29,'2015-04-03',12,'asldj',3,3),(30,'2015-04-03',15,'ddddd',1,3),(31,'2015-04-03',12,'asldj',3,3),(32,'2015-04-03',15,'ddddd',1,3);
/*!40000 ALTER TABLE `user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'max'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2015-04-03  8:29:19
