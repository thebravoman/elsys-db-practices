create table Article_50 (
id int(6) primary key auto_increment not null,
created_on date,
content longtext,
password varchar(12)
);

create table Category(
id int(6) primary key auto_increment not null,
name varchar(12),
description longtext
);

create table User(
id int(6) primary key auto_increment not null,
created_on date,
age int,
gender varchar(12)
);

create table Tag(
id int(6) primary key auto_increment not null,
priority int,
name varchar(12)
);

create table category_tag(
id int(6) primary key auto_increment not null,
category_id int,
tag_id int
);

alter table tag add column user_id int;
alter table tag add foreign key (user_id) references user(id);

alter table user add column tag_id int;
alter table user add foreign key (tag_id) references tag(id);

alter table user add column article_id int;
alter table user add foreign key (article_id) references article_50(id);

alter table article_50 add column user_id int;
alter table article_50 add foreign key (user_id) references user(id);

alter table category_tag add foreign key (category_id) references category(id);
alter table category_tag add foreign key (tag_id) references tag(id);



