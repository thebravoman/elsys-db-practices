create table tag_part1(id int(6) primary key auto_increment not null,
priority int
);
create table tag_part2(id int(6) primary key auto_increment not null,
name varchar(12),
user_id int
);

insert into tag_part1(priority) select priority from tag;
insert into tag_part2(name,user_id) select name,user_id from tag;