select * from article_50
join Tag,user
where article_50.id = user.article_id
and tag.id = user.tag_id;