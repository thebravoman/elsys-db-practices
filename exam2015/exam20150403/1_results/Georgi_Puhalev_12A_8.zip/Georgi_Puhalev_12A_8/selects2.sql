select name
from Category
where Category.tag_id = 2;