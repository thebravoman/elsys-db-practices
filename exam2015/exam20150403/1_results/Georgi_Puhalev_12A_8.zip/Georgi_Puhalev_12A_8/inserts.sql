use puh;

insert into Article_41 values(
	'', 
	'password',
	'2015-03-01',
	12.5,
	'1'
);

insert into Article_41 values(
	'', 
	'password2',
	'2015-03-02',
	12.345,
	'1'
);

insert into Category values(
	'',
	'2015-04-01',
	'music',
	'1'
);

insert into Category values(
	'',
	'2015-04-01',
	'stuff',
	'2'
);

insert into User values(
	'',
	'pass',
	'pesho',
	'2015-04-01',
	'2'
);


insert into User values(
	'',
	'pass',
	'toshu',
	'2015-04-01',
	'2'
);

insert into Tag values(
	'',
	'adhja fiahf ajafb af',
	'3.1'
);

insert into Tag values(
	'',
	'adj ahd dhaihd',
	'4.1'
);
