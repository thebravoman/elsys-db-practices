select name
from User
where User.tag_id = any(
	select tag_id
	from Article_41
	where Article_41.id = 4
);