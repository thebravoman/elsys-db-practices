create database puh;

use puh;

CREATE TABLE Article_41(
	id int(11) auto_increment not null,
	password varchar(255),
	created_on date,
	price float(19,4),
	primary key (id)
);

create table Category(
	id int(11) auto_increment not null, 
	date_created_on date, 
	name varchar(256),
	primary key (id)
);

create table User(
	id int(11) auto_increment not null, 
	password varchar(255), 
	name varchar(255),
	created_on date,
	primary key (id)
);

create table Tag(
	id int(11) auto_increment not null,
	description varchar(255), 
	second_priority float(19,4),
	primary key (id)
);

ALTER TABLE Article_41
ADD tag_id int(11);

ALTER TABLE User
ADD tag_id int(11);

ALTER TABLE Category
ADD tag_id int(11);

