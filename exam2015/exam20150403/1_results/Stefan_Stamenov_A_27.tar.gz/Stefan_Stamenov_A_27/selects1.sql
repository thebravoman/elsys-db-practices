select * from user left join category_article_55 on user.article_55_id= category_article_55.article_55_id left join category on category_article_55.category_id = category.id;
