select * from tag right join user on tag.user_id = user.id right join article_55_part2 on user.article_55_id = article_55_part2.id;

