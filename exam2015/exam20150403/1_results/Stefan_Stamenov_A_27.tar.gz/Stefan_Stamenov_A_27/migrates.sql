create table article_55_part1(id INT(10) UNSIGNED AUTO_INCREMENT PRIMARY KEY, visible tinyint(20));
insert into article_55_part1(visible) select visible from article_55;
create table article_55_part2(id INT(10) UNSIGNED AUTO_INCREMENT PRIMARY KEY, content VARCHAR(255),password VARCHAR(255));
insert into article_55_part2(content,password) select content,password from article_55;
drop table article_55;

