INSERT INTO article_55 (`id`,`content`,`visible`,`password`) VALUES
	('1','gosho','true','aaa'),
	('2','pesho','false','bbb');
INSERT INTO category (`id`,`created_by`,`priority`) VALUES
	('1','gogo','2'),
	('2','pego','1');
INSERT INTO user (`id`,`income`,`description`,`password`,`article_55_id`) VALUES
	('1','25','descript1','pass1','2'),
	('2','75','descript2','pass2','1');
INSERT INTO tag (`id`,`second_priority`,`priority`,`user_id`) VALUES
	('1','1','2','2'),
	('2','2','1','1');
INSERT INTO category_article_55 (`id`,`category_id`,`article_55_id`) VALUES
	('1','1','2'),
	('2','2','1');
