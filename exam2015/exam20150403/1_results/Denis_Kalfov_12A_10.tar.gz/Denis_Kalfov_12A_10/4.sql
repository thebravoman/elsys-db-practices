-- Which are the Tag(s) for a given Category
select Tag.name, Category.name
from test5.article_tags
left join Tag on article_tags.tag_id = Tag.id
left join categories_article on article_tags.article_id = categories_article.article_id
left join Category on categories_article.category_id = Category.id