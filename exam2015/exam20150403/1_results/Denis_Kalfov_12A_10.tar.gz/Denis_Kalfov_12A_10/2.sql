CREATE TABLE `test5`.`categories_article` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `category_id` INT NULL,
  `article_id` INT NULL,
  PRIMARY KEY (`id`));

CREATE TABLE `test5`.`article_tags` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `article_id` INT NULL,
  `tag_id` INT NULL,
  PRIMARY KEY (`id`));

ALTER TABLE test5.Tag
ADD user_id int

