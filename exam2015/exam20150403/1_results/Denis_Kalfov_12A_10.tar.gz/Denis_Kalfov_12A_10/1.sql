CREATE SCHEMA `test5` ;

use test5;

CREATE TABLE `test5`.`Article_42` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `price` DOUBLE NULL,
  `password` VARCHAR(45) NULL,
  `content` LONGTEXT NULL,
  PRIMARY KEY (`id`));

CREATE TABLE `test5`.`Category` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `name` VARCHAR(45) NULL,
  `description` LONGTEXT NULL,
  PRIMARY KEY (`id`));

CREATE TABLE `test5`.`User` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `picture_url` VARCHAR(45) NULL,
  `created_on` DATE NULL,
  `twitter` VARCHAR(45) NULL,
  PRIMARY KEY (`id`));

CREATE TABLE `test5`.`Tag` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `second_priority` FLOAT NULL,
  `name` VARCHAR(45) NULL,
  PRIMARY KEY (`id`));

