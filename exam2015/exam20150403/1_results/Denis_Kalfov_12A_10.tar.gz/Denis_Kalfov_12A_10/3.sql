INSERT INTO `test5`.`Article_42` (`id`, `price`, `password`) VALUES ('1', '32', '1234');
INSERT INTO `test5`.`Article_42` (`id`, `price`, `password`) VALUES ('3', '13', '1111');

INSERT INTO `test5`.`Category` (`id`, `name`, `description`) VALUES ('2', 'cat1', 'd1');
INSERT INTO `test5`.`Category` (`id`, `name`, `description`) VALUES ('3', 'cat3', 'd3');

INSERT INTO `test5`.`categories_article` (`id`, `category_id`, `article_id`) VALUES ('1', '2', '1');
INSERT INTO `test5`.`categories_article` (`id`, `category_id`, `article_id`) VALUES ('2', '3', '3');

INSERT INTO `test5`.`User` (`id`, `picture_url`, `created_on`, `twitter`) VALUES ('1', 'imgur', '2015-03-02', 'no');
INSERT INTO `test5`.`User` (`id`, `picture_url`, `created_on`, `twitter`) VALUES ('2', 'img2', '2015-03-03', 'yes');

INSERT INTO `test5`.`Tag` (`id`, `second_priority`, `name`, `user_id`) VALUES ('1', '4', 'user1', '1');
INSERT INTO `test5`.`Tag` (`id`, `second_priority`, `name`, `user_id`) VALUES ('2', '2', 'user2', '2');

INSERT INTO `test5`.`article_tags` (`id`, `article_id`, `tag_id`) VALUES ('2', '1', '1');
INSERT INTO `test5`.`article_tags` (`id`, `article_id`, `tag_id`) VALUES ('3', '3', '2');

