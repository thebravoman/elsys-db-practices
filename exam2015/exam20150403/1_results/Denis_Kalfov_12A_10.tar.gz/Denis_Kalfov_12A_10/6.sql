ALTER TABLE test5.Article_42
ADD `content` VARCHAR(45);

CREATE TABLE `test5`.`Article_42_part1` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `content` LONGTEXT NULL,
  PRIMARY KEY (`id`));

CREATE TABLE `test5`.`Article_42_part2` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `price` DOUBLE NULL,
  `password` VARCHAR(45) NULL,
  PRIMARY KEY (`id`));

insert into Article_42_part1(content) select content from Article_42;
insert into Article_42_part2(price,password) select price,password from Article_42;

	