CREATE DATABASE opit;
USE opit;

CREATE TABLE Article_46 (id INT(11) not null auto_increment primary key, 
	visible BIT not null, 
	content LONGTEXT not null,
	created_on DATE not null
);

CREATE TABLE Category (id INT(11) not null auto_increment primary key,
  	created_by TEXT not null,
  	description LONGTEXT not null
);

CREATE TABLE User (id INT(11) not null auto_increment primary key,
	income FLOAT(15,2) not null, 
	name VARCHAR(20) not null, 
	age INT(20) not null 
);

CREATE TABLE Tag (id INT(11) not null auto_increment primary key,
	description VARCHAR(255) not null,
	priority INT(50) not null
);

CREATE TABLE Category_Article (id INT(11) not null auto_increment primary key,
	category_id INT(11),
	article_id INT(11)
);