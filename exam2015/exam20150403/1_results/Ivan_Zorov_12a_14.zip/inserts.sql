INSERT INTO Article_46 (id, visible, content, created_on) values 
(1,1,'Zdrasti', ''),
(1,0,'Kak sme', '');

insert into Category (id, created_by, description) values 
(1,'Ivan', 'Opitah se'),
(2,'Zorov', 'Dano stane');

insert into User (id, income, name, age) values 
(1,4.20,'Ivan', 19),
(2,6.66,'Zorov', 19);

insert into Tag (id, description, priority) values 
(1,'Proba', 1),
(2,'Greshka', 2);