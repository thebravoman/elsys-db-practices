select User.name from User left join Article_46 on User.id =Article_46.id 
	left join Category_Article on Category_Article.category_id = Category.id, Category_Article.article_id = Article_46.id  
	where Category.id = 2;