CREATE TABLE Article_46_part1 (id INT(11) not null auto_increment primary key,
 	created_on DATE not null
);

CREATE TABLE Article_46_part2 (id INT(11) not null auto_increment primary key,
 	visible BIT not null, 
	content LONGTEXT not null
);

INSERT INTO Article_46_part1 (created_on) SELECT (created_on) from Article_46;
INSERT INTO Article_46_part2 (visible, content) SELECT (visible, content)  from Article_46;