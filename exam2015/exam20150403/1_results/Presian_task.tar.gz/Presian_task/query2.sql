insert into Article_52 (name)
values ("asd");
insert into Article_52 (name)
values ("pesho");


insert into Tag(name, article_id)
values ("#asd", 1);
insert into Tag(name, article_id)
values ("#fffff", 1);

	
insert into User(gender, tag_id)
values ("f", 1);
insert into User(gender, tag_id)
values ("m", 2);

insert into Category(priority, user_id)
values (1, 1);
insert into Category(priority, user_id)
values (2, 1);

