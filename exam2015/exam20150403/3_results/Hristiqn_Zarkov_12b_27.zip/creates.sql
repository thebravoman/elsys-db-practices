Drop database test1;
CREATE database test1 ;
use test1;
Create table Category(id INT NOT NULL AUTO_INCREMENT Primary key ,date_created_on date, created_by text);
Create table Article_27(id INT NOT NULL AUTO_INCREMENT Primary key, category_id int ,url text,published_on date,created_on date,FOREIGN KEY (category_id) REFERENCES Category(id));
Create table User(id INT NOT NULL AUTO_INCREMENT Primary key,article_27_id int, description varchar(255), gender varchar(6),age int,FOREIGN KEY (article_27_id) REFERENCES Article_27(id));
Create table Tag(id INT NOT NULL AUTO_INCREMENT Primary key,name varchar(50),second_priority float);
Create table Tag_user(user_id int not null, tag_id int not null,FOREIGN KEY (user_id) REFERENCES User(id),FOREIGN KEY (tag_id) REFERENCES Tag(id));

