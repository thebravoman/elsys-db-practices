Drop database test1;
CREATE database test1 ;
use test1;
Create table Category(id INT NOT NULL AUTO_INCREMENT Primary key ,date_created_on date, created_by text);
Create table Article_27(id INT NOT NULL AUTO_INCREMENT Primary key, category_id int ,url text,published_on date,created_on date,FOREIGN KEY (category_id) REFERENCES Category(id));
Create table User(id INT NOT NULL AUTO_INCREMENT Primary key,article_27_id int, description varchar(255), gender varchar(6),age int,FOREIGN KEY (article_27_id) REFERENCES Article_27(id));
Create table Tag(id INT NOT NULL AUTO_INCREMENT Primary key,name varchar(50),second_priority float);
Create table Tag_user(user_id int not null, tag_id int not null,FOREIGN KEY (user_id) REFERENCES User(id),FOREIGN KEY (tag_id) REFERENCES Tag(id));

Insert Into Category(date_created_on,created_by) values('01.01.2013','xaxaaxa');
Insert Into Category(date_created_on,created_by) values('01/01/2013','xaxvfwseaaxa');

Insert Into Article_27(category_id,url,publiched_on,created_on,age) values(1,'https://xaxa.xaxa/xaxa','01/01/2013','01/01/2013',12);
Insert Into Article_27(category_id,url,publiched_on,created_on,age) values(2,'https://xaxa.xaxa/xaxafew','01/11/2013','01/11/2014',12);

Insert Into User(article_27_id,description,gender,age) values(1,'xaxa','muj !',12);
Insert Into User(article_27_id,description,gender,age) values(2,'xaxa','muj !',13);

Insert Into Tag(name,second_priority) values('xaxa',12.1);
Insert Into Tag(name,second_priority) values('haha',12.3);

Insert Into Tag_user(user_id,tag_id) values(1,2);
Insert Into Tag_user(user_id,tag_id) values(2,1);