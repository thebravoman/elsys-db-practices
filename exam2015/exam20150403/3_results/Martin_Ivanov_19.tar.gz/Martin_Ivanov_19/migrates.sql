create table Tag_part1 (
    id serial primary key,
    hash varchar(16)
);

create table Tag_part2 (
    id serial primary key,
    priority int
);

insert into Tag_part1 (hash) select hash from Tag;
insert into Tag_part2 (priority) select priority from Tag;
