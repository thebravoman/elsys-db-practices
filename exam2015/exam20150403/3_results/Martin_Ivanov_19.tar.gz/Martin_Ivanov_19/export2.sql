--
-- PostgreSQL database dump
--

SET statement_timeout = 0;
SET lock_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;

--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


SET search_path = public, pg_catalog;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: article_24; Type: TABLE; Schema: public; Owner: martin; Tablespace: 
--

CREATE TABLE article_24 (
    id integer NOT NULL,
    name character varying(50),
    content text,
    published_on date,
    tag_id integer
);


ALTER TABLE public.article_24 OWNER TO martin;

--
-- Name: article_24_id_seq; Type: SEQUENCE; Schema: public; Owner: martin
--

CREATE SEQUENCE article_24_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.article_24_id_seq OWNER TO martin;

--
-- Name: article_24_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: martin
--

ALTER SEQUENCE article_24_id_seq OWNED BY article_24.id;


--
-- Name: category; Type: TABLE; Schema: public; Owner: martin; Tablespace: 
--

CREATE TABLE category (
    id integer NOT NULL,
    created_by text,
    date_created_on date
);


ALTER TABLE public.category OWNER TO martin;

--
-- Name: category_id_seq; Type: SEQUENCE; Schema: public; Owner: martin
--

CREATE SEQUENCE category_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.category_id_seq OWNER TO martin;

--
-- Name: category_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: martin
--

ALTER SEQUENCE category_id_seq OWNED BY category.id;


--
-- Name: tag; Type: TABLE; Schema: public; Owner: martin; Tablespace: 
--

CREATE TABLE tag (
    id integer NOT NULL,
    hash character varying(16),
    priority integer
);


ALTER TABLE public.tag OWNER TO martin;

--
-- Name: tag_category; Type: TABLE; Schema: public; Owner: martin; Tablespace: 
--

CREATE TABLE tag_category (
    id integer NOT NULL,
    tag_id integer NOT NULL,
    category_id integer NOT NULL
);


ALTER TABLE public.tag_category OWNER TO martin;

--
-- Name: tag_category_id_seq; Type: SEQUENCE; Schema: public; Owner: martin
--

CREATE SEQUENCE tag_category_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.tag_category_id_seq OWNER TO martin;

--
-- Name: tag_category_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: martin
--

ALTER SEQUENCE tag_category_id_seq OWNED BY tag_category.id;


--
-- Name: tag_id_seq; Type: SEQUENCE; Schema: public; Owner: martin
--

CREATE SEQUENCE tag_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.tag_id_seq OWNER TO martin;

--
-- Name: tag_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: martin
--

ALTER SEQUENCE tag_id_seq OWNED BY tag.id;


--
-- Name: tag_part1; Type: TABLE; Schema: public; Owner: martin; Tablespace: 
--

CREATE TABLE tag_part1 (
    id integer NOT NULL,
    hash character varying(16)
);


ALTER TABLE public.tag_part1 OWNER TO martin;

--
-- Name: tag_part1_id_seq; Type: SEQUENCE; Schema: public; Owner: martin
--

CREATE SEQUENCE tag_part1_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.tag_part1_id_seq OWNER TO martin;

--
-- Name: tag_part1_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: martin
--

ALTER SEQUENCE tag_part1_id_seq OWNED BY tag_part1.id;


--
-- Name: tag_part2; Type: TABLE; Schema: public; Owner: martin; Tablespace: 
--

CREATE TABLE tag_part2 (
    id integer NOT NULL,
    priority integer
);


ALTER TABLE public.tag_part2 OWNER TO martin;

--
-- Name: tag_part2_id_seq; Type: SEQUENCE; Schema: public; Owner: martin
--

CREATE SEQUENCE tag_part2_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.tag_part2_id_seq OWNER TO martin;

--
-- Name: tag_part2_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: martin
--

ALTER SEQUENCE tag_part2_id_seq OWNED BY tag_part2.id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: martin; Tablespace: 
--

CREATE TABLE users (
    id integer NOT NULL,
    password character varying(50),
    description text,
    age integer
);


ALTER TABLE public.users OWNER TO martin;

--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: martin
--

CREATE SEQUENCE users_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.users_id_seq OWNER TO martin;

--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: martin
--

ALTER SEQUENCE users_id_seq OWNED BY users.id;


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: martin
--

ALTER TABLE ONLY article_24 ALTER COLUMN id SET DEFAULT nextval('article_24_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: martin
--

ALTER TABLE ONLY category ALTER COLUMN id SET DEFAULT nextval('category_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: martin
--

ALTER TABLE ONLY tag ALTER COLUMN id SET DEFAULT nextval('tag_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: martin
--

ALTER TABLE ONLY tag_category ALTER COLUMN id SET DEFAULT nextval('tag_category_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: martin
--

ALTER TABLE ONLY tag_part1 ALTER COLUMN id SET DEFAULT nextval('tag_part1_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: martin
--

ALTER TABLE ONLY tag_part2 ALTER COLUMN id SET DEFAULT nextval('tag_part2_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: martin
--

ALTER TABLE ONLY users ALTER COLUMN id SET DEFAULT nextval('users_id_seq'::regclass);


--
-- Data for Name: article_24; Type: TABLE DATA; Schema: public; Owner: martin
--

COPY article_24 (id, name, content, published_on, tag_id) FROM stdin;
1	haha	sudurjanie	2001-01-01	1
2	sadsaas	sads	2002-02-02	2
\.


--
-- Name: article_24_id_seq; Type: SEQUENCE SET; Schema: public; Owner: martin
--

SELECT pg_catalog.setval('article_24_id_seq', 2, true);


--
-- Data for Name: category; Type: TABLE DATA; Schema: public; Owner: martin
--

COPY category (id, created_by, date_created_on) FROM stdin;
1	martin	2003-03-03
2	tosho	2004-04-04
\.


--
-- Name: category_id_seq; Type: SEQUENCE SET; Schema: public; Owner: martin
--

SELECT pg_catalog.setval('category_id_seq', 2, true);


--
-- Data for Name: tag; Type: TABLE DATA; Schema: public; Owner: martin
--

COPY tag (id, hash, priority) FROM stdin;
1	asdsa	3
2	dsad	5
\.


--
-- Data for Name: tag_category; Type: TABLE DATA; Schema: public; Owner: martin
--

COPY tag_category (id, tag_id, category_id) FROM stdin;
1	1	1
2	2	2
\.


--
-- Name: tag_category_id_seq; Type: SEQUENCE SET; Schema: public; Owner: martin
--

SELECT pg_catalog.setval('tag_category_id_seq', 2, true);


--
-- Name: tag_id_seq; Type: SEQUENCE SET; Schema: public; Owner: martin
--

SELECT pg_catalog.setval('tag_id_seq', 2, true);


--
-- Data for Name: tag_part1; Type: TABLE DATA; Schema: public; Owner: martin
--

COPY tag_part1 (id, hash) FROM stdin;
1	asdsa
2	dsad
\.


--
-- Name: tag_part1_id_seq; Type: SEQUENCE SET; Schema: public; Owner: martin
--

SELECT pg_catalog.setval('tag_part1_id_seq', 2, true);


--
-- Data for Name: tag_part2; Type: TABLE DATA; Schema: public; Owner: martin
--

COPY tag_part2 (id, priority) FROM stdin;
1	3
2	5
\.


--
-- Name: tag_part2_id_seq; Type: SEQUENCE SET; Schema: public; Owner: martin
--

SELECT pg_catalog.setval('tag_part2_id_seq', 2, true);


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: martin
--

COPY users (id, password, description, age) FROM stdin;
1	123	asdsaas	15
2	234	asdas	18
\.


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: martin
--

SELECT pg_catalog.setval('users_id_seq', 2, true);


--
-- Name: article_24_pkey; Type: CONSTRAINT; Schema: public; Owner: martin; Tablespace: 
--

ALTER TABLE ONLY article_24
    ADD CONSTRAINT article_24_pkey PRIMARY KEY (id);


--
-- Name: category_pkey; Type: CONSTRAINT; Schema: public; Owner: martin; Tablespace: 
--

ALTER TABLE ONLY category
    ADD CONSTRAINT category_pkey PRIMARY KEY (id);


--
-- Name: tag_category_pkey; Type: CONSTRAINT; Schema: public; Owner: martin; Tablespace: 
--

ALTER TABLE ONLY tag_category
    ADD CONSTRAINT tag_category_pkey PRIMARY KEY (id);


--
-- Name: tag_part1_pkey; Type: CONSTRAINT; Schema: public; Owner: martin; Tablespace: 
--

ALTER TABLE ONLY tag_part1
    ADD CONSTRAINT tag_part1_pkey PRIMARY KEY (id);


--
-- Name: tag_part2_pkey; Type: CONSTRAINT; Schema: public; Owner: martin; Tablespace: 
--

ALTER TABLE ONLY tag_part2
    ADD CONSTRAINT tag_part2_pkey PRIMARY KEY (id);


--
-- Name: tag_pkey; Type: CONSTRAINT; Schema: public; Owner: martin; Tablespace: 
--

ALTER TABLE ONLY tag
    ADD CONSTRAINT tag_pkey PRIMARY KEY (id);


--
-- Name: users_pkey; Type: CONSTRAINT; Schema: public; Owner: martin; Tablespace: 
--

ALTER TABLE ONLY users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: public; Type: ACL; Schema: -; Owner: postgres
--

REVOKE ALL ON SCHEMA public FROM PUBLIC;
REVOKE ALL ON SCHEMA public FROM postgres;
GRANT ALL ON SCHEMA public TO postgres;
GRANT ALL ON SCHEMA public TO PUBLIC;


--
-- PostgreSQL database dump complete
--

