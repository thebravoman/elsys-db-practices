select Category.user_id as user_id, Tag.id as Tag_id from Tag left join tag_category on Tag.id=tag_category.tag_id left join Category on Category.id=tag_category.category_id;
