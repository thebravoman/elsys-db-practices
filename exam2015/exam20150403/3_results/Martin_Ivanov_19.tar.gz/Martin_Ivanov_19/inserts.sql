insert into Article_24 (name, content, published_on, tag_id) values ('haha', 'sudurjanie', '2001-01-01', 1), ('sadsaas', 'sads', '2002-02-02', 2);
insert into Category (created_by, date_created_on, user_id) values ('martin', '2003-03-03', 1), ('tosho', '2004-04-04', 2);
insert into users (password, description, age) values ('123', 'asdsaas', 15), ('234', 'asdas', 18);
insert into tag_category (tag_id, category_id) values (1, 1), (2, 2);
insert into Tag (hash, priority) values ('asdsa', 3), ('dsad', 5);

