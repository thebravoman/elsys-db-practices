create table Article_24 (
    id serial primary key,
    name varchar(50),
    content text,
    published_on date,
    tag_id int
);

create table Category (
    id serial primary key,
    created_by text,
    date_created_on date
);

create table users (
    id serial primary key,
    password varchar(50),
    description text,
    age int
);

create table tag_category (
    id serial primary key,
    tag_id int not null,
    category_id int not null
);

create table Tag (
    id serial primary key,
    hash varchar(16),
    priority int
);

alter table category add column user_id int unique;
