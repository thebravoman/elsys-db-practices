CREATE TABLE User_part1 (
	id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
	name VARCHAR(50) NOT NULL
);

CREATE TABLE User_part2 (
	id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
	gender VARCHAR(6) NOT NULL,
	age INT NOT NULL,
	tag_id INT NOT NULL
);

INSERT INTO User_part1 (id, name) SELECT id, name FROM User;
INSERT INTO User_part2 (id, gender, age, tag_id) SELECT id, gender, age, tag_id FROM User;

DROP TABLE User;