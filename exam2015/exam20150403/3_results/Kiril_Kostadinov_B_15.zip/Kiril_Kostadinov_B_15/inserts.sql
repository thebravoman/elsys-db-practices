INSERT INTO Article_21 (name, published_on, visible) VALUES ('Article 1', 2012-03-03, true), ('Article 2', 2012-04-04, true);
INSERT INTO Category (name, date_created_on, user_id) VALUES ('Category 1', 2012-03-03, 1), ('Category 2', 2012-04-04, 2);
INSERT INTO User (gender, age, name, tag_id) VALUES ('male', 21, 'Ivan', 1), ('female', 22, 'Ivanka', 2);
INSERT INTO Tag (second_priority, priority) VALUES (21.2, 3), (21.5, 8);
INSERT INTO Categories_Articles (category_id, article_id) VALUES (1, 1), (2, 2);
