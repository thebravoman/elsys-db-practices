SELECT Article_21.* 
FROM Article_21
LEFT JOIN Categories_Articles on Article_21.id = Categories_Articles.article_id
LEFT JOIN Category on Categories_Articles.category_id = Category.id
LEFT JOIN User_part1 on Category.user_id = User_part1.id
WHERE User_part1.id = 1;