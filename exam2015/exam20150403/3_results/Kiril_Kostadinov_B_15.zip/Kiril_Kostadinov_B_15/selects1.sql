SELECT Category.*
FROM Category
LEFT JOIN User on Category.user_id = User.id
LEFT JOIN Tag on User.tag_id = Tag.id
WHERE Tag.id = 1;