use mihail_kirilov

SELECT * FROM Category
JOIN User on Category.id=User.Category_id
Join Article_25_part2 on User.id=Article_25_part2.id
Join Article_25_part1 on Article_25_part2.id=Article_25_part1.id;
