use mihail_kirilov



INSERT INTO `mihail_kirilov`.`Category` (`id`, `name`, `created_by`) 
VALUES (1, "Misho1", "Me1"),(2, "Misho2", "Me2"),(3, "Misho3", "Me3");

INSERT INTO `mihail_kirilov`.`Article_25` (`id`, `password`, `content`, `url`) 
VALUES (2, "password2", "Content2", "url2"),(1, "password1", "Content1", "url1"),(3, "password3", "Content3", "url3");

INSERT INTO `mihail_kirilov`.`Tag` (`id`, `hash`, `priority`, `Article_25_id`) 
VALUES (1, "h1h1h1h1h1", 1, 1),(2, "h2h2h2h2h2", 2, 2),(3, "h3h3h3h3h3", 3, 3);

INSERT INTO `mihail_kirilov`.`User` (`id`, `name`, `income`, `twitter`, `Article_25_id`, `Category_id`) VALUES (1, "Name1", 101.1, "twitter1", 1, 1);
INSERT INTO `mihail_kirilov`.`User` (`id`, `name`, `income`, `twitter`, `Article_25_id`, `Category_id`) VALUES (2, "Name2", 202.2, "twitter2", 2, 1);
INSERT INTO `mihail_kirilov`.`User` (`id`, `name`, `income`, `twitter`, `Article_25_id`, `Category_id`) VALUES (3, "Name3", 303.3, "twitter3", 1, 2);
INSERT INTO `mihail_kirilov`.`User` (`id`, `name`, `income`, `twitter`, `Article_25_id`, `Category_id`) VALUES (4, "Name4", 404.4, "twitter4", 2, 2);


    	
    	