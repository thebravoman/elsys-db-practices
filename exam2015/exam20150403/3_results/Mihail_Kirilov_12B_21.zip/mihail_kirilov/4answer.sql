use mihail_kirilov

SELECT User.*,Tag.* FROM User
JOIN Article_25 on User.Article_25_id=Article_25.id
Join Tag on Article_25.id=Tag.Article_25_id;
