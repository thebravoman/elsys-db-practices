create table Article_25_part1 (id INT, content longtext);
	insert into Article_25_part1 (id, content) select id, content from Article_25;
		alter table Article_25 rename Article_25_part2;
		alter table Article_25_part2 drop column content;