drop database mihail_kirilov;
-- MySQL Workbench Forward Engineering-- MySQL Workbench Forward Engineering

SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='TRADITIONAL,ALLOW_INVALID_DATES';

-- -----------------------------------------------------
-- Schema mydb
-- -----------------------------------------------------
-- -----------------------------------------------------
-- Schema mihail_kirilov
-- -----------------------------------------------------

-- -----------------------------------------------------
-- Schema mihail_kirilov
-- -----------------------------------------------------
CREATE SCHEMA IF NOT EXISTS `mihail_kirilov` DEFAULT CHARACTER SET utf8 ;
USE `mihail_kirilov` ;

-- -----------------------------------------------------
-- Table `mihail_kirilov`.`Article_25`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `mihail_kirilov`.`Article_25` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `password` TEXT NULL DEFAULT NULL,
  `content` LONGTEXT NULL DEFAULT NULL,
  `url` TEXT NULL DEFAULT NULL,
  PRIMARY KEY (`id`))
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8;


-- -----------------------------------------------------
-- Table `mihail_kirilov`.`Category`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `mihail_kirilov`.`Category` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `name` VARCHAR(50) NULL DEFAULT NULL,
  `created_by` TEXT NULL DEFAULT NULL,
  PRIMARY KEY (`id`))
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8;


-- -----------------------------------------------------
-- Table `mihail_kirilov`.`Tag`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `mihail_kirilov`.`Tag` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `hash` VARCHAR(16) NULL DEFAULT NULL,
  `priority` INT(11) NULL DEFAULT NULL,
  `Article_25_id` INT(11) NOT NULL,
  PRIMARY KEY (`id`, `Article_25_id`),
  INDEX `fk_Tag_Article_25_idx` (`Article_25_id` ASC),
  CONSTRAINT `fk_Tag_Article_25`
    FOREIGN KEY (`Article_25_id`)
    REFERENCES `mihail_kirilov`.`Article_25` (`id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8;


-- -----------------------------------------------------
-- Table `mihail_kirilov`.`User`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `mihail_kirilov`.`User` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `name` VARCHAR(50) NULL DEFAULT NULL,
  `income` FLOAT NULL DEFAULT NULL,
  `twitter` VARCHAR(50) NULL DEFAULT NULL,
  `Article_25_id` INT(11) NOT NULL,
  `Category_id` INT(11) NOT NULL,
  PRIMARY KEY (`id`, `Article_25_id`, `Category_id`),
  INDEX `fk_User_Article_251_idx` (`Article_25_id` ASC),
  INDEX `fk_User_Category1_idx` (`Category_id` ASC),
  CONSTRAINT `fk_User_Article_251`
    FOREIGN KEY (`Article_25_id`)
    REFERENCES `mihail_kirilov`.`Article_25` (`id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_User_Category1`
    FOREIGN KEY (`Category_id`)
    REFERENCES `mihail_kirilov`.`Category` (`id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8;


SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;
