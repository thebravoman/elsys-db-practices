create database mihail_kirilov;
	use mihail_kirilov


Create table Article_25(
	id int primary key not null auto_increment,
	 password text,
	 content longtext,
	 url text);

Create table Category(
	id int primary key not null auto_increment,
	 name varchar(50),
	 created_by text);

Create table User(
	id int primary key not null auto_increment,
	 name varchar(50),
	 income float,
	 twitter varchar(50));

Create table Tag(
	id int primary key not null auto_increment,
	 hash varchar(16),
	 priority int);
